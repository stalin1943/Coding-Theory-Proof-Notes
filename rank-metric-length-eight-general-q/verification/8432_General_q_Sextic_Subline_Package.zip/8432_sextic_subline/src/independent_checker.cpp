// Independent certificate replay: coefficient-based field multiplication,
// right-pivot elimination, direct evaluation of determinant polynomials.
// Does not import or include either generator. Input integer format is
// documented in README and produced from the human-readable JSONL records.
#include <algorithm>
#include <array>
#include <cassert>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <string>
#include <vector>
using namespace std;
struct Scanner{
 ifstream in; explicit Scanner(const string&p):in(p,ios::binary){if(!in)throw runtime_error("cannot open integer certificate");}
 int get(){unsigned char b[4];in.read(reinterpret_cast<char*>(b),4);if(!in)throw runtime_error("truncated certificate");uint32_t a=uint32_t(b[0])|(uint32_t(b[1])<<8)|(uint32_t(b[2])<<16)|(uint32_t(b[3])<<24);return static_cast<int32_t>(a);}
};
struct Finite{
 int q,Q,H;vector<int>pol,inverse;int addK[8][8]{},mulK[8][8]{},negK[8]{},invK[8]{};vector<array<int,6>>digits;vector<int>tripadd;vector<uint16_t>lower,upper;
 Finite(int q0):q(q0){assert(q==3||q==4||q==5);pol=q==4?vector<int>{2,3,2,3,3,1,1}:vector<int>{2,1,0,0,0,0,1};H=q*q*q;Q=H*H;digits.resize(Q);inverse.resize(Q);
  for(int a=0;a<q;a++)for(int b=0;b<q;b++){addK[a][b]=q==4?(a^b):(a+b)%q;int z=0;if(q==4){for(int i=0;i<2;i++)if((a>>i)&1)for(int j=0;j<2;j++)if((b>>j)&1)z^=1<<(i+j);if(z&4)z^=7;}else z=a*b%q;mulK[a][b]=z;}
  for(int a=0;a<q;a++)for(int b=0;b<q;b++){if(addK[a][b]==0)negK[a]=b;if(mulK[a][b]==1)invK[a]=b;}
  for(int x=0;x<Q;x++){int z=x;for(int i=0;i<6;i++){digits[x][i]=z%q;z/=q;}}
  tripadd.resize(H*H);for(int x=0;x<H;x++)for(int y=0;y<H;y++){int m=1,r=0;for(int j=0;j<3;j++,m*=q)r+=m*addK[digits[x][j]][digits[y][j]];tripadd[x*H+y]=r;}
  lower.resize(Q*H);upper.resize(Q*H);
  for(int a=0;a<Q;a++){int pw[6];pw[0]=a;for(int j=1;j<6;j++)pw[j]=shift(pw[j-1]);int base[6][8]{};for(int j=0;j<6;j++)for(int c=0;c<q;c++)base[j][c]=scale(c,pw[j]);
   for(int t=1;t<H;t++){int j=0;while(!digits[t][j])j++;int c=digits[t][j];int p=1;for(int k=0;k<j;k++)p*=q;int rest=t-c*p;lower[a*H+t]=add(lower[a*H+rest],base[j][c]);upper[a*H+t]=add(upper[a*H+rest],base[j+3][c]);}}
  for(int x=1;x<Q;x++){inverse[x]=power(x,Q-2);assert(mul(x,inverse[x])==1);} // establishes all nonzero residues are units
 }
 int pack(const array<int,6>&d)const{int x=0,p=1;for(int a:d){x+=a*p;p*=q;}return x;}
 int add(int x,int y)const{return tripadd[(x%H)*H+y%H]+H*tripadd[(x/H)*H+y/H];}
 int neg(int x)const{auto d=digits[x];for(int&a:d)a=negK[a];return pack(d);}
 int sub(int x,int y)const{return add(x,neg(y));}
 int scale(int c,int x)const{auto d=digits[x];for(int&a:d)a=mulK[c][a];return pack(d);}
 int shift(int a)const{auto d=digits[a];int c=d[5];array<int,6>r{};for(int j=5;j>=1;j--)r[j]=d[j-1];for(int j=0;j<6;j++)r[j]=addK[r[j]][negK[mulK[c][pol[j]]]];return pack(r);}
 int mul(int x,int y)const{return add(lower[x*H+y%H],upper[x*H+y/H]);}
 int power(int x,int n)const{int z=1;while(n){if(n&1)z=mul(z,x);n>>=1;if(n)x=mul(x,x);}return z;}
 int plane(int x)const{auto d=digits[x];d[0]=0;int k=1;while(k<6&&!d[k])k++;assert(k<6);return scale(invK[d[k]],pack(d));}
 int degree(int x)const{int z=x;for(int j=1;j<=6;j++){z=power(z,q);if(z==x)return j;}throw runtime_error("bad Frobenius degree");}
};
using Vector=vector<int>;using Point=array<int,3>;
struct Matrix{
 const Finite*F;int n;vector<Vector>R;vector<int>P;
 Matrix(const Finite&f,int width):F(&f),n(width){}
 bool insert(Vector x){assert((int)x.size()==n);for(size_t i=0;i<R.size();i++){int a=x[P[i]];if(a)for(int j=0;j<n;j++)x[j]=F->addK[x[j]][F->negK[F->mulK[a][R[i][j]]]];}
  int p=n-1;while(p>=0&&!x[p])p--;if(p<0)return false;int inv=F->invK[x[p]];for(int&a:x)a=F->mulK[inv][a];for(auto&r:R){int a=r[p];if(a)for(int j=0;j<n;j++)r[j]=F->addK[r[j]][F->negK[F->mulK[a][x[j]]]];}
  size_t pos=0;while(pos<P.size()&&P[pos]>p)pos++;P.insert(P.begin()+pos,p);R.insert(R.begin()+pos,x);return true;}
 int rank()const{return R.size();}
 vector<Vector> kernel()const{vector<Vector>N;for(int j=0;j<n;j++)if(find(P.begin(),P.end(),j)==P.end()){Vector x(n);x[j]=1;for(size_t i=0;i<R.size();i++)x[P[i]]=F->negK[R[i][j]];N.push_back(x);}return N;}
};
Vector flat(const Finite&F,Point p){Vector z;for(int a:p)z.insert(z.end(),F.digits[a].begin(),F.digits[a].end());return z;}
int dot(const Finite&F,Point a,Point b){int z=0;for(int i=0;i<3;i++)z=F.add(z,F.mul(a[i],b[i]));return z;}
Point cross(const Finite&F,Point a,Point b){return {F.sub(F.mul(a[1],b[2]),F.mul(a[2],b[1])),F.sub(F.mul(a[2],b[0]),F.mul(a[0],b[2])),F.sub(F.mul(a[0],b[1]),F.mul(a[1],b[0]))};}
array<int,4> coefficientIndex(int q,int index){assert(index>=0);for(int p=0;p<4;p++){int n=1;for(int j=p+1;j<4;j++)n*=q;if(index<n){array<int,4>r{};r[p]=1;for(int j=3;j>p;j--){r[j]=index%q;index/=q;}return r;}index-=n;}throw runtime_error("invalid X index");}
Point Xpoint(const Finite&F,const vector<Point>&X,int id){auto c=coefficientIndex(F.q,id);Point p{};for(int j=0;j<3;j++)for(int k=0;k<4;k++)p[j]=F.add(p[j],F.scale(c[k],X[k][j]));return p;}
Point normal(const Finite&F,const vector<Point>&X,int i,int j){assert(i!=j);Point p=cross(F,Xpoint(F,X,i),Xpoint(F,X,j));assert(p[2]);int inv=F.inverse[p[2]];for(int&a:p)a=F.mul(inv,a);return p;}
vector<int> quotientBasis(const Finite&F,const vector<int>&R){Matrix M(F,6);for(int r:R)M.insert(Vector(F.digits[r].begin(),F.digits[r].end()));vector<int>b;int pow=1;for(int i=0;i<6;i++,pow*=F.q)if(M.insert(Vector(F.digits[pow].begin(),F.digits[pow].end())))b.push_back(pow);return b;}
vector<int> scalarTypes(const Finite&F){set<int>types;for(int l=F.Q-1;l>=F.q;l--)if(F.plane(l)==l){int best=F.Q; // use projective denominators instead of all ordered numerator-denominator pairs
  vector<int>den={1};for(int a=0;a<F.q;a++)den.push_back(F.add(a,l));for(int y:den){int z=F.inverse[y];if(z<F.q)z=F.mul(z,l);assert(z>=F.q);best=min(best,F.plane(z));}types.insert(best);}
 assert(types.size()==size_t(F.q*F.q*F.q+F.q+1));return vector<int>(types.begin(),types.end());}
int quotientEval(const Finite&F,const Vector&L,int z){int v=0;for(int i=0;i<6;i++)v=F.addK[v][F.mulK[L[i]][F.digits[z][i]]];return v;}
Vector determinantRow(const Finite&F,Point h,const vector<Point>&S,int eta,const vector<int>&basis){Matrix im(F,6);for(auto s:S){int a=dot(F,h,s);im.insert(Vector(F.digits[a].begin(),F.digits[a].end()));}assert(im.rank()==4);auto n=im.kernel();assert(n.size()==2);auto det=[&](int u,int v){int a=F.add(F.mul(eta,h[0]),u),b=F.add(F.mul(eta,h[1]),v);int x=F.mulK[quotientEval(F,n[0],a)][quotientEval(F,n[1],b)],y=F.mulK[quotientEval(F,n[1],a)][quotientEval(F,n[0],b)];return F.addK[x][F.negK[y]];};
 int c=det(0,0);Vector row(15);row[0]=c;for(int i=0;i<4;i++){row[1+i]=F.addK[det(basis[i],0)][F.negK[c]];row[5+i]=F.addK[det(0,basis[i])][F.negK[c]];}
 int k=9;for(int i=0;i<4;i++)for(int j=i+1;j<4;j++){int a=det(basis[i],basis[j]);for(int z:{c,row[1+i],row[5+j]})a=F.addK[a][F.negK[z]];row[k++]=a;int b=det(basis[j],basis[i]);for(int z:{c,row[1+j],row[5+i]})b=F.addK[b][F.negK[z]];assert(a==F.negK[b]);}
 for(int i=0;i<4;i++){int a=det(basis[i],basis[i]);for(int z:{c,row[1+i],row[5+i]})a=F.addK[a][F.negK[z]];assert(a==0);}return row;}
struct Affine{int points=0;vector<Vector>compatible;bool symbolic=false;};
Affine solveAffine(const Finite&F,const vector<Vector>&equations){vector<Vector>A;for(auto r:equations){Vector v(r.begin()+1,r.end());v.push_back(F.negK[r[0]]);A.push_back(v);}int used=0;vector<int>piv;
 for(int j=13;j>=0;j--){int found=-1;for(int i=used;i<(int)A.size();i++)if(A[i][j]){found=i;break;}if(found<0)continue;swap(A[used],A[found]);int inv=F.invK[A[used][j]];for(int&x:A[used])x=F.mulK[inv][x];for(int i=0;i<(int)A.size();i++)if(i!=used&&A[i][j]){int x=A[i][j];for(int k=0;k<15;k++)A[i][k]=F.addK[A[i][k]][F.negK[F.mulK[x][A[used][k]]]];}piv.push_back(j);used++;}
 for(int i=used;i<(int)A.size();i++){assert(all_of(A[i].begin(),A[i].begin()+14,[](int a){return a==0;}));if(A[i][14]){Affine out;out.symbolic=true;return out;}}
 vector<int>free;for(int j=0;j<14;j++)if(find(piv.begin(),piv.end(),j)==piv.end())free.push_back(j);assert(free.size()<=2);int total=1;for(size_t j=0;j<free.size();j++)total*=F.q;Affine out;out.points=total;
 {int f=free.size();vector<Vector>lin(14,Vector(f+1));for(int j=0;j<f;j++)lin[free[j]][j+1]=1;for(int i=0;i<used;i++){lin[piv[i]][0]=A[i][14];for(int j=0;j<f;j++)lin[piv[i]][j+1]=F.negK[A[i][free[j]]];}
  int nc=1+f+f*(f+1)/2;Matrix poly(F,nc);int k=8;
  auto product=[&](const Vector&a,const Vector&b){Vector r(nc);r[0]=F.mulK[a[0]][b[0]];for(int i=1;i<=f;i++)r[i]=F.addK[F.mulK[a[i]][b[0]]][F.mulK[a[0]][b[i]]];int p=1+f;for(int i=1;i<=f;i++)for(int j=i;j<=f;j++){r[p]=F.mulK[a[i]][b[j]];if(i!=j)r[p]=F.addK[r[p]][F.mulK[a[j]][b[i]]];p++;}return r;};
  for(int i=0;i<4;i++)for(int j=i+1;j<4;j++){Vector a=product(lin[i],lin[4+j]),b=product(lin[j],lin[4+i]),r(nc);for(int t=0;t<nc;t++)r[t]=F.addK[F.negK[a[t]]][b[t]];for(int t=0;t<=f;t++)r[t]=F.addK[r[t]][lin[k][t]];k++;poly.insert(r);}Vector one(nc);one[0]=1;out.symbolic=!poly.insert(one);
 }
 for(int n=0;n<total;n++){Vector x(14);int v=n;for(int f:free){x[f]=v%F.q;v/=F.q;}for(int i=0;i<used;i++){int a=A[i][14];for(int f:free)a=F.addK[a][F.negK[F.mulK[A[i][f]][x[f]]]];x[piv[i]]=a;}bool valid=true;int k=8;for(int i=0;i<4;i++)for(int j=i+1;j<4;j++){int a=F.mulK[x[i]][x[j+4]],b=F.mulK[x[j]][x[i+4]];if(x[k++]!=F.addK[a][F.negK[b]])valid=false;}if(valid)out.compatible.push_back(x);}return out;}
int fieldValue(const Finite&F,const Vector&m,const vector<int>&basis,int shift){int a=0;for(int i=0;i<4;i++)a=F.add(a,F.scale(m[i+shift],basis[i]));return a;}
int rankImage(const Finite&F,Point h,const vector<Point>&W){Matrix A(F,6);for(auto w:W){int a=dot(F,h,w);A.insert(Vector(F.digits[a].begin(),F.digits[a].end()));}return A.rank();}
int pointWeight(const Finite&F,Point p,const vector<Point>&W){assert(p!=Point{});Matrix A(F,18);for(auto w:W)A.insert(flat(F,w));assert(A.rank()==10);int pow=1;for(int i=0;i<6;i++,pow*=F.q){Point x=p;for(int&a:x)a=F.mul(a,pow);A.insert(flat(F,x));}return 16-A.rank();}
int main(int argc,char**argv){if(argc!=3)throw runtime_error("usage checker integer_certificate output.json");auto start=chrono::steady_clock::now();Scanner in(argv[1]);assert(in.get()==843213);int q=in.get(),eps=in.get(),nrecord=in.get();assert(eps==0||eps==1);Finite F(q);auto types=scalarTypes(F);vector<int>sextic;for(int l:types)if(F.degree(l)==6)sextic.push_back(l);assert(sextic.size()==size_t(q*q*q+q-1));set<uint64_t>remaining;
 auto key=[&](int l,int b,int g){return uint64_t(l)+uint64_t(F.Q)*(uint64_t(b)+uint64_t(F.Q)*(g+1));};
 for(int l:sextic){if(eps==0){for(int b:types)if(b!=l)for(int g=-1;g<q;g++)remaining.insert(key(l,b,g));}else{auto CB=quotientBasis(F,{1,l,F.inverse[l]});assert(CB.size()==3);for(int i=0;i<q*q*q;i++){int z=i,c=0;for(int j=0;j<3;j++){c=F.add(c,F.scale(z%q,CB[j]));z/=q;}for(int g=-1;g<q;g++)remaining.insert(key(l,c,g));}}}
 assert(remaining.size()==size_t(nrecord));long long equationCount=0,affineTotal=0,compatibleTotal=0,rankTests=0,pointTests=0,dualTests=0,zeroCore=0,rankKilled=0,pointKilled=0,dualKilled=0,symbolicCells=0;map<int,int>rankHist;
 for(int rec=0;rec<nrecord;rec++){
 int l=in.get(),b=in.get(),g=in.get(),kind=in.get();assert(l>=0&&l<F.Q&&b>=0&&b<F.Q&&g>=-1&&g<q);assert(remaining.erase(key(l,b,g))==1);vector<Point>X;if(eps==0)X={{1,0,0},{0,1,0},{l,0,1},{0,l,b}};else X={{0,0,1},{l,0,0},{0,1,0},{1,F.neg(l),b}};vector<Point>S=X;for(auto x:X){for(int&a:x)a=F.mul(a,l);S.push_back(x);}Matrix base(F,18);for(auto x:S)base.insert(flat(F,x));assert(base.rank()==8);
 if(kind==0){assert(eps==1&&b==0);Matrix M=base;int pow=1;for(int i=0;i<6;i++,pow*=q)M.insert(flat(F,{pow,0,0}));assert(14-M.rank()>=3);zeroCore++;continue;}
 if(kind==1){int ia=in.get(),ib=in.get();assert(ia!=ib);Point a=Xpoint(F,X,ia),d=Xpoint(F,X,ib);assert(cross(F,a,d)==Point{});zeroCore++;continue;}
 assert(kind==2);int eta=g==-1?F.power(l,3):F.inverse[F.sub(l,g)];vector<int>basis=quotientBasis(F,{1,eps==0?b:l});assert(basis.size()==4);
 int np=in.get();vector<Vector>rows;Matrix rowspace(F,15);for(int j=0;j<np;j++){int a=in.get(),d=in.get();Point h=normal(F,X,a,d);Vector row=determinantRow(F,h,S,eta,basis);assert(rowspace.insert(row));rows.push_back(row);equationCount++;}
 int nt=in.get();vector<Point>norms;for(int i=0;i<nt;i++){int a=in.get(),d=in.get();norms.push_back(normal(F,X,a,d));}
 vector<Point>points;int ns=in.get();for(int i=0;i<ns;i++){Point p{in.get(),in.get(),in.get()};assert(eps==1);points.push_back({F.scale(p[0],l),p[1],p[2]});}
 int ng=in.get();for(int i=0;i<ng;i++)points.push_back({in.get(),in.get(),in.get()});int nd=in.get();vector<array<Point,2>>dual;for(int i=0;i<nd;i++){Point p{in.get(),in.get(),in.get()},t{in.get(),in.get(),in.get()};assert(cross(F,p,t)!=Point{});dual.push_back({p,t});}
 int savedRank=in.get(),savedAffine=in.get(),savedCompatible=in.get();assert(savedRank==rowspace.rank());auto m=solveAffine(F,rows);symbolicCells+=m.symbolic;assert(savedAffine==m.points&&savedCompatible==(int)m.compatible.size());affineTotal+=m.points;compatibleTotal+=m.compatible.size();rankHist[rowspace.rank()]++;
 for(auto v:m.compatible){int u=fieldValue(F,v,basis,0),w=fieldValue(F,v,basis,4);vector<Point>W=S;W.push_back({eta,0,u});W.push_back({0,eta,w});Matrix MB(F,18);for(auto p:W)MB.insert(flat(F,p));assert(MB.rank()==10);bool killed=false;
  for(auto h:norms){rankTests++;if(rankImage(F,h,W)!=5){killed=true;rankKilled++;break;}}
  if(!killed)for(auto p:points){pointTests++;if(pointWeight(F,p,W)>2){killed=true;pointKilled++;break;}}
  if(!killed)for(auto pair:dual){dualTests++;if(pointWeight(F,pair[0],W)>=2&&pointWeight(F,pair[1],W)>=2&&rankImage(F,cross(F,pair[0],pair[1]),W)==6){killed=true;dualKilled++;break;}}
  assert(killed);
 }
 }
 assert(remaining.empty());int extra;in.in.read(reinterpret_cast<char*>(&extra),4);assert(in.in.gcount()==0);
 ofstream out(argv[2]);out<<"{\"q\":"<<q<<",\"epsilon\":"<<eps<<",\"complete_cells\":"<<nrecord<<",\"sextic_types\":"<<sextic.size()<<",\"scalar_types\":"<<types.size()<<",\"selected_secant_equations\":"<<equationCount<<",\"final_affine_points\":"<<affineTotal<<",\"compatible_moments_before_rank_tests\":"<<compatibleTotal<<",\"rank_tests_performed\":"<<rankTests<<",\"point_tests_performed\":"<<pointTests<<",\"dual_pair_tests_performed\":"<<dualTests<<",\"compatible_moments_killed_by_rank\":"<<rankKilled<<",\"compatible_moments_killed_by_point\":"<<pointKilled<<",\"compatible_moments_killed_by_dual_pair\":"<<dualKilled<<",\"core_point_exclusions\":"<<zeroCore<<",\"symbolic_degree_two_contradictions\":"<<symbolicCells<<",\"all_cells_excluded\":true,\"linear_rank_histogram\":{";bool first=true;for(auto [r,n]:rankHist){if(!first)out<<",";first=false;out<<"\""<<r<<"\":"<<n;}out<<"},\"seconds\":"<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"}\n";
 cerr<<"checked q="<<q<<" eps="<<eps<<" cells="<<nrecord<<" equations="<<equationCount<<" seconds="<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"\n";
}
