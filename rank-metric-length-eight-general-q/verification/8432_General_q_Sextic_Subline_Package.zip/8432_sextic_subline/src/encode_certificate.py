"""Strict JSONL to signed little-endian integer stream for the independent checker.
The conversion has no mathematical responsibilities; all dimensions, equations,
parameter coverage and exclusions are recomputed by independent_checker.cpp.
"""
import argparse,json,struct
from pathlib import Path

def encode(source:Path,target:Path,q:int,epsilon:int)->dict:
    count=(q**3+q-1)*(q+1)*((q**3+q) if epsilon==0 else q**3)
    stats={'records':0,'quadratic_records':0,'secant_equations':0,'rank_tests_saved':0,'point_tests_saved':0,'global_point_tests_saved':0,'dual_pair_tests_saved':0}
    with source.open() as src,target.open('wb') as out:
        def emit(a):
            assert all(type(x)is int and -(1<<31)<=x<(1<<31) for x in a)
            out.write(struct.pack('<'+'i'*len(a),*a))
        emit([843213,q,epsilon,count])
        for line in src:
            r=json.loads(line);stats['records']+=1
            assert r.get('closed',r['kind']=='point') is True
            l=r['lambda'];b=r['mu'] if epsilon==0 else r['c'];g=r['g'];kind={'zero_c':0,'point':1,'quadratic':2}[r['kind']]
            assert 0<=l<q**6 and 0<=b<q**6 and -1<=g<q
            emit([l,b,g,kind])
            if kind==0:continue
            if kind==1:assert len(r['pair'])==2;emit(r['pair']);continue
            stats['quadratic_records']+=1
            for key,sz,stat in [('pairs',2,'secant_equations'),('rank_tests',2,'rank_tests_saved'),('point_tests',3,'point_tests_saved'),('global_point_tests',3,'global_point_tests_saved')]:
                rows=r.get(key,[]);assert all(len(x)==sz for x in rows);emit([len(rows)]);emit([a for row in rows for a in row]);stats[stat]+=len(rows)
            rows=r.get('dual_pair_tests',[]);assert all(len(x)==2 and all(len(p)==3 for p in x) for x in rows);emit([len(rows)]);emit([a for x in rows for p in x for a in p]);stats['dual_pair_tests_saved']+=len(rows)
            compat=r['remaining_moments'] if epsilon==0 else r['actual_moments']
            emit([r['linear_rank'],r['affine_points'],compat])
    assert stats['records']==count
    return stats
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('source',type=Path);p.add_argument('target',type=Path);p.add_argument('--q',type=int,required=True);p.add_argument('--epsilon',type=int,required=True);a=p.parse_args();print(json.dumps(encode(a.source,a.target,a.q,a.epsilon)))
