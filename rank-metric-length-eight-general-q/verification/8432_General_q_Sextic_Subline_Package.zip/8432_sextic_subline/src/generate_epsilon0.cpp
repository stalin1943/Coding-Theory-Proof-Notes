// Exact fixed-branch enumeration: sextic isolated subline, epsilon=0.
// Canonical form proof is supplied separately. This is not a full code search.
#include <algorithm>
#include <array>
#include <cassert>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <numeric>
#include <random>
#include <set>
#include <sstream>
#include <string>
#include <vector>
using namespace std;
struct Field{
 int q,Q;vector<int>pol,lg,ex,iv;vector<array<int,6>>d;int plus[8][8]{},times[8][8]{},neg[8]{},ki[8]{};
 Field(int base,vector<int>p):q(base),pol(p){Q=1;for(int i=0;i<6;i++)Q*=q;d.resize(Q);for(int a=0;a<q;a++)for(int b=0;b<q;b++){plus[a][b]=q==4?(a^b):(a+b)%q;int c=0;if(q==4){for(int j=0;j<2;j++)if((b>>j)&1)c^=a<<j;if(c&4)c^=7;}else c=a*b%q;times[a][b]=c;}for(int a=0;a<q;a++)for(int b=0;b<q;b++){if(plus[a][b]==0)neg[a]=b;if(times[a][b]==1)ki[a]=b;}for(int a=0;a<Q;a++){int x=a;for(int i=0;i<6;i++){d[a][i]=x%q;x/=q;}}lg.assign(Q,-1);ex.resize(2*(Q-1));iv.resize(Q);int primitive=0;vector<int>fac;int n=Q-1;for(int p0=2;p0*p0<=n;p0++)if(n%p0==0){fac.push_back(p0);while(n%p0==0)n/=p0;}if(n>1)fac.push_back(n);for(int a=2;a<Q;a++){bool ok=true;for(int f:fac)if(rawpow(a,(Q-1)/f)==1){ok=false;break;}if(ok){primitive=a;break;}}assert(primitive);int x=1;for(int i=0;i<Q-1;i++){assert(lg[x]<0&&x);lg[x]=i;ex[i]=ex[i+Q-1]=x;x=raw(x,primitive);}assert(x==1);for(int a=1;a<Q;a++){iv[a]=ex[(Q-1-lg[a])%(Q-1)];assert(raw(a,iv[a])==1);}}
 int pack(const array<int,6>&a)const{int r=0,m=1;for(int x:a){r+=m*x;m*=q;}return r;}
 int add(int a,int b)const{array<int,6>c;for(int i=0;i<6;i++)c[i]=plus[d[a][i]][d[b][i]];return pack(c);}
 int nval(int a)const{array<int,6>c;for(int i=0;i<6;i++)c[i]=neg[d[a][i]];return pack(c);}
 int sub(int a,int b)const{return add(a,nval(b));}
 int scale(int c,int a)const{array<int,6>x;for(int i=0;i<6;i++)x[i]=times[c][d[a][i]];return pack(x);}
 int raw(int a,int b)const{int c[11]={};for(int i=0;i<6;i++)for(int j=0;j<6;j++)c[i+j]=plus[c[i+j]][times[d[a][i]][d[b][j]]];for(int i=10;i>=6;i--){int z=c[i];for(int j=0;j<6;j++)c[i-6+j]=plus[c[i-6+j]][neg[times[z][pol[j]]]];}array<int,6>o;copy(c,c+6,o.begin());return pack(o);}
 int rawpow(int a,int n)const{int z=1;while(n){if(n&1)z=raw(z,a);a=raw(a,a);n>>=1;}return z;}
 int mul(int a,int b)const{return a&&b?ex[lg[a]+lg[b]]:0;}
 int power(int a,int n)const{if(n==0)return 1;return a?ex[(int)((long long)lg[a]*n%(Q-1))]:0;}
 int plane(int a)const{array<int,6>c=d[a];c[0]=0;int p=1;while(p<6&&!c[p])p++;assert(p<6);int v=ki[c[p]];for(int i=1;i<6;i++)c[i]=times[v][c[i]];return pack(c);}
 int degree(int x)const{for(int e: {1,2,3,6}){int n=1;for(int j=0;j<e;j++)n*=q;if(power(x,n)==x)return e;}abort();}
};
struct Space{
 const Field*F;int n;vector<vector<int>>rows;vector<int>piv;
 Space(const Field&f,int nn):F(&f),n(nn){}
 bool put(vector<int>v){for(size_t i=0;i<rows.size();i++){int a=v[piv[i]];if(a)for(int j=0;j<n;j++)v[j]=F->plus[v[j]][F->neg[F->times[a][rows[i][j]]]];}int p=0;while(p<n&&!v[p])p++;if(p==n)return false;int inv=F->ki[v[p]];for(int&x:v)x=F->times[inv][x];for(auto&r:rows){int a=r[p];if(a)for(int j=0;j<n;j++)r[j]=F->plus[r[j]][F->neg[F->times[a][v[j]]]];}auto it=lower_bound(piv.begin(),piv.end(),p);int at=it-piv.begin();piv.insert(it,p);rows.insert(rows.begin()+at,v);return true;}
 vector<vector<int>> null()const{vector<vector<int>>out;for(int j=0;j<n;j++)if(!binary_search(piv.begin(),piv.end(),j)){vector<int>v(n);v[j]=1;for(size_t k=0;k<rows.size();k++)v[piv[k]]=F->neg[rows[k][j]];out.push_back(v);}return out;}
 int rank()const{return rows.size();}
};
using Pt=array<int,3>;
int dot(const Field&F,const Pt&a,const Pt&b){int r=0;for(int i=0;i<3;i++)r=F.add(r,F.mul(a[i],b[i]));return r;}
Pt cross(const Field&F,const Pt&a,const Pt&b){return {F.sub(F.mul(a[1],b[2]),F.mul(a[2],b[1])),F.sub(F.mul(a[2],b[0]),F.mul(a[0],b[2])),F.sub(F.mul(a[0],b[1]),F.mul(a[1],b[0]))};}
vector<array<int,4>> projective4(int q){vector<array<int,4>>out;for(int p=0;p<4;p++){int n=1;for(int j=p+1;j<4;j++)n*=q;for(int v=0;v<n;v++){array<int,4>c{};c[p]=1;int z=v;for(int j=3;j>p;j--){c[j]=z%q;z/=q;}out.push_back(c);}}return out;}
vector<int> types(const Field&F){set<int>ts;for(int l=F.q;l<F.Q;l++)if(F.plane(l)==l){int best=F.Q;vector<int>B;for(int a=0;a<F.q;a++)for(int b=0;b<F.q;b++)B.push_back(F.add(a,F.scale(b,l)));for(int y:B)if(y)for(int x:B){int v=F.mul(x,F.iv[y]);if(v>=F.q)best=min(best,F.plane(v));}ts.insert(best);}assert(ts.size()==(size_t)(F.q*F.q*F.q+F.q+1));return vector<int>(ts.begin(),ts.end());}
struct Eq{int ia,ib;vector<int>L0,L1;Pt h;};
vector<int> coefficient(const Field&F,const Eq&E,int eta,const vector<int>&basis){auto ev=[&](const vector<int>&L,int x){int z=0;for(int i=0;i<6;i++)z=F.plus[z][F.times[L[i]][F.d[x][i]]];return z;};array<int,2>c{ev(E.L0,F.mul(eta,E.h[0])),ev(E.L1,F.mul(eta,E.h[0]))},d{ev(E.L0,F.mul(eta,E.h[1])),ev(E.L1,F.mul(eta,E.h[1]))};vector<array<int,2>>cols;for(int x:basis)cols.push_back({ev(E.L0,x),ev(E.L1,x)});auto det=[&](array<int,2>a,array<int,2>b){return F.plus[F.times[a[0]][b[1]]][F.neg[F.times[a[1]][b[0]]]];};vector<int>r={det(c,d)};for(auto x:cols)r.push_back(det(x,d));for(auto x:cols)r.push_back(det(c,x));for(int i=0;i<4;i++)for(int j=i+1;j<4;j++)r.push_back(det(cols[i],cols[j]));assert(r.size()==15);return r;}
struct Feas{bool tested=false;int total=0,solutions=0,free=0;};
Feas feasibility(const Field&F,const Space&A){Feas out;Space lin(F,15);for(auto r:A.rows){vector<int>v(r.begin()+1,r.end());v.push_back(F.neg[r[0]]);lin.put(v);}if(binary_search(lin.piv.begin(),lin.piv.end(),14)){out.tested=true;return out;}vector<int>free;for(int j=0;j<14;j++)if(!binary_search(lin.piv.begin(),lin.piv.end(),j))free.push_back(j);out.free=free.size();if(free.size()>2)return out;out.tested=true;int N=1;for(size_t i=0;i<free.size();i++)N*=F.q;out.total=N;for(int n=0;n<N;n++){vector<int>x(14);int v=n;for(int j:free){x[j]=v%F.q;v/=F.q;}for(size_t i=0;i<lin.rows.size();i++){int val=lin.rows[i][14];for(int j:free)val=F.plus[val][F.neg[F.times[lin.rows[i][j]][x[j]]]];x[lin.piv[i]]=val;}int k=8;bool good=true;for(int i=0;i<4;i++)for(int j=i+1;j<4;j++){int w=F.plus[F.times[x[i]][x[4+j]]][F.neg[F.times[x[j]][x[4+i]]]];if(x[k++]!=w)good=false;}if(good)out.solutions++;}return out;}
int main(int argc,char**argv){assert(argc>=3);auto begin=chrono::steady_clock::now();int q=atoi(argv[1]);assert(q==3||q==4||q==5);vector<int>poly=q==4?vector<int>{2,3,2,3,3,1,1}:vector<int>{2,1,0,0,0,0,1};Field F(q,poly);auto ts=types(F);auto P=projective4(q);vector<pair<int,int>>pairorder;for(int i=0;i<(int)P.size();i++)for(int j=i+1;j<(int)P.size();j++)pairorder.push_back({i,j});mt19937 rng(9132026);shuffle(pairorder.begin(),pairorder.end(),rng);string prefix=argv[2];ofstream cert(prefix+".jsonl");map<int,int>ranks;int excluded=0,surv=0,cores=0,pointbad=0,affines=0;vector<int>Btypes;for(int l:ts)if(F.degree(l)==6)Btypes.push_back(l);assert(Btypes.size()==(size_t)(q*q*q+q-1));
for(int l:Btypes){for(int mu:ts)if(mu!=l){
 Space R(F,6);for(int x:{1,mu})R.put(vector<int>(F.d[x].begin(),F.d[x].end()));Space span=R;vector<int>basis;int pwr=1;for(int i=0;i<6;i++,pwr*=q)if(span.put(vector<int>(F.d[pwr].begin(),F.d[pwr].end())))basis.push_back(pwr);assert(basis.size()==4);
 vector<Pt>X;for(auto c:P)X.push_back({F.add(c[0],F.scale(c[2],l)),F.add(c[1],F.scale(c[3],l)),F.add(c[2],F.scale(c[3],mu))});vector<Pt>xb={{1,0,0},{0,1,0},{l,0,1},{0,l,mu}};vector<Pt>S=xb;for(auto v:xb){for(int&x:v)x=F.mul(l,x);S.push_back(v);}Space sb(F,18);for(auto v:S){vector<int>r;for(int x:v)r.insert(r.end(),F.d[x].begin(),F.d[x].end());sb.put(r);}assert(sb.rank()==8);
 vector<Eq>eqs;int ip=0,jp=0;bool badpoint=false; // Enough equations are generated lazily below.
 for(auto [i,j]:pairorder){Pt h=cross(F,X[i],X[j]);if(h==Pt{0,0,0}){ip=i;jp=j;badpoint=true;break;}if(!h[2])continue;int iv=F.iv[h[2]];for(int&x:h)x=F.mul(iv,x);Space C(F,6);for(auto v:S){int w=dot(F,h,v);C.put(vector<int>(F.d[w].begin(),F.d[w].end()));}if(C.rank()!=4)continue;auto nn=C.null();assert(nn.size()==2);eqs.push_back({i,j,nn[0],nn[1],h});if(eqs.size()>=120)break;}
 for(int g=-1;g<q;g++){cores++;cert<<"{\"lambda\":"<<l<<",\"mu\":"<<mu<<",\"g\":"<<g;
 if(badpoint){cert<<",\"kind\":\"point\",\"pair\":["<<ip<<","<<jp<<"]}\n";excluded++;pointbad++;continue;}
 int eta=g<0?F.power(l,3):F.iv[F.sub(l,g)];Space A(F,15);vector<pair<int,int>>selected;Feas last;bool closed=false;
 for(auto&E:eqs){auto c=coefficient(F,E,eta,basis);if(!A.put(c))continue;selected.push_back({E.ia,E.ib});if(A.rank()>=12){last=feasibility(F,A);if(last.tested&&!last.solutions){closed=true;break;}}}
 cert<<",\"kind\":\"quadratic\",\"pairs\":[";bool first=true;for(auto [a,b]:selected){if(!first)cert<<",";first=false;cert<<"["<<a<<","<<b<<"]";}cert<<"],\"linear_rank\":"<<A.rank()<<",\"affine_points\":"<<last.total<<",\"remaining_moments\":"<<last.solutions<<",\"closed\":"<<(closed?"true":"false")<<"}\n";
 ranks[A.rank()]++;affines+=last.total;if(closed)excluded++;else{surv++;cerr<<"NOT CLOSED "<<q<<" "<<l<<" "<<mu<<" "<<g<<" rank "<<A.rank()<<" affine "<<last.total<<" sol "<<last.solutions<<"\n";}
 }
 }
 cerr<<"lambda "<<l<<" cores "<<cores<<" excluded "<<excluded<<" notclosed "<<surv<<" elapsed "<<chrono::duration<double>(chrono::steady_clock::now()-begin).count()<<"\n";
}
assert(cores==(q*q*q+q-1)*(q*q*q+q)*(q+1));ofstream sum(prefix+"_summary.json");sum<<"{\"q\":"<<q<<",\"polynomial\":[";for(size_t i=0;i<poly.size();i++){if(i)sum<<",";sum<<poly[i];}sum<<"],\"scalar_types\":"<<ts.size()<<",\"sextic_types\":"<<Btypes.size()<<",\"parameter_triples\":"<<cores<<",\"excluded\":"<<excluded<<",\"not_closed\":"<<surv<<",\"point_exclusions\":"<<pointbad<<",\"total_affine_points_tested\":"<<affines<<",\"linear_rank_histogram\":{";bool first=true;for(auto[r,n]:ranks){if(!first)sum<<",";first=false;sum<<"\""<<r<<"\":"<<n;}sum<<"},\"seconds\":"<<chrono::duration<double>(chrono::steady_clock::now()-begin).count()<<"}\n";return 0;}
