#include <unordered_map>
#define main epsilon_zero_generator_main
#include "generate_epsilon0.cpp"
#undef main
struct MomentSet{bool tested=false;int affine=0;vector<vector<int>>solutions;};
MomentSet moments(const Field&F,const Space&A){MomentSet out;Space L(F,15);for(auto r:A.rows){vector<int>v(r.begin()+1,r.end());v.push_back(F.neg[r[0]]);L.put(v);}if(binary_search(L.piv.begin(),L.piv.end(),14)){out.tested=true;return out;}vector<int>free;for(int j=0;j<14;j++)if(!binary_search(L.piv.begin(),L.piv.end(),j))free.push_back(j);if(free.size()>2)return out;out.tested=true;int N=1;for(size_t i=0;i<free.size();i++)N*=F.q;out.affine=N;for(int n=0;n<N;n++){vector<int>x(14);int d=n;for(int j:free){x[j]=d%F.q;d/=F.q;}for(size_t i=0;i<L.rows.size();i++){int val=L.rows[i][14];for(int j:free)val=F.plus[val][F.neg[F.times[L.rows[i][j]][x[j]]]];x[L.piv[i]]=val;}bool good=true;int k=8;for(int i=0;i<4;i++)for(int j=i+1;j<4;j++){int w=F.plus[F.times[x[i]][x[4+j]]][F.neg[F.times[x[j]][x[4+i]]]];if(x[k++]!=w)good=false;}if(good)out.solutions.push_back(x);}return out;}
int linval(const Field&F,const vector<int>&x,const vector<int>&bas,int off){int z=0;for(int j=0;j<(int)bas.size();j++)z=F.add(z,F.scale(x[off+j],bas[j]));return z;}
vector<int> quotientBasis(const Field&F,const vector<int>&R){Space A(F,6);for(int a:R)A.put(vector<int>(F.d[a].begin(),F.d[a].end()));vector<int>out;int p=1;for(int i=0;i<6;i++,p*=F.q)if(A.put(vector<int>(F.d[p].begin(),F.d[p].end())))out.push_back(p);return out;}

struct GlobalWitness{int kind=0;Pt point{};array<Pt,2>pair{};};
GlobalWitness checkGlobal(const Field&F,const vector<Pt>&W){
 unordered_map<uint64_t,int>counts;counts.reserve(1<<18);
 auto normalize=[&](Pt x){int inv=F.iv[x[0]?x[0]:(x[1]?x[1]:x[2])];for(int&v:x)v=F.mul(inv,v);return x;};
 auto code=[&](Pt x){return uint64_t(x[0])+uint64_t(F.Q)*(uint64_t(x[1])+uint64_t(F.Q)*x[2]);};
 vector<Pt>subspace={Pt{0,0,0}}; // enumerate projective vectors by last nonzero coefficient
 for(auto b:W){
   for(auto x:subspace){for(int j=0;j<3;j++)x[j]=F.add(x[j],b[j]);Pt p=normalize(x);int c=++counts[code(p)];if(c>F.q+1)return {1,p,{}};}
   auto old=subspace;subspace.clear();subspace.reserve(old.size()*F.q);
   for(int c=0;c<F.q;c++)for(auto x:old){for(int j=0;j<3;j++)x[j]=F.add(x[j],F.scale(c,b[j]));subspace.push_back(x);}
 }
 vector<Pt>heavy;for(auto [key0,c]:counts){if(c!=F.q+1)continue;uint64_t key=key0;Pt p{};for(int j=0;j<3;j++){p[j]=key%F.Q;key/=F.Q;}heavy.push_back(p);}sort(heavy.begin(),heavy.end());
 for(size_t i=0;i<heavy.size();i++)for(size_t j=i+1;j<heavy.size();j++){
  Pt h=cross(F,heavy[i],heavy[j]);Space Q(F,6);for(auto w:W){int z=dot(F,h,w);Q.put(vector<int>(F.d[z].begin(),F.d[z].end()));}if(Q.rank()==6)return {2,{},array<Pt,2>{heavy[i],heavy[j]}};
 }
 return {};
}
int main(int argc,char**argv){assert(argc>=3);auto start=chrono::steady_clock::now();int q=atoi(argv[1]);assert(q==3||q==4||q==5);Field F(q,q==4?vector<int>{2,3,2,3,3,1,1}:vector<int>{2,1,0,0,0,0,1});auto ts=types(F);auto Ps=projective4(q);vector<pair<int,int>>pairorder;for(int i=0;i<(int)Ps.size();i++)for(int j=i+1;j<(int)Ps.size();j++)pairorder.push_back({i,j});mt19937 rng(9132027);shuffle(pairorder.begin(),pairorder.end(),rng);string prefix=argv[2];ofstream cert(prefix+".jsonl");int total=0,closedn=0,unclosed=0,pointn=0,affine_total=0,actual_total=0;map<int,int>rankhist;vector<int>Btypes;for(int l:ts)if(F.degree(l)==6)Btypes.push_back(l);
for(int l:Btypes){auto cbasis=quotientBasis(F,{1,l,F.iv[l]});assert(cbasis.size()==3);auto uvbasis=quotientBasis(F,{1,l});assert(uvbasis.size()==4);
for(int cc=0;cc<q*q*q;cc++){vector<int>dig(3);int n=cc;for(int i=0;i<3;i++){dig[i]=n%q;n/=q;}int c=linval(F,dig,cbasis,0);vector<Pt>xb={{0,0,1},{l,0,0},{0,1,0},{1,F.nval(l),c}};vector<Pt>S=xb;for(auto x:xb){for(int&v:x)v=F.mul(l,v);S.push_back(x);}Space SB(F,18);for(auto x:S){vector<int>r;for(int v:x)r.insert(r.end(),F.d[v].begin(),F.d[v].end());SB.put(r);}assert(SB.rank()==8);
vector<Pt>X;for(auto cf:Ps){Pt x{};for(int j=0;j<3;j++)for(int k=0;k<4;k++)x[j]=F.add(x[j],F.scale(cf[k],xb[k][j]));X.push_back(x);}vector<Eq>eqs;vector<Eq>allnorm;pair<int,int>badpt={-1,-1};
if(c)for(auto [i,j]:pairorder){Pt h=cross(F,X[i],X[j]);if(h==Pt{0,0,0}){badpt={i,j};break;}if(!h[2])continue;int iv=F.iv[h[2]];for(int&v:h)v=F.mul(iv,v);Space A(F,6);for(auto x:S){int v=dot(F,h,x);A.put(vector<int>(F.d[v].begin(),F.d[v].end()));}Eq E{i,j,{},{},h};auto N=A.null();if(N.size()==2){E.L0=N[0];E.L1=N[1];eqs.push_back(E);}allnorm.push_back(E);if(eqs.size()>=120&&allnorm.size()>=160)break;}
for(int g=-1;g<q;g++){total++;cert<<"{\"lambda\":"<<l<<",\"c\":"<<c<<",\"g\":"<<g;
if(!c){cert<<",\"kind\":\"zero_c\",\"closed\":true}\n";closedn++;pointn++;continue;}
if(badpt.first>=0){cert<<",\"kind\":\"point\",\"pair\":["<<badpt.first<<","<<badpt.second<<"],\"closed\":true}\n";closedn++;pointn++;continue;}
int eta=g<0?F.power(l,3):F.iv[F.sub(l,g)];Space A(F,15);vector<pair<int,int>>selected;set<pair<int,int>>reject;set<Pt>rejectpoints;set<Pt>globalpoints;set<array<Pt,2>>globalpairs;MomentSet ms;bool ok=false;
for(auto&E:eqs){if(!A.put(coefficient(F,E,eta,uvbasis)))continue;selected.push_back({E.ia,E.ib});if(A.rank()<12)continue;ms=moments(F,A);if(!ms.tested)continue;
 reject.clear();rejectpoints.clear();bool remains=false;
 for(auto m:ms.solutions){int u=linval(F,m,uvbasis,0),v=linval(F,m,uvbasis,4);bool killed=false;for(auto&N:allnorm){Space C(F,6);for(auto x:S){int z=dot(F,N.h,x);C.put(vector<int>(F.d[z].begin(),F.d[z].end()));}for(int z:{F.add(F.mul(eta,N.h[0]),u),F.add(F.mul(eta,N.h[1]),v)})C.put(vector<int>(F.d[z].begin(),F.d[z].end()));if(C.rank()!=5){reject.insert({N.ia,N.ib});killed=true;break;}}if(!killed){
 vector<Pt>W=S;W.push_back({eta,0,u});W.push_back({0,eta,v});
 for(auto cf:Ps){if(cf[0])continue;Pt point={F.scale(cf[1],l),cf[2],cf[3]};Space T(F,18);for(auto w:W){vector<int>z;for(int c:w)z.insert(z.end(),F.d[c].begin(),F.d[c].end());T.put(z);}int pw=1;for(int j=0;j<6;j++,pw*=q){vector<int>z;for(int c:point){int t=F.mul(c,pw);z.insert(z.end(),F.d[t].begin(),F.d[t].end());}T.put(z);}if(16-T.rank()>2){rejectpoints.insert({cf[1],cf[2],cf[3]});killed=true;break;}}
}
if(!killed){remains=true;break;}}
 if(!remains){ok=true;break;}
}

if(!ok){
 vector<Eq>expanded;set<Pt>seen;
 for(auto [i,j]:pairorder){Pt h=cross(F,X[i],X[j]);if(!h[2])continue;int iv=F.iv[h[2]];for(int&v:h)v=F.mul(iv,v);if(!seen.insert(h).second)continue;Space Q(F,6);for(auto w:S){int z=dot(F,h,w);Q.put(vector<int>(F.d[z].begin(),F.d[z].end()));}Eq E{i,j,{},{},h};if(Q.rank()==4){auto N=Q.null();E.L0=N[0];E.L1=N[1];if(A.put(coefficient(F,E,eta,uvbasis)))selected.push_back({i,j});}expanded.push_back(E);}
 ms=moments(F,A);assert(ms.tested);reject.clear();rejectpoints.clear();bool remains=false;
 for(auto m:ms.solutions){int u=linval(F,m,uvbasis,0),v=linval(F,m,uvbasis,4);bool killed=false;for(auto&N:expanded){Space Q(F,6);for(auto w:S){int z=dot(F,N.h,w);Q.put(vector<int>(F.d[z].begin(),F.d[z].end()));}for(int z:{F.add(F.mul(eta,N.h[0]),u),F.add(F.mul(eta,N.h[1]),v)})Q.put(vector<int>(F.d[z].begin(),F.d[z].end()));if(Q.rank()!=5){reject.insert({N.ia,N.ib});killed=true;break;}}if(!killed){
 vector<Pt>W=S;W.push_back({eta,0,u});W.push_back({0,eta,v});
 for(auto cf:Ps){if(cf[0])continue;Pt point={F.scale(cf[1],l),cf[2],cf[3]};Space T(F,18);for(auto w:W){vector<int>z;for(int c:w)z.insert(z.end(),F.d[c].begin(),F.d[c].end());T.put(z);}int pw=1;for(int j=0;j<6;j++,pw*=q){vector<int>z;for(int c:point){int t=F.mul(c,pw);z.insert(z.end(),F.d[t].begin(),F.d[t].end());}T.put(z);}if(16-T.rank()>2){rejectpoints.insert({cf[1],cf[2],cf[3]});killed=true;break;}}
}
if(!killed){vector<Pt>W=S;W.push_back({eta,0,u});W.push_back({0,eta,v});auto gw=checkGlobal(F,W);if(gw.kind==1){globalpoints.insert(gw.point);killed=true;}else if(gw.kind==2){globalpairs.insert(gw.pair);killed=true;}}
if(!killed){remains=true;break;}}
 ok=!remains;
}

cert<<",\"kind\":\"quadratic\",\"pairs\":[";bool first=true;for(auto[a,b]:selected){if(!first)cert<<",";first=false;cert<<"["<<a<<","<<b<<"]";}cert<<"],\"rank_tests\":[";first=true;for(auto[a,b]:reject){if(!first)cert<<",";first=false;cert<<"["<<a<<","<<b<<"]";}cert<<"],\"point_tests\":[";first=true;for(auto pp:rejectpoints){if(!first)cert<<",";first=false;cert<<"["<<pp[0]<<","<<pp[1]<<","<<pp[2]<<"]";}cert<<"],\"global_point_tests\":[";first=true;for(auto pp:globalpoints){if(!first)cert<<",";first=false;cert<<"["<<pp[0]<<","<<pp[1]<<","<<pp[2]<<"]";}cert<<"],\"dual_pair_tests\":[";first=true;for(auto pp:globalpairs){if(!first)cert<<",";first=false;cert<<"[["<<pp[0][0]<<","<<pp[0][1]<<","<<pp[0][2]<<"],["<<pp[1][0]<<","<<pp[1][1]<<","<<pp[1][2]<<"]]";}cert<<"],\"linear_rank\":"<<A.rank()<<",\"affine_points\":"<<ms.affine<<",\"actual_moments\":"<<ms.solutions.size()<<",\"closed\":"<<(ok?"true":"false")<<"}\n";rankhist[A.rank()]++;affine_total+=ms.affine;actual_total+=ms.solutions.size();if(ok)closedn++;else{unclosed++;cerr<<"UNRESOLVED "<<l<<" "<<c<<" "<<g<<" rank "<<A.rank()<<" actual "<<ms.solutions.size()<<"\n";}
}
}
cerr<<"l "<<l<<" total "<<total<<" closed "<<closedn<<" unclosed "<<unclosed<<" seconds "<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"\n";
}
assert(total==(q*q*q+q-1)*(q+1)*q*q*q);ofstream out(prefix+"_summary.json");out<<"{\"q\":"<<q<<",\"epsilon\":1,\"parameter_cells\":"<<total<<",\"excluded\":"<<closedn<<",\"not_closed\":"<<unclosed<<",\"core_point_exclusions\":"<<pointn<<",\"affine_points_tested\":"<<affine_total<<",\"actual_moments_rank_checked\":"<<actual_total<<",\"linear_rank_histogram\":{";bool first=true;for(auto [r,n]:rankhist){if(!first)out<<",";first=false;out<<"\""<<r<<"\":"<<n;}out<<"},\"seconds\":"<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"}\n";}
