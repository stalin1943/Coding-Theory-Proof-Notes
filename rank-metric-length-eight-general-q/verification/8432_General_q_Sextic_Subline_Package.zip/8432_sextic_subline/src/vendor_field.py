#!/usr/bin/env python3
"""Independent coefficient arithmetic and small exact checks, standard library only."""
from __future__ import annotations
from functools import lru_cache
from itertools import product, combinations
from pathlib import Path
from collections import Counter
from fractions import Fraction
import argparse, json, math

class Base:
    def __init__(self,q):
        if q not in (2,3,4,5,7):raise ValueError('This checker supports q=2,3,4,5,7.')
        self.q=q
        self.add=[[0]*q for _ in range(q)];self.mul=[[0]*q for _ in range(q)]
        for a,b in product(range(q),repeat=2):
            self.add[a][b]=(a^b) if q==4 else (a+b)%q
            if q==4:
                c=0
                for j in range(2):
                    if b>>j&1:c^=a<<j
                if c&4:c^=7
                self.mul[a][b]=c
            else:self.mul[a][b]=a*b%q
        self.neg=[next(b for b in range(q) if self.add[a][b]==0) for a in range(q)]
        self.inv=[0]+[next(b for b in range(1,q) if self.mul[a][b]==1) for a in range(1,q)]
    def sub(self,a,b):return self.add[a][self.neg[b]]

class Field:
    def __init__(self,q,pol):
        self.K=Base(q);self.q=q;self.m=len(pol)-1;self.Q=q**self.m;self.pol=pol
        assert pol[-1]==1
    @lru_cache(None)
    def digits(self,a):
        v=[]
        for _ in range(self.m):v.append(a%self.q);a//=self.q
        return tuple(v)
    def pack(self,v):return sum(x*self.q**i for i,x in enumerate(v))
    def add(self,a,b):return self.pack([self.K.add[x][y] for x,y in zip(self.digits(a),self.digits(b))])
    def neg(self,a):return self.pack([self.K.neg[x] for x in self.digits(a)])
    @lru_cache(maxsize=100000)
    def mul(self,a,b):
        K=self.K;c=[0]*(2*self.m-1)
        for i,x in enumerate(self.digits(a)):
            for j,y in enumerate(self.digits(b)):c[i+j]=K.add[c[i+j]][K.mul[x][y]]
        for j in range(2*self.m-2,self.m-1,-1):
            z=c[j]
            for k,p in enumerate(self.pol[:-1]):c[j-self.m+k]=K.sub(c[j-self.m+k],K.mul[z][p])
        return self.pack(c[:self.m])
    def pow(self,x,n):
        out=1
        while n:
            if n&1:out=self.mul(out,x)
            x=self.mul(x,x);n//=2
        return out
    @lru_cache(None)
    def inv(self,x):
        assert x
        r=self.pow(x,self.Q-2);assert self.mul(x,r)==1
        return r
    def trace(self,x):
        z=0
        for _ in range(self.m):z=self.add(z,x);x=self.pow(x,self.q)
        assert z<self.q
        return z
    def scale(self,c,x):return self.pack([self.K.mul[c][v] for v in self.digits(x)])
    def normal(self,x):
        assert x
        return self.scale(self.K.inv[next(c for c in reversed(self.digits(x)) if c)],x)
    def plane(self,l):return self.span([1,l])
    def span(self,basis):
        out=[0]
        for b in basis:out=[self.add(x,self.scale(c,b)) for c in range(self.q) for x in out]
        return sorted(set(out))
    def typekey(self,l):
        B=self.plane(l);keys=[]
        for y in B:
            if not y:continue
            vals=sorted(self.mul(x,self.inv(y)) for x in B)
            keys.append(tuple(vals))
        return min(keys)

def trim(p):
    p=list(p)
    while len(p)>1 and p[-1]==0:p.pop()
    return p

def prem(K,a,b):
    a=trim(a);b=trim(b);iv=K.inv[b[-1]]
    while any(a) and len(a)>=len(b):
        r=len(a)-len(b);z=K.mul[a[-1]][iv]
        for j,c in enumerate(b):a[r+j]=K.sub(a[r+j],K.mul[z][c])
        a=trim(a)
    return a

def pmul(K,a,b,p):
    c=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):c[i+j]=K.add[c[i+j]][K.mul[x][y]]
    return prem(K,c,p)

def ppow(K,a,n,p):
    z=[1]
    while n:
        if n&1:z=pmul(K,z,a,p)
        a=pmul(K,a,a,p);n//=2
    return z

def irreducible(F):
    K=F.K;p=F.pol;x=[0,1]
    for e in (2,3):
        a=ppow(K,x,F.q**e,p)
        if len(a)<2:a+=[0]*(2-len(a))
        a[1]=K.sub(a[1],1)
        b=p[:]
        while any(a):b,a=a,prem(K,b,a)
        assert len(trim(b))==1
    assert ppow(K,x,F.q**6,p)==x

def rref(K,rows,n):
    rows=[list(v) for v in rows];r=0;piv=[]
    for j in range(n-1,-1,-1):
        i=next((i for i in range(r,len(rows)) if rows[i][j]),None)
        if i is None:continue
        rows[r],rows[i]=rows[i],rows[r];iv=K.inv[rows[r][j]];rows[r]=[K.mul[iv][x] for x in rows[r]]
        for i in range(len(rows)):
            if i!=r and rows[i][j]:
                z=rows[i][j];rows[i]=[K.sub(a,K.mul[z][b]) for a,b in zip(rows[i],rows[r])]
        piv.append(j);r+=1
        if r==len(rows):break
    return rows[:r],piv

def rank(K,rows):
    if not rows:return 0
    return len(rref(K,rows,len(rows[0]))[1])

def null(K,rows,n):
    R,piv=rref(K,rows,n);out=[]
    for j in range(n):
        if j in piv:continue
        v=[0]*n;v[j]=1
        for rr,p in zip(R,piv):v[p]=K.neg[rr[j]]
        out.append(v)
    return out

def direct_reciprocal(F,ls):
    q=F.q;Bs=[F.plane(l) for l in ls]
    assert len(set(F.typekey(l) for l in ls))==4
    assert all(len(B)==q*q for B in Bs)
    reps=sorted({F.normal(x) for x in Bs[0] if x})
    assert len(reps)==q+1
    last=set(Bs[3]);count=0;directions=set()
    for b1,b2,b3 in product(reps,Bs[1][1:],Bs[2][1:]):
        a=[F.inv(b1),F.inv(b2),F.inv(b3)]
        c=F.add(F.add(a[0],a[1]),a[2])
        if c and F.inv(c) in last:
            count+=1;iv=F.inv(next(x for x in a if x));directions.add(tuple(F.mul(iv,x) for x in a))
    assert len(directions)==count
    # Independently calculate three pair-convolution counts, with unprojected sums.
    counts=[]
    for i,j,k,l in [(0,1,2,3),(0,2,1,3),(0,3,1,2)]:
        f=Counter(F.add(F.inv(x),F.inv(y)) for x,y in product(Bs[i][1:],Bs[j][1:]))
        g=Counter(F.add(F.inv(x),F.inv(y)) for x,y in product(Bs[k][1:],Bs[l][1:]))
        v=sum(n*g.get(c,0) for c,n in f.items())
        assert v%(q-1)==0;counts.append(v//(q-1))
    assert counts==[count]*3
    return {'count':count,'direct_triples':len(reps)*(q*q-1)**2,'three_pair_counts':counts,'projective_injection_check':True}

def weight_check():
    # Cyclic group order 6 with point orbits 6,3,2,1. Includes subset stabilizers
    # and anchored subsets meeting their earliest point orbit 2,3,4 times.
    perm=list(range(12))
    for cyc in [list(range(6)),[6,7,8],[9,10],[11]]:
        for a,b in zip(cyc,cyc[1:]+cyc[:1]):perm[a]=b
    omin=[];size=[]
    for x in range(12):
        o=[];y=x
        while y not in o:o.append(y);y=perm[y]
        omin.append(min(o));size.append(len(o))
    full=Counter();anchored=Counter();visits=0
    def orbit(A):
        out=[];B=tuple(A)
        for _ in range(6):out.append(B);B=tuple(sorted(perm[x] for x in B))
        return min(out)
    for A in combinations(range(12),4):
        key=orbit(A);full[key]+=1;i=min(omin[x] for x in A)
        if i in A:
            k=sum(omin[x]==i for x in A)
            anchored[key]+=Fraction(size[i],k);visits+=1
    assert full==anchored
    return {'all_four_sets':math.comb(12,4),'group_orbits':len(full),'anchored_records':visits,'orbit_by_orbit_weighted_totals_equal':True}

def quadratic_checks():
    out=[]
    polys={3:[2,1,0,0,0,0,1],4:[2,3,2,3,3,1,1],5:[2,1,0,0,0,0,1]}
    for q in [3,4,5]:
        F=Field(q,polys[q]);irreducible(F);K=F.K;l=q;lp=[1]
        for _ in range(5):lp.append(F.mul(lp[-1],l))
        rows=[[F.trace(F.mul(lp[j],q**k)) for k in range(6)] for j in range(5)]
        ker=null(K,rows,6);assert len(ker)==1;delta=F.pack(ker[0]);assert delta
        assert all(F.trace(F.mul(delta,lp[j]))==0 for j in range(5))
        Ddual=null(K,rows[:3],6)
        assert rank(K,Ddual+[list(F.digits(F.mul(delta,lp[j]))) for j in range(3)])==3
        vals=list(product(range(q),repeat=3));counts=Counter();n=0
        for a,b in product(vals,repeat=2):
            n0=K.sub(K.mul[a[1]][b[2]],K.mul[a[2]][b[1]])
            n1=K.sub(K.mul[a[2]][b[0]],K.mul[a[0]][b[2]])
            n2=K.sub(K.mul[a[0]][b[1]],K.mul[a[1]][b[0]])
            conic=K.sub(K.mul[n1][n1],K.mul[n0][n2])==0
            # (a,ta,b,tb) in the degree<=3 polynomial space. Injects into F.
            r=rank(K,[list(a)+[0],[0]+list(a),list(b)+[0],[0]+list(b)])
            assert (r<=3)==conic;n+=1;counts[r]+=1
        out.append({'q':q,'all_polynomial_pairs':n,'rank_histogram':dict(counts),'trace_dual_delta':delta,'trace_dual_C_equals_delta_D':True})
    return out

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--results',type=Path,required=True);args=ap.parse_args()
    ex=[]
    for name in ['q5_primary.json','q5_secondary.json']:
        row=json.loads((args.results/name).read_text());F=Field(5,row['polynomial']);irreducible(F)
        rr=direct_reciprocal(F,row['max_example']);assert rr['count']==row['maximum']
        ex.append({'source':name,'polynomial':F.pol,'lambda':row['max_example'],**rr})
    out={'maximum_examples':ex,'group_weight_check':weight_check(),'quadratic_checks':quadratic_checks(),'all_passed':True,
         'scope':'independent direct checks of two maximum examples; exact orbit weighting check; all small polynomial pairs and trace-dual identities. Not an independent full 5-ary histogram.'}
    (args.results/'independent.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False))
if __name__=='__main__':main()
