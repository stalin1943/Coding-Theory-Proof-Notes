#!/usr/bin/env python3
"""Independent coefficient-arithmetic checks of the new normalizations and examples.
The field arithmetic is reused unchanged from the supplied baseline (renamed
vendor_field.py); this file is new. No exhaustive code classification is claimed.
"""
from pathlib import Path
from itertools import product,combinations
import argparse,json
from vendor_field import Field,Base,rank,rref,null,irreducible

def projective(q,n):
    for p in range(n):
        for tail in product(range(q),repeat=n-p-1):yield [0]*p+[1]+list(tail)
def combo(K,c,rows):
    out=[0]*len(rows[0])
    for a,r in zip(c,rows):out=[K.add[x][K.mul[a][y]] for x,y in zip(out,r)]
    return out
def dot(F,a,b):
    z=0
    for x,y in zip(a,b):z=F.add(z,F.mul(x,y))
    return z
def cross(F,a,b):
    return tuple(F.add(F.mul(a[(j+1)%3],b[(j+2)%3]),F.neg(F.mul(a[(j+2)%3],b[(j+1)%3]))) for j in range(3))
def vectors(F,xb):
    out=[]
    for c in projective(F.q,4):
        v=[]
        for j in range(3):
            a=0
            for x,b in zip(c,xb):a=F.add(a,F.scale(x,b[j]))
            v.append(a)
        out.append(tuple(v))
    return out
def flatten(F,x):return [d for a in x for d in F.digits(a)]
def extension_normals(F,xb):
    S=xb+[tuple(F.mul(F.q,a) for a in x) for x in xb]
    assert rank(F.K,[flatten(F,x) for x in S])==8
    result={}
    for a,b in combinations(vectors(F,xb),2):
        h=cross(F,a,b);assert any(h)
        if not h[2]:continue
        h=tuple(F.mul(F.inv(h[2]),x) for x in h);result[h]=True
    return S,list(result)

def hyperplanes():
    out=[]
    for q in [3,4,5]:
        K=Base(q);count1=count2=0
        normal=null(K,[[1,0,0,1]],4)
        expected=rref(K,normal,4)[0]
        for h in projective(q,4):
            Y=null(K,[h],4);C=[[h[0],h[2]],[h[1],h[3]]]
            if rank(K,C)==1:
                vv=null(K,C,2);assert len(vv)==1;v=vv[0]
                for row in [[v[0],0,v[1],0],[0,v[0],0,v[1]]]:
                    assert combo(K,row,[[a] for a in h])==[0]
                count1+=1
            else:
                Z=[]
                for y in Y:
                    a,b,c,d=y
                    Z.append([K.add[K.mul[C[0][0]][a]][K.mul[C[0][1]][c]],K.add[K.mul[C[0][0]][b]][K.mul[C[0][1]][d]],K.add[K.mul[C[1][0]][a]][K.mul[C[1][1]][c]],K.add[K.mul[C[1][0]][b]][K.mul[C[1][1]][d]]])
                assert rref(K,Z,4)[0]==expected
                count2+=1
        assert count1==(q+1)**2 and count2==q*(q*q-1)
        out.append({'q':q,'all_hyperplanes':count1+count2,'rank_one_forms':count1,'rank_two_forms_all_normalized':count2})
    return out

def example0(F):
    K=F.K;l=3;mu=9;eta=27;basis=[3,27,81,243]
    X=[(1,0,0),(0,1,0),(l,0,1),(0,l,mu)]
    S,ns=extension_normals(F,X);rows=[]
    for h in ns:
        im=[F.digits(dot(F,h,s)) for s in S]
        if rank(K,im)!=4:continue
        p0,p1=null(K,im,6)
        def ev(p,z):return combo(K,p,[[x] for x in F.digits(z)])[0]
        def det(a,b):return K.sub(K.mul[ev(p0,a)][ev(p1,b)],K.mul[ev(p1,a)][ev(p0,b)])
        c=F.mul(eta,h[0]);d=F.mul(eta,h[1]);row=[det(c,d)]
        row +=[det(t,d) for t in basis]+[det(c,t) for t in basis]+[det(basis[i],basis[j]) for i,j in combinations(range(4),2)]
        rows.append(row)
    R=rref(K,rows,15)[0];assert len(R)==13
    N=null(K,R,15);p=next(x for x in N if x[0]);p=[K.mul[K.inv[p[0]]][x] for x in p]
    directions=rref(K,[[K.sub(a,K.mul[x[0]][b]) for a,b in zip(x,p)] for x in N],15)[0]
    assert len(directions)==1
    actual=sorted(tuple(K.add[a][K.mul[t][b]] for a,b in zip(p,directions[0])) for t in range(3))
    expected=sorted((1,t,0,0,0,0,t,1,0,0,0,2,0,0,0) for t in range(3))
    assert actual==expected
    return {'q':3,'lambda':l,'mu':mu,'eta':eta,'quotient_basis':basis,'secant_normals':len(ns),'linear_rank':13,'affine_line_base':p,'affine_line_direction':directions[0],'rref':R,'all_affine_moment_vectors':actual,'contradiction':'u4=v4=0 while w14=2; therefore w14 cannot equal u1*v4-u4*v1'}

def example1(F):
    K=F.K;l=3;c=9;eta=27;u=261;v=0
    X=[(0,0,1),(l,0,0),(0,1,0),(1,F.neg(l),c)]
    S,ns=extension_normals(F,X);W=S+[(eta,0,u),(0,eta,v)]
    assert rank(K,[flatten(F,x) for x in W])==10
    assert all(rank(K,[F.digits(dot(F,h,w)) for w in W])==5 for h in ns)
    ambient=W+[(0,3**j,0) for j in range(6)]
    weight=16-rank(K,[flatten(F,x) for x in ambient]);assert weight==3
    trace_rows=[]
    for w in W:
        trace_rows.append([F.trace(F.mul(w[j],3**k)) for j in range(3) for k in range(6)])
    ub=null(K,trace_rows,18);assert len(ub)==8
    U=[tuple(F.pack(row[6*j:6*(j+1)]) for j in range(3)) for row in ub]
    h=(0,1,0);word=[dot(F,h,x) for x in U];assert rank(K,[F.digits(a) for a in word])==3
    return {'q':3,'lambda':l,'c':c,'eta':eta,'u':u,'v':v,'all_X_secants_off_carrier_passed':len(ns),'W_basis':W,'bad_point':[0,1,0],'bad_point_weight':weight,'U_generator_columns':U,'rank_three_codeword':word,'point_condition_is_independent_of_these_secant_equalities':True}

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    F=Field(3,[2,1,0,0,0,0,1]);irreducible(F)
    out={'hyperplane_normalization':hyperplanes(),'epsilon0_affine_line_example':example0(F),'epsilon1_point_obstruction_example':example1(F),'all_passed':True,'scope':'All 281 projection hyperplanes for q=3,4,5 and two explicit ternary normal-form examples; not a complete independent replay of the certificate family.'}
    a.output.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'all_passed':True,'hyperplanes':sum(x['all_hyperplanes'] for x in out['hyperplane_normalization'])}))
if __name__=='__main__':main()
