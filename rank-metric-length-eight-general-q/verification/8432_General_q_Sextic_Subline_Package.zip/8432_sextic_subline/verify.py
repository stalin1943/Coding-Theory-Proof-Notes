#!/usr/bin/env python3
"""Replay every finite exclusion in a new directory, optionally regenerating it.
Python standard library + a C++17 compiler. Do not disable assertions.
This is not a formal proof-assistant check of the normal-form mathematics.
"""
from __future__ import annotations
import argparse,hashlib,json,os,re,shutil,subprocess,sys,time
from pathlib import Path

def stable(x):
    if isinstance(x,dict):return {k:stable(v) for k,v in x.items() if k not in {'seconds','elapsed_seconds'}}
    if isinstance(x,list):return [stable(v) for v in x]
    return x

def texcheck(p:Path):
    s=re.sub(r'(?<!\\)%[^\n]*','',p.read_text());labels=re.findall(r'\\label\{([^}]+)\}',s);refs=re.findall(r'\\(?:ref|eqref)\{([^}]+)\}',s)
    assert len(labels)==len(set(labels)) and set(refs)<=set(labels)
    stack=[]
    for op,e in re.findall(r'\\(begin|end)\{([^}]+)\}',s):
        if op=='begin':stack.append(e)
        else:assert stack and stack.pop()==e
    assert not stack
    level=0
    for c in re.sub(r'\\[{}]','',s):
        if c=='{':level+=1
        elif c=='}':level-=1
        assert level>=0
    assert level==0
    return {'labels':len(labels),'internal_references':len(refs),'scope':'source structure only; not TeX compilation'}

def run(work:Path,regenerate:bool=False):
    if not __debug__:raise RuntimeError('Assertions must be enabled; do not use python -O.')
    root=Path(__file__).resolve().parent;work=work.resolve()
    if work==root or root in work.parents:raise ValueError('Choose a work directory outside the package.')
    if work.exists() and (not work.is_dir() or any(work.iterdir())):raise ValueError('Work directory must be new or empty.')
    work.mkdir(parents=True,exist_ok=True);start=time.perf_counter()
    manifest=root/'MANIFEST.json';files=0
    if manifest.exists():
        for rel,digest in json.loads(manifest.read_text()).items():
            assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==digest,rel
            files+=1
    cxx=os.environ.get('CXX') or shutil.which('g++') or shutil.which('clang++')
    if not cxx:raise RuntimeError('A C++17 compiler is required.')
    sources=['independent_checker']+(['generate_epsilon0','generate_epsilon1'] if regenerate else [])
    for name in sources:
        with (work/(name+'_compile.log')).open('w') as log:
            subprocess.run([cxx,'-std=c++17','-O3',str(root/'src'/f'{name}.cpp'),'-o',str(work/name)],stdout=log,stderr=subprocess.STDOUT,check=True)
    sys.path.insert(0,str(root/'src'))
    from encode_certificate import encode
    reports=[];encodings=[];comparisons=[]
    for q in [3,4,5]:
        for eps in [0,1]:
            label=f'q{q}_epsilon{eps}'
            if regenerate:
                prefix=work/label
                with (work/(label+'_generation.log')).open('w') as log:
                    subprocess.run([str(work/f'generate_epsilon{eps}'),str(q),str(prefix)],stdout=log,stderr=subprocess.STDOUT,check=True)
                path=prefix.with_suffix('.jsonl')
                summary=json.loads((work/(label+'_summary.json')).read_text());assert summary['not_closed']==0
            else:path=root/'results'/(label+'.jsonl')
            enc=encode(path,work/(label+'.bin'),q,eps);encodings.append({'q':q,'epsilon':eps,**enc})
            output=work/(label+'_independent.json')
            with (work/(label+'_replay.log')).open('w') as log:
                subprocess.run([str(work/'independent_checker'),str(work/(label+'.bin')),str(output)],stdout=log,stderr=subprocess.STDOUT,check=True)
            report=json.loads(output.read_text());assert report['all_cells_excluded']
            reference=json.loads((root/'results'/(label+'_independent.json')).read_text())
            same=stable(report)==stable(reference)
            if not regenerate:assert same,label
            comparisons.append({'case':label,'stored_counts_match':same})
            reports.append(report)
            print(label,'complete cells',report['complete_cells'],'all independently excluded',flush=True)
    with (work/'small_examples.log').open('w') as log:
        subprocess.run([sys.executable,str(root/'src/check_small_examples.py'),'--output',str(work/'small_examples.json')],stdout=log,stderr=subprocess.STDOUT,check=True)
    small=json.loads((work/'small_examples.json').read_text());assert stable(small)==stable(json.loads((root/'results/small_examples.json').read_text()))
    keys=['complete_cells','selected_secant_equations','final_affine_points','compatible_moments_before_rank_tests','compatible_moments_killed_by_rank','compatible_moments_killed_by_point','core_point_exclusions','symbolic_degree_two_contradictions']
    totals={k:sum(r[k] for r in reports) for k in keys}
    assert totals['complete_cells']==248202
    assert totals['compatible_moments_before_rank_tests']==totals['compatible_moments_killed_by_rank']+totals['compatible_moments_killed_by_point']
    result={'date':'2026-09-13','status':'passed','regenerated_all_parameter_certificates':regenerate,'manifest_files_checked':files,
       'parameter_cases':reports,'totals':totals,'saved_count_comparisons':comparisons,'all_saved_counts_match':all(x['stored_counts_match'] for x in comparisons),
       'json_encodings':encodings,'projection_hyperplanes_checked':sum(x['all_hyperplanes'] for x in small['hyperplane_normalization']),
       'explicit_examples_checked':2,'tex':texcheck(root/'THEOREMS_en.tex'),
       'elapsed_seconds':round(time.perf_counter()-start,3),
       'scope':'Complete replay of all sextic isolated-subline normal-form cells for q=3,4,5. Cubic-type sublines, low-weight-point branches, and larger base fields are not classified. No old quinary reciprocal or previous terminal computation is rerun.'}
    (work/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'status':'passed','regenerated':regenerate,'totals':totals,'elapsed_seconds':result['elapsed_seconds']}),flush=True)
    return result

def main():
    p=argparse.ArgumentParser();p.add_argument('--work',type=Path,required=True);p.add_argument('--regenerate',action='store_true');a=p.parse_args();run(a.work,a.regenerate)
if __name__=='__main__':main()
