#!/usr/bin/env python3
"""Recompute the complete rank-five incidence theorem and its geometry checks.

Python standard library + a C++17 compiler. All mathematical stages run in the
current process tree; no remote service or saved executable is used.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent


def digest(p: Path) -> str:
    h = hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(1 << 20), b''): h.update(block)
    return h.hexdigest()


def math_json(value):
    if isinstance(value, dict):
        return {k:math_json(v) for k,v in value.items() if k != 'seconds'}
    if isinstance(value, list): return [math_json(v) for v in value]
    return value


def main() -> None:
    if not __debug__: raise RuntimeError('Do not disable assertions with python -O.')
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--work', required=True, help='New or empty output directory.')
    ap.add_argument('--cxx', default=os.environ.get('CXX','g++'))
    ap.add_argument('--cxxflags', default=os.environ.get('CXXFLAGS',''))
    ap.add_argument('--no-latex', action='store_true')
    args = ap.parse_args()
    if 'NDEBUG' in args.cxxflags: raise ValueError('NDEBUG is not permitted.')
    work = Path(args.work).resolve()
    if work == ROOT or ROOT in work.parents:
        raise ValueError('Place recomputation outside the immutable package directory.')
    if work.exists() and any(work.iterdir()):
        raise ValueError(f'Output directory is not empty: {work}')
    work.mkdir(parents=True, exist_ok=True)
    logs=work/'logs';logs.mkdir()
    compiler=shlex.split(args.cxx)
    if not compiler or shutil.which(compiler[0]) is None:
        raise RuntimeError(f'C++17 compiler not found: {args.cxx}')
    os.environ['PYTHONDONTWRITEBYTECODE']='1'
    start=time.perf_counter(); stages=[]
    manifest=json.loads((ROOT/'MANIFEST.json').read_text())
    for rel,expected in manifest['sha256'].items():
        p=ROOT/rel
        if not p.is_file() or digest(p)!=expected:
            raise RuntimeError(f'Package integrity mismatch: {rel}')
    print(f'Input integrity: {len(manifest["sha256"])} files verified',flush=True)

    def run(name, command, cwd=ROOT):
        print(name,flush=True); t=time.perf_counter()
        with (logs/(name+'.log')).open('w',encoding='utf-8') as out:
            result=subprocess.run([str(x) for x in command],cwd=cwd,stdout=out,
                                  stderr=subprocess.STDOUT,check=False)
        item={'stage':name,'exit_code':result.returncode,'seconds':time.perf_counter()-t}
        stages.append(item)
        if result.returncode:
            raise RuntimeError(f'{name} failed; see {logs/(name+".log")}')

    flags=['-std=c++17','-O3']+shlex.split(args.cxxflags)
    binaries={}
    for name in ('primary','independent','compare_arrays','independent_geometry'):
        exe=work/(name+('.exe' if os.name=='nt' else ''))
        run('compile_'+name,compiler+flags+[ROOT/'src'/f'{name}.cpp','-o',exe])
        binaries[name]=exe
    for q in (3,5,7):
        run(f'primary_q{q}',[binaries['primary'],q,work/f'inc{q}'])
        run(f'independent_q{q}',[binaries['independent'],q,work/f'ind{q}'])
    run('coordinate_maps',[sys.executable,ROOT/'src/compare_setup.py',work])
    for q in (3,5,7):
        run(f'compare_complete_arrays_q{q}',[binaries['compare_arrays'],work/f'map{q}.txt',
                 work/f'inc{q}_counts.bin',work/f'ind{q}_counts.bin',work/f'compare{q}.json'])
    run('reconstruct_and_bind_sections',[sys.executable,ROOT/'src/bridge.py',work])
    run('symbolic_and_mass_checks',[sys.executable,ROOT/'src/symbolic_checks.py',work])
    run('octic_norm_and_operator_checks',[sys.executable,ROOT/'src/check_geometry.py',work])
    run('prepare_independent_sections',[sys.executable,ROOT/'src/prepare_geometry.py',work])
    for q in (3,5,7):
        run(f'independent_original_geometry_q{q}',[binaries['independent_geometry'],
                work/f'geometry_input{q}.txt',work/f'independent_geometry{q}.json'])

    compared=[]
    for saved in sorted((ROOT/'results').iterdir()):
        if not saved.is_file():continue
        generated=work/saved.name
        if not generated.is_file():raise RuntimeError(f'Missing output: {saved.name}')
        if saved.suffix=='.json':
            same=math_json(json.loads(saved.read_text()))==math_json(json.loads(generated.read_text()))
        else: same=digest(saved)==digest(generated)
        if not same:raise RuntimeError(f'Recomputed mathematical output differs: {saved.name}')
        compared.append(saved.name)
    latex=False
    if not args.no_latex and shutil.which('pdflatex'):
        target=work/'latex';target.mkdir()
        shutil.copy2(ROOT/'fragment_check.tex',target)
        shutil.copy2(ROOT/'THEOREMS_en.tex',target)
        for i in (1,2):
            run(f'latex_fragment_{i}',['pdflatex','-halt-on-error','-interaction=nonstopmode',
                'fragment_check.tex'],cwd=target)
        log=(target/'fragment_check.log').read_text(errors='replace')
        if 'undefined references' in log or 'There were undefined' in log:
            raise RuntimeError('Unresolved reference in LaTeX theorem fragment.')
        latex=True
    totals={'projective_relation_directions_compared':0,'eligible_multiplication_spaces':0,
            'incidence_updates_per_complete_path':0,'independent_section_point_checks':0,
            'independent_original_trace_conic_checks':0}
    maxima={}
    for q in (3,5,7):
        a=json.loads((work/f'inc{q}.json').read_text());g=json.loads((work/f'independent_geometry{q}.json').read_text())
        totals['projective_relation_directions_compared']+=a['projective_relations']
        totals['eligible_multiplication_spaces']+=a['eligible_planes']
        totals['incidence_updates_per_complete_path']+=a['incidence_updates']
        totals['independent_section_point_checks']+=g['full_point_checks']
        totals['independent_original_trace_conic_checks']+=g['raw_trace_conic_checks']
        maxima[str(q)]=a['maximum_nondegenerate']
    report={'passed':True,'package_integrity_files':len(manifest['sha256']),
            'mathematical_outputs_compared':compared,'compiler':args.cxx,'compiler_flags':flags,
            'python_version':sys.version,'complete_rank_five_maxima':maxima,'totals':totals,
            'all_extremal_relations_reconstructed':15,'additional_rank_five_bindings':652,
            'full_symbolic_octic_charts':108,'explicit_moore_sections':12,
            'independent_geometry_models':691,'latex_fragment_compiled':latex,
            'not_claimed':['classification of all rank-six sections',
                           'independent re-proof of all historical nonexistence reductions',
                           'proof-assistant formalization or external mathematical peer review'],
            'stages':stages,'seconds':time.perf_counter()-start}
    (work/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print('All complete incidence arrays, geometry checks and saved outputs agree.',flush=True)
    print(json.dumps({'maxima':maxima,'totals':totals,'seconds':report['seconds']},indent=2),flush=True)

if __name__=='__main__':
    main()
