"""Write explicitly mapped inputs for the separate polynomial-field checker."""
from pathlib import Path
import sys,json
PACKAGE=Path(__file__).resolve().parents[1];W=Path(sys.argv[1]).resolve()
sys.path.insert(0,str(PACKAGE/'vendor'))
from tower_arithmetic import Base,rref

def inverse(M,q):
 K=Base(q);R,p=rref(K,[list(r)+[int(i==j)for j in range(6)]for i,r in enumerate(M)],12);assert p[:6]==list(range(6));return [r[6:]for r in R]

def main():
 ex=json.load(open(W/'bridge5_results.json'))['extrema'];mo=json.load(open(PACKAGE/'inputs/moore_cases.json'));sa=[json.loads(l)for l in open(PACKAGE/'inputs/rank5_samples7.jsonl')];extra=json.load(open(PACKAGE/'inputs/rank6_samples7.json'))
 fields=json.load(open(PACKAGE/'inputs/polyfields.json'))
 for f in fields:
  q=f['q'];pw=f['power_basis_in_primary'];C=[[pw[j]//q**i%q for j in range(6)]for i in range(6)];I=inverse(C,q)
  def convert(x):
   a=[x//q**i%q for i in range(6)];b=[sum(u*v for u,v in zip(r,a))%q for r in I];return sum(b[i]*q**i for i in range(6))
  records=[]
  for r in ex:
   if r['q']==q:records.append((r['section'],r['zeros'],5,1,0))
  for r in mo:
   if r['q']==q:records.append((r['section'],r['zeros'],r['rank'],1,1))
  for r in sa+extra:
   if r['q']==q:records.append((r['section'],r['zeros'],r['rank'],0,0))
  with (W/f'geometry_input{q}.txt').open('w')as out:
   out.write(f'{q} {len(records)} {convert(q)} {convert(q**3)}\n')
   for T,z,rank,tr,moore in records:out.write(f'{z} {rank} {tr} {moore} '+' '.join(str(convert(x))for t in T for x in t)+'\n')
if __name__=='__main__':main()
