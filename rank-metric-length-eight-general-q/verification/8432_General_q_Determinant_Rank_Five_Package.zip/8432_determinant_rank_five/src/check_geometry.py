"""Exact original-octic bindings and Moore norm division; standard library only."""
from pathlib import Path
import sys,json,itertools,collections
PACKAGE=Path(__file__).resolve().parents[1]
WORK=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else PACKAGE/'results'
sys.path.insert(0,str(PACKAGE/'vendor'))
from algebra import Algebra
from baseline_octic import Polynomial,octic
from tower_arithmetic import projective,rank

def norm_form(F,D):
 p={(0,0,0,0):1}
 for k in range(6):
  co=[F.pow(x,F.q**k)for x in D];out={}
  for m,c in p.items():
   for j,a in enumerate(co):
    n=list(m);n[j]+=1;n=tuple(n);z=F.add(out.get(n,0),F.mul(c,a))
    if z:out[n]=z
    elif n in out:del out[n]
  p=out
 assert all(c<F.q for c in p.values())
 return p

def divide(f,g,q):
 f=dict(f);g=dict(g);out={};lm=max(g);lc=pow(g[lm],-1,q)
 while f:
  m=max(f)
  assert all(a>=b for a,b in zip(m,lm)),('nonzero remainder',m,lm)
  n=tuple(a-b for a,b in zip(m,lm));c=f[m]*lc%q;out[n]=(out.get(n,0)+c)%q
  for e,a in g.items():
   b=tuple(x+y for x,y in zip(e,n));v=(f.get(b,0)-c*a)%q
   if v:f[b]=v
   elif b in f:del f[b]
 return {m:c for m,c in out.items()if c}

def eval_poly(p,v,q):return sum(c*prod(pow(x,e,q)for x,e in zip(v,m))for m,c in p.items())%q

def prod(it):
 v=1
 for x in it:v*=x
 return v

def determinant(F,M):
 M=[r[:]for r in M];n=len(M);v=1
 for j in range(n):
  k=next((i for i in range(j,n)if M[i][j]),None)
  if k is None:return 0
  if k!=j:M[k],M[j]=M[j],M[k];v=F.neg(v)
  a=M[j][j];v=F.mul(v,a);ia=F.inv(a)
  for i in range(j+1,n):
   c=F.mul(M[i][j],ia)
   for l in range(j,n):M[i][l]=F.add(M[i][l],F.neg(F.mul(c,M[j][l])))
 return v

def operator_coefficients(A,T):
 F=A.F;q=A.q
 p=[A.sub(F.mul(T[i][0],T[j][1]),F.mul(T[i][1],T[j][0]))for i in range(4)for j in range(i+1,4)]
 perm=[5,4,3,2,1,0];sgn=[1,-1,1,1,-1,1];co=[]
 for k in range(6):
  v=0
  for i in range(6):
   x=F.mul(p[i],F.pow(p[perm[i]],q**k));v=F.add(v,x if sgn[i]>0 else F.neg(x))
  co.append(v)
 assert co[0]==0 and co[2]!=0
 assert co[5]==F.pow(co[1],q**5) and co[4]==F.pow(co[2],q**4) and co[3]==F.pow(co[3],q**3)
 G=list(map(list,zip(*T)))
 for k in [1,2,3]:assert determinant(F,G+[[F.pow(x,q**k)for x in r]for r in G])==co[k]
 for x in [0,1,q,F.mu,F.add(q,F.mu),F.add(q*q,F.scale(q-1,F.mu))]:
  v=0
  for i in range(6):
   y=F.scale(F.trace(F.mul(p[perm[i]],x)),p[i]);v=F.add(v,y if sgn[i]>0 else F.neg(y))
  assert v==F.dot(co,[F.pow(x,q**k)for k in range(6)])
 return co

def main():
 extrema=json.load(open(WORK/'bridge5_results.json'))['extrema'];moore=json.load(open(PACKAGE/'inputs/moore_cases.json'))
 out=dict(extrema=[],moore=[],original_chart_determinants=0,full_projective_point_checks=0,operator_checks=[])
 for q in [3,5,7]:
  A=Algebra(q);F=A.F;P=Polynomial(A)
  for rec in [r for r in extrema if r['q']==q]:
   T=rec['section'];O,_=octic(A,P,T);terms={P.exponents(e):c for e,c in O.items()};zeros=[]
   for v in projective(q,4):
    if eval_poly(terms,v,q)==0:zeros.append(list(v))
   assert zeros==rec['zero_points']
   out['extrema'].append(dict(q=q,relation_id=rec['relation_id'],terms=len(O),zeros=len(zeros)))
   out['operator_checks'].append(dict(q=q,kind='extremum',identifier=rec['relation_id'],coefficients=operator_coefficients(A,T)))
   out['original_chart_determinants']+=4;out['full_projective_point_checks']+=sum(q**k for k in range(4))
  for rec in [r for r in moore if r['q']==q]:
   T=rec['section'];O,_=octic(A,P,T);terms={P.exponents(e):c for e,c in O.items()};N=norm_form(F,[x for x,y in T]);Q=divide(terms,N,q)
   assert all(sum(m)==2 for m in Q)
   zero=0
   for v in projective(q,4):
    n=eval_poly(N,v,q);assert n
    assert eval_poly(terms,v,q)==n*eval_poly(Q,v,q)%q
    zero+=eval_poly(Q,v,q)==0
   assert zero==rec['zeros']
   co=operator_coefficients(A,T);assert co[1]==0
   out['moore'].append(dict(q=q,lambda_=rec['lambda'],rank=rec['rank'],section=T,quadratic=[[list(m),Q[m]]for m in sorted(Q)],norm_terms=len(N),octic_terms=len(O),zeros=zero,quadratic_identically_zero=not Q))
   out['operator_checks'].append(dict(q=q,kind='Moore',identifier=rec['lambda'],coefficients=co))
   out['original_chart_determinants']+=4;out['full_projective_point_checks']+=sum(q**k for k in range(4))
  print('geometry q',q,'complete',flush=True)
 (WORK/'geometry.json').write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__':main()
