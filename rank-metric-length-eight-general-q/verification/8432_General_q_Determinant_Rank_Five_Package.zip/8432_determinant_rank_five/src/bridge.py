import sys,json,itertools,struct,collections
from pathlib import Path
PACKAGE=Path(__file__).resolve().parents[1]
BASE=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else PACKAGE/'results'
sys.path.insert(0,str(PACKAGE/'vendor'))
from algebra import Algebra
from tower_arithmetic import rank,rref,projective

def invmat(K,M):
 n=len(M);R,p=rref(K,[list(r)+[int(i==j)for j in range(n)]for i,r in enumerate(M)],2*n)
 assert p[:n]==list(range(n));return [r[n:]for r in R]
def mm(A,B,q):return [[sum(x*y for x,y in zip(r,c))%q for c in zip(*B)]for r in A]
def ns(K,M,n):
 R,p=rref(K,M,n);out=[]
 for j in range(n):
  if j in p:continue
  v=[0]*n;v[j]=1
  for row,k in zip(R,p):v[k]=K.neg[row[j]]
  out.append(v)
 return out

def solve(K,M,y):
 n=len(M[0]);R,p=rref(K,[list(r)+[v]for r,v in zip(M,y)],n+1)
 assert n not in p
 x=[0]*n
 for row,j in zip(R,p):x[j]=row[n]
 return x

def bil(R,x,y,q):return sum(x[i]*R[i][j]*y[j]for i in range(len(x))for j in range(len(x)))%q

def witt(K,R):
 q=K.q;n=len(R);e=next(list(v)for v in projective(q,n)if bil(R,v,v,q)==0)
 j=next(j for j in range(n)if sum(e[i]*R[i][j]for i in range(n))%q)
 f=[0]*n;f[j]=K.inv[sum(e[i]*R[i][j]for i in range(n))%q]
 s=bil(R,f,f,q)*K.inv[2]%q;f=[(v-s*u)%q for u,v in zip(e,f)]
 assert bil(R,e,f,q)==1 and bil(R,f,f,q)==0
 C=ns(K,mm([e,f],R,q),n)
 R1=mm(mm(C,R,q),list(zip(*C)),q)
 if n==3:P=[e,f]+C
 else:
  Pc=witt(K,R1);P=[e,f]+mm(Pc,C,q)
 return P

def unrank(i,q,n):
 for lead in range(n):
  cnt=q**(n-lead-1)
  if i<cnt:break
  i-=cnt
 v=[0]*n;v[lead]=1
 for j in range(lead+1,n):v[j]=i%q;i//=q
 assert i==0
 return v

def index(v,q):
 j=next(i for i,x in enumerate(v)if x);iv=pow(v[j],-1,q);v=[x*iv%q for x in v]
 return sum(q**(len(v)-i-1)for i in range(j))+sum(v[i]*q**(i-j-1)for i in range(j+1,len(v)))

def matrixfromcoeff(co,rb,q):
 flat=[sum(co[k]*rb[k][j]for k in range(9))%q for j in range(15)]
 R=[[0]*5 for _ in range(5)];t=0
 for i in range(5):
  for j in range(i,5):R[i][j]=R[j][i]=flat[t];t+=1
 return R

def reconstruct(A,data,id):
 q=A.q;F=A.F;K=A.K;D=data['D_basis'];R=matrixfromcoeff(unrank(id,q,9),data['relation_basis'],q)
 P=witt(K,R);G=mm(mm(P,R,q),list(zip(*P)),q);a=G[4][4]
 expected=[[0]*5 for _ in range(5)];expected[0][1]=expected[1][0]=expected[2][3]=expected[3][2]=1;expected[4][4]=a
 assert G==expected and a
 C=[[0]*6 for _ in range(5)];C[0][0]=1;C[1][5]=1;C[2][1]=1;C[3][4]=q-1;C[4][2]=1;C[4][3]=a*K.inv[2]%q
 B=mm(invmat(K,P),C,q)
 J=[[0]*6 for _ in range(6)]
 for i,j,s in [(0,5,1),(1,4,q-1),(2,3,1)]:J[i][j]=J[j][i]=s
 assert mm(mm(B,J,q),list(zip(*B)),q)==R
 be=[F.dot(D,[B[i][j]for i in range(5)])for j in range(6)]
 assert F.add(A.sub(F.mul(be[0],be[5]),F.mul(be[1],be[4])),F.mul(be[2],be[3]))==0
 beta=[[0]*4 for _ in range(4)];h=0
 for i in range(4):
  for j in range(i+1,4):beta[i][j]=be[h];beta[j][i]=F.neg(be[h]);h+=1
 p,r=next((i,j)for i in range(4)for j in range(i+1,4)if beta[i][j]);iv=F.inv(beta[p][r])
 T=[(F.neg(F.mul(beta[r][i],iv)),beta[p][i])for i in range(4)]
 for i in range(4):
  for j in range(4):assert A.sub(F.mul(T[i][0],T[j][1]),F.mul(T[i][1],T[j][0]))==beta[i][j]
 z=0;hist=collections.Counter();points=[]
 for x in projective(q,4):
  v=[F.dot(x,[t[j]for t in T])for j in range(2)];l=next(i for i,c in enumerate(x)if c)
  S=[A.sub(F.mul(v[0],T[j][1]),F.mul(v[1],T[j][0]))for j in range(4)if j!=l]
  assert rank(K,[F.digits(s)for s in S])==3
  sr=rank(K,[F.digits(F.mul(S[i],S[j]))for i in range(3)for j in range(i,3)])
  hist[sr]+=1
  if sr<6:z+=1;points.append(list(x))
 assert z==data['maximum_nondegenerate'],(q,id,z,data['maximum_nondegenerate'])
 erank=A.kspan_rank(T+[(F.mul(F.mu,x),F.mul(F.mu,y))for x,y in T])
 return dict(q=q,relation_id=id,R=R,B=B,section=T,E_span_dimension=erank//2,zeros=z,square_hist=dict(hist),zero_points=points)

def samplebind(A,data,T):
 q=A.q;F=A.F;K=A.K
 be=[A.sub(F.mul(T[i][0],T[j][1]),F.mul(T[j][0],T[i][1]))for i in range(4)for j in range(i+1,4)]
 ann=A.kdual([(x,)for x in be],1);assert len(ann)==1;k=ann[0][0]
 b=[F.mul(k,x)for x in be];D=data['D_basis'];Dmat=list(zip(*[F.digits(x)for x in D]));cols=[solve(K,Dmat,F.digits(x))for x in b];B=list(zip(*cols))
 J=[[0]*6 for _ in range(6)]
 for i,j,s in [(0,5,1),(1,4,q-1),(2,3,1)]:J[i][j]=J[j][i]=s
 R=mm(mm(B,J,q),list(zip(*B)),q)
 assert len(rref(K,R,5)[0])==5
 flat=[R[i][j]for i in range(5)for j in range(i,5)]
 co=solve(K,list(zip(*data['relation_basis'])),flat)
 return index(co,q)

def main():
 out=dict(extrema=[],bindings=[])
 for q in [3,5,7]:
  A=Algebra(q);data=json.load(open(BASE/f'inc{q}.json'))
  for i in data['max_ids']:
   r=reconstruct(A,data,i);out['extrema'].append(r);print(q,i,r['zeros'],r['E_span_dimension'],flush=True)
 if (PACKAGE/'inputs/rank5_samples7.jsonl').exists():
  A=Algebra(7);data=json.load(open(BASE/'inc7.json'));counts=struct.unpack('<'+'H'*data['projective_relations'],(BASE/'inc7_counts.bin').read_bytes())
  for line in open(PACKAGE/'inputs/rank5_samples7.jsonl'):
   rec=json.loads(line)
   if rec['rank']!=5:continue
   i=samplebind(A,data,rec['section']);assert counts[i]==rec['zeros'],(i,counts[i],rec['zeros'])
   out['bindings'].append([rec['sequence'],i,rec['zeros']])
 (BASE/'bridge5_results.json').write_text(json.dumps(out,indent=2)+'\n');print('done',len(out['extrema']),len(out['bindings']))
if __name__=='__main__':main()
