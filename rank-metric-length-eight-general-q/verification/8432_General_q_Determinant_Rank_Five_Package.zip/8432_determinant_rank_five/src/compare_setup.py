import json,sys
from pathlib import Path
PACKAGE=Path(__file__).resolve().parents[1]
ROOT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else PACKAGE/'results'
sys.path.insert(0,str(PACKAGE/'vendor'))
from algebra import Algebra
from tower_arithmetic import rank,rref
sys.path.insert(0,str(PACKAGE/'src'))
from bridge import solve,mm,ns

def canonical(K,rows):return tuple(tuple(r)for r in rref(K,rows,len(rows[0]))[0])

def main():
 report=[];fields=json.load(open(PACKAGE/'inputs/polyfields.json'))
 for item in fields:
  q=item['q'];A=Algebra(q);F=A.F;K=A.K
  d=json.load(open(ROOT/f'inc{q}.json'));e=json.load(open(ROOT/f'ind{q}.json'))
  for key in ['planes','eligible_planes','projective_relations','incidence_updates','maximum_nondegenerate','square_rank_hist','restriction_rank_hist','histograms']:assert d[key]==e[key],(q,key)
  powers=item['power_basis_in_primary'];theta=item['theta'];v=0
  for c in reversed(item['minimal_polynomial']):v=F.add(F.mul(v,theta),c)
  assert v==0 and rank(K,[F.digits(x)for x in powers])==6
  cache={}
  def convert(x):
   if x in cache:return cache[x]
   z=x;digits=[]
   for _ in range(6):digits.append(z%q);z//=q
   y=F.dot(digits,powers);cache[x]=y;return y
  D2=[convert(x)for x in e['D_basis']];dc=list(zip(*(F.digits(x)for x in d['D_basis'])))
  L=list(zip(*(solve(K,dc,F.digits(x))for x in D2)))
  maps=[]
  for flat in e['relation_basis']:
   R=[[0]*5 for _ in range(5)];j=0
   for a in range(5):
    for b in range(a,5):R[a][b]=R[b][a]=flat[j];j+=1
   R1=mm(mm(L,R,q),list(zip(*L)),q);flat1=[R1[i][j]for i in range(5)for j in range(i,5)]
   maps.append(solve(K,list(zip(*d['relation_basis'])),flat1))
  transform=list(map(list,zip(*maps)));assert rank(K,transform)==9
  (ROOT/f'map{q}.txt').write_text(str(q)+'\n'+'\n'.join(' '.join(map(str,r))for r in transform)+'\n')
  Pset=set()
  for line in open(ROOT/f'inc{q}_planes.txt'):
   a=list(map(int,line.split()));sr=a[0];M=[a[1:6],a[6:11]];S=ns(K,M,5)
   fvals=[F.dot(r,d['D_basis'])for r in S];Pset.add((sr,canonical(K,[F.digits(x)for x in fvals])))
  Sset=set()
  for line in open(ROOT/f'ind{q}_spaces.txt'):
   a=list(map(int,line.split()));Sset.add((a[0],canonical(K,[F.digits(convert(x))for x in a[1:]])))
  assert Pset==Sset and len(Pset)==d['eligible_planes']
  report.append(dict(q=q,eligible_space_sets_equal=True,spaces_compared=len(Pset),coordinate_map=transform,histograms_equal=True))
  print(q,'actual eligible space sets equal',len(Pset),flush=True)
 (ROOT/'comparison_setup.json').write_text(json.dumps(report,indent=2)+'\n')
if __name__=='__main__':main()
