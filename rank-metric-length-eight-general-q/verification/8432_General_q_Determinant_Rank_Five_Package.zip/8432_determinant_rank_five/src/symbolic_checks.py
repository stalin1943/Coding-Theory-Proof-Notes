#!/usr/bin/env python3
"""Exact integer polynomial identities and complete-output mass checks."""
import itertools
import json
import math
import sys
from pathlib import Path


def add(a, b):
    z = [0] * max(len(a), len(b))
    for i, x in enumerate(a): z[i] += x
    for i, x in enumerate(b): z[i] += x
    while len(z) > 1 and not z[-1]: z.pop()
    return z


def mul(a, b):
    z = [0] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b): z[i + j] += x * y
    while len(z) > 1 and not z[-1]: z.pop()
    return z


def scale(a, c): return [c * x for x in a]
def sub(a, b): return add(a, scale(b, -1))
def th(n): return [1] * (n + 1)
def xp(n): return [0] * n + [1]
def ev(a, x):
    s = 0
    for c in reversed(a): s = s * x + c
    return s


def shift(a, k):
    r = [0]
    for i, c in enumerate(a):
        p = [1]
        for _ in range(i): p = mul(p, [k, 1])
        r = add(r, scale(p, c))
    return r


def determinant_expansion():
    """Compare symbolic 4x4 determinant with the six minor pair terms."""
    def mon(v): return tuple(sorted(v))
    def acc(P, key, c):
        P[key] = P.get(key, 0) + c
        if not P[key]: del P[key]
    left = {}
    for p in itertools.permutations(range(4)):
        sg = (-1) ** sum(p[i] > p[j] for i in range(4) for j in range(i+1, 4))
        acc(left, mon([4*i+p[i] for i in range(4)]), sg)
    right = {}
    for a, b in itertools.combinations(range(4), 2):
        c, d = [i for i in range(4) if i not in (a, b)]
        sg = (-1) ** (a+b+1)
        for ids, s in [([a,4+b],1), ([b,4+a],-1)]:
            for jds, t in [([8+c,12+d],1), ([8+d,12+c],-1)]:
                acc(right, mon(ids+jds), sg*s*t)
    assert left == right and len(left) == 24
    return len(left)


def main():
    assert __debug__, 'Assertions must be enabled.'
    dest = Path(sys.argv[1]); dest.mkdir(parents=True, exist_ok=True)
    t2 = th(2)
    # Eligible multiplication spaces: the three disjoint classes.
    eligible = add([1], mul(xp(1), mul(t2,t2)))
    classes = add([1], add(mul(add([1],xp(2)), t2), mul(add([-1],add(xp(1),xp(3))), t2)))
    assert eligible == classes
    n2 = add([1], xp(2))
    n3 = mul(xp(1), mul(n2,t2))
    n4 = mul(xp(2), mul(n2, add([-1],add(xp(2),xp(3)))))
    n5 = sub(sub(xp(8),xp(5)),xp(3))
    assert add(add(n2,n3),add(n4,n5)) == th(8)
    assert add(add(mul(n2,th(2)),mul(n3,th(1))),n4) == mul(th(4),th(3))
    moore_difference = sub(mul([-4,1], th(3)),mul([-3,1],[1,1,2]))
    assert moore_difference == [-1,-1,2,-5,1]
    positive_shift = shift(moore_difference,5)
    assert positive_shift == [44,144,77,15,1]
    assert all(c > 0 for c in positive_shift)
    records = []
    for q, maximum in [(3,28),(5,72),(7,122)]:
        a = json.loads((dest/f'inc{q}.json').read_text())
        b = json.loads((dest/f'ind{q}.json').read_text())
        hist = {int(k):{int(x):int(y) for x,y in h.items()} for k,h in a['histograms'].items()}
        assert hist == {int(k):{int(x):int(y) for x,y in h.items()} for k,h in b['histograms'].items()}
        assert a['eligible_planes'] == ev(eligible,q)
        assert a['projective_relations'] == ev(th(8),q)
        assert a['maximum_nondegenerate'] == maximum
        ranks = {r:sum(h.values()) for r,h in hist.items()}
        assert ranks == {2:ev(n2,q),3:ev(n3,q),4:ev(n4,q),5:ev(n5,q)}
        mass = sum(x*y for h in hist.values() for x,y in h.items())
        assert mass == a['incidence_updates'] == ev(eligible,q)*ev(th(5),q)
        assert a['restriction_rank_hist'] == {'3':ev(eligible,q)}
        assert a['planes'] == ((q**5-1)*(q**4-1))//((q**2-1)*(q-1))
        records.append({'q':q,'eligible':ev(eligible,q),'all_relations':ev(th(8),q),
                        'rank_counts':ranks,'mass':mass,'maximum':maximum,
                        'all_polynomial_and_mass_checks':True})
    exponent_checks = [q for q in range(3,202,2) if math.gcd(q*q+1,q**6-1)==2]
    assert len(exponent_checks)==100
    out = {'polynomial_identities_over_Z':True,'eligible_polynomial':eligible,
           'rank_polynomials':{'2':n2,'3':n3,'4':n4,'5':n5},
           'moore_difference':moore_difference,'positive_at_5_plus_x':positive_shift,
           'four_by_four_minor_identity_terms':determinant_expansion(),
           'odd_integer_gcd_test_values':exponent_checks,
           'integer_tests_are_not_additional_finite_field_classifications':True,
           'complete_output_checks':records}
    (dest/'symbolic_checks.json').write_text(json.dumps(out,indent=2)+'\n')
    print('integer polynomial identities, minor identity, all complete masses passed')

if __name__ == '__main__': main()
