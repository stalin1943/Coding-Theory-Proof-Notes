#include <vector>
#include <array>
#include <cassert>
#include <fstream>
#include <iostream>
#include <cstdint>
#include <string>
using namespace std;
vector<uint16_t> load(const string&p,int n){ifstream f(p,ios::binary);assert(f);vector<uint16_t>a(n);for(int i=0;i<n;i++){int x=f.get(),y=f.get();assert(x>=0&&y>=0);a[i]=x+256*y;}assert(f.get()==EOF);return a;}
int main(int argc,char**argv){assert(argc==5);ifstream f(argv[1]);int q;f>>q;int T[9][9];for(auto&r:T)for(int &x:r)f>>x;int pw[10];pw[0]=1;for(int j=1;j<=9;j++)pw[j]=pw[j-1]*q;int n=(pw[9]-1)/(q-1);auto a=load(argv[2],n),b=load(argv[3],n);vector<array<int,9>>tab[3];for(int block=0;block<3;block++){tab[block].resize(pw[3]);for(int c=0;c<pw[3];c++){int u=c;int v[3];for(int j=0;j<3;j++){v[j]=u%q;u/=q;}for(int i=0;i<9;i++)for(int j=0;j<3;j++)tab[block][c][i]=(tab[block][c][i]+T[i][3*block+j]*v[j])%q;}}
int off0[9],n0=0;for(int j=0;j<9;j++){off0[j]=n0;n0+=pw[8-j];}vector<int>inv(q);for(int j=1;j<q;j++)for(int k=1;k<q;k++)if(j*k%q==1)inv[j]=k;int sec=0;uint64_t sum=0;for(int last=0;last<9;last++)for(int code=0;code<pw[last];code++,sec++){int label=code+pw[last];int u0=label%pw[3],u1=label/pw[3]%pw[3],u2=label/pw[6];array<int,9>v;int lead=9;for(int j=0;j<9;j++){v[j]=(tab[0][u0][j]+tab[1][u1][j]+tab[2][u2][j])%q;if(v[j]&&lead==9)lead=j;}assert(lead<9);int norm=inv[v[lead]],id=off0[lead];for(int j=lead+1;j<9;j++)id+=(v[j]*norm%q)*pw[j-lead-1];assert(a[id]==b[sec]);sum+=a[id];}assert(sec==n);ofstream out(argv[4]);out<<"{\"q\":"<<q<<",\"projective_arrays_equal_after_field_and_basis_change\":true,\"entries_compared\":"<<n<<",\"sum_of_entries\":"<<sum<<"}\n";cout<<q<<" compared "<<n<<" all match\n";}
