# Heavy-projection capacity: q = 3 and q = 4

This package proves the new heavy-special-section exclusion described in `PROOF_zh.md` and `THEOREMS_en.tex`. It does **not** complete the general q=3,4 existence classification. Non-Hermitian scattered special sections remain.

## Read first

`PROOF_zh.md` gives the hypotheses, the projection-injectivity theorem, the exhaustive finite lemma, and the precise connection to the supplied project baseline. `results/summary.json` contains the complete aggregated joint distributions and the final inequalities. Each `spectrum_*` file retains the full joint distribution `(m(V), b(V), multiplicity)` for every scalar type.

`inputs/` preserves the two directly used research records. The previous large global computations are not rerun here. `PROVENANCE.json` distinguishes copied arithmetic from new code.

## Full recomputation

From this directory run:

```bash
python verify.py --work /absolute/path/to/new_or_empty_directory --jobs 1
```

A Python 3 standard-library environment and a C++17 compiler (GCC or Clang) are required. No Sage, optimization solver, NumPy or OpenMP is used. `--jobs 2` runs two complete tasks concurrently. The dense compatibility table in a q=4 task contains 93,093 x 425 unsigned 64-bit words; the rank-two-fibre array contains 22,940,820 32-bit entries. Memory is bounded and reused between scalar types; choose one job on a memory-constrained personal computer.

Assertions must remain enabled. Do not use `python -O` or `-DNDEBUG`. The verifier enables standard-container assertions. `--sanitize` additionally enables undefined-behaviour checks. `--portable` omits `-march=native`; exact results are unchanged, but hardware population-count optimization may then be unavailable.

The verifier compiles sources, regenerates all four complete spectra, matches every scalar type through an explicit field isomorphism, reconstructs all selected actual spaces from their coset parameters, and checks them geometrically. Saved distributions are used only for the final comparison.

## Saved-file check is a different task

```bash
python verify.py --check-saved
```

This verifies file digests and final numerical implications. It does not rerun the finite classification and should not be described as a full proof replay.

## What the finite computation covers

For q=3, all 31 scalar types and all 3^10 cosets for each type are included. For q=4, all 69 types and all 4^10 cosets are included. Both include the quadratic-subfield type. Cosets containing a rank-zero or rank-one matrix are marked inadmissible by a complete enumeration, because they correspond to a projected point of weight at least three.

The primary implementation enumerates every rank-two matrix by its image plane and a surjective 2 x 4 matrix. The second implementation uses its row plane and an injective 4 x 2 matrix, with different finite-field defining polynomials and extension order. Joint spectra are compared type by type, rather than pretending unrelated coset indices are identical.

The direct geometric check covers all global capacity maximizers and one maximizer of each other type: 76 ternary and 237 quaternary spaces. It enumerates their actual projective points, recovers fibres, and tests actual four-subspaces. This is not a third complete coset classification.

An extra ternary local space has capacity 612 when the E-plane projection hypothesis is dropped. It is included to make the scope limitation explicit; it is not an eight-dimensional intersecting code.
