#!/usr/bin/env python3
"""Recompute both complete local joint spectra, then verify actual geometry.

Default: full recomputation.  --check-saved only checks supplied files and
numerical implications; it is not equivalent to a full recomputation.
All arithmetic is exact. Assertions must remain enabled.
"""
from __future__ import annotations
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import argparse, hashlib, json, os, shutil, subprocess, sys, time
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'))

def sha(p:Path)->str:
    h=hashlib.sha256()
    with p.open('rb') as f:
        for s in iter(lambda:f.read(1<<20),b''):h.update(s)
    return h.hexdigest()

def check_manifest()->int:
    mp=ROOT/'MANIFEST.json'
    if not mp.exists():return 0
    m=json.loads(mp.read_text())
    for rel,h in m.items():
        assert sha(ROOT/rel)==h,('file digest mismatch',rel)
    return len(m)

def run(cmd:list[str],log:Path)->dict:
    t=time.monotonic()
    with log.open('w',encoding='utf-8') as out:
        p=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,check=False)
    if p.returncode:
        raise RuntimeError(f'Failed ({p.returncode}): {cmd}; see {log}')
    return {'command':cmd,'return_code':p.returncode,'elapsed_seconds':round(time.monotonic()-t,3),'log':log.name}

def main():
    if not __debug__:raise RuntimeError('Run without python -O.')
    pa=argparse.ArgumentParser(description=__doc__)
    pa.add_argument('--work',type=Path)
    pa.add_argument('--jobs',type=int,default=1)
    pa.add_argument('--compiler')
    pa.add_argument('--sanitize',action='store_true')
    pa.add_argument('--portable',action='store_true',help='Do not pass -march=native.')
    pa.add_argument('--check-saved',action='store_true')
    a=pa.parse_args()
    checked=check_manifest()
    if a.check_saved:
        d=json.loads((ROOT/'results/summary.json').read_text())
        x,y=d['finite_data']
        assert x['allowed_cosets']==1732968 and x['max_b']==44 and x['max_b_plus_m_with_degree_bound']==52
        assert y['allowed_cosets']==70867320 and y['max_b']==7 and y['max_b_plus_m_with_degree_bound']==81
        assert d['ternary_contradiction']==[68,52] and d['quaternary_contradiction']==[134,7]
        print(json.dumps({'mode':'saved files only, NOT full recomputation','manifest_files_checked':checked,'numerical_implications_pass':True},indent=2))
        return
    if a.work is None:pa.error('--work is required for full recomputation')
    if a.jobs not in (1,2):pa.error('--jobs must be 1 or 2')
    w=a.work.resolve()
    if w.exists() and any(w.iterdir()):pa.error('--work must be absent or empty')
    (w/'bin').mkdir(parents=True,exist_ok=True);(w/'results').mkdir();(w/'logs').mkdir()
    cc=a.compiler or shutil.which('g++') or shutil.which('clang++')
    if not cc:raise RuntimeError('A C++17 compiler (g++ or clang++) is required.')
    flags=['-O3','-std=c++17','-D_GLIBCXX_ASSERTIONS']
    if not a.portable:flags+=['-march=native']
    if a.sanitize:flags+=['-fsanitize=undefined','-fno-sanitize-recover=all']
    ext='.exe' if os.name=='nt' else ''
    stages=[]
    for name in ('capacity_primary','capacity_independent','direct_geometry'):
        stages.append(run([cc,*flags,str(ROOT/f'src/{name}.cpp'),'-o',str(w/'bin'/f'{name}{ext}')],w/f'logs/compile_{name}.log'))
    tasks=[]
    for q in (3,4):
        for kind in ('primary','independent'):
            nm=f'spectrum_{kind}_q{q}'
            tasks.append(([str(w/'bin'/f'capacity_{kind}{ext}'),str(q),str(w/f'results/{nm}.json')],w/f'logs/{nm}.log'))
    with ThreadPoolExecutor(max_workers=a.jobs) as pool:
        for result in pool.map(lambda x:run(*x),tasks):stages.append(result)
    stages.append(run([sys.executable,str(ROOT/'src/summarize.py'),str(w/'results')],w/'logs/compare_joint_spectra.log'))
    stages.append(run([sys.executable,str(ROOT/'src/prepare_geometry.py'),str(w/'results')],w/'logs/prepare_actual_spaces.log'))
    for name in ('geometric_inputs_q3','geometric_inputs_q4','scope_example'):
        dest={'geometric_inputs_q3':'direct_geometry_q3','geometric_inputs_q4':'direct_geometry_q4','scope_example':'scope_example_check'}[name]
        stages.append(run([str(w/'bin'/f'direct_geometry{ext}'),str(w/f'results/{name}.txt'),str(w/f'results/{dest}.json')],w/f'logs/{dest}.log'))
    stages.append(run([sys.executable,str(ROOT/'src/check_exterior_normal_form.py'),str(w/'results')],w/'logs/exterior_normal_form_checks.log'))
    files={}
    for p in sorted((w/'results').iterdir()):
        if not p.is_file():continue
        orig=ROOT/'results'/p.name
        if orig.exists():
            if p.suffix=='.json':assert json.loads(p.read_text())==json.loads(orig.read_text()),('mathematical output mismatch',p.name)
            else:assert p.read_bytes()==orig.read_bytes(),('output mismatch',p.name)
            files[p.name]=sha(p)
    report={'status':'PASS','mode':'full independent recomputation of both complete joint spectra and selected actual geometry','manifest_files_checked':checked,'stages':stages,'exact_outputs_compared':files,'historical_global_proof_recomputed':False,'all_q_classification_complete':False}
    (w/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'status':'PASS','exact_output_files':len(files),'report':str(w/'verification.json')},indent=2))
if __name__=='__main__':main()
