#!/usr/bin/env python3
"""Exact coefficient checks of the twelve-parameter exterior-heavy-point reduction.
This is a bounded collection of examples, not a classification of remaining graphs.
"""
from pathlib import Path
import json,sys,random
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'vendor'))
from graph_independent_arithmetic import Field
from tower_arithmetic import Base,rref

def erref(F,rows,n):
    a=[r[:] for r in rows];p=[];k=0
    for j in range(n):
        z=next((i for i in range(k,len(a)) if a[i][j]),None)
        if z is None:continue
        a[k],a[z]=a[z],a[k];c=F.ei[a[k][j]];a[k]=[F.em[c][x] for x in a[k]]
        for i in range(len(a)):
            if i!=k and a[i][j]:
                c=a[i][j];a[i]=[F.ea[x][F.en[F.em[c][y]]] for x,y in zip(a[i],a[k])]
        p.append(j);k+=1
        if k==len(a):break
    return a[:k],p

def check(results):
    records=[]
    for q in (3,4):
        for alt in (False,True):
            meta=dict(q=q,cubic_polynomial=([1,2,0,1] if q==3 else [1,0,2,1]) if alt else [1,0,2 if q==3 else 1,1],beta=1 if alt else (0 if q==3 else 1),nu=(1 if q==3 else 3) if alt else 2)
            F=Field(meta);K=Base(q);rng=random.Random(91001+q+100*alt);bs=[1,F.xi,F.mul(F.xi,F.xi)]
            for rank_target in (0,1,2):
                for example in range(2):
                    while True:
                        V=[(rng.randrange(q**6),rng.randrange(q**6)) for _ in range(6)]
                        ev=[F.dig(x)+F.dig(y) for x,y in V]
                        _,pv=erref(F,ev,6)
                        if len(pv)==6:break
                    # Prescribe a map V -> EB/B with the requested rank, then hide it by a shear.
                    coeff=[[0]*6 for _ in range(2)]
                    if rank_target:
                        coeff[0][0]=1
                        for j in range(1,6):coeff[0][j]=rng.randrange(q)
                    if rank_target==2:
                        coeff[1][1]=1
                        for j in range(2,6):coeff[1][j]=rng.randrange(q)
                    a,b=rng.randrange(q**6),rng.randrange(q**6)
                    desired=[];original=[]
                    for j,(x,y) in enumerate(V):
                        w=F.add(F.add(rng.randrange(q),F.scale(rng.randrange(q),F.xi)),F.add(F.scale(coeff[0][j],F.mu),F.scale(coeff[1][j],F.mul(F.mu,F.xi))))
                        desired.append(w);original.append(F.sub(F.sub(w,F.mul(a,x)),F.mul(b,y)))
                    mat=[]
                    for j,(x,y) in enumerate(V):
                        row=[F.dig(F.mul(c,x))[2] for c in bs]+[F.dig(F.mul(c,y))[2] for c in bs]
                        row.append(F.en[F.dig(original[j])[2]]);mat.append(row)
                    rr,piv=erref(F,mat,6);assert len(piv)==6
                    solution=[0]*6
                    for row,j in zip(rr,piv):solution[j]=row[6]
                    aa=F.pack(solution[:3]);bb=F.pack(solution[3:]);assert (aa,bb)==(a,b)
                    adjusted=[F.add(z,F.add(F.mul(aa,x),F.mul(bb,y))) for z,(x,y) in zip(original,V)]
                    assert adjusted==desired and all(F.dig(z)[2]==0 for z in adjusted)
                    qm=[[F.dig(z)[i]//q for z in adjusted] for i in range(2)]
                    _,pv=rref(K,qm,6);assert len(pv)==rank_target
                    U=[(1,0,0),(F.xi,0,0)]+[(z,x,y) for z,(x,y) in zip(adjusted,V)]
                    ku=[F.flat(u) for u in U]
                    assert F.rank(ku)==8
                    assert F.rank(ku+[F.flat([F.mul(F.mu,x) for x in u]) for u in U])==16
                    first_rank=F.rank([F.flat([u[0]]) for u in U])
                    assert first_rank==2+rank_target
                    records.append(dict(q=q,alternate_field=alt,map_rank=rank_target,V=V,original_lifts=original,removing_shear=[aa,bb],adjusted_lifts=adjusted,special_section_dimension=8-first_rank))
    out={'examples':len(records),'records':records,'all_coefficient_identities_pass':True,'complete_classification':False}
    (results/'exterior_normal_form_checks.json').write_text(json.dumps(out,indent=2)+'\n')
    print('Exterior normal form:',len(records),'exact examples')
if __name__=='__main__':check(Path(sys.argv[1]))
