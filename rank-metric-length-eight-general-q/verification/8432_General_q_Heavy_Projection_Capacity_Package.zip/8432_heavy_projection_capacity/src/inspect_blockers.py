from pathlib import Path
import sys,json,collections
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'vendor'))
from graph_independent_arithmetic import Field,proj
from tower_arithmetic import Base,rref
ROOT=Path(__file__).resolve().parents[1]
def recover(q,lam,sid,domain_annihilator=None):
 meta=dict(q=q,cubic_polynomial=[1,0,2 if q==3 else 1,1],beta=0 if q==3 else 1,nu=2)
 F=Field(meta);K=Base(q);fb=[q**j for j in range(6)];Z=[1,F.mu,F.xi,F.mul(F.mu,F.xi)]
 if domain_annihilator is not None:
  def tr(x):
   ans=0
   for i in range(6):ans=F.add(ans,F.pow(x,q**i))
   assert ans<q
   return ans
  rows=[[tr(F.mul(c,b)) for b in fb] for c in (1,domain_annihilator)]
  rr,pp=rref(K,rows,6);assert len(pp)==2
  Z=[]
  for j in range(6):
   if j in pp:continue
   vv=[0]*6;vv[j]=1
   for i,pi in enumerate(pp):vv[pi]=K.sub(0,rr[i][j])
   Z.append(sum(x*q**k for k,x in enumerate(vv)))
 cr,pc=rref(K,[F.flat([x]) for x in [1,lam]],6);fc=[i for i in range(6) if i not in pc]
 c=[sum(x*q**j for j,x in enumerate(r)) for r in cr]
 def quotient(x):
  a=F.flat([x]);
  for row,p in zip(cr,pc):
   k=a[p];a=[K.sub(x,K.mul[k][y]) for x,y in zip(a,row)]
  return [a[j] for j in fc]
 code=[]
 for v in fb:
  cols=[quotient(F.mul(v,z)) for z in Z]
  code.append([cols[j][i] for i in range(4) for j in range(4)])
 co,pm=rref(K,code,16);assert len(co)==6
 fm=[j for j in range(16) if j not in pm];flat=[0]*16;v=sid
 for j in fm:flat[j]=v%q;v//=q
 assert v==0
 phis=[]
 for j in range(4):
  ds=[0]*6
  for i,k in enumerate(fc):ds[k]=flat[4*i+j]
  phis.append(sum(x*q**i for i,x in enumerate(ds)))
 V=[(c[0],0),(c[1],0)]+list(zip(phis,Z))
 return F,V
