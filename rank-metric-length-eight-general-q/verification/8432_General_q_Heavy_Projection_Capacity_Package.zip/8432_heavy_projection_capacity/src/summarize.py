#!/usr/bin/env python3
"""Match complete local joint spectra through an explicit field isomorphism."""
from pathlib import Path
from collections import Counter
import json,sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'vendor'))
from graph_independent_arithmetic import Field

def compare(results:Path,q:int)->dict:
    a=json.loads((results/f'spectrum_primary_q{q}.json').read_text())
    b=json.loads((results/f'spectrum_independent_q{q}.json').read_text())
    pm=dict(q=q,cubic_polynomial=[1,0,2 if q==3 else 1,1],beta=0 if q==3 else 1,nu=2)
    im=dict(q=q,cubic_polynomial=[1,2,0,1] if q==3 else [1,0,2,1],beta=1,nu=1 if q==3 else 3)
    P,F=Field(pm),Field(im)
    def peval(cs,x):
        z=0
        for c in reversed(cs):z=F.add(F.mul(z,x),c)
        return z
    eta=next(x for x in range(q,q*q) if F.sub(F.sub(F.mul(x,x),F.mul(pm['beta'],x)),pm['nu'])==0)
    xi=next(x for x in range(1,q**6) if F.pow(x,q**3)==x and F.pow(x,q)!=x and peval(pm['cubic_polynomial'],x)==0)
    ib=[1,eta,xi,F.mul(eta,xi),F.mul(xi,xi),F.mul(eta,F.mul(xi,xi))]
    def convert(x):
        z=0
        for v in ib:z=F.add(z,F.scale(x%q,v));x//=q
        assert x==0
        return z
    images=[convert(x) for x in range(q**6)]
    assert len(set(images))==q**6
    for i in range(6):
        for j in range(6):assert images[P.mul(q**i,q**j)]==F.mul(ib[i],ib[j])
    def plane(lam):return {F.add(i,F.scale(j,lam)) for i in range(q) for j in range(q)}
    typemap={}
    for r in b['types']:
        c=plane(r['lambda'])
        for u in c-{0}:
            iv=F.inv(u)
            for v in c-{0}:
                z=F.mul(v,iv)
                if z>=q:
                    assert z not in typemap or typemap[z]==r['lambda']
                    typemap[z]=r['lambda']
    assert len(typemap)==q**6-q
    bm={r['lambda']:r for r in b['types']};mapping=[]
    globalhist=Counter();globalpairs=Counter();globaljoint=Counter()
    for r in a['types']:
        lmap=images[r['lambda']];lr=typemap[lmap];s=bm[lr]
        for k in ('histogram','joint_histogram','actual_joint_spectrum','max_scattered_blockers','joint_max'):
            assert r[k]==s[k],(q,r['lambda'],lr,k)
        cr=plane(lr)
        alpha=next(c for c in sorted(cr-{0}) if F.mul(c,lmap) in cr)
        assert {F.mul(alpha,images[x]) for x in {P.add(i,P.scale(j,r['lambda'])) for i in range(q) for j in range(q)}}==cr
        mapping.append(dict(primary_lambda=r['lambda'],independent_lambda=lr,converted_lambda=lmap,output_scaling=alpha))
        h=Counter();jh=Counter()
        for m,cap,n in r['actual_joint_spectrum']:
            assert n>0 and m>=1 and cap>=0
            h[cap]+=n
            if m<=1+q+q*q+q*q*q:jh[m+cap]+=n
            globalpairs[m,cap]+=n
        assert dict(h)=={int(k):v for k,v in r['histogram'].items()}
        assert dict(jh)=={int(k):v for k,v in r['joint_histogram'].items()}
        assert max(h)==r['max_scattered_blockers'] and max(jh)==r['joint_max']
        globalhist.update(h);globaljoint.update(jh)
    assert len(mapping)==q**3+q+1
    assert len({r['independent_lambda'] for r in mapping})==len(mapping)
    scale_z=next(t for t in range(1,q**4) if F.mul(t,xi)<q**4)
    result=dict(q=q,primary_field=pm,independent_field=im,primary_mu_image=eta,primary_xi_image=xi,domain_scaling=scale_z,types=len(mapping),mapping=mapping,all_joint_spectra_agree=True,field_map_is_bijective=True,basis_product_checks=36,all_cosets=len(mapping)*q**10,allowed_cosets=sum(globalhist.values()),max_b=max(globalhist),max_b_plus_m_with_degree_bound=max(globaljoint),capacity_histogram={str(k):v for k,v in sorted(globalhist.items())},actual_joint_spectrum=[[m,cap,n] for (m,cap),n in sorted(globalpairs.items())])
    (results/f'comparison_q{q}.json').write_text(json.dumps(result,indent=2)+'\n')
    return result

def build(results:Path)->dict:
    comp=[compare(results,q) for q in (3,4)]
    assert comp[0]['max_b']==44 and comp[0]['max_b_plus_m_with_degree_bound']==52
    assert comp[1]['max_b']==7 and comp[1]['max_b_plus_m_with_degree_bound']==81
    lower3=[161-31*s for s in (1,2,3)]
    lower4=[341-69*s for s in (1,2,3)]
    assert min(lower3)>52 and min(lower4)>7
    out=dict(result_scope='q=3,4: no heavy point in the distinguished four-section whose projection is an E-plane, under s<=3 and the stated intersection/distance hypotheses. General non-Hermitian scattered sections remain unresolved.',finite_data=comp,ternary_required_joint_lower_bounds=lower3,quaternary_required_scattered_section_lower_bounds=lower4,ternary_contradiction=[min(lower3),52],quaternary_contradiction=[min(lower4),7],all_q_classification_complete=False)
    (results/'summary.json').write_text(json.dumps(out,indent=2)+'\n')
    return out
if __name__=='__main__':
    result=build(Path(sys.argv[1]))
    for x in result['finite_data']:print(x['q'],x['types'],x['allowed_cosets'],x['max_b'],x['max_b_plus_m_with_degree_bound'])
