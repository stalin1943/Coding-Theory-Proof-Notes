#include "common_alt.hpp"
using Row=array<int,16>;
vector<Row> rr(const Field&f,vector<Row>a,int n,vector<int>&piv){int r=0;for(int j=0;j<n&&r<(int)a.size();j++){int t=r;while(t<(int)a.size()&&!a[t][j])t++;if(t==(int)a.size())continue;swap(a[r],a[t]);int iv=f.ki[a[r][j]];for(int k=j;k<n;k++)a[r][k]=f.km[iv][a[r][k]];for(int i=0;i<(int)a.size();i++)if(i!=r&&a[i][j]){int c=a[i][j];for(int k=j;k<n;k++)a[i][k]=f.ka[a[i][k]][f.kn[f.km[c][a[r][k]]]];}piv.push_back(j);r++;}a.resize(r);return a;}
int main(int argc,char**argv){assert(argc>=3);int q=atoi(argv[1]);Field f=makefield(q);auto start=chrono::steady_clock::now();int V=q*q*q*q,ALL=1,CH=1;for(int i=0;i<10;i++)ALL*=q;for(int i=0;i<5;i++)CH*=q;
 vector<uint16_t>add(q==3?CH*CH:1);if(q==3)for(int a=0;a<CH;a++)for(int b=0;b<CH;b++){int x=a,y=b,z=0,p=1;for(int j=0;j<5;j++){z+=p*f.ka[x%q][y%q];x/=q;y/=q;p*=q;}add[a*CH+b]=z;}
 auto plus=[&](int a,int b)->int{if(q==4)return a^b;return add[(a%CH)*CH+b%CH]+CH*add[(a/CH)*CH+b/CH];};
 vector<array<int,4>>vec(V);for(int a=0;a<V;a++){int x=a;for(int j=0;j<4;j++){vec[a][j]=x%q;x/=q;}}
 vector<pair<int,int>>valid;for(int a=1;a<V;a++)for(int b=1;b<V;b++){int j=0;while(!vec[a][j])j++;int c=f.km[vec[b][j]][f.ki[vec[a][j]]];bool dep=true;for(int k=0;k<4;k++)if(f.km[c][vec[a][k]]!=vec[b][k])dep=false;if(!dep)valid.push_back({a,b});}
 vector<pair<int,int>>planes;vector<array<array<int,4>,2>>kerbasis;map<uint64_t,int>kernelIDs;
 for(int p=0;p<4;p++)for(int r=p+1;r<4;r++){vector<pair<int,int>>slots;for(int j=p+1;j<4;j++)if(j!=r)slots.push_back({0,j});for(int j=r+1;j<4;j++)slots.push_back({1,j});int lim=1;for(auto v:slots)lim*=q;for(int x=0;x<lim;x++){int a[2][4]={};a[0][p]=a[1][r]=1;int t=x;for(auto[i,j]:slots){a[i][j]=t%q;t/=q;}int u=0,v=0,w=1;array<array<int,4>,2>bb{};for(int j=0;j<4;j++){u+=w*a[0][j];v+=w*a[1][j];w*=q;bb[0][j]=a[0][j];bb[1][j]=a[1][j];}kernelIDs[uint64_t(u)*V+v]=planes.size();planes.push_back({u,v});kerbasis.push_back(bb);}}
 vector<int>kernel(V*V,-1);for(auto[u,v]:valid){vector<Row>a(2);for(int j=0;j<4;j++){a[0][j]=vec[u][j];a[1][j]=vec[v][j];}vector<int>pv;a=rr(f,a,4,pv);vector<Row>bs;for(int j=0;j<4;j++)if(find(pv.begin(),pv.end(),j)==pv.end()){Row c{};c[j]=1;for(int k=0;k<2;k++)c[pv[k]]=f.kn[a[k][j]];bs.push_back(c);}pv.clear();bs=rr(f,bs,4,pv);int b0=0,b1=0,w=1;for(int j=0;j<4;j++){b0+=w*bs[0][j];b1+=w*bs[1][j];w*=q;}kernel[u*V+v]=kernelIDs.at(uint64_t(b0)*V+b1);}
 // Enumerate all two-spaces of K^6; a dual plane annihilates one four-space.
 vector<pair<int,int>>lines,targets;unordered_map<uint64_t,int>lineIDs;
 for(int p=0;p<6;p++)for(int r=p+1;r<6;r++){vector<pair<int,int>>slots;for(int j=p+1;j<6;j++)if(j!=r)slots.push_back({0,j});for(int j=r+1;j<6;j++)slots.push_back({1,j});int lim=1;for(auto a:slots)lim*=q;for(int n=0;n<lim;n++){Vec a{},b{};a[p]=b[r]=1;int t=n;for(auto[i,j]:slots){(i==0?a:b)[j]=t%q;t/=q;}int aa=enc(f,a),bb=enc(f,b);lineIDs[uint64_t(aa)*f.Q+bb]=lines.size();lines.push_back({aa,bb});int det=f.ka[f.km[a[0]][b[1]]][f.kn[f.km[a[1]][b[0]]]];if(det==0&&(a[0]||a[1]||b[0]||b[1]))targets.push_back({aa,bb});}}
 reverse(targets.begin(),targets.end());int NT=targets.size(),NW=(NT+63)/64,NL=lines.size();cerr<<"lines="<<NL<<" targets="<<NT<<" words="<<NW<<"\n";
 vector<uint8_t>dot(f.Q*f.Q);for(int a=0;a<f.Q;a++)for(int b=0;b<f.Q;b++){int z=0;for(int j=0;j<6;j++)z=f.ka[z][f.km[f.digits[a][j]][f.digits[b][j]]];dot[a*f.Q+b]=z;}
 vector<uint64_t>compatible(uint64_t(NL)*NW);
 for(int i=0;i<NL;i++){auto[u,v]=lines[i];auto du=&dot[u*f.Q],dv=&dot[v*f.Q];uint64_t *buf=&compatible[uint64_t(i)*NW];for(int j=0;j<NT;j++){auto[a,b]=targets[j];int aa=du[a],ab=dv[a],ba=du[b],bb=dv[b];if((aa||ab||ba||bb)&&f.km[aa][bb]==f.km[ab][ba])buf[j/64]|=uint64_t(1)<<(j%64);}}
 cerr<<"compatibility prepared "<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"s\n";
 auto reps=ordinarytypes(f);reps.push_back(f.mu);if(argc>3){int only=atoi(argv[3]);reps={only};}
 ofstream out(argv[2]);out<<"{\"q\":"<<q<<",\"two_spaces_K6\":"<<NL<<",\"targets_after_horizontal_condition\":"<<NT<<",\"types\":[";bool first=true;
 vector<int>db={1,f.mu,f.xi,f.mul(f.mu,f.xi)};
 for(int lam:reps){auto t0=chrono::steady_clock::now();vector<int>cb={1,lam};vector<Row>cr;for(int x:cb){Row a{};for(int i=0;i<6;i++)a[i]=f.digits[x][i];cr.push_back(a);}vector<int>pc;cr=rr(f,cr,6,pc);vector<int>fc;for(int i=0;i<6;i++)if(find(pc.begin(),pc.end(),i)==pc.end())fc.push_back(i);
 auto quot=[&](int x){Row a{};for(int i=0;i<6;i++)a[i]=f.digits[x][i];for(int k=0;k<2;k++){int c=a[pc[k]];for(int j=pc[k];j<6;j++)a[j]=f.ka[a[j]][f.kn[f.km[c][cr[k][j]]]];}array<int,4>z{};for(int j=0;j<4;j++)z[j]=a[fc[j]];return z;};
 vector<Row>code;vector<int>acode;for(int s=0,w=1;s<6;s++,w*=q){Row a{};for(int j=0;j<4;j++){auto z=quot(f.mul(w,db[j]));for(int i=0;i<4;i++)a[4*i+j]=z[i];}code.push_back(a);acode.push_back(w);}vector<int>pm;int rank=0;for(int j=0;j<16&&rank<6;j++){int t=rank;while(t<6&&!code[t][j])t++;if(t==6)continue;swap(code[rank],code[t]);swap(acode[rank],acode[t]);int iv=f.ki[code[rank][j]];for(int k=j;k<16;k++)code[rank][k]=f.km[iv][code[rank][k]];acode[rank]=f.scale(iv,acode[rank]);for(int i=0;i<6;i++)if(i!=rank&&code[i][j]){int c=code[i][j];for(int k=j;k<16;k++)code[i][k]=f.ka[code[i][k]][f.kn[f.km[c][code[rank][k]]]];acode[i]=sub(f,acode[i],f.scale(c,acode[rank]));}pm.push_back(j);rank++;}assert(rank==6);vector<int>fm;for(int i=0;i<16;i++)if(find(pm.begin(),pm.end(),i)==pm.end())fm.push_back(i);
 auto syndrome=[&](Row a){int c=0;for(int k=0;k<6;k++){int ck=a[pm[k]];c=f.add(c,f.scale(ck,acode[k]));for(int j=pm[k];j<16;j++)a[j]=f.ka[a[j]][f.kn[f.km[ck][code[k][j]]]];}int z=0,w=1;for(int j:fm){z+=w*a[j];w*=q;}return make_pair(z,c);};
 vector<int>rs(V*V),rc(V*V);for(int u=1;u<V;u++){array<array<pair<int,int>,4>,4>sg{};for(int j=0;j<4;j++)for(int c=1;c<q;c++){Row a{};for(int i=0;i<4;i++)a[4*i+j]=f.km[vec[u][i]][c];sg[j][c]=syndrome(a);}for(int v=1;v<V;v++){int j=0,t=v,w=1;while(t%q==0){j++;t/=q;w*=q;}int c=t%q;rs[u*V+v]=plus(rs[u*V+(v-c*w)],sg[j][c].first);rc[u*V+v]=f.add(rc[u*V+(v-c*w)],sg[j][c].second);}}
 vector<uint32_t>offset(ALL+1);for(auto[u,v]:planes)for(auto[i,j]:valid)offset[plus(rs[i*V+u],rs[j*V+v])+1]++;
 vector<uint8_t>bad(ALL);bad[0]=1;for(int u=1;u<V;u++){int j=0;while(!vec[u][j])j++;if(vec[u][j]!=1)continue;for(int v=1;v<V;v++)bad[rs[u*V+v]]=1;}
 for(int i=1;i<=ALL;i++)offset[i]+=offset[i-1];vector<uint32_t>at(offset.begin(),offset.end()),ids(offset.back());
 // Determine the actual lifted kernel in coordinates (C-basis,Z-basis).
 vector<uint32_t>lifted(f.Q*planes.size());for(int c=0;c<f.Q;c++)for(int a=0;a<(int)planes.size();a++){vector<int>bv;for(auto z:kerbasis[a]){int fieldz=combination(f,db,vector<int>(z.begin(),z.end()));int cz=f.mul(c,fieldz);Vec x{};x[0]=f.kn[f.digits[cz][pc[0]]];x[1]=f.kn[f.digits[cz][pc[1]]];for(int j=0;j<4;j++)x[2+j]=z[j];bv.push_back(enc(f,x));}auto b=can(f,bv);assert(b.size()==2);lifted[c*planes.size()+a]=lineIDs.at(uint64_t(b[0])*f.Q+b[1]);}
 for(auto[u,v]:planes)for(auto[i,j]:valid){int sid=plus(rs[i*V+u],rs[j*V+v]);int c=f.add(rc[i*V+u],rc[j*V+v]);ids[at[sid]++]=lifted[c*planes.size()+kernel[u*V+v]];}
 for(int i=0;i<ALL;i++)assert(at[i]==offset[i+1]);
 map<int,uint64_t>hist,joint_hist;map<pair<int,int>,uint64_t> actual_spectrum;int joint_max=-1;int mx=0,ex=-1;vector<uint64_t>bits(NW);vector<int>small;vector<int>maxcases;
 for(int sid=0;sid<ALL;sid++)if(!bad[sid]){
  for(int j=0;j<NW;j++)bits[j]=~uint64_t(0);if(NT%64)bits.back()=(uint64_t(1)<<(NT%64))-1;bool sparse=false;small.clear();int count=NT;
  for(uint32_t k=offset[sid];k<offset[sid+1]&&count;k++){
   const uint64_t *bm=&compatible[uint64_t(ids[k])*NW];
   if(!sparse){count=0;for(int j=0;j<NW;j++){bits[j]&=bm[j];count+=__builtin_popcountll(bits[j]);}if(count<=48){sparse=true;for(int j=0;j<NW;j++){uint64_t b=bits[j];while(b){int t=__builtin_ctzll(b);small.push_back(j*64+t);b&=b-1;}}}}
   else{int n=0;for(int j:small)if((bm[j/64]>>(j%64))&1)small[n++]=j;small.resize(n);count=n;}
  }
  hist[count]++;int m=1+offset[sid+1]-offset[sid];actual_spectrum[{m,count}]++;if(m<=1+q+q*q+q*q*q){joint_hist[count+m]++;joint_max=max(joint_max,count+m);}if(count>mx){mx=count;ex=sid;maxcases.clear();}if(count==mx&&(count>0||maxcases.empty()))maxcases.push_back(sid);
 }
 if(!first)out<<",";first=false;out<<"{\"lambda\":"<<lam<<",\"max_scattered_blockers\":"<<mx<<",\"example_coset\":"<<ex<<",\"max_cases\":[";for(int i=0;i<(int)maxcases.size();i++){if(i)out<<",";out<<maxcases[i];}out<<"],\"histogram\":{";bool ff=true;for(auto[k,n]:hist){if(!ff)out<<",";ff=false;out<<"\""<<k<<"\":"<<n;}out<<"},\"joint_max\":"<<joint_max<<",\"joint_histogram\":{";ff=true;for(auto[k,n]:joint_hist){if(!ff)out<<",";ff=false;out<<"\""<<k<<"\":"<<n;}out<<"},\"actual_joint_spectrum\":[";ff=true;for(auto kv:actual_spectrum){if(!ff)out<<",";ff=false;out<<"["<<kv.first.first<<","<<kv.first.second<<","<<kv.second<<"]";}out<<"]}";out.flush();cerr<<"q="<<q<<" lam="<<lam<<" cap="<<mx<<" sec="<<chrono::duration<double>(chrono::steady_clock::now()-t0).count()<<"\n";
 }
 out<<"]}\n";
}
