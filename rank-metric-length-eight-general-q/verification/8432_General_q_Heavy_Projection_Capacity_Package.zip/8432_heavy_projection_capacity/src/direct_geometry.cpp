// Independent geometric check: enumerate points of actual projected spaces,
// recover all point fibres, and test four-subspaces directly. No coset code,
// rank-two matrix enumeration, or saved kernel-compatibility table is used.
#include "../vendor/alternate_field.hpp"
#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <array>
#include <vector>
#include <cassert>
using namespace std;
using V6=array<int,6>;
vector<V6> projective(int q,int n){vector<V6>o;for(int p=n-1;p>=0;--p){int N=1;for(int j=p+1;j<n;j++)N*=q;for(int id=N-1;id>=0;--id){V6 a{};a[p]=1;int t=id;for(int j=p+1;j<n;j++){a[j]=t%q;t/=q;}o.push_back(a);}}return o;}
int dot(const Field&f,const V6&a,const V6&b){int s=0;for(int i=0;i<6;i++)s=f.ka[s][f.km[a[i]][b[i]]];return s;}
vector<V6> rref(const Field&f,vector<V6>a,vector<int>&pv){int r=0;for(int j=5;j>=0&&r<(int)a.size();--j){int p=r;while(p<(int)a.size()&&!a[p][j])p++;if(p==(int)a.size())continue;swap(a[p],a[r]);int u=f.ki[a[r][j]];for(int k=0;k<6;k++)a[r][k]=f.km[u][a[r][k]];for(int i=0;i<(int)a.size();i++)if(i!=r&&a[i][j]){int c=a[i][j];for(int k=0;k<6;k++)a[i][k]=f.ka[a[i][k]][f.kn[f.km[c][a[r][k]]]];}pv.push_back(j);r++;}a.resize(r);return a;}
vector<V6> nullspace(const Field&f,const V6&a,const V6&b){vector<int>pv;auto rr=rref(f,{a,b},pv);assert(pv.size()==2);vector<V6>n;for(int j=0;j<6;j++){if(j==pv[0]||j==pv[1])continue;V6 c{};c[j]=1;for(int i=0;i<2;i++)c[pv[i]]=f.kn[rr[i][j]];n.push_back(c);}return n;}
pair<int,int> value(const Field&f,const array<pair<int,int>,6>&B,const V6&v){int x=0,y=0;for(int i=0;i<6;i++){x=f.add(x,f.scale(v[i],B[i].first));y=f.add(y,f.scale(v[i],B[i].second));}return {x,y};}
pair<int,int> normal(const Field&f,pair<int,int>v){assert(v.first||v.second);return v.first?make_pair(1,f.mul(v.second,f.iv[v.first])):make_pair(0,1);}
int main(int argc,char**argv){assert(argc==3);ifstream in(argv[1]);assert(in);int q,N;in>>q>>N;assert(q==3||q==4);Field f=q==3?Field(q,{1,2,0,1},1,1):Field(q,{1,0,2,1},1,3);auto pg=projective(q,6),p4=projective(q,4);vector<pair<V6,V6>>planes;size_t allplanes=0;
 // Reverse-pivot RREF is deliberately different from the main forward charts.
 for(int p=5;p>=0;p--)for(int r=p-1;r>=0;r--){vector<pair<int,int>>slots;for(int j=0;j<p;j++)if(j!=r)slots.push_back({0,j});for(int j=0;j<r;j++)slots.push_back({1,j});int lim=1;for(auto z:slots)lim*=q;for(int id=lim-1;id>=0;--id){V6 a{},b{};a[p]=b[r]=1;int z=id;for(auto[i,j]:slots){(i?b:a)[j]=z%q;z/=q;}allplanes++;int aa=a[0],ab=a[1],ba=b[0],bb=b[1];if((aa||ab||ba||bb)&&f.km[aa][bb]==f.km[ab][ba])planes.push_back({a,b});}}
 assert(allplanes==(q==3?11011:93093));assert(planes.size()==size_t((q+1)*(q*q*q+q*q+q+1)*q*q*q));
 ofstream out(argv[2]);assert(out);out<<"{\"q\":"<<q<<",\"actual_spaces\":"<<N<<",\"all_dual_two_spaces\":"<<allplanes<<",\"horizontal_compatible_dual_spaces\":"<<planes.size()<<",\"records\":[";
 uint64_t fibre_points=0,verified_R_points=0,accepted_total=0;
 for(int id=0;id<N;id++){int lam,sid,expected;array<pair<int,int>,6>B;in>>lam>>sid>>expected;for(auto&v:B)in>>v.first>>v.second;assert(in);
  map<pair<int,int>,vector<V6>>fib;for(auto v:pg){auto x=value(f,B,v);assert(x.first||x.second);fib[normal(f,x)].push_back(v);fibre_points++;}
  vector<pair<V6,V6>>heavy;for(auto&[dir,vs]:fib){assert(vs.size()==1||vs.size()==size_t(q+1));if(vs.size()==size_t(q+1)){vector<int>pv;auto rr=rref(f,vs,pv);assert(rr.size()==2);heavy.push_back({rr[0],rr[1]});}}
  vector<pair<V6,V6>>valid;
  for(auto&[a,b]:planes){bool ok=true;for(auto&[u,v]:heavy){int aa=dot(f,a,u),ab=dot(f,a,v),ba=dot(f,b,u),bb=dot(f,b,v);if((!aa&&!ab&&!ba&&!bb)||f.km[aa][bb]!=f.km[ab][ba]){ok=false;break;}}if(!ok)continue;valid.push_back({a,b});
   // Also reconstruct the accepted R and check all of its actual F-points.
   auto nb=nullspace(f,a,b);set<pair<int,int>>rp;map<pair<int,int>,int>meet;
   for(auto c:p4){V6 v{};for(int i=0;i<4;i++)for(int j=0;j<6;j++)v[j]=f.ka[v[j]][f.km[c[i]][nb[i][j]]];auto p=normal(f,value(f,B,v));assert(rp.insert(p).second);meet[p]++;verified_R_points++;}
   for(auto&[dir,vs]:fib)if(vs.size()==size_t(q+1))assert(meet[dir]==1);
  }
  assert((int)valid.size()==expected);int m=heavy.size();accepted_total+=valid.size();
  if(id)out<<",";out<<"{\"lambda_primary\":"<<lam<<",\"coset\":"<<sid<<",\"m\":"<<m<<",\"b\":"<<valid.size()<<",\"joint\":"<<m+valid.size();
  if(id==0||expected==(q==3?44:7)){out<<",\"compatible_dual_planes\":[";for(int k=0;k<(int)valid.size();k++){if(k)out<<",";out<<"[";for(int j=0;j<6;j++){if(j)out<<",";out<<valid[k].first[j];}for(int j=0;j<6;j++)out<<","<<valid[k].second[j];out<<"]";}out<<"]";}
  out<<"}";out.flush();if((id+1)%25==0)cerr<<"q="<<q<<" direct "<<id+1<<"/"<<N<<"\n";
 }
 out<<"],\"projective_vectors_in_actual_spaces\":"<<fibre_points<<",\"accepted_four_subspaces_checked\":"<<accepted_total<<",\"projective_vectors_in_accepted_four_subspaces\":"<<verified_R_points<<",\"all_exact_checks_passed\":true}\n";cerr<<"q="<<q<<" DONE "<<N<<" spaces "<<accepted_total<<" subspaces\n";
}
