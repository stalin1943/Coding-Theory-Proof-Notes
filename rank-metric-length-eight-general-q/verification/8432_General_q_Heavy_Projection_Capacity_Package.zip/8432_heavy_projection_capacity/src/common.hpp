#pragma once
#include "../vendor/input_field.hpp"
#include <fstream>
#include <iostream>
#include <map>
#include <unordered_map>
#include <set>
#include <numeric>
#include <functional>
#include <chrono>
using Vec = array<int,6>;
inline Field makefield(int q){return q==3?Field(q,{1,0,2,1},0,2):Field(q,{1,0,1,1},1,2);}
inline int sub(const Field&f,int a,int b){return f.add(a,f.scale(f.kn[1],b));}
inline int enc(const Field&f,const Vec&v){int x=0,p=1;for(int j=0;j<6;j++){x+=p*v[j];p*=f.q;}return x;}
inline vector<int> can(const Field&f,const vector<int>&vals){
 vector<Vec>a;for(auto v:vals)a.push_back(f.digits[v]);int r=0;for(int j=0;j<6&&r<(int)a.size();j++){
  int p=r;while(p<(int)a.size()&&!a[p][j])p++;if(p==(int)a.size())continue;swap(a[p],a[r]);int iv=f.ki[a[r][j]];for(int k=j;k<6;k++)a[r][k]=f.km[iv][a[r][k]];
  for(int i=0;i<(int)a.size();i++)if(i!=r&&a[i][j]){int c=a[i][j];for(int k=j;k<6;k++)a[i][k]=f.ka[a[i][k]][f.kn[f.km[c][a[r][k]]]];}r++;
 }
 vector<int>b;for(int i=0;i<r;i++)b.push_back(enc(f,a[i]));return b;
}
inline uint64_t key(const Field&f,const vector<int>&v){uint64_t a=0;for(auto x:v)a=a*f.Q+x;return a;}
inline vector<vector<int>> proj(int q,int n){vector<vector<int>>p;for(int j=0;j<n;j++){int lim=1;for(int k=j+1;k<n;k++)lim*=q;for(int v=0;v<lim;v++){vector<int>a(n);a[j]=1;int t=v;for(int k=j+1;k<n;k++){a[k]=t%q;t/=q;}p.push_back(a);}}return p;}
inline int combination(const Field&f,const vector<int>&v,const vector<int>&cs){int x=0;for(int j=0;j<(int)v.size();j++)x=f.add(x,f.scale(cs[j],v[j]));return x;}
inline int erank(const Field&f,vector<int>v){vector<array<int,3>>a;for(int x:v)a.push_back({x%f.e,(x/f.e)%f.e,x/(f.e*f.e)});int r=0;for(int j=0;j<3&&r<(int)a.size();j++){int p=r;while(p<(int)a.size()&&!a[p][j])p++;if(p==(int)a.size())continue;swap(a[p],a[r]);int inv=f.iv[a[r][j]];for(int k=j;k<3;k++)a[r][k]=f.mul(inv,a[r][k]);for(int i=r+1;i<(int)a.size();i++)if(a[i][j]){int c=a[i][j];for(int k=j;k<3;k++)a[i][k]=sub(f,a[i][k],f.mul(c,a[r][k]));}r++;}return r;}
inline vector<int> ordinarytypes(const Field&f){vector<uint8_t>seen(f.Q);vector<int>r;for(int a=0;a<f.Q;a++)if(f.pow(a,f.q*f.q)==a)seen[a]=1;
 for(int x=0;x<f.Q;x++)if(!seen[x]){set<int>o;vector<int>v={x};for(int c=0;c<f.q;c++)v.push_back(f.iv[sub(f,x,c)]);for(int y:v)for(int b=1;b<f.q;b++)for(int a=0;a<f.q;a++)o.insert(f.add(a,f.scale(b,y)));for(int y:o)seen[y]=1;r.push_back(x);}assert((int)r.size()==f.q*f.q*f.q+f.q);return r;}
