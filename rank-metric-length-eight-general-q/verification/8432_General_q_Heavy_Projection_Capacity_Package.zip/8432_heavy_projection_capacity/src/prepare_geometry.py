#!/usr/bin/env python3
"""Recover every global maximizer and one maximizer of each remaining type."""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'vendor'))
from graph_independent_arithmetic import Field
from inspect_blockers import recover

def converter(comp):
    F=Field(comp['independent_field']);mu=comp['primary_mu_image'];xi=comp['primary_xi_image'];q=comp['q']
    bs=[1,mu,xi,F.mul(mu,xi),F.mul(xi,xi),F.mul(mu,F.mul(xi,xi))]
    def conv(x):
        z=0
        for b in bs:z=F.add(z,F.scale(x%q,b));x//=q
        assert x==0
        return z
    return conv

def prepare(results:Path):
    for q in (3,4):
        a=json.loads((results/f'spectrum_primary_q{q}.json').read_text())
        comp=json.loads((results/f'comparison_q{q}.json').read_text());conv=converter(comp)
        mx=max(t['max_scattered_blockers'] for t in a['types']);records=[]
        for t in a['types']:
            cases=t['max_cases'] if t['max_scattered_blockers']==mx else t['max_cases'][:1]
            for sid in cases:
                _,V=recover(q,t['lambda'],sid)
                records.append(dict(q=q,lambda_primary=t['lambda'],coset=sid,expected_b=t['max_scattered_blockers'],primary_basis=V,alternate_basis=[[conv(x),conv(y)] for x,y in V]))
        obj=dict(q=q,selection='All global capacity maximizers plus one local maximizer of each other scalar type.',field=comp['independent_field'],records=records)
        (results/f'geometric_inputs_q{q}.json').write_text(json.dumps(obj,indent=2)+'\n')
        with (results/f'geometric_inputs_q{q}.txt').open('w') as f:
            f.write(f'{q} {len(records)}\n')
            for r in records:f.write(' '.join(map(str,[r['lambda_primary'],r['coset'],r['expected_b']]+[v for p in r['alternate_basis'] for v in p]))+'\n')
    q=3;lam=9;sid=3050;ann=9
    F,V=recover(q,lam,sid,ann)
    comp=json.loads((results/'comparison_q3.json').read_text());conv=converter(comp)
    assert F.rank([F.flat(v) for v in V])==6
    assert F.rank([F.flat(v) for v in V]+[F.flat([F.mul(F.mu,x) for x in v]) for v in V])==12
    B=[[conv(x),conv(y)] for x,y in V]
    obj=dict(q=q,lambda_primary=lam,coset=sid,domain_annihilator=ann,primary_basis=V,alternate_basis=B,expected_b=612,note='Scope example only: the four-dimensional projection is not an E-plane. This is a six-dimensional local space, NOT an eight-dimensional target code.')
    (results/'scope_example.json').write_text(json.dumps(obj,indent=2)+'\n')
    (results/'scope_example.txt').write_text('3 1\n'+' '.join(map(str,[lam,sid,612]+[v for pair in B for v in pair]))+'\n')
if __name__=='__main__':prepare(Path(sys.argv[1]))
