#!/usr/bin/env python3
"""Recompute all finite claims in this supplement from source.
Not a proof-assistant verification of the algebraic-geometric argument.
"""
from pathlib import Path
import argparse,hashlib,json,os,re,shlex,shutil,subprocess,sys,time

PYJOBS=['twisted_curve.py','check_curve_factors.py','check_initial.py','check_normal_form.py',
        'quinary_blocks.py','independent_quinary_blocks.py','symbolic_checks.py']
JSONS=['curves.json','curve_factors.json','initial.json','input_ranks.json','normal_form.json',
       'quinary_blocks.json','quinary_independent.json','symbolic.json']

def stable(x):
 if isinstance(x,dict):return {k:stable(v) for k,v in x.items() if k not in ['seconds','elapsed_seconds']}
 if isinstance(x,list):return [stable(v) for v in x]
 return x

def tex_structure(path):
 s=re.sub(r'(?<!\\)%[^\n]*','',path.read_text())
 labs=re.findall(r'\\label\{([^}]+)\}',s);refs=re.findall(r'\\(?:eqref|ref)\{([^}]+)\}',s)
 assert len(labs)==len(set(labs)) and set(refs)<=set(labs)
 stack=[]
 for op,e in re.findall(r'\\(begin|end)\{([^}]+)\}',s):
  if op=='begin':stack.append(e)
  else:assert stack and stack.pop()==e
 assert not stack
 return dict(internal_labels=len(labs),internal_references=len(refs),environments_balanced=True)

def run(root,work,compare=True):
 if not __debug__:raise RuntimeError('Assertions must remain enabled.')
 root=root.resolve();work=work.resolve()
 if work==root or root in work.parents:raise ValueError('Place the work directory outside the package.')
 if work.exists() and (not work.is_dir() or any(work.iterdir())):raise ValueError('Use a new or empty work directory.')
 work.mkdir(parents=True,exist_ok=True);start=time.monotonic()
 mf=root/'MANIFEST.json';nfiles=0
 if mf.exists():
  for name,digest in json.loads(mf.read_text()).items():
   assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name;nfiles+=1
 compiler=os.environ.get('CXX') or shutil.which('g++') or shutil.which('clang++')
 if not compiler:raise RuntimeError('A C++17 compiler is required.')
 flags=shlex.split(os.environ.get('CXXFLAGS','-O3 -march=native'))
 assert '-DNDEBUG' not in flags,'Do not disable assertions.'
 for source in ['scan_semilinear','independent_scan']:
  with (work/(source+'_build.log')).open('w') as log:
   subprocess.run([compiler,'-std=c++17',*flags,str(root/'src'/f'{source}.cpp'),'-o',str(work/source)],stdout=log,stderr=subprocess.STDOUT,check=True)
 total=valid=dirs=0
 for q in [3,5,7]:
  for exe,suffix in [('scan_semilinear','scan'),('independent_scan','independent')]:
   prefix=work/f'q{q}_{suffix}'
   with (work/f'q{q}_{suffix}.log').open('w') as log:
    subprocess.run([str(work/exe),str(q),str(prefix)],stdout=log,stderr=subprocess.STDOUT,check=True)
  a=json.loads((work/f'q{q}_scan.json').read_text());b=json.loads((work/f'q{q}_independent.json').read_text())
  aa=(work/f'q{q}_scan.bin').read_bytes();bb=(work/f'q{q}_independent.bin').read_bytes()
  assert aa==bb and len(aa)==q**6
  assert a['complete_parameter_scan'] and a['parameters_tested']==b['parameters_tested']==q**6-q*q
  assert a['rank4_parameters']==b['rank4_parameters']
  assert a['determinant_rank_histogram']==b['determinant_rank_histogram']
  assert a['quotient_zero_histogram']==b['quotient_zero_histogram']
  assert all(int(k)%2==0 for k in a['quotient_zero_histogram'])
  assert a['maximum_original_zeros']=={3:32,5:84,7:144}[q]
  total+=a['parameters_tested'];valid+=a['rank4_parameters'];dirs+=b['quotient_directions_checked']
  if compare:
   for suffix in ['scan','independent']:
    name=f'q{q}_{suffix}.json';assert stable(json.loads((work/name).read_text()))==stable(json.loads((root/'results'/name).read_text())),name
    name=f'q{q}_{suffix}.bin';assert (work/name).read_bytes()==(root/'results'/name).read_bytes(),name
  print('complete paired scan passed:',q,a['parameters_tested'],flush=True)
 for script in PYJOBS:
  with (work/(script+'.log')).open('w') as log:
   subprocess.run([sys.executable,str(root/'src'/script),'--work',str(work)],stdout=log,stderr=subprocess.STDOUT,check=True)
  print(script,'passed',flush=True)
 if compare:
  for name in JSONS:
   assert stable(json.loads((work/name).read_text()))==stable(json.loads((root/'results'/name).read_text())),name
 curves=json.loads((work/'curves.json').read_text());ind=json.loads((work/'quinary_independent.json').read_text())
 assert len(curves)==20 and all(r['octic_bound_checked'] for r in curves)
 assert ind['status']=='passed' and ind['models']==18 and ind['disjoint_full_rank_groups']==126
 normal=json.loads((work/'normal_form.json').read_text());assert normal['models']==36
 tex=tex_structure(root/'THEOREMS_en.tex');latex=shutil.which('pdflatex')
 tex['compiled']=False
 if latex:
  for k in range(2):
   with (work/f'latex_{k}.log').open('w') as log:
    subprocess.run([latex,'-interaction=nonstopmode','-halt-on-error',f'-output-directory={work}',str(root/'fragment_check.tex')],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
  log=(work/'fragment_check.log').read_text(errors='replace')
  assert 'undefined references' not in log and 'undefined on input' not in log
  tex['compiled']=True;tex['overfull_warnings']=log.count('Overfull')
 result=dict(status='passed',date='2026-09-18',manifest_files_checked=nfiles,
  normalized_parameters_per_scan=total,rank_four_parameters=valid,
  quotient_directions_per_scan=dirs,per_parameter_binary_arrays_equal=True,
  exact_maximum_section_zeros={'3':32,'5':84,'7':144},
  analytic_seven_field_bound=176,required_seven_field_bound=300,
  original_octic_coefficient_bindings=len(curves),original_octic_chart_determinants=4*len(curves),
  original_full_section_point_checks=3184,constructive_normal_form_recoveries=normal['models'],
  quinary_boundary_models=18,quinary_original_trace_blocks=ind['original_trace_point_blocks'],
  quinary_full_section_point_checks=ind['all_section_point_ranks'],
  quinary_disjoint_full_rank_groups=126,quinary_group_point_occurrences=ind['group_point_occurrences'],
  quinary_maximum_allowed_good_points=77,quinary_minimum_required_good_points=78,
  mathematical_outputs_compared=compare,tex=tex,
  elapsed_seconds=round(time.monotonic()-start,3),
  scope='rank-four scattered special sections only: uniform odd-q proof (q>=7); complete q=3,5,7 normal-form scans; quinary all-graph rank certificates. Does not exclude determinant ranks five or six or complete any remaining base field.')
 (work/'verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
 return result

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path,required=True);args=ap.parse_args()
 run(Path(__file__).resolve().parent,args.work,True)
if __name__=='__main__':main()
