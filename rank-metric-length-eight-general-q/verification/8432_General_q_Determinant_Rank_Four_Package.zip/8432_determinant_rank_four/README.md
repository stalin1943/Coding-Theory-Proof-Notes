# 行列式四秩散布截面：统一规范形、曲线证明与五元边界

本包继续最新的非 Hermitian 散布特殊截面研究。它并未完成所有 [8,3]_(q^6/q) 码的存在性分类。

## 新结论

对奇基域，四维散布截面的六个行列式只能张成4、5或6维。四秩且全 E-张成的情形具有完整的二次半线性规范形。其八次障碍下降到非分裂二次曲面上的 Jacobian；所有奇素幂 q≥7 的四秩特殊截面由统一解析点数界排除。

五元通过完整规范形扫描只留下18个边界截面。每个截面的七组互不重叠的局部条件都约束全部20个非坐标图参数，得到78>77的矛盾，完成同一个四秩散布截面分支的排除。

七元的行列式五秩、六秩非 Hermitian 散布截面仍保留；五元的其他截面也仍保留。整体未决基域仍为3、4、5、7。

## 阅读与运行

- `PROOF_zh.md`：完整中文论证、适用前提、有限结果和剩余范围。
- `THEOREMS_en.tex`：英文定理插入节；不是整篇投稿稿件。
- `fragment_check.tex`：独立格式编译模板，使用标准 amsmath/amssymb/amsthm。
- `src/scan_semilinear.cpp`：三次再二次的主域算术，遍历规范参数，利用已证明的 E 轨道不变性计数。
- `src/independent_scan.cpp`：二次再三次的独立系数乘法，直接算六个行列式，使用另一套射影代表与反向主元。
- `src/twisted_curve.py`：重建20个明确例子的六点净、Jacobian与原始八次式全部系数。
- `src/check_curve_factors.py`：三条共轭曲线及 Moore 例外的因子身份。
- `src/check_normal_form.py`：对36个变换后的实际截面恢复规范形，比较实际 K-子空间。
- `src/check_initial.py`：14个规范截面全点检查，并对输入的13个截面重算行列式秩。
- `src/quinary_blocks.py`：全部18个边界截面的原始48参数点行块和七组满秩点集。
- `src/independent_quinary_blocks.py`：独立从原始迹方程求解全部行块并核对实际行空间。
- `src/symbolic_checks.py`：标准库整数多项式核验两个 Jacobian 身份及正系数差式。
- `vendor/`：从明确上传包中原样复用的基础 Python 算术与原始八次构造。来源见 `PROVENANCE.json`。
- `results/`：本轮的实际数学输出。

需要 Python 3.10+ 标准库以及一个 C++17 编译器。无需 OpenMP、Sage、SymPy或求解器。不要使用 `python -O`，不要关闭 C++断言。

```bash
python verify.py --work /absolute/path/to/new_or_empty_directory
```

可用 `CXX=clang++` 或 `CXX=g++` 指定编译器，`CXXFLAGS` 添加优化/检查选项。例如：

```bash
CXX=clang++ CXXFLAGS="-O2 -fsanitize=undefined -fno-sanitize-recover=all" \
python verify.py --work /absolute/path/to/another_new_directory
```

每次都会从源代码重新编译两套程序，并完整重算全部规范参数、曲线、点行块和独立检查；不是只检查保存摘要。`--work` 必须不存在或为空，而且不能在本包内部。机器相关耗时不参与数学输出相等比较。

若系统有 pdflatex，验证程序还会将英文片段在附带模板中编译两次；没有 LaTeX 不影响数学检查。最终交付没有打包字体或预编译程序。

## 输出的含义

`q*_scan.bin` 与 `q*_independent.bin` 按主表示的域元素整数标签索引，长度为 q^6。值255表示参数在E中、不纳入规范形；254表示行列式秩不足四；其他值是该 eta 的平方缺陷 E-射影轨道数。二者逐字节比较相同。q+1 倍才是原始四维截面的点数。

这些是规范形参数记录，不是不等价截面数，更不是码数。两个完整算术路径采用同一个抽象有限域及明确坐标转换，没有声称使用两种不同的六次不可约模多项式。

`quinary_blocks.json` 保存全部18个截面的1296个原始点行块及126个互不重叠满秩组。它覆盖所有图系数，但没有枚举5^20个图。

本轮未重算二元终局、一般大域分类或历史子直线排除。证明未经过外部专家验收或证明助理形式化；重点审查环节已列于中文证明末节。
