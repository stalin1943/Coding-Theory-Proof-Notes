#!/usr/bin/env python3
"""Integer sparse-polynomial checks. No computer-algebra library is used."""
from pathlib import Path
import argparse,itertools,json,math
ROOT=Path(__file__).resolve().parents[1]
class Ring:
 def __init__(self,n):self.n=n;self.zero=(0,)*n;self.one={self.zero:1}
 def var(self,i):v=[0]*self.n;v[i]=1;return {tuple(v):1}
 def add(self,a,b):
  r=dict(a)
  for m,c in b.items():
   v=r.get(m,0)+c
   if v:r[m]=v
   else:r.pop(m,None)
  return r
 def neg(self,a):return {m:-c for m,c in a.items()}
 def sub(self,a,b):return self.add(a,self.neg(b))
 def mul(self,a,b):
  r={}
  for m,c in a.items():
   for n,d in b.items():
    k=tuple(x+y for x,y in zip(m,n));v=r.get(k,0)+c*d
    if v:r[k]=v
    else:r.pop(k,None)
  return r
 def derivative(self,a,j):
  r={}
  for m,c in a.items():
   if m[j]:n=list(m);n[j]-=1;r[tuple(n)]=c*m[j]
  return r
 def det(self,M):
  r={};n=len(M)
  for p in itertools.permutations(range(n)):
   t=self.one
   for i,j in enumerate(p):t=self.mul(t,M[i][j])
   if sum(p[i]>p[j] for i in range(n) for j in range(i+1,n))%2:t=self.neg(t)
   r=self.add(r,t)
  return r
 def jac(self,a):return self.det([a,[self.derivative(p,0) for p in a],[self.derivative(p,1) for p in a]])

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path,default=ROOT/'results');args=ap.parse_args()
 R=Ring(14);x=R.var(0);y=R.var(1);xy=R.mul(x,y);forms=[]
 for i in range(3):
  p={}
  for j,m in enumerate([R.one,x,y,xy]):p=R.add(p,R.mul(R.var(2+4*i+j),m))
  forms.append(p)
 U,V,W=forms;UV=R.mul(U,V);UW=R.mul(U,W);VW=R.mul(V,W)
 lhs=R.jac([UV,UW,VW]);rhs=R.neg(R.mul(R.mul(UV,W),R.jac(forms)));assert lhs==rhs
 R2=Ring(5);x=R2.var(0);y=R2.var(1);aa=[R2.var(i) for i in range(2,5)]
 fx=R2.one;fy=R2.one;li=[]
 for a in aa:fx=R2.mul(fx,R2.sub(x,a));fy=R2.mul(fy,R2.sub(y,a))
 for i in range(3):
  p=R2.one
  for j,a in enumerate(aa):
   if i!=j:p=R2.mul(p,R2.mul(R2.sub(x,a),R2.sub(y,a)))
  li.append(p)
 vand=R2.one
 for i,j in itertools.combinations(range(3),2):vand=R2.mul(vand,R2.sub(aa[j],aa[i]))
 lhs2=R2.jac(li);rhs2=R2.mul(R2.mul(R2.mul(fx,fy),R2.sub(x,y)),vand);assert lhs2==rhs2
 # Exact arithmetic for the inequality used after the genus-three point bound.
 assert [38,48,13,1]==[7**3-8*7**2+13*7-4,3*7**2-16*7+13,3*7-8,1]
 tests=[]
 for q in range(7,201,2):
  assert (3*q-1)**2>=36*q
  assert (q-4)*(q*q+1)>4*q*(q-3)
  tests.append(q)
 out=dict(status='passed',integer_jacobian_product_identity=True,product_identity_terms=len(lhs),
          generic_moore_factorization_identity=True,moore_identity_terms=len(lhs2),
          root_vandermonde_factor='product_{i<j}(a_j-a_i)',
          shifted_count_polynomial=[38,48,13,1],integer_inequality_checks=len(tests),
          scope='identities over Z plus integer substitutions; non-prime-powers are not treated as finite fields')
 (args.work/'symbolic.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
