#!/usr/bin/env python3
"""Verify the two exceptional factorization formulas on all listed examples.
The normal-form finite scans are separate and complete for their stated fields.
"""
from pathlib import Path
import argparse,itertools,json,sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'vendor'))
from algebra import Algebra
from twisted_curve import points,net,kernel,mul,add,neg,determinant,derivative,normalize,eval_bihom

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path,default=ROOT/'results');a=ap.parse_args()
 data=json.loads((a.work/'curves.json').read_text());fields={};records=[]
 for r in data:
  q=r['q']
  if q not in fields:fields[q]=Algebra(q)
  A=fields[q];F=A.F;Z,N,J=net(A,r['eta']);case=r['case']
  if case=='degree_two_del_Pezzo':
   assert r['quotient_zeros']%2==0
   assert (r['quotient_zeros']-q-1)**2<=36*q
   records.append(dict(q=q,eta=r['eta'],case=case,parity_and_Hasse_bound=True))
   continue
  if case=='Moore_collision':
   fx={(0,0):1};fy={(0,0):1}
   for x in sorted({x for x,y in Z}):fx=mul(F,fx,{(1,0):1,(0,0):F.neg(x)})
   for y in sorted({y for x,y in Z}):fy=mul(F,fy,{(0,1):1,(0,0):F.neg(y)})
   product=mul(F,mul(F,fx,fy),{(1,0):1,(0,1):F.neg(1)})
   assert normalize(F,J)==normalize(F,product)
   assert all(eval_bihom(F,fx,(x,1),(1,1),3,0)!=0 for x in A.E2)
   assert all(eval_bihom(F,fy,(1,1),(x,1),0,3)!=0 for x in A.E2)
   assert r['quotient_zeros']==q+1
   records.append(dict(q=q,eta=r['eta'],case=case,norm_times_diagonal_identity=True,quotient_zeros=q+1))
   continue
  forms=[];sets=[]
  for j in range(3):
   inds=[i for i in range(6) if i not in [j,j+3]]
   kn=kernel(A,[[1,Z[i][0],Z[i][1],F.mul(*Z[i])] for i in inds],4)
   assert len(kn)==1
   p={m:c for m,c in zip([(0,0),(1,0),(0,1),(1,1)],kn[0]) if c}
   assert all(eval_bihom(F,p,(Z[i][0],1),(Z[i][1],1),1,1)==0 for i in inds)
   assert all(eval_bihom(F,p,(Z[i][0],1),(Z[i][1],1),1,1)!=0 for i in [j,j+3])
   forms.append(p);sets.append(inds)
  products=[mul(F,forms[0],forms[1]),mul(F,forms[0],forms[2]),mul(F,forms[1],forms[2])]
  prodjac=determinant(F,[products,[derivative(F,p,0) for p in products],[derivative(F,p,1) for p in products]])
  smalljac=determinant(F,[forms,[derivative(F,p,0) for p in forms],[derivative(F,p,1) for p in forms]])
  normpoly=mul(F,mul(F,forms[0],forms[1]),forms[2])
  expected=neg(F,mul(F,normpoly,smalljac))
  assert prodjac==expected
  assert normalize(F,J)==normalize(F,expected)
  assert smalljac and max(i for i,j in smalljac)<=1 and max(j for i,j in smalljac)<=1
  normzeros=[];reszeros=[]
  for t in A.E2+[-1]:
   v=(1,0) if t==-1 else (t,1);w=(1,0) if t==-1 else(A.bar(t),1)
   if eval_bihom(F,normpoly,v,w,3,3)==0:normzeros.append(t)
   if eval_bihom(F,smalljac,v,w,1,1)==0:reszeros.append(t)
  assert not normzeros and len(reszeros)==q+1
  records.append(dict(q=q,eta=r['eta'],case=case,forms=[[[*m,c] for m,c in sorted(p.items())] for p in forms],
                      residual=[[*m,c] for m,c in sorted(smalljac.items())],norm_has_no_rational_zeros=True,quotient_zeros=len(reszeros),jacobian_product_identity=True))
 out=dict(status='passed',curve_examples=len(data),exceptional_factorizations=sum(r['case']!='degree_two_del_Pezzo' for r in records),records=records,
          scope='complete coefficient identities for listed examples; analytic proofs supply all-parameter statements')
 (a.work/'curve_factors.json').write_text(json.dumps(out,indent=2)+'\n')
 print('curve factorization checks passed:',out['curve_examples'],out['exceptional_factorizations'])
if __name__=='__main__':main()
