#!/usr/bin/env python3
"""Original-trace descent blocks for the 18 maximal rank-four quinary sections.
No graph enumeration: finite linear-rank witnesses cover all 20 graph parameters.
"""
from pathlib import Path
import sys,json,itertools,collections,random,argparse,time
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'vendor'))
from algebra import Algebra,projective
from tower_arithmetic import rref,rank
from twisted_curve import section,kernel
PAIRS=[(0,0),(0,1),(0,2),(1,1),(1,2),(2,2)]

def coefficient(A,z,S):
 F=A.F;out=[]
 for i,j in PAIRS:
  c=F.mul(F.pow(S[i],A.q*A.q),F.pow(S[j],A.q**4))
  if i!=j:c=F.add(c,F.mul(F.pow(S[j],A.q*A.q),F.pow(S[i],A.q**4)))
  out.append(A.tr2(F.mul(z,c)))
 return out

def setup(A,T):
 F=A.F;q=A.q;xi=q;om=F.mu
 alpha=F.inv(F.add(F.scale(3%q,F.mul(xi,xi)),F.scale(2*F.E.poly[2]%q,xi)))
 # The chosen cubics have no X term.
 zvec=[F.mul(alpha,z) for z in [1,om,xi,F.mul(om,xi)]]
 assert all(A.tr2(z)==0 for z in zvec)
 fb=[F.from_digits([int(i==j) for i in range(6)]) for j in range(6)]
 comp=[xi,F.mul(om,xi),F.mul(xi,xi),F.mul(om,F.mul(xi,xi))]
 ci=A.inverse([[F.trace(F.mul(z,c)) for c in comp] for z in zvec])
 cslots=[F.dot([ci[i][j] for i in range(4)],comp) for j in range(4)]
 def flatten(lift):return [c for row in lift for x in row for c in F.digits(x)]
 gauge=[]
 for slot in range(4):
  for t in T:
   m=[[0,0] for _ in range(4)];m[slot]=list(t);gauge.append(flatten(m))
 for coord in range(2):
  for a in fb:
   m=[[0,0] for _ in range(4)]
   for i,z in enumerate(zvec):m[i][coord]=F.mul(a,z)
   gauge.append(flatten(m))
 _,piv=rref(A.K,gauge,48);assert len(piv)==28
 free=[i for i in range(48) if i not in piv];assert len(free)==20
 return zvec,fb,cslots,gauge,free

def block(A,T,x,fb,cslots):
 F=A.F;q=A.q
 P=[F.dot(x,[t[j] for t in T]) for j in range(2)]
 ell=[F.neg(P[1]),P[0]]
 Srows=[F.digits(F.dot(ell,t)) for t in T]
 R,_=rref(A.K,Srows,6);S=[F.from_digits(r) for r in R]
 assert len(S)==3
 er=len(A.rr([A.ec(s) for s in S])[1])
 sr=rank(A.K,[F.digits(F.mul(a,b)) for i,a in enumerate(S) for b in S[i:]])
 if er!=3 or sr==6:return dict(point=x,E_rank=er,square_rank=sr)
 assert sr==5
 cols=[coefficient(A,z,S) for z in fb]
 nk=kernel(A,[[cols[j][i]//F.M for j in range(6)] for i in range(6)],6)
 assert len(nk)==1
 z0=F.from_digits(nk[0]);v0=A.ec(z0)
 assert all(c<q for c in coefficient(A,z0,S))
 D=kernel(A,[[F.trace(F.mul(s,z)) for z in fb] for s in S],6)
 D=[F.from_digits(r) for r in D];assert len(D)==3
 di=A.inverse([A.ec(z) for z in D]);weights=[]
 for i in range(3):
  ai=F.dot([di[j][i] for j in range(3)],A.dual)
  row=[]
  for c in cslots:
   _,b1,b2=A.ec(c)
   row.append(F.mul(ai,A.sub(F.mul(b1,A.dual[2]),F.mul(b2,A.dual[1]))))
  weights.append(row)
 raw=[]
 for slot in range(4):
  for coord in range(2):
   for element in fb:
    z=0
    for i in range(3):
     rhs=A.K.neg[F.trace(F.mul(D[i],F.mul(ell[coord],element)))]
     z=F.add(z,F.scale(rhs,weights[i][slot]))
    v=A.ec(z);col=[]
    for j,k in [(0,1),(0,2),(1,2)]:
     w=A.sub(F.mul(v[j],v0[k]),F.mul(v[k],v0[j]));assert w in A.Eset
     col.extend([w%F.M,w//F.M])
    raw.append(col)
 mat=[list(r) for r in zip(*raw)];assert rank(A.K,mat)==4
 return dict(point=x,E_rank=er,square_rank=sr,conic_direction=z0,raw_block=mat)

def packing(K,blocks,n=7):
 ids=sorted(blocks);rng=random.Random(5084)
 for attempt in range(100):
  rem=ids[:];rng.shuffle(rem);groups=[]
  for _ in range(n):
   rows=[];selected=[];rk=0
   for i in rem:
    M,p=rref(K,rows+blocks[i],20)
    if len(p)>rk:rows=M;rk=len(p);selected.append(i)
    if rk==20:break
   if rk!=20:break
   groups.append(selected);rem=[i for i in rem if i not in selected]
  if len(groups)==n:return groups
 return None

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path,default=ROOT/'results');args=ap.parse_args();wd=args.work
 data=(wd/'q5_scan.bin').read_bytes();etas=[i for i,v in enumerate(data) if v==14];assert len(etas)==18
 A=Algebra(5);F=A.F;out=[];points_checked=0;blocks_checked=0
 for eta in etas:
  T=section(A,eta);zvec,fb,cslots,gauge,free=setup(A,T)
  records=[];blocks={};hist=collections.Counter()
  for i,x in enumerate(projective(5,4)):
   r=block(A,T,x,fb,cslots);hist[r['E_rank'],r['square_rank']]+=1;records.append(r);points_checked+=1
   if 'raw_block' in r:
    assert all(sum(a*b for a,b in zip(row,g))%5==0 for row in r['raw_block'] for g in gauge)
    blocks[i]=[[row[j] for j in free] for row in r['raw_block']];blocks_checked+=1
  allrank=rank(A.K,[row for bm in blocks.values() for row in bm])
  groups=packing(A.K,blocks) if allrank==20 else None
  print('eta',eta,'hist',dict(hist),'allrank',allrank,'groups',None if groups is None else list(map(len,groups)),flush=True)
  out.append(dict(eta=eta,section=T,zvec=zvec,gauge=gauge,free_columns=free,points=records,
                  joint_rank=allrank,disjoint_rank20_groups=groups))
 result=dict(status='computed',q=5,maximal_normalized_sections=18,point_checks=points_checked,
             raw_point_blocks=blocks_checked,all_covered=all(r['disjoint_rank20_groups'] for r in out),records=out)
 (wd/'quinary_blocks.json').write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__':main()
