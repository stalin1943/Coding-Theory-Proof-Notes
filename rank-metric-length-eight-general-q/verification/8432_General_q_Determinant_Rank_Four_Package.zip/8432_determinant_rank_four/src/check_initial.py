from pathlib import Path
import sys,json,itertools,collections
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'vendor'))
from algebra import Algebra,projective
from tower_arithmetic import rank
from baseline_octic import Polynomial,octic

def minor_rank(A,T):
 F=A.F
 vals=[A.sub(F.mul(T[i][0],T[j][1]),F.mul(T[i][1],T[j][0])) for i,j in itertools.combinations(range(4),2)]
 return rank(A.K,[F.digits(v) for v in vals])

def count(A,T):
 F=A.F;hist=collections.Counter();zeros=[]
 for x in projective(A.q,4):
  p=[F.dot(x,[t[j] for t in T]) for j in range(2)]
  skip=next(i for i,a in enumerate(x) if a)
  S=[A.sub(F.mul(p[0],t[1]),F.mul(p[1],t[0])) for j,t in enumerate(T) if j!=skip]
  r=rank(A.K,[F.digits(v) for v in S]);assert r==3
  sr=rank(A.K,[F.digits(F.mul(a,b)) for i,a in enumerate(S) for b in S[i:]])
  hist[sr]+=1
  if sr<6:zeros.append(x)
 return dict(hist),zeros
import argparse
ap=argparse.ArgumentParser();ap.add_argument("--work",type=Path,default=ROOT/"results");args=ap.parse_args();args.work.mkdir(parents=True,exist_ok=True)
out=[]
for q,etas in [(3,[3,4,124]),(5,[5,6,1846]),(7,[7,8,5543,12345,98000])]:
 A=Algebra(q);F=A.F;om=F.mu;xi=q
 for eta in etas+[F.pow(xi,q),F.pow(xi,q*q)]:
  T=[(1,1),(om,F.neg(om)),(xi,eta),(F.mul(om,xi),F.neg(F.mul(om,eta)))]
  d=minor_rank(A,T)
  if d!=4:print('excluded eta',q,eta,'rank',d);continue
  assert A.point_weights(T)['histogram']=={1:sum(q**i for i in range(4))}
  assert len(A.rr([A.ec(t[0])+A.ec(t[1]) for t in T])[1])==4
  h,z=count(A,T)
  print(q,eta,d,h,flush=True)
  out.append(dict(q=q,eta=eta,minor_rank=d,square_histogram=h,zeros=z))
input_ranks=[]
for r in json.loads((ROOT/'inputs/section_samples.json').read_text()):
 A=Algebra(r['q']);T=r['section'];d=minor_rank(A,T)
 assert A.point_weights(T)['histogram']=={1:sum(A.q**i for i in range(4))}
 assert len(A.rr([A.ec(t[0])+A.ec(t[1]) for t in T])[1])==4
 print('input rank',r['q'],r['label'],d)
 input_ranks.append(dict(q=A.q,label=r['label'],determinant_rank=d,scattered=True,E_span=4))
(args.work/'input_ranks.json').write_text(json.dumps(input_ranks,indent=2)+'\n')
(args.work/'initial.json').write_text(json.dumps(out,indent=2)+'\n')
