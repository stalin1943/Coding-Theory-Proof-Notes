"""Twisted (2,2) net attached to a determinant-rank-four section.
Pure exact arithmetic; only the underlying input field module is reused.
"""
from pathlib import Path
import sys,itertools
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'vendor'))
from algebra import Algebra,projective
from tower_arithmetic import rank
from baseline_octic import Polynomial,octic

M22=[(i,j) for i in range(3) for j in range(3)]
def section(A,eta):
 F=A.F;xi=A.q;w=F.mu
 return [(1,1),(w,F.neg(w)),(xi,eta),(F.mul(w,xi),F.neg(F.mul(w,eta)))]
def minor_values(A,T):
 F=A.F
 return [A.sub(F.mul(T[i][0],T[j][1]),F.mul(T[j][0],T[i][1])) for i,j in itertools.combinations(range(4),2)]
def minor_rank(A,T):return rank(A.K,[A.F.digits(v) for v in minor_values(A,T)])
def kernel(A,rows,n):
 R,p=A.rr(rows,n);ans=[]
 for j in range(n):
  if j in p:continue
  v=[0]*n;v[j]=1
  for row,c in zip(R,p):v[c]=A.F.neg(row[j])
  ans.append(v)
 return ans

def points(A,eta):
 F=A.F;x=F.neg(A.q);y=F.neg(eta);Z=[]
 for _ in range(6):
  Z.append((x,y));x,y=F.pow(y,A.q),F.pow(x,A.q)
 assert (x,y)==Z[0] and len(set(Z))==6
 return Z

def add(F,p,q):
 r=dict(p)
 for m,c in q.items():
  v=F.add(r.get(m,0),c)
  if v:r[m]=v
  else:r.pop(m,None)
 return r

def neg(F,p):return {m:F.neg(c) for m,c in p.items()}
def mul(F,p,q):
 r={}
 for (i,j),c in p.items():
  for (k,l),d in q.items():
   m=(i+k,j+l);v=F.add(r.get(m,0),F.mul(c,d))
   if v:r[m]=v
   else:r.pop(m,None)
 return r

def derivative(F,p,a):
 r={}
 for m,c in p.items():
  if m[a]:
   n=list(m);n[a]-=1;v=F.scale(m[a]%F.K.p,c)
   if v:r[tuple(n)]=v
 return r

def determinant(F,rows):
 out={}
 for pi in itertools.permutations(range(len(rows))):
  a={(0,0):1}
  for i,j in enumerate(pi):a=mul(F,a,rows[i][j])
  if sum(pi[i]>pi[j] for i in range(len(pi)) for j in range(i+1,len(pi)))%2:a=neg(F,a)
  out=add(F,out,a)
 return out

def net(A,eta):
 F=A.F;Z=points(A,eta)
 ev=[[F.mul(F.pow(x,i),F.pow(y,j)) for i,j in M22] for x,y in Z]
 N=kernel(A,ev,9);assert len(N)==3
 basis=[{m:c for m,c in zip(M22,row) if c} for row in N]
 jac=determinant(F,[basis,[derivative(F,p,0) for p in basis],[derivative(F,p,1) for p in basis]])
 assert jac and max(i for i,j in jac)<=4 and max(j for i,j in jac)<=4
 assert all(c in A.Eset for c in jac.values())
 return Z,basis,jac

def eval_bihom(F,p,a,b,d1,d2):
 x0,x1=a;y0,y1=b;z=0
 for (i,j),c in p.items():
  t=F.mul(F.pow(x0,i),F.pow(x1,d1-i));t=F.mul(t,F.mul(F.pow(y0,j),F.pow(y1,d2-j)))
  z=F.add(z,F.mul(c,t))
 return z

def normalize(F,p):
 m=max(p);iv=F.inv(p[m]);return {k:F.mul(c,iv) for k,c in p.items()}

def compose(A,jac):
 P=Polynomial(A);F=A.F;w=P.index[F.mu];wn=P.negs[w]
 forms=[{1:1,16:w},{256:1,4096:w},{1:1,16:wn},{256:1,4096:wn}]
 powers=[]
 for f in forms:
  row=[{0:1}]
  for _ in range(4):row.append(P.mul(row[-1],f))
  powers.append(row)
 out={}
 for (i,j),c in jac.items():
  p={0:P.index[c]}
  for k,e in enumerate([i,4-i,j,4-j]):p=P.mul(p,powers[k][e])
  out=P.add(out,p)
 out={m:P.E[c] for m,c in out.items()};out=normalize(F,out)
 assert all(c<A.q for c in out.values())
 return out

def classify(A,eta):
 F=A.F;Z=points(A,eta)
 if len({x for x,y in Z})<6:
  assert eta in [F.pow(A.q,A.q),F.pow(A.q,A.q*A.q)]
  return 'Moore_collision'
 # A four-point (1,1) curve must omit opposite members of the 6-cycle.
 ii=[1,2,4,5]
 E4=[[1,x,y,F.mul(x,y)] for x,y in [Z[i] for i in ii]]
 r=len(A.rr(E4)[1]);assert r in [3,4]
 return 'conjugate_three_curves' if r==3 else 'degree_two_del_Pezzo'

def curve_record(A,eta,bind_octic=False):
 F=A.F;T=section(A,eta);assert minor_rank(A,T)==4
 Z,basis,jac=net(A,eta);cl=classify(A,eta)
 roots=[]
 for a in A.E2:
  if eval_bihom(F,jac,(a,1),(A.bar(a),1),4,4)==0:roots.append(a)
 if eval_bihom(F,jac,(1,0),(1,0),4,4)==0:roots.append(-1)
 # Check all six double base points algebraically.
 for x,y in Z:
  for p in [jac,derivative(F,jac,0),derivative(F,jac,1)]:
   assert eval_bihom(F,p,(x,1),(y,1),4,4)==0
 if cl=='degree_two_del_Pezzo':
  for I in itertools.combinations(range(6),4):
   assert len(A.rr([[1,Z[i][0],Z[i][1],F.mul(*Z[i])] for i in I])[1])==4
  for d,e in [(2,1),(1,2)]:
   assert len(A.rr([[F.mul(F.pow(x,i),F.pow(y,j)) for i in range(d+1) for j in range(e+1)] for x,y in Z])[1])==6
 else:
  assert len(roots)==A.q+1
 record=dict(q=A.q,eta=eta,section=T,case=cl,net_basis=[[[i,j,c] for (i,j),c in sorted(p.items())] for p in basis],jacobian=[[*m,c] for m,c in sorted(jac.items())],quotient_roots=roots,quotient_zeros=len(roots),original_zeros=(A.q+1)*len(roots),octic_bound_checked=False)
 if bind_octic:
  expected=compose(A,jac);P=Polynomial(A);O,_=octic(A,P,T);actual=normalize(F,O)
  assert expected==actual
  record['octic_bound_checked']=True;record['octic_terms']=len(O)
 return record
if __name__=='__main__':
 import json,random,argparse
 ap=argparse.ArgumentParser();ap.add_argument("--work",type=Path,default=ROOT/"results");args=ap.parse_args();args.work.mkdir(parents=True,exist_ok=True)
 out=[]
 for q,etas in [(3,[4,124]),(5,[6,1846]),(7,[8,5543,12345,98000])]:
  A=Algebra(q);F=A.F
  etas += [F.pow(q,q),F.pow(q,q*q)]
  # find a conjugate three-curve case, without searching graph parameters
  hits=0
  for eta in range(q,F.Q):
   if eta in A.Eset or eta in etas:continue
   if minor_rank(A,section(A,eta))!=4:continue
   if classify(A,eta)=='conjugate_three_curves':
    etas.append(eta);hits+=1
    if hits==2:break
  for eta in etas:
   r=curve_record(A,eta,True);out.append(r);print(q,eta,r['case'],r['quotient_zeros'],r['octic_terms'],flush=True)
 (args.work/'curves.json').write_text(json.dumps(out,indent=2)+'\n')
