#!/usr/bin/env python3
"""Constructively recover the rank-four semilinear normal form.
Checks actual K-subspace equality after explicit F-linear coordinate changes.
Not a classification of determinant ranks five and six.
"""
from pathlib import Path
import sys, json, random, itertools, argparse
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'vendor'))
from algebra import Algebra
from tower_arithmetic import rank
from twisted_curve import section,minor_values,minor_rank,kernel

PAIRS=list(itertools.combinations(range(4),2))

def pfaff(A,z):
 F=A.F
 return F.add(A.sub(F.mul(z[0],z[5]),F.mul(z[1],z[4])),F.mul(z[2],z[3]))

def recover(A,T):
 F=A.F;K=A.K
 det=minor_values(A,T)
 rows=[[F.digits(x)[j] for x in det] for j in range(6)]
 N=kernel(A,rows,6)
 assert len(N)==2 and all(x<A.q for r in N for x in r)
 assert all(pfaff(A,[F.add(x,F.mul(t,y)) for x,y in zip(*N)]) for t in range(A.q))
 roots=[]
 for t in A.E2:
  z=[F.add(x,F.mul(t,y)) for x,y in zip(*N)]
  if pfaff(A,z)==0:roots.append(t)
 assert len(roots)==2 and all(t>=A.q for t in roots)
 assert A.bar(roots[0])==roots[1]
 z=[F.add(x,F.mul(roots[0],y)) for x,y in zip(*N)]
 skew=[[0]*4 for _ in range(4)]
 for (i,j),v in zip(PAIRS,z):skew[i][j]=v;skew[j][i]=F.neg(v)
 Vplus,_=A.rr(skew,4)
 assert len(Vplus)==2
 Vminus=[[A.bar(x) for x in r] for r in Vplus]
 assert len(A.rr(Vplus+Vminus,4)[1])==4
 def image(r):return [F.dot(r,[v[j] for v in T]) for j in range(2)]
 plus=[image(r) for r in Vplus];minus=[image(r) for r in Vminus]
 assert A.det3([[plus[0][0],plus[0][1],0],[plus[1][0],plus[1][1],0],[0,0,1]])==0
 C=[plus[0],minus[0]];Cinv=A.inverse(C)
 p=A.matmul(plus,Cinv);m=A.matmul(minus,Cinv)
 assert all(row[1]==0 for row in p) and all(row[0]==0 for row in m)
 a,b=p[0][0],m[0][1]
 scale=[[F.inv(a),0],[0,F.inv(b)]]
 trans=A.matmul(Cinv,scale)
 TT=A.matmul(T,trans)
 xi=F.mul(p[1][0],F.inv(a));eta=F.mul(m[1][1],F.inv(b))
 assert xi not in A.Eset and eta not in A.Eset
 om=F.mu
 model=[(1,1),(om,F.neg(om)),(xi,eta),(F.mul(om,xi),F.neg(F.mul(om,eta)))]
 assert A.kcan(TT)==A.kcan(model)
 # An E-linear relation gives a PGL(2,E) map taking xi to xi0=q.
 xi0=A.q
 cols=[1,xi,F.neg(xi0),F.neg(F.mul(xi0,xi))]
 rel=kernel(A,[[A.ec(x)[j] for x in cols] for j in range(3)],4)
 assert len(rel)==1
 aa,bb,cc,dd=rel[0]
 assert A.sub(F.mul(cc,bb),F.mul(aa,dd))!=0
 denom1=F.add(cc,F.mul(dd,xi))
 denom2=F.add(A.bar(cc),F.mul(A.bar(dd),eta))
 eta0=F.mul(F.add(A.bar(aa),F.mul(A.bar(bb),eta)),F.inv(denom2))
 assert F.mul(F.add(aa,F.mul(bb,xi)),F.inv(denom1))==xi0
 trans=A.matmul(trans,[[F.inv(denom1),0],[0,F.inv(denom2)]])
 canonical=section(A,eta0)
 assert A.kcan(A.matmul(T,trans))==A.kcan(canonical)
 assert minor_rank(A,canonical)==4
 return dict(kernel=N,split_roots=roots,plus=Vplus,minus=Vminus,
             transform=trans,eta=eta0,canonical_section=canonical)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path,default=ROOT/'results');args=ap.parse_args();args.work.mkdir(parents=True,exist_ok=True)
 out=[]
 for q,etas in [(3,[4,124,11,26]),(5,[6,1846,84,65]),(7,[8,5543,165,226])]:
  A=Algebra(q);F=A.F;R=random.Random(813400+q)
  for eta in etas:
   for rep in range(3):
    original=section(A,eta)
    while True:
     L=[[R.randrange(q) for _ in range(4)] for _ in range(4)]
     if rank(A.K,L)==4:break
    while True:
     G=[[R.randrange(F.Q) for _ in range(2)] for _ in range(2)]
     if A.sub(F.mul(G[0][0],G[1][1]),F.mul(G[0][1],G[1][0])):break
    T=A.matmul(A.matmul(L,original),G)
    assert minor_rank(A,T)==4
    rec=recover(A,T)
    # Recovered and source normal forms must have the same complete orbit count.
    arr=(args.work/f'q{q}_scan.bin').read_bytes()
    assert arr[eta]==arr[rec['eta']] and arr[eta]<254
    out.append(dict(q=q,source_eta=eta,repeat=rep,section=T,**rec,quotient_zeros=arr[eta]))
  print('normal-form recovery',q,12,flush=True)
 result=dict(status='passed',models=len(out),explicit_F_linear_equivalences=len(out),records=out,
             scope='36 transformed rank-four sections; exact subspace equalities, not enumeration of all sections')
 (args.work/'normal_form.json').write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__':main()
