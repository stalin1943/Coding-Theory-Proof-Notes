#!/usr/bin/env python3
"""Independently rebuild quinary point equations from original trace systems.
Quadratic-then-cubic coefficient arithmetic, right pivots, direct graph basis solves.
It does not import the primary block constructor or its formulas.
"""
from pathlib import Path
import sys,itertools,json,argparse,time
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'vendor'))
from graph_independent_arithmetic import Field,proj
q=5

def rr(rows,n):
 a=[list(r) for r in rows];p=[];i=0
 for j in range(n-1,-1,-1):
  k=next((k for k in range(i,len(a)) if a[k][j]%q),None)
  if k is None:continue
  a[i],a[k]=a[k],a[i];iv=pow(a[i][j],-1,q);a[i]=[x*iv%q for x in a[i]]
  for k in range(len(a)):
   if k!=i and a[k][j]:
    c=a[k][j];a[k]=[(x-c*y)%q for x,y in zip(a[k],a[i])]
  p.append(j);i+=1
  if i==len(a):break
 return a[:i],p

def nk(rows,n):
 a,p=rr(rows,n);out=[]
 for j in range(n):
  if j in p:continue
  v=[0]*n;v[j]=1
  for r,k in zip(a,p):v[k]=-r[j]%q
  out.append(v)
 return out

def inv_e(F,rows):
 n=len(rows);a=[list(r)+[int(i==j) for j in range(n)] for i,r in enumerate(rows)];p=[];i=0
 for j in range(n-1,-1,-1):
  k=next(k for k in range(i,n) if a[k][j]);a[i],a[k]=a[k],a[i]
  a[i]=[F.em[F.ei[a[i][j]]][x] for x in a[i]]
  for k in range(n):
   if k!=i and a[k][j]:
    c=a[k][j];a[k]=[F.ea[x][F.en[F.em[c][y]]] for x,y in zip(a[k],a[i])]
  p.append(j);i+=1
 out=[None]*n
 for k,r in zip(p,a):out[k]=r[n:]
 return out

def etr(F,x):
 y=F.add(F.add(x,F.pow(x,25)),F.pow(x,625));assert y<F.e;return y

def tr(F,x):
 y=etr(F,x);v=F.ea[y][F.epow(y,q)];assert v<q;return v

def ecoef(F,z,S):
 out=[]
 for i,j in [(0,0),(0,1),(0,2),(1,1),(1,2),(2,2)]:
  v=F.mul(F.pow(S[i],25),F.pow(S[j],625))
  if i!=j:v=F.add(v,F.mul(F.pow(S[j],25),F.pow(S[i],625)))
  out.append(etr(F,F.mul(z,v)))
 return out

def point_block(F,T,x):
 xi,om=F.xi,F.mu;kb=[1,om,xi,F.mul(om,xi),F.mul(xi,xi),F.mul(om,F.mul(xi,xi))]
 rawfb=[kb[i] for i in [0,2,4,1,3,5]]
 P=[F.dot(x,[t[j] for t in T]) for j in range(2)];ell=[F.neg(P[1]),P[0]]
 vals=[F.dot(ell,t) for t in T]
 sm,_=rr([F.flat([s]) for s in vals],6);S=[F.dot(v,kb) for v in sm];assert len(S)==3
 D=[F.dot(v,kb) for v in nk([[tr(F,F.mul(s,b)) for b in kb] for s in S],6)]
 assert len(D)==3
 di=inv_e(F,[F.dig(x) for x in D]);inv_e(F,[F.dig(x) for x in S])
 zvec=[F.mul(F.alpha,z) for z in [1,om,xi,F.mul(om,xi)]]
 comp=kb[2:];ci=inv_e(F,[[tr(F,F.mul(z,c)) for c in comp] for z in zvec])
 assert all(v<q for row in ci for v in row)
 cslots=[F.dot([ci[i][j] for i in range(4)],comp) for j in range(4)]
 gi=inv_e(F,[[etr(F,F.mul(x,y)) for y in F.eb] for x in F.eb]);dual=[F.dot(r,F.eb) for r in gi]
 columns=[ecoef(F,e,S) for e in kb]
 kn=nk([[columns[j][i]//q for j in range(6)] for i in range(6)],6)
 assert len(kn)==1
 z0=F.dot(kn[0],kb);v0=F.dig(z0);assert all(c<q for c in ecoef(F,z0,S))
 result=[]
 for slot in range(4):
  for coord in range(2):
   for elem in rawfb:
    images=[F.scale(-tr(F,F.mul(t,F.mul(ell[coord],elem)))%q,cslots[slot]) for t in D]
    coeff=[F.dig(v)[1:] for v in images]
    g=[]
    for j in range(3):
     row=[]
     for a in range(2):
      z=0
      for i in range(3):z=F.ea[z][F.em[di[j][i]][coeff[i][a]]]
      row.append(z)
     g.append(row)
    aa=F.dot([r[0] for r in g],dual);bb=F.dot([r[1] for r in g],dual)
    z=F.sub(F.mul(aa,dual[2]),F.mul(bb,dual[1]));v=F.dig(z);col=[]
    for i,j in [(0,1),(0,2),(1,2)]:
     c=F.ea[F.em[v[i]][v0[j]]][F.en[F.em[v[j]][v0[i]]]];col.extend([c%q,c//q])
    result.append(col)
 return list(map(list,zip(*result)))

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path,default=ROOT/'results');args=ap.parse_args();wd=args.work;start=time.monotonic()
 data=json.loads((wd/'quinary_blocks.json').read_text());F=Field(dict(q=5,beta=0,nu=2,cubic_polynomial=[1,0,1,1]))
 expected={i for i,v in enumerate((wd/'q5_independent.bin').read_bytes()) if v==14}
 assert expected=={r['eta'] for r in data['records']} and len(expected)==18
 blocks_checked=0;groups_checked=0;distinct_points=0;point_checks=0;zero_sets=[]
 for rec in data['records']:
  T=[[F.convert(x) for x in t] for t in rec['section']]
  # Point list coverage is regenerated using right-normalized projective coordinates.
  pointset=set()
  for x in proj(q,4):
   iv=pow(next(a for a in x if a),-1,q);pointset.add(tuple(iv*a%q for a in x))
  assert pointset=={tuple(r['point']) for r in rec['points']}
  mats={};point_hist={}
  for i,p in enumerate(rec['points']):
   x=p['point'];P=[F.dot(x,[t[j] for t in T]) for j in range(2)];ell=[F.neg(P[1]),P[0]]
   skip=next(j for j,c in enumerate(x) if c)
   S=[F.dot(ell,t) for j,t in enumerate(T) if j!=skip]
   assert F.rank([F.flat([v]) for v in S])==3
   er=F.rank([F.flat([v]) for v in S]+[F.flat([F.mul(F.mu,v)]) for v in S])//2
   sr=F.rank([F.flat([F.mul(v,w)]) for j,v in enumerate(S) for w in S[j:]])
   assert (er,sr)==(p['E_rank'],p['square_rank']);point_checks+=1
   if 'raw_block' not in p:continue
   mat=point_block(F,T,p['point']);assert rr(mat,48)[0]==rr(p['raw_block'],48)[0]
   assert len(rr(mat,48)[1])==4
   assert all(sum(x*y for x,y in zip(row,g))%q==0 for row in mat for g in rec['gauge'])
   mats[i]=[[row[j] for j in rec['free_columns']] for row in mat];blocks_checked+=1
  assert len(mats)==72
  assert len(rr(rec['gauge'],48)[1])==28
  axes=[[int(i==j) for i in range(48)] for j in rec['free_columns']]
  assert len(rr(rec['gauge']+axes,48)[1])==48
  groups=rec['disjoint_rank20_groups'];assert len(groups)==7
  used=[]
  for group in groups:
   assert len(rr([r for i in group for r in mats[i]],20)[1])==20
   used+=group;groups_checked+=1
  assert len(set(used))==len(used);distinct_points+=len(used)
  print('independent original trace blocks:',rec['eta'],len(mats),'seven disjoint full-rank groups',flush=True)
 out=dict(status='passed',q=5,models=18,all_section_point_ranks=point_checks,original_trace_point_blocks=blocks_checked,
          disjoint_full_rank_groups=groups_checked,group_point_occurrences=distinct_points,
          all_group_ranks=20,common_raw_kernel_dimension=28,
          maximum_allowed_good_points_for_nonzero_graph=77,required_good_points=78,
          arithmetic='quadratic then cubic coefficient arithmetic; direct 48-basis original-trace solves; reverse pivots',
          scope='all 18 maximal normal-form sections and all their 1296 ordinary zero-point blocks; no full graph enumeration',
          seconds=time.monotonic()-start)
 (wd/'quinary_independent.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
