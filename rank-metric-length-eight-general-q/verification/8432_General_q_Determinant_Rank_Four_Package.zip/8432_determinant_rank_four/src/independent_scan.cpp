// Independent coefficient arithmetic: K -> E (degree 2) -> F (degree 3).
// No import of the primary arithmetic, logarithms, or square-span code.
#include <algorithm>
#include <array>
#include <cassert>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <string>
#include <vector>
using namespace std;
struct Arithmetic {
 int p,e,Q,nu,c2;vector<int>ea,em,en,esh,shift1,shift2,kinv;vector<array<int,6>>digits;
 int add(int x,int y)const {return ea[(x%e)*e+y%e]+e*ea[((x/e)%e)*e+(y/e)%e]+e*e*ea[(x/(e*e))*e+y/(e*e)];}
 int neg(int x)const{return en[x%e]+e*en[(x/e)%e]+e*e*en[x/(e*e)];}
 int sub(int x,int y)const{return add(x,neg(y));}
 int scaleE(int a,int x)const{return esh[a*Q+x];}
 int mul(int x,int y)const{return add(add(scaleE(y%e,x),scaleE((y/e)%e,shift1[x])),scaleE(y/(e*e),shift2[x]));}
 int barE(int x)const{return x%p+p*((p-x/p)%p);}
 int from_original(int x)const{array<int,6>a{};for(int i=0;i<6;i++){a[i]=x%p;x/=p;}return a[0]+p*a[3]+e*(a[1]+p*a[4])+e*e*(a[2]+p*a[5]);}
 explicit Arithmetic(int q):p(q),e(q*q),Q(e*e*e),ea(e*e),em(e*e),en(e),esh(e*Q),shift1(Q),shift2(Q),kinv(p),digits(Q){
  assert(p==3||p==5||p==7);nu=0;for(int c=2;c<p;c++){bool sq=false;for(int a=1;a<p;a++)if(a*a%p==c)sq=true;if(!sq){nu=c;break;}}assert(nu);
  c2=0;for(int c=0;c<p;c++){bool hasroot=false;for(int x=0;x<p;x++)if((x*x*x+c*x*x+1)%p==0)hasroot=true;if(!hasroot){c2=c;break;}}assert(c2);
  for(int a=0;a<e;a++){int a0=a%p,a1=a/p;en[a]=(p-a0)%p+p*((p-a1)%p);for(int b=0;b<e;b++){int b0=b%p,b1=b/p;ea[a*e+b]=(a0+b0)%p+p*((a1+b1)%p);em[a*e+b]=(a0*b0+nu*a1*b1)%p+p*((a0*b1+a1*b0)%p);}}
  for(int c=0;c<e;c++)for(int x=0;x<Q;x++)esh[c*Q+x]=em[c*e+x%e]+e*em[c*e+(x/e)%e]+e*e*em[c*e+x/(e*e)];
  for(int x=0;x<Q;x++){int a=x%e,b=(x/e)%e,c=x/(e*e);shift1[x]=en[c]+e*a+e*e*ea[b*e+en[em[c2*e+c]]];int z=x;for(int j=0;j<6;j++){digits[x][j]=z%p;z/=p;}}
  for(int x=0;x<Q;x++)shift2[x]=shift1[shift1[x]];
  for(int a=1;a<p;a++)for(int b=1;b<p;b++)if(a*b%p==1)kinv[a]=b;
  for(int x=1;x<e;x++) {int inv=0;for(int y=1;y<e;y++)if(em[x*e+y]==1)inv=y;assert(inv&&mul(x,inv)==1);}
 }
 int rank(const vector<int>&values)const{
  vector<array<int,6>>a;for(int x:values)a.push_back(digits[x]);int r=0;
  for(int c=5;c>=0;c--){int i=r;while(i<(int)a.size()&&!a[i][c])i++;if(i==(int)a.size())continue;swap(a[i],a[r]);int inv=kinv[a[r][c]];for(int j=0;j<=c;j++)a[r][j]=a[r][j]*inv%p;
   for(int k=r+1;k<(int)a.size();k++){int v=a[k][c];if(v)for(int j=0;j<=c;j++)a[k][j]=(a[k][j]-v*a[r][j]+p*p)%p;}r++;if(r==(int)a.size())break;}
  return r;
 }
 int determinant(const array<int,2>&a,const array<int,2>&b)const{return sub(mul(a[0],b[1]),mul(a[1],b[0]));}
 bool bad(const array<int,2>&P,const vector<array<int,2>>&others)const{
  vector<int>s;for(auto a:others)s.push_back(determinant(P,a));assert(rank(s)==3);vector<int>sq;for(int i=0;i<3;i++)for(int j=i;j<3;j++)sq.push_back(mul(s[i],s[j]));return rank(sq)<6;
 }
};
int main(int argc,char**argv){
 int q=argc>1?stoi(argv[1]):7;string prefix=argc>2?argv[2]:"independent";auto start=chrono::steady_clock::now();Arithmetic F(q);int xi=F.e,om=q;
 vector<uint8_t>record(F.Q,255);map<int,int>dhist,zhist;int total=0,valid=0;long long count=0;
 for(int original=0;original<F.Q;original++){
  int eta=F.from_original(original);if(eta<F.e)continue;total++;
  vector<array<int,2>>T={{{1,1}},{{om,F.neg(om)}},{{xi,eta}},{{F.mul(om,xi),F.neg(F.mul(om,eta))}}};
  vector<int>minors;for(int i=0;i<4;i++)for(int j=i+1;j<4;j++)minors.push_back(F.determinant(T[i],T[j]));int r=F.rank(minors);dhist[r]++;
  if(r!=4){record[original]=254;continue;}valid++;
  int zero=0;
  for(int t=0;t<F.e;t++){
   array<int,2>P={F.add(t,xi),F.add(F.barE(t),eta)};
   array<int,2>omP={F.scaleE(om,P[0]),F.scaleE(F.barE(om),P[1])};
   if(F.bad(P,{omP,T[0],T[1]}))zero++;count++;
  }
  if(F.bad(T[0],{T[1],T[2],T[3]}))zero++;count++;
  record[original]=zero;zhist[zero]++;
 }
 ofstream out(prefix+".json");out<<"{\"q\":"<<q<<",\"coefficient_tower\":\"quadratic_then_cubic\",\"parameters_tested\":"<<total<<",\"rank4_parameters\":"<<valid<<",\"quotient_directions_checked\":"<<count<<",\"determinant_rank_histogram\":{";bool first=true;for(auto[k,v]:dhist){if(!first)out<<",";first=false;out<<"\""<<k<<"\":"<<v;}out<<"},\"quotient_zero_histogram\":{";first=true;for(auto[k,v]:zhist){if(!first)out<<",";first=false;out<<"\""<<k<<"\":"<<v;}out<<"},\"seconds\":"<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"}\n";
 ofstream bin(prefix+".bin",ios::binary);bin.write((char*)record.data(),record.size());cerr<<"independent q="<<q<<" parameters="<<total<<" valid="<<valid<<" finished\n";
}
