#!/usr/bin/env python3
"""Recompute this supplement in a new directory and compare exact outputs.
Python standard library and a C++17 compiler are required. Assertions stay on.
This is finite verification, not a formalization of the analytic proof.
"""
from pathlib import Path
import argparse,hashlib,json,os,re,shutil,subprocess,sys,time

RESULTS=['symbolic.json','poles.json','semilinear.json','independent.json',
         'residual_inputs.json','residuals.json','independent_residuals.json']

def mathematical(x):
 if isinstance(x,dict):return {k:mathematical(v) for k,v in x.items() if k not in {'elapsed_seconds','seconds'}}
 if isinstance(x,list):return [mathematical(v) for v in x]
 return x

def tex_check(p):
 s=re.sub(r'(?<!\\)%[^\n]*','',p.read_text());stack=[]
 for mode,name in re.findall(r'\\(begin|end)\{([^}]+)\}',s):
  if mode=='begin':stack.append(name)
  else:assert stack and stack.pop()==name
 assert not stack
 level=0
 for c in re.sub(r'\\[{}]','',s):
  if c=='{':level+=1
  if c=='}':level-=1
  assert level>=0
 assert level==0
 labels=re.findall(r'\\label\{([^}]+)\}',s);refs=re.findall(r'\\(?:ref|eqref)\{([^}]+)\}',s)
 assert len(labels)==len(set(labels)) and set(refs)<=set(labels)
 return dict(labels=len(labels),internal_references=len(refs),scope='structural checks only; no complete manuscript compilation')

def run(root,work,compare=True):
 if not __debug__:raise RuntimeError('Do not disable Python assertions.')
 root=root.resolve();work=work.resolve()
 if work==root or root in work.parents:raise ValueError('Work directory must be outside the package.')
 if work.exists() and (not work.is_dir() or any(work.iterdir())):raise ValueError('Use a new or empty work directory.')
 work.mkdir(parents=True,exist_ok=True);start=time.time();manifest_n=0
 if (root/'MANIFEST.json').exists():
  for name,want in json.loads((root/'MANIFEST.json').read_text()).items():
   assert hashlib.sha256((root/name).read_bytes()).hexdigest()==want,name
   manifest_n+=1
 jobs=[('check_symbolic.py',['--output',str(work/'symbolic.json')]),
       ('check_poles.py',['--output',str(work/'poles.json')]),
       ('check_semilinear.py',['--output',str(work/'semilinear.json')]),
       ('independent_check.py',['--results',str(work)]),
       ('generate_residuals.py',['--results',str(work)])]
 stages=[]
 for name,args in jobs:
  t=time.time()
  with (work/(name+'.log')).open('w') as f:subprocess.run([sys.executable,str(root/'src'/name),*args],stdout=f,stderr=subprocess.STDOUT,check=True,cwd=root)
  stages.append(dict(program=name,passed=True,seconds=round(time.time()-t,3)))
  print(name,'passed',flush=True)
 cxx=os.environ.get('CXX') or shutil.which('g++') or shutil.which('clang++')
 if not cxx:raise RuntimeError('A C++17 compiler is required for the explicit residual-family check.')
 exe=work/'check_residuals'
 with (work/'compile.log').open('w') as f:subprocess.run([cxx,'-std=c++17','-O3',str(root/'src/check_residuals.cpp'),'-o',str(exe)],stdout=f,stderr=subprocess.STDOUT,check=True)
 t=time.time()
 with (work/'check_residuals.log').open('w') as f:subprocess.run([str(exe),str(work/'residual_input.txt'),str(work/'residuals.json')],stdout=f,stderr=subprocess.STDOUT,check=True)
 stages.append(dict(program='check_residuals.cpp',passed=True,seconds=round(time.time()-t,3)));print('check_residuals.cpp passed',flush=True)
 t=time.time()
 with (work/'independent_residuals.log').open('w') as f:subprocess.run([sys.executable,str(root/'src/independent_residuals.py'),'--results',str(work)],stdout=f,stderr=subprocess.STDOUT,check=True)
 stages.append(dict(program='independent_residuals.py',passed=True,seconds=round(time.time()-t,3)));print('independent_residuals.py passed',flush=True)
 if compare:
  for name in RESULTS:assert mathematical(json.loads((work/name).read_text()))==mathematical(json.loads((root/'results'/name).read_text())),name
 p=json.loads((work/'poles.json').read_text());s=json.loads((work/'semilinear.json').read_text());r=json.loads((work/'independent_residuals.json').read_text())
 out=dict(status='passed',date='2026-09-13',analytic_eps0_range='all prime powers q>=4; q=3 is inherited',
   analytic_eps1_range='exact secant-compatible family for q>=4',residual_family_formula='q^2*(q^2+q+1)',
   new_complete_cubic_subline_base_fields=[4,5],full_existence_classification_completed=False,
   pole_formula_examples=p['counts'],semilinear_examples=dict(models=s['model_count'],secants=s['secant_checks'],ternary_actual_space_set_matched=s['ternary_set_match']),
   complete_residual_spaces=r['complete_residual_spaces_checked'],residual_spaces_per_q=r['models_per_q'],explicit_residual_failures=r['violations_per_q'],
   old_large_enumerations_recomputed=False,external_mathematical_review_completed=False,proof_assistant_formalization=False,
   tex=tex_check(root/'THEOREMS_en.tex'),manifest_files_checked=manifest_n,all_saved_mathematical_outputs_compared=compare,jobs=stages,elapsed_seconds=round(time.time()-start,3),
   scope='analytic proofs plus finite formula checks and complete small residual families only; not complete q=3,4,5 code classification and not a general-q brute-force enumeration')
 (work/'verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False,indent=2),flush=True)
 return out

def main():
 p=argparse.ArgumentParser();p.add_argument('--work',type=Path,required=True);a=p.parse_args();run(Path(__file__).resolve().parent,a.work)
if __name__=='__main__':main()
