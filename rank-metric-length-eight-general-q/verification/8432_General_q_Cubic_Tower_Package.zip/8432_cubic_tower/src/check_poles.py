#!/usr/bin/env python3
"""Exact examples for the cubic-tower split-projection obstruction.
The theorem is analytic. This program checks explicitly listed models and
extensions; it does not enumerate all codes or all scalar types.
"""
from pathlib import Path
import itertools as it,json,random,time,argparse
from tower_model import *

def pa(F,a,b):
    n=max(len(a),len(b));r=[0]*n
    for i,x in enumerate(a):r[i]=F.add(r[i],x)
    for i,x in enumerate(b):r[i]=F.add(r[i],x)
    while len(r)>1 and r[-1]==0:r.pop()
    return r

def pm(F,a,b):
    r=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):r[i+j]=F.add(r[i+j],F.mul(x,y))
    return r

def pe(F,a,t):
    r=0
    for x in reversed(a):r=F.add(F.mul(r,t),x)
    return r

def ba(F,A,B):return [[F.add(A[i][j],B[i][j]) for j in range(len(A[0]))] for i in range(len(A))]
def bm(F,A,B):
    C=[[0]*(len(A[0])+len(B[0])-1) for _ in range(len(A)+len(B)-1)]
    for i,row in enumerate(A):
        for j,a in enumerate(row):
            if not a:continue
            for k,row2 in enumerate(B):
                for l,b in enumerate(row2):
                    if b:C[i+k][j+l]=F.add(C[i+k][j+l],F.mul(a,b))
    return C

def be(F,A,s,t):
    if s is None:row=A[-1]
    else:row=[pe(F,[A[i][j] for i in range(len(A))],s) for j in range(len(A[0]))]
    return row[-1] if t is None else pe(F,row,t)

def row_polynomials(m,w,L):
    F=m.F;q=m.q;P,J,nu=m.flag_data(L);a,b,c=m.abc(L,w)
    conjugates=[F.pow(m.lam,q**i) for i in range(3)];weights=[F.pow(m.kappa_weight,q**i) for i in range(3)]
    f=[1]
    for lam in conjugates:f=pm(F,f,[lam,1])
    assert all(z<q for z in f)
    A=[[0]*4 for _ in range(2)];B=[[0]*2 for _ in range(4)]
    ca=[m.kappa(F.add(F.mul(m.lam,c[0]),F.neg(F.add(a[0],F.mul(J[0][0],b[0]))))),m.kappa(c[0])]
    cb=[m.kappa(F.add(F.mul(m.lam,c[1]),F.neg(F.add(a[1],F.mul(J[1][1],b[1]))))),m.kappa(c[1])]
    for i in range(2):
        for j in range(4):A[i][j]=F.mul(ca[i],f[j]);B[j][i]=F.mul(cb[i],f[j])
    for h,lam in enumerate(conjugates):
        fj=[1]
        for k,other in enumerate(conjugates):
            if k!=h:fj=pm(F,fj,[other,1])
        coeff1=F.mul(weights[h],F.pow(F.mul(J[0][1],b[1]),q**h));coeff2=F.mul(weights[h],F.pow(F.mul(J[1][0],b[0]),q**h))
        for i,factor in enumerate([lam,1]):
            for j,value in enumerate(fj):
                A[i][j]=F.add(A[i][j],F.neg(F.mul(coeff1,F.mul(factor,value))))
                B[j][i]=F.add(B[j][i],F.neg(F.mul(coeff2,F.mul(factor,value))))
    assert all(x<q for row in A+B for x in row)
    return A,B,f

def determinant_poly(m,v,w,L):
    A,B,f=row_polynomials(m,v,L);C,D,g=row_polynomials(m,w,L);assert f==g
    R=bm(m.F,A,D);S=bm(m.F,C,B)
    R=[[m.F.add(x,m.F.neg(y)) for x,y in zip(r,s)] for r,s in zip(R,S)]
    assert len(R)==len(R[0])==5 and all(x<m.q for row in R for x in row)
    return R,f

def witness(m,v,w,s,t):
    F=m.F;K=m.K;lam=m.lam;mu=m.mu;L=m.flags[0]
    x=[1,0,0] if s is None else [F.add(s,lam),0,1]
    y=[0,1,0] if t is None else [0,F.add(t,lam),mu]
    n=m.normal(L,s,t);W=m.W0+[v,w]
    assert dot(F,n,x)==dot(F,n,y)==0
    assert rank(K,[F.digits(dot(F,n,a)) for a in W])==6
    trrows=[[F.trace(F.mul(a[k],m.q**j)) for k in range(3) for j in range(6)] for a in W]
    Ucoeff=null(K,trrows,18);assert len(Ucoeff)==8
    U=[[F.pack(a[6*k:6*k+6]) for k in range(3)] for a in Ucoeff]
    words=[[dot(F,msg,u) for u in U] for msg in [x,y]]
    sr=[[[F.digits(a)[j] for a in word] for j in range(6)] for word in words]
    ranks=[rank(K,sr[0]),rank(K,sr[1]),rank(K,sr[0]+sr[1])];assert ranks==[4,4,8]
    return dict(parameters=[s,t],normal=n,secant_points=[x,y],U_basis=U,codewords=words,support_rank_triple=ranks)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);args=ap.parse_args();start=time.time();records=[];models=[];rng=random.Random(84320613)
    counts=dict(models=0,extensions=0,projection_values=0,polynomial_grid_values=0,pole_evaluations=0,explicit_codeword_pairs=0)
    for q in [3,4,5,7]:
        first=Model(q);F=first.F;mu2=F.pow(q,q**4+q*q+1)
        if mu2<q:
            for k in range(q,F.Q):
                mu2=F.pow(k,q**4+q*q+1)
                if mu2>=q:break
        mus=[first.mu,F.add(first.mu,1),mu2]
        assert len(set(mus))==3
        for mi,mu in enumerate(mus):
            m=Model(q,mu,first.lam);F=m.F;K=m.K;L=m.flags[0]
            rows,norms=m.kernel_rows(L);counts['projection_values']+=(q+1)**2*(10+8)
            # Input check: the field polynomial is independent of any enumerated code.
            model=dict(q=q,polynomial=F.pol,lambda_value=m.lam,mu=mu,E_basis=m.eb,tower_basis=m.basis,E_polynomial=m.E_polynomial,mu_quadratic=m.quadratic,coordinate_rows=m.co,mu_matrix=m.J,kappa_weight=m.kappa_weight,X=m.X,W0=m.W0,quotient_basis=m.reps,secant_grid_size=(q+1)**2)
            mid=len(models);models.append(model);counts['models']+=1
            for case in range(5):
                while True:
                    coeffs=[[rng.randrange(q) for _ in range(10)] for __ in range(2)]
                    vv=[]
                    for cs in coeffs:vv.append([fs(F,(F.scale(c,r[k]) for c,r in zip(cs,m.reps))) for k in range(3)])
                    u,w=vv
                    B0=[[m.split(u[k])[1],m.split(w[k])[1]] for k in range(2)]
                    if det2(F,B0):break
                # Add arbitrary W0 representatives; determinant constraints are unchanged.
                for ix in range(2):
                    extra=[rng.randrange(q) for _ in range(8)]
                    vv[ix]=plus(F,vv[ix],[fs(F,(F.scale(c,r[k]) for c,r in zip(extra,m.W0))) for k in range(3)])
                u,w=vv
                assert rank(K,[vec(F,x) for x in m.W0+[u,w]])==10
                N,f=determinant_poly(m,u,w,L);assert any(x for r in N for x in r)
                pole_records=[];ls=[F.pow(m.lam,q**i) for i in range(3)]
                for i,j in it.permutations(range(3),2):
                    val=be(F,N,F.neg(ls[i]),F.neg(ls[j]));bi=[[F.pow(m.split(v[k])[1],q**i) for v in [u,w]] for k in range(2)]
                    bj=[[F.pow(m.split(v[k])[1],q**j) for v in [u,w]] for k in range(2)]
                    factor1=F.neg(F.mul(F.pow(F.mul(m.kappa_weight,m.J[0][1]),q**j),F.add(ls[j],F.neg(ls[i]))))
                    factor2=F.neg(F.mul(F.pow(F.mul(m.kappa_weight,m.J[1][0]),q**i),F.add(ls[i],F.neg(ls[j]))))
                    for k in range(3):
                        if k!=j:factor1=F.mul(factor1,F.add(ls[k],F.neg(ls[j])))
                        if k!=i:factor2=F.mul(factor2,F.add(ls[k],F.neg(ls[i])))
                    d=det2(F,[bj[1],bi[0]])
                    assert factor1 and factor2 and val==F.mul(F.mul(factor1,factor2),d)
                    pole_records.append(dict(indices=[i,j],value=val,row_determinant=d,factors=[factor1,factor2]))
                assert any(x['value'] for x in pole_records);counts['pole_evaluations']+=6
                chosen=None;bad=[]
                pool=list(range(q))+[None]
                for s,t in it.product(pool,repeat=2):
                    a=m.geometric_projection(L,s,t,u);b=m.geometric_projection(L,s,t,w)
                    dd=K.sub(K.mul[a[0]][b[1]],K.mul[a[1]][b[0]])
                    den=F.mul(1 if s is None else pe(F,f,s),1 if t is None else pe(F,f,t))
                    assert be(F,N,s,t)==F.mul(den,dd)
                    if dd:bad.append([s,t])
                    counts['polynomial_grid_values']+=1
                if q>=4:
                    subset=[0,1,2,3,None]
                    chosen=next(([s,t] for s,t in it.product(subset,repeat=2) if be(F,N,s,t)),None)
                    assert chosen is not None
                elif bad:chosen=bad[0]
                wt=witness(m,u,w,*chosen) if chosen is not None else None
                counts['explicit_codeword_pairs']+=wt is not None
                records.append(dict(model_id=mid,extension_vectors=[u,w],outer_matrix=B0,determinant_polynomial=N,norm_polynomial=f,pole_records=pole_records,grid_nonzero=bad,witness=wt))
                counts['extensions']+=1
            print('q',q,'mu',mu,'checked',flush=True)
    result=dict(status='passed',scope='12 specified cubic-tower models, 60 specified extensions, complete secant grids for each model and extension; not all-q enumeration or proof-assistant verification',counts=counts,models=models,records=records,elapsed_seconds=round(time.time()-start,3))
    args.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(counts),flush=True)
if __name__=='__main__':main()
