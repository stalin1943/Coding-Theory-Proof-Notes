#!/usr/bin/env python3
"""Generate exactly the explicit residual family for q=3,4,5.
q=3 is an inherited comparison case. The new uniform formula is proved for q>=4.
"""
from pathlib import Path
import argparse,json,itertools as it
from check_semilinear import subs,candidate
from tower_model import Model

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--results',type=Path,required=True);args=ap.parse_args()
 rows=[];models=[]
 for q in [3,4,5]:
  m=Model(3,3,144) if q==3 else Model(q)
  mid=len(models);models.append(dict(q=q,polynomial=m.F.pol,lambda_value=m.lam,mu=m.mu,kappa_weight=m.kappa_weight,tower_basis=m.basis,E_polynomial=m.E_polynomial,mu_quadratic=m.quadratic))
  n=0
  for P in subs(m.K,3,2):
   for rvals in it.product(range(q),repeat=2):
    X,W0,vv,W=candidate(m,P,rvals)
    rows.append(dict(id=len(rows),model_id=mid,q=q,P=P,rvals=list(rvals),W=W));n+=1
  assert n==q*q*(q*q+q+1)
 out=dict(models=models,records=rows,count=len(rows),scope='Complete explicit secant-compatible family in three fixed normalized cubic epsilon=1 frames; not all rank-metric codes.')
 (args.results/'residual_inputs.json').write_text(json.dumps(out,indent=2)+'\n')
 with (args.results/'residual_input.txt').open('w') as f:
  f.write(str(len(models))+'\n')
  for i,m in enumerate(models):
   rr=[r for r in rows if r['model_id']==i];f.write(f"{m['q']} {m['lambda_value']} {len(rr)}\n"+' '.join(map(str,m['polynomial']))+'\n')
   for r in rr:f.write(str(r['id'])+' '+' '.join(str(a) for v in r['W'] for a in v)+'\n')
 print('generated',len(rows),'fixed-frame residual spaces',flush=True)
if __name__=='__main__':main()
