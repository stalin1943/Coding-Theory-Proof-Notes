"""Small finite-field models for the cubic-tower proof; not exhaustive classification.
Base arithmetic is explicitly reused from the uploaded Ternary Subline package.
"""
from pathlib import Path
import sys,itertools as it
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'vendor'))
from preceding_field import Field,rank,rref,null,irreducible

POLYS={3:[2,1,0,0,0,0,1],4:[2,3,2,3,3,1,1],5:[2,1,0,0,0,0,1],7:[6,4,1,2,6,2,1]}

def ks(K,terms):
    z=0
    for t in terms:z=K.add[z][t]
    return z

def fs(F,terms):
    z=0
    for t in terms:z=F.add(z,t)
    return z

def dot(F,a,b):return fs(F,(F.mul(x,y) for x,y in zip(a,b)))
def plus(F,a,b):return [F.add(x,y) for x,y in zip(a,b)]
def scale(F,c,a):return [F.mul(c,x) for x in a]
def vec(F,a):return [z for x in a for z in F.digits(x)]
def mm(F,A,B):return [[dot(F,A[i],[B[k][j] for k in range(len(B))]) for j in range(len(B[0]))] for i in range(len(A))]
def det2(F,A):return F.add(F.mul(A[0][0],A[1][1]),F.neg(F.mul(A[0][1],A[1][0])))
def inv2(F,A):
    d=F.inv(det2(F,A));return [[F.mul(d,A[1][1]),F.neg(F.mul(d,A[0][1]))],[F.neg(F.mul(d,A[1][0])),F.mul(d,A[0][0])]]

def solve(K,A,b):
    n=len(A[0]);N=null(K,[list(r)+[c] for r,c in zip(A,b)],n+1)
    v=next(v for v in N if v[-1]);s=K.neg[K.inv[v[-1]]]
    ans=[K.mul[s][x] for x in v[:-1]]
    assert all(ks(K,(K.mul[x][y] for x,y in zip(r,ans)))==c for r,c in zip(A,b))
    return ans

class Model:
    def __init__(self,q,mu=None,lam=None):
        self.q=q;self.F=F=Field(q,POLYS[q]);self.K=K=F.K;irreducible(F)
        if mu is None:mu=q
        assert F.pow(mu,q**3)!=mu
        if lam is None:
            lam=F.pow(mu,q**3+1)
            if lam<q:
                lam=F.add(mu,F.pow(mu,q**3))
            if lam<q:
                for t in range(q,F.Q):
                    lam=F.add(t,F.pow(t,q**3))
                    if lam>=q:break
        assert F.pow(lam,q**3)==lam and F.pow(lam,q)!=lam
        self.mu=mu;self.lam=lam;self.eb=[1,lam,F.mul(lam,lam)]
        bf=self.eb+[F.mul(mu,e) for e in self.eb]
        self.basis=bf
        A=[list(F.digits(e)) for e in bf];assert rank(K,A)==6
        self.co=[solve(K,A,[int(i==j) for i in range(6)]) for j in range(6)]
        for i,e in enumerate(bf):assert self.coordinates(e)==[int(i==j) for j in range(6)]
        a,b=self.split(F.mul(mu,mu));self.J=[[0,a],[1,b]]
        lc=self.coordinates(F.pow(lam,3));assert not any(lc[3:])
        self.E_polynomial=[K.neg[x] for x in lc[:3]]+[1]
        self.quadratic=[self.coordinates(a)[:3],self.coordinates(b)[:3]]
        self.X=[[1,0,0],[lam,0,1],[0,1,0],[0,lam,mu]]
        self.W0=self.X+[scale(F,lam,x) for x in self.X]
        assert rank(K,[vec(F,x) for x in self.W0])==8
        self.reps=[[F.mul(mu,e),0,0] for e in self.eb]+[[0,F.mul(mu,e),0] for e in self.eb]+[[0,0,e] for e in self.eb[1:]]+[[0,0,F.mul(mu,e)] for e in self.eb[1:]]
        assert rank(K,[vec(F,x) for x in self.W0+self.reps])==18
        # kappa(x) extracts the lambda^2 coordinate on E and is represented by Tr_E/K(k*x).
        TM=[[self.tr3(F.mul(e,f)) for f in self.eb] for e in self.eb]
        kval=solve(K,TM,[0,0,1]);self.kappa_weight=self.element(kval)
        assert self.kappa_weight
        for x in self.eb:assert self.tr3(F.mul(self.kappa_weight,x))==self.kappa(x)
        self.flags=[[[1,0],[0,1]],[[1,1],[0,1]]]
    def coordinates(self,x):return [ks(self.K,(self.K.mul[a][b] for a,b in zip(r,self.F.digits(x)))) for r in self.co]
    def element(self,c):return fs(self.F,(self.F.scale(a,b) for a,b in zip(c,self.eb)))
    def split(self,x):
        c=self.coordinates(x);return [self.element(c[:3]),self.element(c[3:])]
    def kappa(self,x):
        c=self.coordinates(x);assert not any(c[3:]);return c[2]
    def tr3(self,x):
        F=self.F;q=self.q;assert F.pow(x,q**3)==x
        t=F.add(F.add(x,F.pow(x,q)),F.pow(x,q*q));assert t<q;return t
    def mv(self,A,x):return [dot(self.F,r,x) for r in A]
    def flag_data(self,L):
        F=self.F;P=inv2(F,L);J=mm(F,mm(F,L,self.J),P)
        assert J[0][1] and J[1][0]
        nu=[dot(F,[1,self.mu],[P[0][i],P[1][i]]) for i in range(2)]
        return P,J,nu
    def abc(self,L,w):
        a1,b1=self.split(w[0]);a2,b2=self.split(w[1]);c=self.split(w[2])
        return self.mv(L,[a1,a2]),self.mv(L,[b1,b2]),self.mv(L,c)
    def normal(self,L,s,t):
        F=self.F;P,J,nu=self.flag_data(L)
        ds=[0 if z is None else F.inv(F.add(self.lam,z)) for z in [s,t]]
        coeff=[F.neg(F.mul(a,b)) for a,b in zip(nu,ds)]
        return [dot(F,coeff,[L[0][i],L[1][i]]) for i in range(2)]+[1]
    def geometric_projection(self,L,s,t,w):
        F=self.F;n=self.normal(L,s,t);raw=self.mv(L,self.split(dot(F,n,w)))
        return [self.kappa(F.mul(x,1 if z is None else F.add(self.lam,z))) for x,z in zip(raw,[s,t])]
    def formula_projection(self,L,s,t,w):
        F=self.F;P,J,nu=self.flag_data(L);a,b,c=self.abc(L,w)
        if s is None:
            r1=c[0] if t is None else F.add(c[0],F.neg(F.mul(F.mul(J[0][1],b[1]),F.inv(F.add(t,self.lam)))))
        else:
            sl=F.add(s,self.lam)
            r1=F.add(F.mul(sl,c[0]),F.neg(F.add(a[0],F.mul(J[0][0],b[0]))))
            if t is not None:r1=F.add(r1,F.neg(F.mul(F.mul(F.mul(sl,J[0][1]),b[1]),F.inv(F.add(t,self.lam)))))
        if t is None:
            r2=c[1] if s is None else F.add(c[1],F.neg(F.mul(F.mul(J[1][0],b[0]),F.inv(F.add(s,self.lam)))))
        else:
            tl=F.add(t,self.lam)
            r2=F.add(F.mul(tl,c[1]),F.neg(F.add(a[1],F.mul(J[1][1],b[1]))))
            if s is not None:r2=F.add(r2,F.neg(F.mul(F.mul(F.mul(tl,J[1][0]),b[0]),F.inv(F.add(s,self.lam)))))
        return [self.kappa(r1),self.kappa(r2)]
    def kernel_rows(self,L):
        K=self.K;rows=[];norms=[];pairs=list(it.combinations(range(10),2))
        for s,t in it.product(list(range(self.q))+[None],repeat=2):
            n=self.normal(L,s,t);S=[dot(self.F,n,x) for x in self.W0]
            assert rank(K,[self.F.digits(x) for x in S])==4
            im=[self.geometric_projection(L,s,t,w) for w in self.reps]
            assert im==[self.formula_projection(L,s,t,w) for w in self.reps]
            assert all(not any(self.geometric_projection(L,s,t,w)) for w in self.W0)
            assert rank(K,im)==2
            rows.append([K.sub(K.mul[im[i][0]][im[j][1]],K.mul[im[i][1]][im[j][0]]) for i,j in pairs]);norms.append(n)
        return rows,norms

if __name__=='__main__':
    import collections,json,time
    for q in [3,4,5,7]:
        st=time.time();m=Model(q);rows=[]
        for L in m.flags:rows+=m.kernel_rows(L)[0]
        ker=null(m.K,rows,45);inds=[i for i,(a,b) in enumerate(it.combinations(range(10),2)) if b<6]
        proj=rref(m.K,[[p[i] for i in inds] for p in ker],15)[0]
        print(q,'lambda',m.lam,'mu',m.mu,'rows',len(rows),'kernel',len(ker),'projection',len(proj),'seconds',time.time()-st,flush=True)
