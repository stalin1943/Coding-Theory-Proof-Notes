#!/usr/bin/env python3
"""Checks the explicit secant-admissible family in the cubic epsilon=1 case.
Full q=3 comparison is with the previously supplied 117 candidate spaces, not
with all rank-metric codes. For other q only listed examples are checked.
"""
from pathlib import Path
import itertools as it,json,argparse,random,time
from tower_model import *

def subs(K,n,d):
    for piv in it.combinations(range(n),d):
        free=[(i,j) for i,p in enumerate(piv) for j in range(p+1,n) if j not in piv]
        for vals in it.product(range(K.q),repeat=len(free)):
            rows=[[int(j==p) for j in range(n)] for p in piv]
            for (i,j),x in zip(free,vals):rows[i][j]=x
            yield rows

def pg(q,n):
    for i in range(n):
        for tail in it.product(range(q),repeat=n-i-1):yield [0]*i+[1]+list(tail)

def eps1(m):return [[0,0,1]]+[[u,m.F.pow(u,m.q),m.F.mul(m.mu,m.F.pow(u,m.q*m.q))] for u in m.eb]

def candidate(m,P,rvals):
    F=m.F;q=m.q;k=m.kappa_weight;xi=F.mul(F.pow(k,q*q),F.inv(k));beta=m.J[1][1]
    X=eps1(m);W0=X+[scale(F,m.lam,x) for x in X];extensions=[]
    for c,rv in zip(P,rvals):
        p=m.element(c);r=F.scale(rv,m.eb[2]);b=F.mul(xi,F.pow(p,q*q))
        s=F.neg(F.add(F.mul(F.pow(beta,q),p),F.mul(F.pow(beta,q*q),b)))
        extensions.append([F.mul(m.mu,p),F.mul(m.mu,b),F.add(r,F.mul(m.mu,s))])
    W=W0+extensions;assert rank(m.K,[vec(F,w) for w in W])==10
    assert det2(F,[[m.split(w[i])[1] for w in extensions] for i in range(2)])
    return X,W0,extensions,W

def secant(m,a,z):
    F=m.F;q=m.q;delta=F.inv(F.pow(a,q*q));eta=F.add(F.mul(m.mu,delta),F.neg(F.pow(z,q*q)))
    n=[F.mul(a,F.add(eta,z)),F.mul(F.pow(a,q),F.add(eta,F.pow(z,q))),1]
    return n,delta,z

def image(m,n,delta,z,w):
    F=m.F;q=m.q;u,v=m.split(dot(F,n,w));d=F.mul(v,F.inv(delta));c=F.add(u,F.mul(F.pow(z,q*q),d))
    return [m.kappa(c),m.kappa(d)]

def canonical(m,W):return tuple(tuple(r) for r in rref(m.K,[vec(m.F,w) for w in W],18)[0])

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);args=ap.parse_args();root=Path(__file__).resolve().parents[1];start=time.time();rng=random.Random(38122026);records=[];secants=0
    for q in [3,4,5,7]:
        m=Model(q,3,144) if q==3 else Model(q)
        F=m.F;K=m.K;planes=list(subs(K,3,2));assert len(planes)==q*q+q+1
        for idx in [0,len(planes)//2,len(planes)-1]:
            rvals=[rng.randrange(q),rng.randrange(q)];X,W0,vv,W=candidate(m,planes[idx],rvals)
            counts={'secants':0,'rank5':0,'rank4':0}
            for ac in pg(q,3):
                a=m.element(ac)
                for zc in it.product(range(q),repeat=2):
                    z=m.element([0,*zc]);n,delta,z=secant(m,a,z)
                    ims=[image(m,n,delta,z,w) for w in vv]
                    assert all(t[1]==0 for t in ims)
                    assert all(not any(image(m,n,delta,z,w)) for w in W0)
                    rk0=rank(K,[F.digits(dot(F,n,w)) for w in W0]);assert rk0==4
                    full=rank(K,[F.digits(dot(F,n,w)) for w in W]);assert full in [4,5]
                    counts['rank'+str(full)]+=1;counts['secants']+=1;secants+=1
            records.append(dict(q=q,polynomial=F.pol,lambda_value=m.lam,mu=m.mu,kappa_weight=m.kappa_weight,tower_basis=m.basis,E_polynomial=m.E_polynomial,mu_quadratic=m.quadratic,P=planes[idx],rvals=rvals,X=X,W0=W0,extension_vectors=vv,W=W,counts=counts))
        print('epsilon1 q',q,'three complete listed-model secant grids passed',flush=True)
    # Exact candidate-set comparison in the supplied ternary frame.
    m=Model(3,3,144);expected=json.loads((root/'inputs/ternary_candidates.json').read_text())
    supplied={canonical(m,r['W']) for r in expected};generated=set()
    for P in subs(m.K,3,2):
        for rvals in it.product(range(3),repeat=2):generated.add(canonical(m,candidate(m,P,rvals)[3]))
    assert len(generated)==len(supplied)==117 and generated==supplied
    out=dict(status='passed',scope='12 specified semilinear-family models with their complete nonvertical secant grids; exact match to the 117 supplied ternary surviving secant candidates. Not proof of intersection or a new full code classification.',models=records,model_count=len(records),secant_checks=secants,ternary_set_match=True,ternary_spaces=117,elapsed_seconds=round(time.time()-start,3))
    args.output.write_text(json.dumps(out,indent=2)+'\n');print('semilinear checks',secants,'and 117-space exact comparison passed')
if __name__=='__main__':main()
