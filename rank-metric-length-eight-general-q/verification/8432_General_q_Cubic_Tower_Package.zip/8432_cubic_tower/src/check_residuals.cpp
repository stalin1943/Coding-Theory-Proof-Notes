#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <numeric>
#include <unordered_map>
#include <vector>
using namespace std;
using V=array<int,3>;
struct Field{
 int q,Q,C;vector<int> pol,powq,lg,ex,iv,ng,tr;vector<array<int,6>>dig;vector<vector<int>> add,mul,sca;vector<int> ktinv,ktneg;vector<vector<int>> halfadd;
 Field(int qq,vector<int>p):q(qq),pol(p){Q=1;powq.push_back(1);for(int i=0;i<6;i++){Q*=q;powq.push_back(Q);}C=powq[3];
  add.assign(q,vector<int>(q));mul=add;ktinv.assign(q,0);ktneg=ktinv;
  for(int a=0;a<q;a++)for(int b=0;b<q;b++){add[a][b]=q==4?(a^b):(a+b)%q;int c=0;if(q==4){for(int j=0;j<2;j++)if((b>>j)&1)c^=a<<j;if(c&4)c^=7;}else c=a*b%q;mul[a][b]=c;}
  for(int a=0;a<q;a++)for(int b=0;b<q;b++){if(!add[a][b])ktneg[a]=b;if(mul[a][b]==1)ktinv[a]=b;}
  dig.resize(Q);for(int a=0;a<Q;a++){int t=a;for(int j=0;j<6;j++){dig[a][j]=t%q;t/=q;}}
  halfadd.assign(C,vector<int>(C));for(int a=0;a<C;a++)for(int b=0;b<C;b++)for(int j=0;j<3;j++)halfadd[a][b]+=add[dig[a][j]][dig[b][j]]*powq[j];
  sca.assign(q,vector<int>(Q));for(int c=0;c<q;c++)for(int a=0;a<Q;a++)for(int j=0;j<6;j++)sca[c][a]+=mul[c][dig[a][j]]*powq[j];
  ng.resize(Q);for(int a=0;a<Q;a++)for(int j=0;j<6;j++)ng[a]+=ktneg[dig[a][j]]*powq[j];
  vector<int> primes;int n=Q-1;for(int p0=2;p0*p0<=n;p0++)if(n%p0==0){primes.push_back(p0);while(n%p0==0)n/=p0;}if(n>1)primes.push_back(n);
  int g=0;for(int a=q;a<Q;a++){bool ok=true;for(int p0:primes)if(rawpow(a,(Q-1)/p0)==1){ok=false;break;}if(ok&&rawpow(a,Q-1)==1){g=a;break;}}assert(g);
  lg.assign(Q,-1);ex.resize(2*(Q-1));int x=1;for(int i=0;i<Q-1;i++){assert(lg[x]==-1);lg[x]=i;ex[i]=ex[i+Q-1]=x;x=raw(x,g);}assert(x==1);iv.resize(Q);for(int a=1;a<Q;a++){iv[a]=ex[(Q-1-lg[a])%(Q-1)];assert(raw(a,iv[a])==1);}
  tr.resize(Q);for(int a=0;a<Q;a++){int x=a,s=0;for(int i=0;i<6;i++){s=plus(s,x);x=power(x,q);}assert(s<q);tr[a]=s;}
 }
 int plus(int a,int b)const{return halfadd[a%C][b%C]+C*halfadd[a/C][b/C];}
 int raw(int a,int b)const{int c[11]={};for(int i=0;i<6;i++)for(int j=0;j<6;j++)c[i+j]=add[c[i+j]][mul[dig[a][i]][dig[b][j]]];for(int i=10;i>=6;i--){int t=c[i];for(int j=0;j<6;j++)c[i-6+j]=add[c[i-6+j]][ktneg[mul[t][pol[j]]]];}int r=0;for(int i=0;i<6;i++)r+=c[i]*powq[i];return r;}
 int rawpow(int a,int n)const{int r=1;for(;n;n>>=1,a=raw(a,a))if(n&1)r=raw(r,a);return r;}
 int times(int a,int b)const{return a&&b?ex[lg[a]+lg[b]]:0;}
 int power(int a,int n)const{int r=1;for(;n;n>>=1,a=times(a,a))if(n&1)r=times(r,a);return r;}
 V vsum(V a,V b)const{for(int i=0;i<3;i++)a[i]=plus(a[i],b[i]);return a;}
 V scale(int c,V v)const{for(int&x:v)x=times(c,x);return v;}
 int dot(V a,V b)const{int s=0;for(int i=0;i<3;i++)s=plus(s,times(a[i],b[i]));return s;}
 V normal(V a)const{int x=a[0]?a[0]:(a[1]?a[1]:a[2]);assert(x);return scale(iv[x],a);}
 uint64_t key(V a)const{a=normal(a);if(a[0])return uint64_t(a[1])*Q+a[2];if(a[1])return uint64_t(Q)*Q+a[2];return uint64_t(Q)*Q+Q;}
 int rank(vector<V>rows)const{array<V,18>basis{};int r=0;for(V x:rows)for(int j=17;j>=0;j--){int c=dig[x[j/6]][j%6];if(!c)continue;if(basis[j][j/6])x=vsum(x,scale(ktneg[c],basis[j]));else{basis[j]=scale(ktinv[c],x);r++;break;}}return r;}
 vector<V> dual(vector<V>W)const{vector<vector<int>>A;for(V w:W){vector<int>row;for(int j=0;j<18;j++)row.push_back(tr[times(w[j/6],powq[j%6])]);A.push_back(row);}int r=0;vector<int>piv;for(int j=17;j>=0;j--){int i=r;while(i<(int)A.size()&&!A[i][j])i++;if(i==(int)A.size())continue;swap(A[r],A[i]);int c=ktinv[A[r][j]];for(int&x:A[r])x=mul[c][x];for(int i2=0;i2<(int)A.size();i2++)if(i2!=r&&A[i2][j]){int a=A[i2][j];for(int k=0;k<18;k++)A[i2][k]=add[A[i2][k]][ktneg[mul[a][A[r][k]]]];}piv.push_back(j);r++;if(r==(int)A.size())break;}vector<V>out;for(int j=0;j<18;j++)if(find(piv.begin(),piv.end(),j)==piv.end()){vector<int>v(18);v[j]=1;for(int i=0;i<r;i++)v[piv[i]]=ktneg[A[i][j]];V x{};for(int k=0;k<18;k++)x[k/6]+=v[k]*powq[k%6];out.push_back(x);}return out;}
 int knorm(int x)const{for(int j=5;j>=0;j--)if(dig[x][j])return sca[ktinv[dig[x][j]]][x];return 0;}
 int pnorm(int x)const{return knorm(plus(x,ng[x%q]));}
 vector<int> plane(int l)const{vector<int>b;for(int x=0;x<q;x++)for(int y=0;y<q;y++)b.push_back(plus(x,sca[y][l]));sort(b.begin(),b.end());return b;}
 int type(int l)const{auto B=plane(l);int key=Q;for(int a:B)if(a)for(int b:B){int z=times(iv[a],b);if(z>=q)key=min(key,pnorm(z));}return key;}
};
void pv(ostream&o,V a){o<<'['<<a[0]<<','<<a[1]<<','<<a[2]<<']';}
void pb(ostream&o,vector<V>a){o<<'[';for(size_t i=0;i<a.size();i++){if(i)o<<',';pv(o,a[i]);}o<<']';}
int main(int argc,char**argv){assert(argc==3);ifstream in(argv[1]);ofstream out(argv[2]);int nm;in>>nm;out<<"{\"records\":[";bool first=true;map<string,int>total;vector<int>surv;
 for(int mid=0;mid<nm;mid++){int q,l,n;in>>q>>l>>n;vector<int>poly(7);for(int&a:poly)in>>a;Field F(q,poly);map<int,int>types;for(int a=q;a<F.Q;a++)if(F.pnorm(a)==a)types.emplace(F.type(a),a);assert(types.size()==size_t(q*q*q+q+1));int btype=F.type(l);map<string,int>hist;
  for(int step=0;step<n;step++){int id;in>>id;vector<V>W(10);for(V&v:W)for(int&a:v){in>>a;assert(a>=0&&a<F.Q);}assert(in&&F.rank(W)==10);auto U=F.dual(W);assert(U.size()==8);string reason;int tau=0,vr=-1;V u{},h{};vector<V>inter;
   for(auto [key,t]:types){auto WW=W;for(V v:W)WW.push_back(F.scale(t,v));int r=F.rank(WW);int target=key==btype?16:18;if(r<target){inter=F.dual(WW);assert((int)inter.size()==18-r);reason=key==btype?"excess_cubic_multiplicity":"extra_noncubic_type";tau=t;vr=r;u=inter[0];assert(all_of(W.begin(),W.end(),[&](V w){return F.tr[F.dot(w,u)]==0&&F.tr[F.dot(w,F.scale(t,u))]==0;}));break;}}
   uint64_t inspected=0;
   if(reason.empty()){
    unordered_map<uint64_t,uint8_t>counts;counts.reserve(100000);bool done=false;
    for(int p=0;p<10&&!done;p++){uint64_t lim=1;for(int j=p+1;j<10;j++)lim*=q;for(uint64_t z=0;z<lim;z++){uint64_t zz=z;V v=W[p];for(int j=p+1;j<10;j++){int c=zz%q;zz/=q;v=F.vsum(v,F.scale(c,W[j]));}inspected++;auto key=F.key(v);int c=++counts[key];if(c>q+1){h=F.normal(v);vector<V>images;for(V a:U)images.push_back({F.dot(h,a),0,0});vr=F.rank(images);assert(vr<=3);reason="minimum_rank";done=true;break;}}}
    if(reason.empty()){reason="unresolved";surv.push_back(id);}
   }
   if(!first)out<<',';first=false;out<<"\n{\"id\":"<<id<<",\"q\":"<<q<<",\"reason\":\""<<reason<<"\",\"rank\":"<<vr<<",\"U_basis\":";pb(out,U);if(reason=="minimum_rank"){out<<",\"h\":";pv(out,h);}else if(reason!="unresolved"){out<<",\"tau\":"<<tau<<",\"u\":";pv(out,u);out<<",\"intersection_basis\":";pb(out,inter);}out<<",\"W_projective_vectors_examined\":"<<inspected<<'}';hist[reason]++;total[reason]++;
  }
  cerr<<"q "<<q<<" models "<<n<<":";for(auto[a,b]:hist)cerr<<" "<<a<<'='<<b;cerr<<'\n';
 }
 out<<"],\"histogram\":{";first=true;for(auto[a,b]:total){if(!first)out<<',';first=false;out<<'"'<<a<<"\":"<<b;}out<<"},\"unresolved\":[";for(size_t i=0;i<surv.size();i++){if(i)out<<',';out<<surv[i];}out<<"]}\n";
}
