#!/usr/bin/env python3
"""Independent verification with tower arithmetic K -> E -> F.
Does not import the primary arithmetic, model, or polynomial implementation.
Only the explicitly saved examples are checked, not the whole classification.
"""
from pathlib import Path
import itertools as it,json,argparse,time

class Tower:
    def __init__(self,r):
        self.q=q=r['q'];self.pol=r['E_polynomial'];self.A=tuple(r['mu_quadratic'][0]);self.B=tuple(r['mu_quadratic'][1])
        self.ad=[[((a^b) if q==4 else (a+b)%q) for b in range(q)] for a in range(q)]
        self.mt=[]
        for a in range(q):
            row=[]
            for b in range(q):
                if q==4:
                    x=0
                    for j in range(2):
                        if (b>>j)&1:x^=a<<j
                    if x&4:x^=7
                else:x=a*b%q
                row.append(x)
            self.mt.append(row)
        self.ng=[next(b for b in range(q) if self.ad[a][b]==0) for a in range(q)]
        self.iv=[0]+[next(b for b in range(1,q) if self.mt[a][b]==1) for a in range(1,q)]
        self.zero=(0,)*6;self.one=(1,0,0,0,0,0);self.lam=(0,1,0,0,0,0);self.mu=(0,0,0,1,0,0)
        self.tb=[self.digits(x) for x in r['tower_basis']]
        # Column-basis inverse: solve through independent left-pivot row reduction.
        M=[[self.tb[j][i] for j in range(6)] for i in range(6)]
        R,piv=self.rref([row+[int(i==j) for j in range(6)] for i,row in enumerate(M)],6)
        assert piv==list(range(6));self.inverse=[row[6:] for row in R]
        assert self.decode(r['lambda_value'])==self.lam and self.decode(r['mu'])==self.mu
        alpha=self.decode(q);v=self.one
        for i in range(6):assert self.encode(v)==q**i;v=self.mul(v,alpha)
        z=self.zero
        for c in reversed(r['polynomial']):z=self.add(self.mul(z,alpha),self.embed(c))
        assert z==self.zero
        # Directly certify the cubic and quadratic tower steps.
        for x in range(q):assert self.eval_E(self.pol,(x,0,0))!=(0,0,0)
        for x in it.product(range(q),repeat=3):
            v=self.eadd(self.eadd(self.emul(x,x),self.eneg(self.emul(self.B,x))),self.eneg(self.A))
            assert v!=(0,0,0)
    def digits(self,a):return tuple((a//self.q**j)%self.q for j in range(6))
    def ksum(self,x):
        s=0
        for a in x:s=self.ad[s][a]
        return s
    def decode(self,a):
        d=self.digits(a);return tuple(self.ksum(self.mt[x][y] for x,y in zip(row,d)) for row in self.inverse)
    def encode(self,x):
        d=[self.ksum(self.mt[c][b[j]] for c,b in zip(x,self.tb)) for j in range(6)]
        return sum(c*self.q**j for j,c in enumerate(d))
    def embed(self,c):return (c,0,0,0,0,0)
    def eadd(self,a,b):return tuple(self.ad[x][y] for x,y in zip(a,b))
    def eneg(self,a):return tuple(self.ng[x] for x in a)
    def emul(self,a,b):
        r=[0]*5
        for i,x in enumerate(a):
            for j,y in enumerate(b):r[i+j]=self.ad[r[i+j]][self.mt[x][y]]
        for i in range(4,2,-1):
            c=r[i]
            for j in range(3):r[i-3+j]=self.ad[r[i-3+j]][self.ng[self.mt[c][self.pol[j]]]]
        return tuple(r[:3])
    def eval_E(self,p,x):
        z=(0,0,0)
        for c in reversed(p):z=self.eadd(self.emul(z,x),(c,0,0))
        return z
    def add(self,a,b):return tuple(self.ad[x][y] for x,y in zip(a,b))
    def neg(self,a):return tuple(self.ng[x] for x in a)
    def mul(self,a,b):
        ac=self.emul(a[:3],b[:3]);bd=self.emul(a[3:],b[3:]);u=self.eadd(ac,self.emul(self.A,bd))
        v=self.eadd(self.eadd(self.emul(a[:3],b[3:]),self.emul(a[3:],b[:3])),self.emul(self.B,bd))
        return u+v
    def power(self,a,n):
        z=self.one
        while n:
            if n&1:z=self.mul(z,a)
            a=self.mul(a,a);n//=2
        return z
    def inv(self,a):
        assert a!=self.zero
        z=self.power(a,self.q**6-2);assert self.mul(a,z)==self.one;return z
    def tr(self,a):
        r=self.zero
        for _ in range(6):r=self.add(r,a);a=self.power(a,self.q)
        assert not any(r[1:]);return r[0]
    def dot(self,a,b):
        r=self.zero
        for x,y in zip(a,b):r=self.add(r,self.mul(x,y))
        return r
    def rref(self,rows,n=None):
        a=[list(x) for x in rows if any(x)];n=n or (len(a[0]) if a else 0);r=0;piv=[]
        for j in range(n):
            k=next((i for i in range(r,len(a)) if a[i][j]),None)
            if k is None:continue
            a[r],a[k]=a[k],a[r];c=self.iv[a[r][j]];a[r]=[self.mt[c][x] for x in a[r]]
            for i in range(len(a)):
                if i!=r and a[i][j]:
                    c=a[i][j];a[i]=[self.ad[x][self.ng[self.mt[c][y]]] for x,y in zip(a[i],a[r])]
            piv.append(j);r+=1
            if r==len(a):break
        return a[:r],piv
    def rank(self,a):return len(self.rref(a)[1]) if a else 0
    def poly(self,p,s,t):
        def ev(row,x):
            if x is None:return self.embed(row[-1])
            z=self.zero
            for a in reversed(row):z=self.add(self.mul(z,x),self.embed(a))
            return z
        if s is None:return ev(p[-1],t)
        vals=[]
        for j in range(len(p[0])):vals.append(ev([p[i][j] for i in range(len(p))],s))
        if t is None:return vals[-1]
        z=self.zero
        for a in reversed(vals):z=self.add(self.mul(z,t),a)
        return z
    def qmap(self,s,t,w):
        ds=self.one if s is None else self.add(self.lam,self.embed(s));dt=self.one if t is None else self.add(self.lam,self.embed(t))
        n=[self.zero if s is None else self.neg(self.inv(ds)),self.zero if t is None else self.neg(self.mul(self.mu,self.inv(dt))),self.one]
        a=self.dot(n,w);u=self.emul(ds[:3],a[:3]);v=self.emul(dt[:3],a[3:]);return [u[2],v[2]],n


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--results',type=Path,required=True);args=ap.parse_args();st=time.time()
    data=json.loads((args.results/'poles.json').read_text());models=data['models'];towers=[Tower(r) for r in models];witnesses=gridchecks=poles=0
    for rec in data['records']:
        r=models[rec['model_id']];T=towers[rec['model_id']];q=T.q
        W0=[[T.decode(a) for a in w] for w in r['W0']];ext=[[T.decode(a) for a in w] for w in rec['extension_vectors']];W=W0+ext
        assert T.rank([sum((list(x) for x in w),[]) for w in W])==10
        bad=[]
        for s,t in it.product(list(range(q))+[None],repeat=2):
            ims=[T.qmap(s,t,w)[0] for w in ext]
            d=T.ad[T.mt[ims[0][0]][ims[1][1]]][T.ng[T.mt[ims[0][1]][ims[1][0]]]]
            N=T.poly(rec['determinant_polynomial'],None if s is None else T.embed(s),None if t is None else T.embed(t))
            f=rec['norm_polynomial'];fac=T.one
            for z in [s,t]:
                if z is None:continue
                val=T.eval_E(f,(z,0,0));fac=T.mul(fac,val+(0,0,0))
            assert N==T.mul(fac,T.embed(d))
            if d:bad.append([s,t])
            gridchecks+=1
        assert bad==rec['grid_nonzero']
        for pp in rec['pole_records']:
            i,j=pp['indices'];s=T.neg(T.power(T.lam,q**i));t=T.neg(T.power(T.lam,q**j));v=T.poly(rec['determinant_polynomial'],s,t)
            assert v==T.decode(pp['value'])
            assert v==T.mul(T.mul(T.decode(pp['factors'][0]),T.decode(pp['factors'][1])),T.decode(pp['row_determinant']))
            poles+=1
        wt=rec['witness']
        if wt is None:assert q==3;continue
        n=[T.decode(a) for a in wt['normal']];xy=[[T.decode(a) for a in v] for v in wt['secant_points']];U=[[T.decode(a) for a in w] for w in wt['U_basis']]
        assert all(T.dot(n,x)==T.zero for x in xy)
        assert T.rank([list(T.dot(n,w)) for w in W])==6
        assert T.rank([sum((list(x) for x in u),[]) for u in U])==8
        assert all(T.tr(T.dot(w,u))==0 for w in W for u in U)
        words=[[T.dot(x,u) for u in U] for x in xy];assert [[T.encode(a) for a in w] for w in words]==wt['codewords']
        mats=[[[a[j] for a in word] for j in range(6)] for word in words]
        assert [T.rank(mats[0]),T.rank(mats[1]),T.rank(mats[0]+mats[1])]==[4,4,8];witnesses+=1
    semi=json.loads((args.results/'semilinear.json').read_text());semicount=0
    for rec in semi['models']:
        T=Tower(rec);q=T.q;lam=T.lam;mu=T.mu;X=[[T.decode(a) for a in v] for v in rec['X']];W0=[[T.decode(a) for a in v] for v in rec['W0']];ext=[[T.decode(a) for a in v] for v in rec['extension_vectors']]
        k=T.decode(rec['kappa_weight']);ratio=T.mul(T.power(k,q*q),T.inv(k));beta=T.B+(0,0,0)
        for w in ext:
            p=T.mul(w[0],T.inv(mu));b=T.mul(w[1],T.inv(mu));assert not any(p[3:]+b[3:])
            assert b==T.mul(ratio,T.power(p,q*q))
            ss=T.neg(T.add(T.mul(T.power(beta,q),p),T.mul(T.power(beta,q*q),b)))
            assert tuple(w[2][3:])==ss[:3]
        # Independently check every listed-model nonvertical secant quotient has zero second row.
        Ebas=[T.one,T.lam,T.mul(T.lam,T.lam)]
        def ev(cs):
            z=T.zero
            for a,b in zip(cs,Ebas):z=T.add(z,T.mul(T.embed(a),b))
            return z
        for leading in range(3):
            for tail in it.product(range(q),repeat=2-leading):
                aa=ev([0]*leading+[1]+list(tail));delta=T.inv(T.power(aa,q*q))
                for zc in it.product(range(q),repeat=2):
                    z=ev([0,*zc]);zq2=T.power(z,q*q);eta=T.add(T.mul(mu,delta),T.neg(zq2))
                    n=[T.mul(aa,T.add(eta,z)),T.mul(T.power(aa,q),T.add(eta,T.power(z,q))),T.one]
                    for w in ext:
                        v=T.dot(n,w);dd=T.mul(tuple(v[3:])+(0,0,0),T.inv(delta));assert dd[2]==0
                    assert T.rank([list(T.dot(n,w)) for w in W0])==4
                    semicount+=1
    assert semicount==semi['secant_checks']
    out=dict(status='passed',arithmetic='independent cubic-then-quadratic tower multiplication; independent left-pivot elimination',models=len(models),extensions=len(data['records']),full_grid_checks=gridchecks,pole_checks=poles,explicit_support_pairs=witnesses,semilinear_models=len(semi['models']),semilinear_secants=semicount,scope='independent checking of saved examples and witnesses, not formal verification of the universal proofs or enumeration of all models',elapsed_seconds=round(time.time()-st,3))
    (args.results/'independent.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
if __name__=='__main__':main()
