#!/usr/bin/env python3
"""Independently checks completeness of the small residual family and each failure.
Uses tower arithmetic only, not the generator arithmetic or the C++ eliminator.
"""
from pathlib import Path
import argparse,json,itertools as it,collections,time
from independent_check import Tower

def pg(q,n):
 for i in range(n):
  for tail in it.product(range(q),repeat=n-i-1):yield [0]*i+[1]+list(tail)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--results',type=Path,required=True);a=ap.parse_args();start=time.time()
 source=json.loads((a.results/'residual_inputs.json').read_text());answer=json.loads((a.results/'residuals.json').read_text())
 assert len(source['records'])==len(answer['records'])==1228 and not answer['unresolved']
 towers=[Tower(m) for m in source['models']];counts=collections.Counter();byq={};covered={}
 for mid,m in enumerate(source['models']):
  T=towers[mid];q=T.q;points=list(pg(q,3));planes=set()
  for x,y in it.combinations(points,2):planes.add(tuple(tuple(r) for r in T.rref([x,y],3)[0]))
  assert len(planes)==q*q+q+1
  actual={}
  for r in source['records']:
   if r['model_id']!=mid:continue
   P=tuple(tuple(x) for x in T.rref(r['P'],3)[0]);assert P in planes
   actual.setdefault(P,set());vv=tuple(r['rvals']);assert vv not in actual[P];actual[P].add(vv)
  assert set(actual)==planes and all(len(x)==q*q for x in actual.values())
  covered[q]=q*q*(q*q+q+1)
 for src,res in zip(source['records'],answer['records']):
  assert src['id']==res['id'] and src['q']==res['q'];T=towers[src['model_id']];q=T.q;m=source['models'][src['model_id']]
  k=T.decode(m['kappa_weight']);xi=T.mul(T.power(k,q*q),T.inv(k));beta=T.B+(0,0,0);eb=[T.one,T.lam,T.mul(T.lam,T.lam)]
  X=[[T.zero,T.zero,T.one]]+[[t,T.power(t,q),T.mul(T.mu,T.power(t,q*q))] for t in eb]
  W=X+[[T.mul(T.lam,x) for x in v] for v in X]
  for coeff,rval in zip(src['P'],src['rvals']):
   p=T.zero
   for c,e in zip(coeff,eb):p=T.add(p,T.mul(T.embed(c),e))
   r=T.mul(xi,T.power(p,q*q));b=T.neg(T.add(T.mul(T.power(beta,q),p),T.mul(T.power(beta,q*q),r)))
   W.append([T.mul(T.mu,p),T.mul(T.mu,r),T.add(T.mul(T.embed(rval),eb[2]),T.mul(T.mu,b))])
  assert [[T.encode(x) for x in v] for v in W]==src['W']
  assert T.rank([sum((list(x) for x in v),[]) for v in W])==10
  U=[[T.decode(x) for x in v] for v in res['U_basis']]
  assert T.rank([sum((list(x) for x in v),[]) for v in U])==8
  assert all(T.tr(T.dot(w,u))==0 for w in W for u in U)
  reason=res['reason'];counts[reason]+=1;byq.setdefault(q,collections.Counter());byq[q][reason]+=1
  if reason=='extra_noncubic_type':
   tau=T.decode(res['tau']);u=[T.decode(x) for x in res['u']];assert any(x!=T.zero for x in u)
   assert T.power(tau,q**3)!=tau
   tu=[T.mul(tau,x) for x in u]
   assert all(T.tr(T.dot(w,u))==0 and T.tr(T.dot(w,tu))==0 for w in W)
   D=[[T.decode(x) for x in v] for v in res['intersection_basis']]
   assert T.rank([sum((list(x) for x in v),[]) for v in D])==18-res['rank']
   assert all(T.tr(T.dot(w,d))==0 and T.tr(T.dot(w,[T.mul(tau,x) for x in d]))==0 for d in D for w in W)
  elif reason=='minimum_rank':
   h=[T.decode(x) for x in res['h']];assert any(x!=T.zero for x in h)
   rr=T.rank([list(T.dot(h,u)) for u in U]);assert rr==res['rank']<=3
  else:raise AssertionError('Unhandled or unresolved record: '+reason)
 assert dict(counts)==answer['histogram']
 out=dict(status='passed',complete_residual_spaces_checked=len(answer['records']),models_per_q=covered,violations_per_q={q:dict(c) for q,c in byq.items()},histogram=dict(counts),scope='complete explicit residual family only for q=3,4,5; every candidate reconstructed and each explicit noncubic fiber or rank<=3 message checked with independent arithmetic; no low-point branch classification',elapsed_seconds=round(time.time()-start,3))
 (a.results/'independent_residuals.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
if __name__=='__main__':main()
