#!/usr/bin/env python3
"""Exact integer coefficient extraction, no symbolic algebra dependency.
The tests support the paper derivations, not replace the universal proof.
"""
from pathlib import Path
import argparse,itertools as it,json
from tower_model import Model,rank

ZERO=(0,0,0)
def pa(*args):
 d={}
 for p in args:
  for m,c in p.items():d[m]=d.get(m,0)+c
 return {m:c for m,c in d.items() if c}
def pn(p):return {m:-c for m,c in p.items()}
def pm(p,q):
 d={}
 for m,c in p.items():
  for n,b in q.items():
   v=tuple(x+y for x,y in zip(m,n));d[v]=d.get(v,0)+c*b
 return {m:c for m,c in d.items() if c}
def mon(*inds):
 e=[0,0,0]
 for i in inds:e[i]+=1
 return {tuple(e):1}
def rv(i,c):return [c if j==i else {} for j in range(6)]
def va(*args):return [pa(*(v[i] for v in args)) for i in range(6)]
def vn(v):return [pn(p) for p in v]
PAIRS=list(it.combinations(range(6),2))
def wedge(u,v):return [pa(pm(u[i],v[j]),pn(pm(u[j],v[i]))) for i,j in PAIRS]
def row_at(w,e):return [p.get(e,0) for p in w]
def unit(a,b,c=1):
 out=[0]*15
 if a>b:a,b,c=b,a,-c
 out[PAIRS.index((a,b))]=c
 return out
def addrow(*rs):return [sum(t) for t in zip(*rs)]

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
 P=[rv(i,mon(i,(i+2)%3)) for i in range(3)]
 R=[rv(i+3,mon((i+1)%3,(i+2)%3)) for i in range(3)]
 u=vn(va(P[1],R[1]));v=va(P[1],R[2]);w=vn(va(P[2],R[2]));lx=va(P[0],u,R[2]);ly=va(R[0],P[1],w)
 # x^3, y^3, x^2 y, x y^2 coefficients of (u x²+v xy+w y²) wedge (lx x+ly y).
 E=[wedge(u,lx),wedge(w,ly),[pa(a,b) for a,b in zip(wedge(u,ly),wedge(v,lx))],[pa(a,b) for a,b in zip(wedge(v,ly),wedge(w,lx))]]
 rows=[]
 for n,eq in enumerate(E):
  for e in sorted({m for p in eq for m in p}):
   row=row_at(eq,e)
   if any(row):rows.append(dict(equation=n,alpha_monomial=e,row=row))
 assert len(rows)==14
 identities=[]
 checks=[('p0_wedge_r1',row_at(E[0],(2,0,2)),unit(0,4)),
 ('p1_wedge_r2',[-x for x in row_at(E[0],(2,2,0))],unit(1,5)),
 ('p2_wedge_r0',[-x for x in row_at(E[1],(0,2,2))],unit(2,3)),
 ('p0p1_equals_r1r2',row_at(E[0],(2,1,1)),addrow(unit(0,1),unit(4,5,-1))),
 ('p0r2_equals_r1r2',row_at(E[3],(2,1,1)),addrow(unit(0,5),unit(4,5,-1))),
 ('p0p2_equals_minus_r0r1',addrow(row_at(E[2],(1,1,2)),row_at(E[3],(1,1,2))),addrow(unit(0,2),unit(3,4)))]
 for name,a,b in checks:assert a==b;identities.append(name)
 # After r_i=p_{i-1}, the second-row z-linear terms vanish identically.
 R2=[P[(i-1)%3] for i in range(3)]
 u2=vn(va(P[1],R2[1]));w2=vn(va(P[2],R2[2]))
 assert not any(va(P[0],u2,R2[2])) and not any(va(R2[0],P[1],w2))
 # d_i now use formal row slots 3,4,5. Check that the six named coefficients
 # force each d_i to be parallel to two independent p rows.
 D=va(*(rv(i+3,mon(i)) for i in range(3)))
 Ud=wedge(u2,D);Wd=wedge(w2,D)
 expected=[(Ud,(2,0,1),unit(0,3,-1)),(Ud,(2,1,0),unit(1,3,-1)),
 (Ud,(1,2,0),unit(1,4,-1)),(Wd,(0,2,1),unit(2,4,-1)),
 (Ud,(1,0,2),unit(0,5,-1)),(Wd,(0,1,2),unit(2,5,-1))]
 for eq,e,want in expected:assert row_at(eq,e)==want
 grids=[]
 for q in [3,4,5,7]:
  m=Model(q);K=m.K
  def power(a,n):
   s=1
   for _ in range(n):s=K.mul[s][a]
   return s
  vals=[]
  for t in list(range(q))+[None]:vals.append([int(i==4) if t is None else power(t,i) for i in range(5)])
  matrix=[[K.mul[a][b] for a in u for b in v] for u in vals for v in vals]
  r=rank(K,matrix);assert r==(16 if q==3 else 25)
  # Homogeneous quartics in three variables; no polynomial of degree<=q
  # can vanish on all points of PG(2,q) unless zero.
  mons=[(a,b,4-a-b) for a in range(5) for b in range(5-a)]
  pts=[]
  for p in range(3):
   for tail in it.product(range(q),repeat=2-p):pts.append([0]*p+[1]+list(tail))
  mat=[]
  for x in pts:
   line=[]
   for e in mons:
    t=1
    for a,n in zip(x,e):t=K.mul[t][power(a,n)]
    line.append(t)
   mat.append(line)
  rh=rank(K,mat)
  if q>=4:assert rh==15
  grids.append(dict(q=q,biquartic_grid_rank=r,homogeneous_quartic_rank=rh,projective_plane_points=len(pts)))
 out=dict(status='passed',formal_vector_order=['p0','p1','p2','r0','r1','r2'],wedge_pairs=PAIRS,cubic_z_coefficient_rows=rows,unit_coefficient_consequences=identities,post_substitution_z_row_zero=True,post_substitution_constant_row_checks=len(expected),interpolation_examples=grids,scope='exact integer coefficient identities and listed finite interpolation matrices; not an exhaustive code classification')
 args.output.write_text(json.dumps(out,indent=2)+'\n');print('14 coefficient relations, 12 selected consequences, and interpolation checks passed',flush=True)
if __name__=='__main__':main()
