#!/usr/bin/env python3
"""Complete recomputation of this supplement; Python stdlib and C++17.
The mathematical normalizations are proved in PROOF_zh.md, not by this program.
"""
from pathlib import Path
import argparse,subprocess,sys,shutil,json,hashlib,time,os
RESULTS=['full_q3_plucker.json','full_q3_candidates.json','q3_final_results.json','cubic_models.json','cubic_projection_planes.json','cubic_complete.json','cubic_candidates.json','cubic_final_results.json','independent_results.json','normalization_checks.json']
def stable(x):
 if isinstance(x,dict):return {k:stable(v) for k,v in x.items() if k not in ['seconds','elapsed_seconds']}
 if isinstance(x,list):return [stable(v) for v in x]
 return x

def run(root:Path,work:Path,compare=True):
 if not __debug__:raise RuntimeError('Assertions must remain enabled.')
 if work.exists() and any(work.iterdir()):raise ValueError('Work directory must be new or empty.')
 if work==root or root in work.parents:raise ValueError('Use a work directory outside the source package.')
 work.mkdir(parents=True,exist_ok=True);start=time.perf_counter()
 if (root/'MANIFEST.json').exists():
  for name,digest in json.loads((root/'MANIFEST.json').read_text()).items():
   assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
 for p in (root/'src').iterdir():
  if p.is_file():shutil.copyfile(p,work/p.name)
 cxx=os.environ.get('CXX') or shutil.which('g++') or shutil.which('clang++')
 if not cxx:raise RuntimeError('A C++17 compiler is required.')
 def task(cmd,name):
  t=time.perf_counter()
  with (work/(name+'.log')).open('w') as out:subprocess.run(cmd,cwd=work,stdout=out,stderr=subprocess.STDOUT,check=True)
  print(name,'passed',round(time.perf_counter()-t,3),flush=True)
 for name in ['q3_final_check','cubic_complete','cubic_final_check']:
  task([cxx,'-O3','-std=c++17',str(work/(name+'.cpp')),'-o',str(work/name)],name+'_compile')
 task([sys.executable,str(work/'degree6_enumerate.py')],'degree6_enumerate')
 task([str(work/'q3_final_check'),str(work/'full_q3_candidates.txt'),str(work/'q3_final_results.json')],'degree6_final')
 task([sys.executable,str(work/'cubic_models.py')],'cubic_models')
 task([str(work/'cubic_complete'),str(work/'cubic_linear_input.txt'),str(work/'cubic_complete.json')],'cubic_complete')
 task([sys.executable,str(work/'cubic_candidates.py')],'cubic_candidates')
 task([str(work/'cubic_final_check'),str(work/'cubic_candidates.txt'),str(work/'cubic_final_results.json')],'cubic_final')
 task([sys.executable,str(work/'independent_verify.py')],'independent_verify')
 task([sys.executable,str(work/'check_normalizations.py')],'check_normalizations')
 if compare:
  for n in RESULTS:assert stable(json.load(open(work/n)))==stable(json.load(open(root/'results'/n))),n
 a=json.load(open(work/'full_q3_plucker.json'))['summary'];b=json.load(open(work/'cubic_complete.json'));c=json.load(open(work/'q3_final_results.json'));d=json.load(open(work/'cubic_final_results.json'));e=json.load(open(work/'independent_results.json'))
 assert a['records']==4988 and a['candidates']==1044
 assert b['subcases']==330057 and b['graph_candidate_count']==117
 assert c['histogram']=={'extra_primal_fibre':922,'minimum_rank':122} and not c['survivors']
 assert d['histogram']=={'wrong_primal_type_multiplicity':114,'minimum_rank':3} and not d['survivors']
 assert e['all_passed']
 normal=json.load(open(work/'normalization_checks.json'));assert normal['all_passed']
 assert sum(x['excluded_gamma_identities'] for x in normal['records'])==3664
 assert sum(x['conic_mobius_identities'] for x in normal['records'])==364
 assert sum(c['secants'] for x in normal['records'] for c in x['cubic_cores'])==12429
 out={'status':'passed','new_theorem_scope':'Nonexistence of an isolated ordinary F3-subline in an intersecting [8,3]_(3^6/3) code; not the whole ternary problem.',
 'degree6_models':4988,'degree6_final_candidates':1044,'cubic_models':31,'cubic_projection_planes_per_model':10647,'cubic_subcases':330057,'cubic_final_candidates':117,'extra_type_or_fibre_witnesses':1036,'rank_three_witnesses':125,'surviving_candidates':0,'independent_complete_reconstruction_passed':True,'saved_mathematical_outputs_compared':compare,'results':RESULTS,'elapsed_seconds':round(time.perf_counter()-start,3),'old_work_recomputed':False,'additional_normalization_checks':{'gamma_identities':3664,'mobius_identities':364,'selected_cubic_secants':12429,'fields':[3,4,5,7]}}
 (work/'verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False,indent=2),flush=True);return out
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--work',required=True,type=Path);a=p.parse_args();run(Path(__file__).resolve().parent,a.work.resolve())
