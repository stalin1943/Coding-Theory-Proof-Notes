#include <array>
#include <vector>
#include <iostream>
#include <fstream>
#include <map>
#include <cassert>
#include <algorithm>
using namespace std;
using Row=array<int,15>;using Ten=array<array<int,10>,10>;
int mod(int x){x%=3;return x<0?x+3:x;}
vector<Row> kernel(vector<Row>a){int r=0;vector<int>p;
 for(int j=0;j<15;j++){int i=r;while(i<(int)a.size()&&!a[i][j])i++;if(i==(int)a.size())continue;swap(a[i],a[r]);int iv=a[r][j];for(int k=0;k<15;k++)a[r][k]=a[r][k]*iv%3;
  for(int z=0;z<(int)a.size();z++)if(z!=r&&a[z][j]){int c=a[z][j];for(int k=0;k<15;k++)a[z][k]=mod(a[z][k]-c*a[r][k]);}p.push_back(j);r++;if(r==(int)a.size())break;}
 vector<Row>ans;for(int f=0;f<15;f++)if(find(p.begin(),p.end(),f)==p.end()){Row v{};v[f]=1;for(int k=0;k<r;k++)v[p[k]]=mod(-a[k][f]);ans.push_back(v);}return ans;}
bool graph(Row p){if(!p[0])return false;int iv=p[0];for(int&x:p)x=x*iv%3;int M[6][6]={};int k=0;for(int i=0;i<6;i++)for(int j=i+1;j<6;j++)M[i][j]=p[k++];for(int i=2;i<6;i++)for(int j=i+1;j<6;j++)if(M[i][j]!=mod(M[0][i]*M[1][j]-M[0][j]*M[1][i]))return false;return true;}
int main(int argc,char**argv){assert(argc==3);ifstream f(argv[1]);assert(f);int n,nd;f>>n>>nd;assert(n==31&&nd==10647);vector<vector<Ten>>eq(n);vector<int>eps(n),mus(n);
 for(int i=0;i<n;i++){int nr;f>>eps[i]>>mus[i]>>nr;for(int t=0;t<nr;t++){Ten M{};for(int a=0;a<10;a++)for(int b=a+1;b<10;b++){int x;f>>x;M[a][b]=x;M[b][a]=mod(-x);}eq[i].push_back(M);}}
 vector<array<array<int,6>,2>>Ds(nd);for(auto&D:Ds)for(auto&v:D)for(int&x:v)f>>x;assert(f);
 ofstream o(argv[2]);o<<"{\"models\":31,\"projection_planes\":10647,\"subcases\":330057,\"records\":[";long long survivors=0,dirs=0;
 for(int k=0;k<n;k++){map<int,int>hist;vector<pair<int,Row>>cand;unsigned long long checksum=0;vector<int>sequence;
  for(int t=0;t<nd;t++){const auto&D=Ds[t];vector<Row>rows;for(const auto&M:eq[k]){Row r{};int c=0;for(int i=0;i<6;i++)for(int j=0;j<6;j++)c+=D[0][i]*M[i][j]*D[1][j];r[0]=mod(c);int z=1;
    for(int a=0;a<2;a++)for(int j=6;j<10;j++){int c=0;for(int i=0;i<6;i++)c+=D[a][i]*M[i][j];r[z++]=mod(c);}for(int i=6;i<10;i++)for(int j=i+1;j<10;j++)r[z++]=M[i][j];assert(z==15);rows.push_back(r);}
   auto ns=kernel(rows);int d=ns.size();assert(d<=8);hist[d]++;sequence.push_back(d);checksum+= (unsigned long long)(t+1)*d;int total=1;for(int i=0;i<d;i++)total*=3;
   for(int piv=0;piv<d;piv++){int lim=1;for(int j=piv+1;j<d;j++)lim*=3;for(int a=0;a<lim;a++){Row p=ns[piv];int s=a;for(int j=piv+1;j<d;j++){int c=s%3;s/=3;for(int i=0;i<15;i++)p[i]=(p[i]+c*ns[j][i])%3;}dirs++;if(graph(p)){cand.push_back({t,p});survivors++;}}}
  }
  if(k)o<<",";o<<"\n{\"id\":"<<k<<",\"epsilon\":"<<eps[k]<<",\"R_generator\":"<<mus[k]<<",\"kernel_histogram\":{";bool first=true;for(auto[d,c]:hist){if(!first)o<<",";first=false;o<<"\""<<d<<"\":"<<c;}o<<"},\"dimension_checksum\":"<<checksum<<",\"kernel_dimension_sequence\":[";for(int i=0;i<nd;i++){if(i)o<<",";o<<sequence[i];}o<<"],\"candidates\":[";for(int i=0;i<(int)cand.size();i++){if(i)o<<",";o<<"{\"projection_id\":"<<cand[i].first<<",\"plucker\":[";for(int j=0;j<15;j++){if(j)o<<",";o<<cand[i].second[j];}o<<"]}";}o<<"]}";
  cerr<<"model "<<k<<" epsilon "<<eps[k]<<" R "<<mus[k]<<" candidates "<<cand.size()<<" kernels ";for(auto[d,c]:hist)cerr<<d<<":"<<c<<" ";cerr<<"\n";
 }
 o<<"],\"projective_kernel_points_checked\":"<<dirs<<",\"graph_candidate_count\":"<<survivors<<"}\n";
}
