#!/usr/bin/env python3
"""Exact linear-algebra checks of the single-subline parameter reduction.
Checks all predicted image planes and hyperplanes for q=3,4,5. It does not
search all candidate codes or assert that these linear conditions suffice.
"""
from pathlib import Path
from itertools import product
import argparse,json
from exact_check import Field,rank,null,rref,irreducible


def proj(q,n):
    for p in range(n):
        for tail in product(range(q),repeat=n-p-1):
            yield [0]*p+[1]+list(tail)

class Quotient:
    def __init__(self,K,subspace,n):
        self.K=K;self.n=n;self.rows,self.piv=rref(K,subspace,n)
        self.free=[i for i in range(n) if i not in self.piv]
    def project(self,x):
        x=list(x)
        for r,p in zip(self.rows,self.piv):
            c=x[p]
            if c:x=[self.K.sub(a,self.K.mul[c][b]) for a,b in zip(x,r)]
        return [x[i] for i in self.free]
    def lift_basis(self):
        return [[int(j==i) for j in range(self.n)] for i in self.free]

def mix(K,c,rows):
    ans=[0]*len(rows[0])
    for a,r in zip(c,rows):
        if a:ans=[K.add[x][K.mul[a][y]] for x,y in zip(ans,r)]
    return ans

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--results',type=Path,required=True);args=ap.parse_args()
    polynomials={3:[2,1,0,0,0,0,1],4:[2,3,2,3,3,1,1],5:[2,1,0,0,0,0,1]}
    out=[]
    for q in [3,4,5]:
        F=Field(q,polynomials[q]);irreducible(F);K=F.K;l=q
        lp=[1]
        for _ in range(5):lp.append(F.mul(lp[-1],l))
        trrows=[[F.trace(F.mul(lp[j],q**k)) for k in range(6)] for j in range(5)]
        db=null(K,trrows,6);assert len(db)==1;delta=F.pack(db[0])
        A=[F.mul(delta,lp[j]) for j in range(4)]
        C=[F.mul(delta,lp[j]) for j in range(3)]
        assert rank(K,[F.digits(x) for x in A])==4
        assert all(F.trace(F.mul(x,b))==0 for x in A for b in [1,l])
        for eps,R in [(0,[1,lp[2]]),(1,[1,l])]:
            M=R+[F.mul(l,x) for x in R]
            QR=Quotient(K,[F.digits(x) for x in R],6)
            QM=Quotient(K,[F.digits(x) for x in M],6)
            reps=[F.pack(x) for x in QR.lift_basis()];t=len(QM.free)
            assert len(reps)==4 and t==2+eps
            # Input graph basis: 8 domain basis vectors times 4 output quotient vectors.
            # Output Delta on 6 ordered domain vectors in C^2.
            mat=[[0]*32 for _ in range(6*t)]
            for coord in range(2):
                for j in range(3):
                    for k,z in enumerate(reps):
                        v=QM.project(F.digits(F.mul(l,z)))
                        w=QM.project(F.digits(F.neg(z)))
                        for a in range(t):
                            mat[(3*coord+j)*t+a][(4*coord+j)*4+k]=v[a]
                            mat[(3*coord+j)*t+a][(4*coord+j+1)*4+k]=w[a]
            assert rank(K,mat)==6*t
            shear=[]
            for coord in range(2):
                for m in range(6):
                    c=q**m;vec=[0]*32
                    for j,a in enumerate(A):
                        value=QR.project(F.digits(F.mul(c,a)))
                        vec[(4*coord+j)*4:(4*coord+j+1)*4]=value
                    shear.append(vec)
            assert rank(K,shear)==12
            assert all(not any(mix(K,v,[list(x) for x in zip(*mat)])) for v in shear)
            # All E_0=g*<1,l> in the three-dimensional polynomial space.
            checks=0;unique=set()
            for g in [[1,0]]+[[K.neg[c],1] for c in range(q)]:
                p0=[g[0],g[1],0];p1=[0,g[0],g[1]]
                E=[p0+[0]*3,p1+[0]*3,[0]*3+p0,[0]*3+p1]
                if eps==0:Ylist=[E]
                else:
                    Ylist=[]
                    for h in proj(q,4):
                        H=null(K,[h],4)
                        Ylist.append([mix(K,v,E) for v in H])
                for Y in Ylist:
                    ky=tuple(sum(rref(K,Y,6)[0],[]));assert ky not in unique;unique.add(ky)
                    con=[]
                    for y in Y:
                        for a in range(t):
                            rows=[mat[j*t+a] for j in range(6)]
                            con.append(mix(K,y,rows))
                    assert rank(K,con)==(4-eps)*t
                    assert 32-rank(K,con)-12==(12 if eps==0 else 11)
                    checks+=1
            assert checks==(q+1 if eps==0 else (q+1)*(1+q+q*q+q**3))
            gl=1
            for j in range(t):gl*=q**t-q**j
            count=q**(20-6*t)*gl
            out.append({'q':q,'epsilon':eps,'section_R':R,'target_dimension':t,
                        'Delta_rank':rank(K,mat),'shear_dimension':12,
                        'constrained_graph_dimension_after_shear':12 if eps==0 else 11,
                        'all_Y_spaces_checked':checks,'all_Y_spaces_distinct':True,
                        'classes_per_fixed_Y_with_exact_kernel':count})
        print('subline q',q,'passed',flush=True)
    result={'all_passed':True,'rows':out,'total_image_spaces_checked':sum(x['all_Y_spaces_checked'] for x in out),
            'scope':'All q+1 image planes and their relevant hyperplanes for q=3,4,5; linear constraint ranks and free shear action only. Not a classification or existence proof for codes.'}
    (args.results/'subline_linear.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)
if __name__=='__main__':main()
