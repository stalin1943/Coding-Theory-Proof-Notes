import sys,itertools as it,json,random,time

from exact_check import Field,rank,null,rref,irreducible
from subline_linear_check import Quotient,mix,proj

def addv(F,a,b):return [F.add(x,y) for x,y in zip(a,b)]
def subv(F,a,b):return [F.add(x,F.neg(y)) for x,y in zip(a,b)]
def sm(F,a,v):return [F.mul(a,x) for x in v]
def dot(F,a,b):
 z=0
 for x,y in zip(a,b):z=F.add(z,F.mul(x,y))
 return z

def cross(F,a,b):return [F.add(F.mul(a[1],b[2]),F.neg(F.mul(a[2],b[1]))),F.add(F.mul(a[2],b[0]),F.neg(F.mul(a[0],b[2]))),F.add(F.mul(a[0],b[1]),F.neg(F.mul(a[1],b[0])))]
def normalize(F,v):return sm(F,F.inv(next(x for x in v if x)),v)
def vec(F,v):return sum([list(F.digits(x)) for x in v],[])
def rsub(K,n,d):
 for piv in it.combinations(range(n),d):
  free=[(i,j) for i,p in enumerate(piv) for j in range(p+1,n) if j not in piv]
  for a in it.product(range(K.q),repeat=len(free)):
   rows=[[int(j==p) for j in range(n)] for p in piv]
   for (i,j),x in zip(free,a):rows[i][j]=x
   yield rows

def examine(q=3,l=None,R=None,epsilon=0,gamma=None,verbose=True,_F=None):
 pol={3:[2,1,0,0,0,0,1],4:[2,3,2,3,3,1,1],5:[2,1,0,0,0,0,1],7:[3,1,0,0,0,0,1]}[q]
 F=_F or Field(q,pol);K=F.K;l=l or q;R=R or ([1,F.mul(l,l)] if epsilon==0 else [1,l])
 lp=[1]
 for _ in range(5):lp.append(F.mul(lp[-1],l))
 d=F.pack(null(K,[[F.trace(F.mul(lp[j],q**k)) for k in range(6)] for j in range(5)],6)[0])
 A=[F.mul(d,p) for p in lp[:4]]
 QR=Quotient(K,[F.digits(x) for x in R],6);reps=[F.pack(x) for x in QR.lift_basis()]
 M=R+[F.mul(l,r) for r in R]
 assert rank(K,[F.digits(x) for x in M])==4-epsilon
 X=([[d,0,0],[F.mul(d,l),0,R[0]],[0,d,0],[0,F.mul(d,l),R[1]]] if epsilon==0 else [[0,0,1],[d,F.neg(F.mul(d,l)),gamma],[F.mul(d,l),0,0],[0,d,0]])
 W0=X+[sm(F,l,x) for x in X]
 assert rank(K,[vec(F,x) for x in W0])==8
 Qlin=[];nr=0;invalid=0;nl=[];weights={}
 for rs in rsub(K,4,2):
  xx=[]
  for a in rs:
   v=[0]*3
   for c,x in zip(a,X):v=addv(F,v,[F.scale(c,t) for t in x])
   xx.append(v)
  n=cross(F,*xx);assert any(n)
  if not n[2]:
   assert rank(K,[F.digits(dot(F,n,x)) for x in W0]+[F.digits(F.mul(n[i],A[3])) for i in [0,1]])<=5
   continue
  n=sm(F,F.inv(n[2]),n)
  S=[dot(F,n,x) for x in W0];rr=rank(K,[F.digits(s) for s in S]);weights[rr]=weights.get(rr,0)+1
  if rr<4:continue
  assert rr<=4, (q,l,R,epsilon,gamma,rr)
  QS=Quotient(K,[F.digits(s) for s in S],6)
  assert len(QS.free)==2
  P=[QS.project(F.digits(s)) for s in reps]
  a=QS.project(F.digits(F.mul(n[0],A[3])));b=QS.project(F.digits(F.mul(n[1],A[3])))
  def det(x,y):return K.sub(K.mul[x[0]][y[1]],K.mul[x[1]][y[0]])
  row=[det(a,b)]+[det(x,b) for x in P]+[det(a,x) for x in P]+[det(x,y) for x in P for y in P]
  assert len(row)==25
  Qlin.append(row);nl.append(n)
  nr+=1
 r=rank(K,Qlin);aug=rank(K,Qlin+[[1]+[0]*24])
 if verbose:print('q',q,'l',l,'R',R,'Xrank',rank(K,[vec(F,x) for x in X]),'secant eq',nr,'weights',weights,'invalid',invalid,'poly rank',r,'with constant',aug,flush=True)
 return dict(q=q,epsilon=epsilon,gamma=gamma,polynomial=pol,l=l,R=R,delta=d,reps=reps,equations=Qlin,normals=nl,rank=r,constant_in_span=(aug==r),X=X,W0=W0)
