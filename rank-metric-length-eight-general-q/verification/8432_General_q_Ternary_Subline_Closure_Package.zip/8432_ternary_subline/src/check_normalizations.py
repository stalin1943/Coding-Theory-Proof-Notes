"""Additional exact checks for algebraic normalization identities in q=3,4,5,7.
These are specified examples and identity tests, not complete classifications
of the nonternary fields. Arithmetic is the attributed input implementation.
"""
from pathlib import Path
import itertools as it,json,random,collections,time
from exact_check import Field,rank,null,irreducible
from secant_core import dot,vec,sm,addv,rsub,cross

POL={3:[2,1,0,0,0,0,1],4:[2,3,2,3,3,1,1],5:[2,1,0,0,0,0,1]}
def make(q):
 if q in POL:F=Field(q,POL[q]);irreducible(F);return F
 rng=random.Random(843200+q)
 for _ in range(1000):
  p=[rng.randrange(1,q)]+[rng.randrange(q) for _ in range(5)]+[1];F=Field(q,p)
  try:irreducible(F);return F
  except AssertionError:continue
 raise AssertionError('irreducible polynomial search exhausted')
def do(q):
 st=time.time();F=make(q);K=F.K;l=q
 ls=([x for x in range(q,F.Q) if x%q==0 and F.normal(x)==x and F.pow(x,9)!=x and F.pow(x,27)!=x] if q==3 else [l])
 gamma_cases=0;mobius_cases=0
 for l in ls:
  delta=F.pack(null(K,[[F.trace(F.mul(F.pow(l,j),q**i)) for i in range(6)] for j in range(5)],6)[0]);assert delta
  for c0,c1,cm in it.product(range(q),repeat=3):
   ga=F.add(F.add(c0,F.scale(c1,l)),F.scale(cm,F.inv(l)))
   X=[[0,0,1],[delta,F.neg(F.mul(delta,l)),ga],[F.mul(delta,l),0,0],[0,delta,0]]
   n=[F.neg(F.mul(cm,F.inv(F.mul(delta,l)))),F.mul(c1,F.inv(delta)),1]
   assert [dot(F,n,x) for x in X]==[1,c0,K.neg[cm],c1]
   assert rank(K,[F.digits(dot(F,n,x)) for x in X+[sm(F,l,x) for x in X]])==2
   gamma_cases+=1
  for c in range(q):
   g=F.add(l,F.neg(c));tau=F.inv(g);dn=F.mul(delta,F.pow(g,4))
   assert all(F.trace(F.mul(dn,F.pow(tau,j)))==0 for j in range(5))
   B=F.span([1,l]);E0=F.span([F.mul(delta,g),F.mul(delta,F.mul(g,l))])
   transformed=set(F.mul(F.mul(g,g),x) for x in E0)
   assert transformed==set(F.mul(dn,x) for x in F.span([1,tau]))
   assert set(F.mul(g,x) for x in F.span([1,tau]))==set(B)
   mobius_cases+=1
 # Cubic representative and trace cores: test every secant for selected R.
 theta=q;cl=next(F.pow(a,q**3+1) for a in range(q,q+100) if F.pow(a,q**3+1)>=q)
 assert F.pow(cl,q**3)==cl and cl>=q
 eb=[1,cl,F.mul(cl,cl)];assert rank(K,[F.digits(e) for e in eb])==3
 omega=next(F.pow(a,(F.Q-1)//(q*q-1)) for a in range(q,q+100) if F.pow(a,(F.Q-1)//(q*q-1))>=q)
 assert F.pow(omega,q*q)==omega
 Xs=[('cubic-eps0-degree6R',[[1,0,0],[cl,0,1],[0,1,0],[0,cl,theta]]),
     ('cubic-eps0-quadraticR',[[1,0,0],[cl,0,1],[0,1,0],[0,cl,omega]]),
     ('cubic-eps1',[[0,0,1]]+[[t,F.pow(t,q),F.mul(theta,F.pow(t,q*q))] for t in eb])]
 core_stats=[]
 for name,X in Xs:
  W0=X+[sm(F,cl,x) for x in X];assert rank(K,[vec(F,w) for w in W0])==8
  norm=set();hi=collections.Counter()
  for D in rsub(K,4,2):
   vs=[]
   for c in D:
    a=[0,0,0]
    for b,x in zip(c,X):a=addv(F,a,[F.scale(b,z) for z in x])
    vs.append(a)
   n=cross(F,*vs);assert any(n);n=sm(F,F.inv(next(x for x in n if x)),n)
   assert tuple(n) not in norm;norm.add(tuple(n))
   r=rank(K,[F.digits(dot(F,n,w)) for w in W0]);assert r in [3,4];hi[r]+=1
  predicted=(q**4-1)*(q**4-q)//((q*q-1)*(q*q-q));assert len(norm)==predicted
  core_stats.append(dict(label=name,secants=len(norm),image_rank_histogram=dict(hi)))
 print('normalization q',q,'gamma',gamma_cases,'mobius',mobius_cases,'secants',sum(x['secants'] for x in core_stats),'seconds',round(time.time()-st,2),flush=True)
 return dict(q=q,polynomial=F.pol,degree6_generators=len(ls),excluded_gamma_identities=gamma_cases,conic_mobius_identities=mobius_cases,cubic_lambda=cl,theta=theta,cubic_cores=core_stats,seconds=time.time()-st)
if __name__=='__main__':
 out=[do(q) for q in [3,4,5,7]]
 result={'all_passed':True,'fields':[r['q'] for r in out],'records':out,'scope':'Explicit gamma-obstruction and Mobius-normalization identities; selected cubic trace cores. Not exhaustive q=4,5,7 subline exclusions.'}
 Path(__file__).with_name('normalization_checks.json').write_text(json.dumps(result,indent=2)+'\n')
