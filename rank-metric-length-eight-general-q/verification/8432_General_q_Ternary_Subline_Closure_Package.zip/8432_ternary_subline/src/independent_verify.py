"""Independent q=3 reconstruction: coefficient-table field, left-pivot kernels,
pair-generated subspaces, direct annihilator determinants and whole projection sweep.
Does not import primary field or Gaussian-elimination implementations.
"""
from pathlib import Path
import itertools as it,json,time,collections
ROOT=Path(__file__).parent
N=729;DIG=[tuple((i//3**j)%3 for j in range(6)) for i in range(N)];P=[3**j for j in range(6)]
ADD=[[sum(((a+b)%3)*p for a,b,p in zip(DIG[x],DIG[y],P)) for y in range(N)] for x in range(N)]
NEG=[sum(((-a)%3)*p for a,p in zip(DIG[x],P)) for x in range(N)]
SC=[[0]*N,list(range(N)),NEG]
def shift(a):
 d=list(DIG[a]);v=[0]+d[:5];v[0]=(-2*d[5])%3;v[1]=(v[1]-d[5])%3
 return sum(x*p for x,p in zip(v,P))
MUL=[]
SM=[0]*N;POS=[0]*N;CO=[0]*N
for b in range(1,N):
 j=next(j for j,x in enumerate(DIG[b]) if x);POS[b]=j;CO[b]=DIG[b][j];SM[b]=b-CO[b]*P[j]
for a in range(N):
 xx=[];x=a
 for j in range(6):xx.append(x);x=shift(x)
 row=[0]*N
 for b in range(1,N):row[b]=ADD[row[SM[b]]][SC[CO[b]][xx[POS[b]]]]
 MUL.append(row)
def power(a,n):
 z=1
 while n:
  if n&1:z=MUL[z][a]
  a=MUL[a][a];n//=2
 return z
INV=[0]+[power(a,N-2) for a in range(1,N)]
assert all(MUL[a][INV[a]]==1 for a in range(1,N))
TR=[]
for a in range(N):
 z=0;x=a
 for _ in range(6):z=ADD[z][x];x=power(x,3)
 assert z<3;TR.append(z)
def plus(a,b):return [ADD[x][y] for x,y in zip(a,b)]
def scale(c,a):return [MUL[c][x] for x in a]
def scalar(c,a):return [SC[c][x] for x in a]
def dot(a,b):
 z=0
 for x,y in zip(a,b):z=ADD[z][MUL[x][y]]
 return z
def vec(a):return sum([list(DIG[x]) for x in a],[])
def pack(a):return sum(x*p for x,p in zip(a,P))
def cross(a,b):return [ADD[MUL[a[1]][b[2]]][NEG[MUL[a[2]][b[1]]]],ADD[MUL[a[2]][b[0]]][NEG[MUL[a[0]][b[2]]]],ADD[MUL[a[0]][b[1]]][NEG[MUL[a[1]][b[0]]]]]
def rr(rows,n):
 A=[list(x) for x in rows if any(x)];p=[];r=0
 for j in range(n):
  k=next((k for k in range(r,len(A)) if A[k][j]),None)
  if k is None:continue
  A[r],A[k]=A[k],A[r];iv=A[r][j];A[r]=[(iv*x)%3 for x in A[r]]
  for k in range(len(A)):
   if k!=r and A[k][j]:
    c=A[k][j];A[k]=[(x-c*y)%3 for x,y in zip(A[k],A[r])]
  p.append(j);r+=1
  if r==len(A):break
 return A[:r],p
def rank(A,n=None):return len(rr(A,n or len(A[0]))[0]) if A else 0
def null(A,n):
 R,p=rr(A,n);out=[]
 for j in range(n):
  if j in p:continue
  v=[0]*n;v[j]=1
  for row,k in zip(R,p):v[k]=-row[j]%3
  out.append(v)
 return out
def proj(n):
 for i in range(n):
  for a in it.product(range(3),repeat=n-i-1):yield [0]*i+[1]+list(a)
def mix(c,A):return [sum(x*a[j] for x,a in zip(c,A))%3 for j in range(len(A[0]))]
def subs_pair(n):
 out=set()
 for a,b in it.combinations(list(proj(n)),2):
  R,_=rr([a,b],n);out.add(tuple(tuple(x) for x in R))
 return sorted(out)
SUB4=subs_pair(4);assert len(SUB4)==130
INDEX6=list(it.combinations(range(6),2));INDEX10=list(it.combinations(range(10),2));INDEX4=list(it.combinations(range(4),2))
def norm(a):return scale(INV[next(x for x in a if x)],a)
def pmat(p):
 M=[[0]*6 for _ in range(6)]
 for x,(i,j) in zip(p,INDEX6):M[i][j]=x;M[j][i]=-x%3
 return M
def coeff15_standard_to_sixth(p):
 # Standard wedge of [outer1,outer2,vertical0..3] to (p0,x,y,z).
 M=pmat(p);return [p[0]]+[-M[1][i]%3 for i in range(2,6)]+[M[0][i] for i in range(2,6)]+[M[i+2][j+2] for i,j in INDEX4]
def sixth_to_standard(v):
 M=[[0]*6 for _ in range(6)];M[0][1]=v[0]
 for i in range(4):M[0][i+2]=v[5+i];M[1][i+2]=-v[1+i]%3
 for x,(i,j) in zip(v[9:],INDEX4):M[i+2][j+2]=x
 return [M[i][j] for i,j in INDEX6]
def determinants(X,W0,reps):
 rows=[];normals=set();hist=collections.Counter()
 assert rank([vec(x) for x in X],18)==4 and rank([vec(x) for x in W0],18)==8
 for D in SUB4:
  vs=[]
  for c in D:
   v=[0,0,0]
   for z,x in zip(c,X):v=plus(v,scalar(z,x))
   vs.append(v)
  n=norm(cross(*vs));assert tuple(n) not in normals;normals.add(tuple(n))
  A=[DIG[dot(n,w)] for w in W0];r=rank(A,6);hist[r]+=1;assert r in [3,4]
  if r==3:continue
  annih=null(A,6);assert len(annih)==2
  image=[[sum(c*x for c,x in zip(f,DIG[dot(n,v)]))%3 for f in annih] for v in reps]
  rows.append([(a[0]*b[1]-a[1]*b[0])%3 for a,b in it.combinations(image,2)])
 return rows,dict(hist)
def typeplanes():
 planes={}
 for a in range(3,N):
  B=tuple(sorted(ADD[x][SC[y][a]] for x in range(3) for y in range(3)))
  planes[B]=None
 assert len(planes)==121
 groups={};representatives={}
 for B in planes:
  key=min(tuple(sorted(MUL[INV[x]][y] for y in B)) for x in B if x)
  groups[B]=key;representatives.setdefault(key,B)
 assert len(representatives)==31
 return groups
TYPES=typeplanes()
def plane(a):return tuple(sorted(ADD[x][SC[y][a]] for x in range(3) for y in range(3)))
def dual(W):return [[pack(v[j:j+6]) for j in [0,6,12]] for v in null([[TR[MUL[w[j//6]][P[j%6]]] for j in range(18)] for w in W],18)]

def verify_sixth():
 st=time.time();source=json.load(open(ROOT/'full_q3_plucker.json'));cs=json.load(open(ROOT/'full_q3_candidates.json'));data=json.load(open(ROOT/'q3_final_results.json'))
 observed=[];seen=set();hist=collections.Counter();candidate_ids=set()
 for num,r in enumerate(source['records']):
  l=r['l'];R=r['R'];d=r['delta'];lp=MUL[d][l]
  assert power(l,9)!=l and power(l,27)!=l
  assert all(TR[MUL[d][power(l,j)]]==0 for j in range(5))
  assert rank([DIG[x] for x in R]+[DIG[x] for x in r['reps']],6)==6
  if r['epsilon']==0:X=[[d,0,0],[lp,0,R[0]],[0,d,0],[0,lp,R[1]]]
  else:X=[[0,0,1],[d,NEG[lp],r['gamma']],[lp,0,0],[0,d,0]]
  W0=X+[scale(l,x) for x in X];a3=MUL[d][power(l,3)];reps=[[a3,0,0],[0,a3,0]]+[[0,0,x] for x in r['reps']]
  rows,histsec=determinants(X,W0,reps);ker=null(rows,15)
  expected=[sixth_to_standard(p) for p in r['kernel_basis']]
  assert len(ker)==len(expected)==rank(expected,15)
  assert all(sum(a*b for a,b in zip(row,p))%3==0 for row in rows for p in expected)
  graphs=set();ranks=collections.Counter()
  for c in proj(len(ker)):
   p=mix(c,ker);rk=rank(pmat(p),6);ranks[rk]+=1
   if p[0] and rk==2:
    p=[v*p[0]%3 for v in p];v=coeff15_standard_to_sixth(p);graphs.add(tuple(v[1:9]))
  assert {str(k):v for k,v in ranks.items()}==r['alternating_rank_histogram']
  reported={tuple(cs[i]['parameter']) for i in r['graph_candidate_ids']};assert graphs==reported
  for id in r['graph_candidate_ids']:
   c=cs[id];candidate_ids.add(id);ts=[]
   for p in [c['parameter'][:4],c['parameter'][4:]]:
    z=0
    for a,b in zip(p,r['reps']):z=ADD[z][SC[a][b]]
    ts.append(z)
   W=W0+[[a3,0,ts[0]],[0,a3,ts[1]]];assert W==c['W']
  seen.add((l,r['epsilon'],tuple(R),r['gamma']));hist[r['epsilon'],len(ker),len(graphs)]+=1
  if (num+1)%500==0:print('independent sixth',num+1,'seconds',round(time.time()-st,1),flush=True)
 assert len(seen)==4988 and len(candidate_ids)==1044
 lset={r['l'] for r in source['records']};assert len(lset)==116
 all_sixth={B for B in TYPES if any(x>=3 and power(x,9)!=x and power(x,27)!=x for x in B)}
 assert len(all_sixth)==116 and {plane(l) for l in lset}==all_sixth
 for l in lset:
  group=[r for r in source['records'] if r['l']==l];eps0=[r for r in group if r['epsilon']==0];eps1=[r for r in group if r['epsilon']==1]
  assert len(eps0)==30 and {TYPES[plane(r['R'][1])] for r in eps0}==set(TYPES.values())-{TYPES[plane(l)]}
  G=[DIG[1],DIG[l],DIG[INV[l]]];assert rank(G,6)==3
  assert len(eps1)==13 and all(rank(G+[DIG[r['gamma']]],6)==4 for r in eps1)
  assert all(rank(G+[DIG[r['gamma']],DIG[s['gamma']]],6)==5 for r,s in it.combinations(eps1,2))
 fin=verify_witnesses(cs,data,'sixth')
 return dict(records=len(seen),canonical_lambdas=116,secants_per_record=130,projective_graphs=1044,histogram={str(k):v for k,v in hist.items()},final=fin,seconds=time.time()-st)

def verify_witnesses(cs,data,tag):
 assert len(cs)==data['candidate_count'];hist=collections.Counter()
 for c,r in zip(cs,data['records']):
  W=c['W'];assert rank([vec(w) for w in W],18)==10;U=dual(W);assert len(U)==8
  if r['reason']=='extra_primal_fibre':
   u=r['u'];s=r['tau'];assert u[2] and s>=3
   assert all(TR[dot(w,u)]==TR[dot(w,scale(s,u))]==0 for w in W)
  elif r['reason']=='wrong_primal_type_multiplicity':
   s=r['tau'];rk=rank([vec(w) for w in W]+[vec(scale(s,w)) for w in W],18);assert rk==r['rank']
   target=16 if TYPES[plane(s)]==TYPES[plane(c['l'])] else 18
   assert rk<target
   assert all(TR[dot(w,r['u'])]==TR[dot(w,scale(s,r['u']))]==0 for w in W)
  elif r['reason']=='minimum_rank':
   assert any(r['h']);rk=rank([DIG[dot(r['h'],u)] for u in U],6);assert rk==r['rank']<=3
  else:raise AssertionError(r['reason'])
  hist[r['reason']]+=1
 assert dict(hist)==data['histogram'] and not data['survivors']
 print('independent witnesses',tag,dict(hist),flush=True);return dict(hist)

def verify_cubic():
 st=time.time();models=json.load(open(ROOT/'cubic_models.json'));Ds_primary=json.load(open(ROOT/'cubic_projection_planes.json'));res=json.load(open(ROOT/'cubic_complete.json'));l=144;eb=[1,l,MUL[l][l]]
 Ds=[]
 for D in subs_pair(6):
  v=[]
  for row in D:
   x=y=0
   for a,b,e in zip(row[:3],row[3:],eb):x=ADD[x][SC[a][e]];y=ADD[y][SC[b][e]]
   v.append([x,y])
  if MUL[v[0][0]][v[1][1]]!=MUL[v[0][1]][v[1][0]]:Ds.append([list(v) for v in D])
 assert len(Ds)==10647 and {tuple(map(tuple,D)) for D in Ds}=={tuple(map(tuple,D)) for D in Ds_primary}
 # Compare by the actual projection subspace rather than by differing enumeration order.
 target_index={tuple(map(tuple,D)):i for i,D in enumerate(Ds_primary)}
 summary=[];cs=json.load(open(ROOT/'cubic_candidates.json'));actualC=collections.defaultdict(list)
 for c in cs:actualC[c['source_model']].append(c)
 for mid,(m,r) in enumerate(zip(models,res['records'])):
  X=m['X']
  expected_X=([[1,0,0],[l,0,1],[0,1,0],[0,l,m['R_generator']]] if m['epsilon']==0 else [[0,0,1]]+[[t,power(t,3),MUL[3][power(t,9)]] for t in eb])
  assert X==expected_X and m['l']==l
  W0=X+[scale(l,x) for x in X];assert W0==m['W0']
  outer=[[MUL[3][t],0,0] for t in eb]+[[0,MUL[3][t],0] for t in eb]
  assert m['reps'][:6]==outer
  assert all(power(v[0],27)==v[0] and power(v[1],27)==v[1] for v in m['reps'][6:])
  assert rank([vec(x) for x in W0+m['reps'][6:]],18)==12
  eq,histsec=determinants(X,W0,m['reps']);basis,_=rr(eq,45)
  assert rank(basis+m['equations'],45)==len(basis)==45-len(m['kernel'])
  assert {str(k):v for k,v in histsec.items()}==m['rankhist']
  assert rank([vec(x) for x in W0+m['reps']],18)==18
  matrices=[]
  for row in basis:
   M=[[0]*10 for _ in range(10)]
   for v,(i,j) in zip(row,INDEX10):M[i][j]=v;M[j][i]=-v%3
   matrices.append(M)
  hh=collections.Counter();total=0;candidate_sets=set()
  for did,D in enumerate(Ds):
   rows=[]
   for M in matrices:
    c=sum(D[0][i]*M[i][j]*D[1][j] for i in range(6) for j in range(6))%3
    row=[c]+[sum(D[a][i]*M[i][j] for i in range(6))%3 for a in range(2) for j in range(6,10)]+[M[i][j] for i,j in it.combinations(range(6,10),2)]
    rows.append(row)
   ke=null(rows,15);hh[len(ke)]+=1;orig=target_index[tuple(map(tuple,D))]
   assert len(ke)==r['kernel_dimension_sequence'][orig]
   for c in proj(len(ke)):
    p=mix(c,ke);total+=1
    if p[0] and rank(pmat(p),6)==2:
     p=tuple(v*p[0]%3 for v in p);candidate_sets.add((orig,p))
  reported={(c['projection_id'],tuple(v*c['plucker'][0]%3 for v in c['plucker'])) for c in r['candidates']}
  assert reported==candidate_sets
  supplied={(target_index[tuple(map(tuple,c['projection_basis']))],tuple(c['plucker'])) for c in actualC[mid]}
  assert supplied==candidate_sets
  # Bind every final field model to the recovered Pluecker graph.
  for c in actualC[mid]:
   p=c['plucker'];D=c['projection_basis'];M=pmat(p);params=[D[0]+[-M[1][i]%3 for i in range(2,6)],D[1]+[M[0][i] for i in range(2,6)]];W=W0[:]
   for row in params:
    w=[0,0,0]
    for a,v in zip(row,m['reps']):w=plus(w,scalar(a,v))
    W.append(w)
   assert W==c['W']
  summary.append(dict(model=mid,histogram=dict(hh),graphs=len(candidate_sets),projective_kernel_points=total))
  print('independent cubic',mid,'hist',dict(hh),'graphs',len(candidate_sets),'seconds',round(time.time()-st,1),flush=True)
 assert len(models)==31
 assert {TYPES[plane(m['R_generator'])] for m in models if m['epsilon']==0}==set(TYPES.values())-{TYPES[plane(l)]}
 fin=verify_witnesses(cs,json.load(open(ROOT/'cubic_final_results.json')),'cubic')
 return dict(models=31,projection_planes=len(Ds),subcases=31*len(Ds),graphs=len(cs),records=summary,final=fin,seconds=time.time()-st)
if __name__=='__main__':
 t=time.time();out={'sixth':verify_sixth()};(ROOT/'independent_partial.json').write_text(json.dumps(out,indent=2)+'\n')
 out['cubic']=verify_cubic();out['all_passed']=True;out['seconds']=time.time()-t;(ROOT/'independent_results.json').write_text(json.dumps(out,indent=2)+'\n');print('ALL PASSED',time.time()-t,flush=True)
