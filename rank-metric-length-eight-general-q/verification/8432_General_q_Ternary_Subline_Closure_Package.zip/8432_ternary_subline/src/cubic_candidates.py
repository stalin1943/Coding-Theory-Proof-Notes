import json,itertools as it,sys
from pathlib import Path

from exact_check import Field,rank
F=Field(3,[2,1,0,0,0,0,1]);root=Path(__file__).parent;rec=json.load(open(root/'cubic_models.json'));out=json.load(open(root/'cubic_complete.json'));Ds=json.load(open(root/'cubic_projection_planes.json'))
cs=[]
for m,r in zip(rec,out['records']):
 for c in r['candidates']:
  p=[v*(1 if c['plucker'][0]==1 else 2)%3 for v in c['plucker']];M=[[0]*6 for _ in range(6)]
  for z,(i,j) in zip(p,it.combinations(range(6),2)):M[i][j]=z;M[j][i]=-z%3
  D=Ds[c['projection_id']];paras=[D[0]+[(-M[1][i])%3 for i in range(2,6)],D[1]+[M[0][i] for i in range(2,6)]];ext=[]
  for a in paras:
   v=[0,0,0]
   for b,w in zip(a,m['reps']):v=[F.add(x,F.scale(b,y)) for x,y in zip(v,w)]
   ext.append(v)
  W=m['W0']+ext;assert rank(F.K,[sum([list(F.digits(z)) for z in w],[]) for w in W])==10
  cs.append(dict(l=m['l'],R=[1,m['R_generator']],epsilon=m['epsilon'],projection_id=c['projection_id'],ts=[],W=W,source_model=r['id'],plucker=p,projection_basis=D))
(root/'cubic_candidates.json').write_text(json.dumps(cs,indent=2)+'\n')
with open(root/'cubic_candidates.txt','w') as f:
 f.write(str(len(cs))+'\n')
 for c in cs:f.write(' '.join(map(str,[c['l'],c['epsilon'],c['projection_id'],*sum(c['W'],[])]))+'\n')
print('wrote',len(cs))
