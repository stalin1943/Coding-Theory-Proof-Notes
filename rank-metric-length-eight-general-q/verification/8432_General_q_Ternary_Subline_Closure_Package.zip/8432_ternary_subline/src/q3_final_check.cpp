#include <array>
#include <vector>
#include <map>
#include <algorithm>
#include <cassert>
#include <fstream>
#include <iostream>
#include <numeric>
#include <cstdint>
#include <string>
using namespace std;
using V=array<int,3>;
const int q=3,Q=729;
int addt[Q][Q],mult[Q][Q],invv[Q],negv[Q],dig[Q][6],tr[Q],pwr[6];
int raw(int a,int b){int c[11]={};for(int i=0;i<6;i++)for(int j=0;j<6;j++)c[i+j]=(c[i+j]+dig[a][i]*dig[b][j])%3;for(int i=10;i>=6;i--){int z=c[i];c[i-6]=(c[i-6]+6-2*z)%3;c[i-5]=(c[i-5]+3-z)%3;}int r=0;for(int i=0;i<6;i++)r+=c[i]*pwr[i];return r;}
int times(int a,int b){return mult[a][b];}int fadd(int a,int b){return addt[a][b];}
int power(int a,int n){int r=1;for(;n;n>>=1,a=times(a,a))if(n&1)r=times(r,a);return r;}
V scale(int c,V a){for(int &x:a)x=times(c,x);return a;}
V sub(V a,V b){for(int i=0;i<3;i++)a[i]=fadd(a[i],negv[b[i]]);return a;}
V normal(V a){int r=0;while(r<3&&!a[r])r++;assert(r<3);return scale(invv[a[r]],a);}
int code(V a){if(a[0])return a[1]*Q+a[2];if(a[1])return Q*Q+a[2];return Q*Q+Q;}
int rk(vector<V> rows){array<V,18>b{};int n=0;for(V x:rows){for(int j=17;j>=0;j--){int c=dig[x[j/6]][j%6];if(!c)continue;if(b[j][j/6]){x=sub(x,scale(c,b[j]));}else{b[j]=scale(c==1?1:2,x);n++;break;}}}return n;}
int dot(V a,V b){int z=0;for(int j=0;j<3;j++)z=fadd(z,times(a[j],b[j]));return z;}
vector<V> dual(vector<V> W){vector<array<int,18>>A;for(auto w:W){array<int,18> r{};for(int j=0;j<18;j++)r[j]=tr[times(w[j/6],pwr[j%6])];A.push_back(r);}int n=0;vector<int>piv;for(int j=17;j>=0;j--){int i=n;while(i<(int)A.size()&&!A[i][j])i++;if(i==(int)A.size())continue;swap(A[n],A[i]);int iv=A[n][j];for(int k=0;k<18;k++)A[n][k]=A[n][k]*iv%3;for(int t=0;t<(int)A.size();t++)if(t!=n&&A[t][j]){int c=A[t][j];for(int k=0;k<18;k++)A[t][k]=(A[t][k]+3-c*A[n][k]%3)%3;}piv.push_back(j);n++;if(n==(int)A.size())break;}vector<V>out;for(int f=0;f<18;f++)if(find(piv.begin(),piv.end(),f)==piv.end()){array<int,18>v{};v[f]=1;for(int k=0;k<n;k++)v[piv[k]]=(3-A[k][f])%3;V x{};for(int j=0;j<18;j++)x[j/6]+=v[j]*pwr[j%6];out.push_back(x);}return out;}
vector<int> plane(int l){vector<int>B;for(int a=0;a<3;a++)for(int b=0;b<3;b++)B.push_back(fadd(a,times(b,l)));sort(B.begin(),B.end());return B;}
int knormal(int l){for(int j=5;j>=0;j--)if(dig[l][j])return times(dig[l][j],l);return 0;}
int pnormal(int l){return knormal(fadd(l,negv[l%3]));}
int typekey(int l){auto B=plane(l);int key=Q;for(int a:B)if(a)for(int b:B){int z=times(invv[a],b);if(z>=3)key=min(key,pnormal(z));}return key;}
V cross(V a,V b){return {fadd(times(a[1],b[2]),negv[times(a[2],b[1])]),fadd(times(a[2],b[0]),negv[times(a[0],b[2])]),fadd(times(a[0],b[1]),negv[times(a[1],b[0])])};}
int rankvalues(vector<int> v){vector<V>r;for(int x:v)r.push_back({x,0,0});return rk(r);}
void pv(ostream&o,V v){o<<"["<<v[0]<<","<<v[1]<<","<<v[2]<<"]";}
int main(int argc,char**argv){assert(argc>=3);pwr[0]=1;for(int i=1;i<6;i++)pwr[i]=3*pwr[i-1];for(int a=0;a<Q;a++){int x=a;for(int j=0;j<6;j++){dig[a][j]=x%3;x/=3;}}for(int a=0;a<Q;a++)for(int b=0;b<Q;b++){int z=0;for(int j=0;j<6;j++)z+=(dig[a][j]+dig[b][j])%3*pwr[j];addt[a][b]=z;mult[a][b]=raw(a,b);}for(int a=0;a<Q;a++){negv[a]=times(2,a);if(a){invv[a]=power(a,Q-2);assert(times(a,invv[a])==1);}int s=0,t=a;for(int j=0;j<6;j++){s=fadd(s,t);t=power(t,3);}assert(s<3);tr[a]=s;}
 map<int,int>ty;for(int l=3;l<Q;l++)if(pnormal(l)==l)ty.emplace(typekey(l),l);assert(ty.size()==31);
 ifstream f(argv[1]);ofstream out(argv[2]);int N=0;if(!(f>>N)||N<0){cerr<<"Invalid candidate input file\n";return 2;}out<<"{\"q\":3,\"candidate_count\":"<<N<<",\"records\":[\n";map<string,int>hist;vector<int>survivors;vector<uint8_t>counts(Q*Q+Q+1);
 for(int id=0;id<N;id++){int l,ep,ga;f>>l>>ep>>ga;vector<V>W(10);for(auto &v:W)for(int &x:v){f>>x;assert(x>=0&&x<Q);}assert(f);assert(rk(W)==10);auto U=dual(W);assert(U.size()==8);int tl=typekey(l);string reason;V u{},h{},g{};int tau=0,wrank=-1;
  // Exact test for weight-two primal points outside the prescribed subline.
  for(auto [key,s]:ty){auto WW=W;for(auto v:W)WW.push_back(scale(s,v));int r=rk(WW);int target=key==tl?16:18;assert(r<=target);if(r<target){auto D=dual(WW);for(auto v:D)if(v[2]){u=v;break;}assert(u[2]);assert(all_of(W.begin(),W.end(),[&](V w){return tr[dot(w,u)]==0&&tr[dot(w,scale(s,u))]==0;}));reason="extra_primal_fibre";tau=s;wrank=r;break;}}
  if(reason.empty()){
   fill(counts.begin(),counts.end(),0);bool bad=false;
   for(int piv=0;piv<10&&!bad;piv++){int lim=1;for(int j=piv+1;j<10;j++)lim*=3;for(int a=0;a<lim;a++){V v=W[piv];int t=a;for(int j=piv+1;j<10;j++){int c=t%3;t/=3;v=sub(v,scale((3-c)%3,W[j]));}v=normal(v);int c=++counts[code(v)];if(c>4){h=v;reason="minimum_rank";vector<int>vals;for(auto x:U)vals.push_back(dot(h,x));wrank=rankvalues(vals);assert(wrank<=3);bad=true;break;}}}
   if(!bad){vector<V>heavy;for(int a=0;a<Q;a++)for(int b=0;b<Q;b++)if(counts[a*Q+b]==4)heavy.push_back({1,a,b});for(int a=0;a<Q;a++)if(counts[Q*Q+a]==4)heavy.push_back({0,1,a});if(counts[Q*Q+Q]==4)heavy.push_back({0,0,1});for(int i=0;i<(int)heavy.size()&&reason.empty();i++)for(int j=i+1;j<(int)heavy.size();j++){V n=cross(heavy[i],heavy[j]);vector<int>im;for(auto w:W)im.push_back(dot(n,w));if(rankvalues(im)==6){reason="disjoint_support";h=heavy[i];g=heavy[j];break;}}if(reason.empty())survivors.push_back(id);}
  }
  if(reason.empty())reason="survives";hist[reason]++;if(id)out<<",\n";out<<"{\"id\":"<<id<<",\"lambda\":"<<l<<",\"epsilon\":"<<ep<<",\"gamma\":"<<ga<<",\"reason\":\""<<reason<<"\",\"rank\":"<<wrank;if(reason=="extra_primal_fibre"){out<<",\"tau\":"<<tau<<",\"u\":";pv(out,u);}else{out<<",\"h\":";pv(out,h);if(reason=="disjoint_support"){out<<",\"g\":";pv(out,g);}}out<<"}";
  if((id+1)%100==0)cerr<<"checked "<<id+1<<" / "<<N<<"\n";
 }
 out<<"\n],\"histogram\":{";bool first=true;for(auto [k,n]:hist){if(!first)out<<",";first=false;out<<"\""<<k<<"\":"<<n;}out<<"},\"survivors\":[";for(int i=0;i<(int)survivors.size();i++){if(i)out<<",";out<<survivors[i];}out<<"]}\n";for(auto[k,n]:hist)cerr<<k<<":"<<n<<" ";cerr<<"\n";
}
