from pathlib import Path
import sys,json,itertools as it,collections,time

from secant_core import examine,addv
from exact_check import Field,rank,null,rref
from subline_linear_check import Quotient,proj,mix
q=3;F=Field(q,[2,1,0,0,0,0,1]);K=F.K
planes=[a for a in range(q,F.Q) if a%q==0 and F.normal(a)==a]
assert len(planes)==121
types={};type_of={}
for a in planes:
 key=F.typekey(a);types.setdefault(key,a);type_of[a]=key
mus=sorted(types.values());assert len(mus)==31
ls=[a for a in planes if F.pow(a,9)!=a and F.pow(a,27)!=a];assert len(ls)==116
pairs=list(it.combinations(range(4),2));start=time.time();records=[];hist=collections.Counter();candidates=[]
def p_matrix(v):
 M=[[0]*6 for _ in range(6)];M[0][1]=v[0]
 for i in range(4):M[0][i+2]=v[5+i];M[1][i+2]=K.neg[v[1+i]]
 for k,(i,j) in enumerate(pairs):M[i+2][j+2]=v[9+k]
 for i in range(6):
  for j in range(i):M[i][j]=K.neg[M[j][i]]
 return M

def process(l,R,epsilon=0,gamma=None):
 rec=examine(q,l,R,epsilon,gamma,False,F)
 eq=[r[:9]+[r[9+4*i+j] for i,j in pairs] for r in rec['equations']]
 ker=null(K,eq,15)
 graph=[];ranks=collections.Counter()
 for c in proj(q,len(ker)):
  p=mix(K,c,ker);r=rank(K,p_matrix(p));ranks[r]+=1
  if r!=2 or p[0]==0:continue
  p=[K.mul[K.inv[p[0]]][x] for x in p]
  # Pfaffian identity restores all mixed products.
  assert all(K.sub(K.mul[p[1+i]][p[5+j]],K.mul[p[1+j]][p[5+i]])==p[9+k] for k,(i,j) in enumerate(pairs))
  ts=[]
  for cs in [p[1:5],p[5:9]]:
   z=0
   for a,b in zip(cs,rec['reps']):z=F.add(z,F.scale(a,b))
   ts.append(z)
  a3=F.mul(rec['delta'],F.pow(l,3))
  W=rec['W0']+[[a3,0,ts[0]],[0,a3,ts[1]]]
  can=dict(l=l,R=R,epsilon=epsilon,gamma=gamma,ts=ts,W=W,parameter=p[1:9])
  candidates.append(can);graph.append(len(candidates)-1)
 compact={k:rec[k] for k in ['q','polynomial','l','R','epsilon','gamma','delta','reps']}
 compact.update(secant_equations=len(eq),row_rank=rank(K,eq),kernel_basis=ker,alternating_rank_histogram=dict(ranks),graph_candidate_ids=graph)
 records.append(compact);hist[epsilon,len(ker),tuple(sorted(ranks.items())),len(graph)]+=1

for j,l in enumerate(ls):
 for mu in mus:
  if type_of[mu]==type_of[l]:continue
  process(l,[1,mu])
 D=[1,l,F.inv(l)];Q=Quotient(K,[F.digits(x) for x in D],6);qs=[F.pack(x) for x in Q.lift_basis()];assert len(qs)==3
 for c in proj(q,3):
  gamma=0
  for a,b in zip(c,qs):gamma=F.add(gamma,F.scale(a,b))
  process(l,[1,l],1,gamma)
 if (j+1)%4==0:
  print('lambda',j+1,'/',len(ls),'records',len(records),'candidates',len(candidates),'seconds',round(time.time()-start,2),flush=True)
summary={'normalized_degree6_planes':len(ls),'R_types':len(mus),'records':len(records),'epsilon0_records':sum(r['epsilon']==0 for r in records),'epsilon1_records':sum(r['epsilon']==1 for r in records),'candidates':len(candidates),'hist':{str(k):v for k,v in hist.items()},'seconds':time.time()-start}
(Path(__file__).parent/'full_q3_plucker.json').write_text(json.dumps({'summary':summary,'records':records},indent=2)+'\n')
(Path(__file__).parent/'full_q3_candidates.json').write_text(json.dumps(candidates,indent=2)+'\n')
with open(Path(__file__).parent/'full_q3_candidates.txt','w') as out:
 out.write(str(len(candidates))+'\n')
 for c in candidates:out.write(' '.join(map(str,[c['l'],c['epsilon'],c['gamma'] or 0,*sum(c['W'],[])]))+'\n')
print(summary,flush=True)
