from pathlib import Path
import sys,itertools as it,json,time,collections

from cubic_core import analyse
from secant_core import rsub
from exact_check import Field,rank,rref
F=Field(3,[2,1,0,0,0,0,1]);K=F.K;l=144;eb=[1,l,F.mul(l,l)];theta=3
planes=[a for a in range(3,F.Q) if a%3==0 and F.normal(a)==a];types={}
for a in planes:types.setdefault(F.typekey(a),a)
assert len(types)==31
rs=[a for key,a in sorted(types.items()) if key!=F.typekey(l)];assert len(rs)==30
records=[]
for mu in rs:
 X=[[1,0,0],[l,0,1],[0,1,0],[0,l,mu]]
 r=analyse(F,l,X,f'cubic-eps0-R{mu}',True);r['epsilon']=0;r['R_generator']=mu;records.append(r)
X=[[0,0,1]]+[[u,F.pow(u,3),F.mul(theta,F.pow(u,9))] for u in eb]
r=analyse(F,l,X,'cubic-eps1',True);r['epsilon']=1;r['R_generator']=l;records.append(r)
Ds=[]
for D in rsub(K,6,2):
 val=[]
 for c in D:
  a=b=0
  for j,e in enumerate(eb):a=F.add(a,F.scale(c[j],e));b=F.add(b,F.scale(c[j+3],e))
  val.append([a,b])
 if F.mul(val[0][0],val[1][1])!=F.mul(val[0][1],val[1][0]):Ds.append(D)
assert len(Ds)==10647
out=Path(__file__).parent
(out/'cubic_models.json').write_text(json.dumps(records,indent=2)+'\n')
(out/'cubic_projection_planes.json').write_text(json.dumps(Ds,separators=(',',':'))+'\n')
with (out/'cubic_linear_input.txt').open('w') as f:
 f.write(f'{len(records)} {len(Ds)}\n')
 for r in records:
  rr,_=rref(K,r['equations'],45);f.write(f"{r['epsilon']} {r['R_generator']} {len(rr)}\n")
  for row in rr:f.write(' '.join(map(str,row))+'\n')
 for D in Ds:f.write(' '.join(map(str,sum(D,[])))+'\n')
print('complete',len(records),len(Ds),flush=True)
