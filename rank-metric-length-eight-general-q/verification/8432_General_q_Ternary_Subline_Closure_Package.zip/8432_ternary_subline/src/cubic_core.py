import sys,json,itertools as it,time,collections

from secant_core import addv,sm,vec,dot,cross,rsub
from exact_check import Field,rank,rref,null
from subline_linear_check import Quotient,mix,proj

def wedge_matrix(K,p,n=10):
 M=[[0]*n for _ in range(n)]
 for v,(i,j) in zip(p,it.combinations(range(n),2)):M[i][j]=v;M[j][i]=K.neg[v]
 return M

def analyse(F,l,X,label,structured=False):
 K=F.K;W0=X+[sm(F,l,x) for x in X];assert rank(K,[vec(F,w) for w in W0])==8
 Q=Quotient(K,[vec(F,w) for w in W0],18);reps=[[F.pack(a[6*j:6*j+6]) for j in range(3)] for a in Q.lift_basis()];assert len(reps)==10
 if structured:
  E=[1,l,F.mul(l,l)];theta=next(x for x in range(F.q,F.Q) if F.pow(x,F.q**3)!=x)
  H=[[e,0,0] for e in E]+[[0,e,0] for e in E]+[[0,0,e] for e in E]+[[0,0,F.mul(theta,e)] for e in E]
  base=[vec(F,w) for w in W0];inner=[]
  for h in H:
   v=vec(F,h)
   if rank(K,base+[v])>len(base):base.append(v);inner.append(h)
  assert len(inner)==4
  outer=[[F.mul(theta,e),0,0] for e in E]+[[0,F.mul(theta,e),0] for e in E]
  reps=outer+inner
  assert rank(K,[vec(F,w) for w in W0+reps])==18
 eq=[];hist=collections.Counter();norms=set();st=time.time()
 for D in rsub(K,4,2):
  v=[]
  for c in D:
   a=[0]*3
   for t,x in zip(c,X):a=addv(F,a,[F.scale(t,z) for z in x])
   v.append(a)
  n=cross(F,*v);assert any(n);n=sm(F,F.inv(next(x for x in n if x)),n);assert tuple(n) not in norms;norms.add(tuple(n))
  S=[dot(F,n,w) for w in W0];r=rank(K,[F.digits(s) for s in S]);hist[r]+=1
  if r<=3:continue
  assert r==4
  QS=Quotient(K,[F.digits(s) for s in S],6);im=[QS.project(F.digits(dot(F,n,w))) for w in reps]
  eq.append([K.sub(K.mul[im[i][0]][im[j][1]],K.mul[im[i][1]][im[j][0]]) for i,j in it.combinations(range(10),2)])
 ke=null(K,eq,45);print(label,'secant rankhist',hist,'kernel',len(ke),'time',time.time()-st,flush=True)
 rh=collections.Counter();dec=[]
 if len(ke)<=9:
  for c in proj(F.q,len(ke)):
   p=mix(K,c,ke);M=wedge_matrix(K,p);r=rank(K,M);rh[r]+=1
   if r==2:
    bas,_=rref(K,M,10);assert len(bas)==2
    w=[]
    for cc in bas:
     v=[0]*3
     for a,b in zip(cc,reps):v=addv(F,v,[F.scale(a,z) for z in b])
     w.append(v)
    dec.append(W0+w)
 print('rankhist',rh,'decomposable',len(dec),flush=True)
 return dict(label=label,q=F.q,polynomial=F.pol,l=l,X=X,W0=W0,reps=reps,rankhist=dict(hist),equations=eq,kernel=ke,alternating_rankhist=dict(rh),decomposable_W=dec)
