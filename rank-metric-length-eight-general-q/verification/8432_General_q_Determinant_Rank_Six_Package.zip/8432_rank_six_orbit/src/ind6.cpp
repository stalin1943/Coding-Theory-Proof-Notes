#include "poly6.hpp"
#include <numeric>
#include <set>
#include <string>
using V=vector<int>;using VV=vector<V>;
int mod(int x,int p){x%=p;return x<0?x+p:x;}
int inverse(int a,int p){int r=1;for(int n=p-2;n;n>>=1,a=a*a%p)if(n&1)r=r*a%p;return r;}
vector<int> echelon(VV&A,int n,int p){int r=0;vector<int>pv;for(int j=n-1;j>=0;j--){int k=r;while(k<(int)A.size()&&!A[k][j])k++;if(k==(int)A.size())continue;swap(A[k],A[r]);int v=inverse(A[r][j],p);for(int&x:A[r])x=x*v%p;for(int i=0;i<(int)A.size();i++)if(i!=r&&A[i][j]){int c=A[i][j];for(int s=0;s<n;s++)A[i][s]=mod(A[i][s]-c*A[r][s],p);}pv.push_back(j);if(++r==(int)A.size())break;}A.resize(r);return pv;}
VV nullspace(VV A,int n,int p){auto pv=echelon(A,n,p);VV B;for(int j=n-1;j>=0;j--)if(find(pv.begin(),pv.end(),j)==pv.end()){V b(n);b[j]=1;for(unsigned k=0;k<pv.size();k++)b[pv[k]]=mod(-A[k][j],p);B.push_back(b);}return B;}
int egcd(int a,int b,int &x,int&y){if(!b){x=1;y=0;return a;}int u,v,g=egcd(b,a%b,u,v);x=v;y=u-a/b*v;return g;}
struct Small {uint16_t a[3],b[3],c;};struct Triple{int a,b,c;};
int val(const PField&F,Triple t,int x){int q=F.q;int v=F.mul(t.a,F.power(x,q));v=F.add(v,F.mul(t.b,F.power(x,q*q)));v=F.add(v,F.mul(t.c,F.power(x,q*q*q)));v=F.add(v,F.mul(F.power(t.b,q*q*q*q),F.power(x,q*q*q*q)));v=F.add(v,F.mul(F.power(t.a,q*q*q*q*q),F.power(x,q*q*q*q*q)));return v;}
int det6(VV A,int q){int d=1;for(int j=5;j>=0;j--){int k=j;while(k>=0&&!A[k][j])k--;if(k<0)return 0;if(k!=j){swap(A[k],A[j]);d=mod(-d,q);}d=d*A[j][j]%q;int iv=inverse(A[j][j],q);for(int i=0;i<j;i++){int c=A[i][j]*iv%q;for(int z=0;z<j;z++)A[i][z]=mod(A[i][z]-c*A[j][z],q);}}return d;}
VV gram(const PField&F,Triple t){V fb;int p=1;for(int j=0;j<6;j++){fb.push_back(p);p*=F.q;}VV G(6,V(6));for(int j=0;j<6;j++){int y=val(F,t,fb[j]);for(int i=0;i<6;i++)G[i][j]=F.trace(F.mul(fb[i],y));}return G;}
int main(int argc,char**argv){if(argc<3){cerr<<"ind6 q prefix\n";return 2;}int q=stoi(argv[1]);string pref=argv[2];PField F(q);auto start=chrono::steady_clock::now();int Q=F.Q,C=F.C,half=(Q-1)/2,weight=q*q+q+1;
 vector<array<int,3>>orbit;vector<uint8_t>seen(Q);int sextic=0;
 // Generate normalized planes containing 1, then scalar-equivalence orbits of those planes.
 for(int t=Q-1;t>=q;t--)if(F.plane(t)==t&&!seen[t]){vector<int>B;for(int a=0;a<q;a++)for(int b=0;b<q;b++)B.push_back(F.add(a,F.scale(b,t)));vector<int>orb;
  for(int y:B)if(y){for(int x:B){int z=F.mul(x,F.invv[y]);if(z>=q){orb.push_back(F.plane(z));break;}}}
  sort(orb.begin(),orb.end());orb.erase(unique(orb.begin(),orb.end()),orb.end());for(int z:orb){assert(!seen[z]);seen[z]=1;}
  if(F.power(t,q*q)!=t&&F.power(t,q*q*q)!=t){assert(orb.size()==size_t(q+1));orbit.push_back({1,t,F.mul(t,t)});sextic++;}
 }
 assert(sextic==q*q*q+q-1);vector<int>E;for(int a=0;a<Q;a++)if(F.power(a,q*q)==a)E.push_back(a);assert(E.size()==size_t(q*q));int om=*find_if(E.begin(),E.end(),[&](int x){return x>=q;});int xi=q,xi2=F.mul(xi,xi);
 for(int e:E)orbit.push_back({1,om,F.add(xi,F.mul(e,xi2))});orbit.push_back({1,om,xi2});orbit.push_back({1,F.cubic_generator,F.mul(F.cubic_generator,F.cubic_generator)});assert(orbit.size()==size_t(q*q*q+q*q+q+1));
 vector<int>areps,aid(Q,-1);for(int a=Q-1;a>0;a--)if(a<F.negv[a]){aid[a]=areps.size();areps.push_back(a);}assert(areps.size()==size_t(half));for(int a=1;a<Q;a++)aid[a]=aid[min(a,F.negv[a])];
 // Invert the exponent by tabulating all powers rather than modular inverse.
 vector<int>mlog(Q),cm(Q),bc(Q,-1);for(int ue=0;ue<(Q-1)/2;ue++){int u=F.ex[ue],d=F.power(u,q*q+1);for(int j=0;j<2;j++){int b=F.mul(F.ex[j],F.invv[d]);assert(bc[b]<0);bc[b]=j;mlog[b]=F.lg[F.power(u,q+1)];cm[b]=F.cti[F.power(u,q*q*q+1)];assert(cm[b]>=0);}}
 vector<pair<int,int>> ij;for(int i=0;i<6;i++)for(int j=i;j<6;j++)ij.push_back({i,j});V fb(6);fb[0]=1;for(int j=1;j<6;j++)fb[j]=fb[j-1]*q;
 VV producteq(6,V(21));array<array<int,21>,3>frobc{};
 for(int s=0;s<21;s++){auto[i,j]=ij[s];int m=F.mul(fb[i],fb[j]);if(i!=j)m=F.scale(2,m);for(int k=0;k<6;k++)producteq[k][s]=F.digits[m][k];for(int k=1;k<=3;k++){int v=F.mul(fb[i],F.power(fb[j],k==1?q:(k==2?q*q:q*q*q)));if(i!=j)v=F.add(v,F.mul(fb[j],F.power(fb[i],k==1?q:(k==2?q*q:q*q*q))));frobc[k-1][s]=v;}}
 size_t totalclasses=size_t(2)*half*C;vector<uint32_t>counts(totalclasses);uint64_t visited=0,goodtotal=0;vector<uint64_t>goodorbit;
 for(int oi=0;oi<(int)orbit.size();oi++){
  VV rows;for(int s:orbit[oi])rows.push_back(V(F.digits[s].begin(),F.digits[s].end()));VV annih=nullspace(rows,6,q);assert(annih.size()==3);VV M=producteq;
  for(int i=0;i<3;i++)for(int j=i;j<3;j++){V row(21);for(int h=0;h<21;h++){auto[a,b]=ij[h];row[h]=annih[i][a]*annih[j][b]%q;if(a!=b)row[h]=(row[h]+annih[i][b]*annih[j][a])%q;}M.push_back(row);}
  VV kernel=nullspace(M,21,q);assert(kernel.size()==9);vector<Triple>K;
  for(auto&r:kernel){Triple t{0,0,0};int*pp[3]={&t.a,&t.b,&t.c};for(int k=0;k<3;k++)for(int j=0;j<21;j++)if(r[j])*pp[k]=F.add(*pp[k],F.scale(r[j],frobc[k][j]));assert(F.cti[t.c]>=0);t.c=F.cti[t.c];K.push_back(t);}
  vector<Small>kb;for(auto t:K){Small b{};for(int i=0;i<3;i++){b.a[i]=t.a%F.V;t.a/=F.V;b.b[i]=t.b%F.V;t.b/=F.V;}b.c=t.c;kb.push_back(b);}
  uint64_t good=0;int wt=oi+1==(int)orbit.size()?1:weight;
  for(int lead=0;lead<9;lead++){int n=8-lead,NN=1;for(int i=0;i<n;i++)NN*=q;Small s=kb[lead];array<int,8>coeff{};
   for(int code=0;code<NN;code++){
    visited++;int a=s.a[0]+F.V*s.a[1]+F.W*s.a[2],b=s.b[0]+F.V*s.b[1]+F.W*s.b[2];
    if(a&&b){int aa=F.ex[F.lg[a]+mlog[b]],cc=F.cmul[cm[b]*C+s.c];if(aa>F.negv[aa])cc=(q-cc%q)%q+q*((q-(cc/q)%q)%q)+q*q*((q-cc/(q*q))%q);size_t id=(size_t(bc[b])*half+aid[aa])*C+cc;counts[id]+=wt;good++;}
    if(code+1<NN){for(int k=0;k<n;k++){auto&z=kb[lead+1+k];for(int j=0;j<3;j++){s.a[j]=F.sum2[s.a[j]*F.V+z.a[j]];s.b[j]=F.sum2[s.b[j]*F.V+z.b[j]];}s.c=F.cadd[s.c*C+z.c];if(++coeff[k]<q)break;coeff[k]=0;}}
   }
  }
  goodtotal+=good;goodorbit.push_back(good);
  if(oi%10==0||oi+1==(int)orbit.size())cerr<<"ind q="<<q<<" orbit="<<oi+1<<"/"<<orbit.size()<<" seconds="<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"\n";
 }
 map<int,uint64_t>hist;uint64_t mass=0;for(auto&v:counts){assert(v%weight==0);v/=weight;hist[v]++;mass+=v;}
 int maximum=-1;vector<size_t>maxids;uint64_t checks=0;for(size_t id=0;id<totalclasses;id++){int n=counts[id];if(n<maximum)continue;size_t z=id/C;Triple t{areps[z%half],F.ex[z/half],F.ctr[id%C]};int d=det6(gram(F,t),q);checks++;bool split=false;if(d)for(int k=1;k<q;k++)if(k*k%q==mod(-d,q))split=true;if(split){if(n>maximum){maximum=n;maxids.clear();}if(n==maximum)maxids.push_back(id);}}
 ofstream bin(pref+"_counts.bin",ios::binary);bin.write((char*)counts.data(),counts.size()*sizeof(uint32_t));bin.close();ofstream out(pref+".json");out<<"{\"q\":"<<q<<",\"polynomial\":[";for(int i=0;i<7;i++){if(i)out<<",";out<<F.f[i];}out<<"],\"cubic_generator\":"<<F.cubic_generator<<",\"nonsquare\":"<<F.ex[1]<<",\"normal_classes\":"<<totalclasses<<",\"scalar_space_orbits\":"<<orbit.size()<<",\"directions_visited\":"<<visited<<",\"eligible_a_b_nonzero\":"<<goodtotal<<",\"incidence_mass\":"<<mass<<",\"maximum_nondegenerate_split\":"<<maximum<<",\"maxima\":[";bool first=true;for(auto id:maxids){if(!first)out<<",";first=false;size_t z=id/C;out<<"{\"id\":"<<id<<",\"a\":"<<areps[z%half]<<",\"b\":"<<F.ex[z/half]<<",\"c\":"<<F.ctr[id%C]<<"}";}out<<"],\"histogram_all_forms\":{";first=true;for(auto[x,n]:hist){if(!first)out<<",";first=false;out<<"\""<<x<<"\":"<<n;}out<<"},\"rank_checks\":"<<checks<<",\"complete\":true,\"seconds\":"<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"}\n";
 cerr<<"INDEPENDENT COMPLETE q="<<q<<" max="<<maximum<<" maxima="<<maxids.size()<<"\n";
}
