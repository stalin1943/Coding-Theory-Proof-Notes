"""Explicit checks of trace-annihilator invariance and auxiliary code duality.
No exhaustive code classification is claimed; all cases and seeds are recorded.
"""
from pathlib import Path
import sys,json,random,itertools,collections
BASE=Path(__file__).resolve().parents[1]/'vendor'
sys.path.insert(0,str(BASE))
from algebra import Algebra
from tower_arithmetic import projective,rank,rref

def sqrank(A,S):
 F=A.F
 return rank(A.K,[F.digits(F.mul(x,y)) for i,x in enumerate(S) for y in S[i:]])
def perp(A,S):return [r[0] for r in A.kdual([(s,) for s in S],1)]
def can(A,S):return A.kcan([(s,)for s in S])
def dual(A,T):
 R,p=A.rr([list(r)for r in zip(*T)],4);N=[];F=A.F
 for j in range(4):
  if j in p:continue
  row=[0]*4;row[j]=1
  for r,k in zip(R,p):row[k]=F.neg(r[j])
  N.append(row)
 return list(map(tuple,zip(*N)))
def section_data(A,T):
 F=A.F;q=A.q;pts=list(projective(q,4));out=collections.Counter();seen=set()
 for x in pts:
  v=[F.dot(x,[t[j]for t in T])for j in range(2)]
  if not any(v):return None
  key=A.enorm(v)
  if key in seen:return None
  seen.add(key);k=next(i for i,c in enumerate(x)if c)
  S=[A.sub(F.mul(v[0],T[j][1]),F.mul(v[1],T[j][0]))for j in range(4)if j!=k]
  if rank(A.K,[F.digits(s)for s in S])!=3:return None
  out[sqrank(A,S)]+=1
 return dict(sorted(out.items()))
def intersect_dim(A,T,S):
 F=A.F;fb=[F.from_digits([int(i==j)for i in range(6)])for j in range(6)]
 C=[[F.mul(x,t[j]) for t in T]for j in range(2)for x in fb]
 W=[]
 for j in range(4):
  for s in S:
   v=[0]*4;v[j]=s;W.append(v)
 assert A.kspan_rank(C)==12 and A.kspan_rank(W)==12
 return 24-A.kspan_rank(C+W)
def main():
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
 spaces=[];sections=[];intersections=0;point_checks=0
 for q in [2,3,4,5,7]:
  A=Algebra(q);F=A.F;rng=random.Random(60918000+q)
  # The first two are the subfield and quadratic-line strata. The rest include
  # sextic geometric-progressions and arbitrary three-spaces.
  Slist=[[1,q,q*q],[1,F.mu,q]]
  t=next(t for t in range(q,F.Q)if F.pow(t,q*q)!=t and F.pow(t,q**3)!=t)
  Slist.append([1,t,F.mul(t,t)])
  while len(Slist)<15:
   S=[rng.randrange(1,F.Q)for _ in range(3)]
   if rank(A.K,[F.digits(s)for s in S])==3:Slist.append(S)
  for S in Slist:
   P=perp(A,S);sr=sqrank(A,S);pr=sqrank(A,P);assert sr==pr
   if sr<6:
    products=[F.mul(x,y)for i,x in enumerate(S)for y in S[i:]]
    annih=perp(A,products);assert annih
    a=annih[0];assert can(A,[F.mul(a,s)for s in S])==can(A,P)
   spaces.append(dict(q=q,basis=S,trace_dual=P,square_rank=sr))
  chosen=[];tries=0
  while len(chosen)<5:
   tries+=1
   T=[(1,0),(0,1)]+[(rng.randrange(F.Q),rng.randrange(F.Q))for _ in range(2)]
   first=section_data(A,T)
   if first is None:continue
   TD=dual(A,T);second=section_data(A,TD);assert second==first
   p=[A.sub(F.mul(T[i][0],T[j][1]),F.mul(T[i][1],T[j][0]))for i in range(4)for j in range(i+1,4)]
   for S in Slist[:5]:
    assert intersect_dim(A,T,S)==intersect_dim(A,TD,perp(A,S));intersections+=1
   chosen.append(T);point_checks+=2*sum(q**i for i in range(4))
   sections.append(dict(q=q,section=T,dual_section=TD,determinant_rank=rank(A.K,[F.digits(x)for x in p]),square_histogram=first))
  print('duality q',q,'spaces',len(Slist),'sections',len(chosen),flush=True)
 out=dict(status='passed',scope='fixed-seed explicit cases, not exhaustive code classification',scalar_space_cases=len(spaces),section_pairs=len(sections),both_family_projective_point_checks=point_checks,trace_code_intersection_equalities=intersections,spaces=spaces,sections=sections)
 args.output.write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__':main()
