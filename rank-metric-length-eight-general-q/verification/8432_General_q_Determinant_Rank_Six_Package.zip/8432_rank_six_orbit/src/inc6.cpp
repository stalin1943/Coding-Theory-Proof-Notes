#include "prime_tower.hpp"
#include <functional>
#include <numeric>
#include <set>
#include <cstring>
using Row=vector<int>;using Rows=vector<Row>;
int md(int x,int q){x%=q;return x<0?x+q:x;}
int ki(int x,int q){for(int t=1;t<q;t++)if(t*x%q==1)return t;assert(false);return 0;}
vector<int> rr(Rows &M,int n,int q){int r=0;vector<int>p;for(int j=0;j<n;j++){int k=r;while(k<(int)M.size()&&!M[k][j])k++;if(k==(int)M.size())continue;swap(M[r],M[k]);int v=ki(M[r][j],q);for(int &x:M[r])x=x*v%q;for(int i=0;i<(int)M.size();i++)if(i!=r&&M[i][j]){int c=M[i][j];for(int z=0;z<n;z++)M[i][z]=md(M[i][z]-c*M[r][z],q);}p.push_back(j);if(++r==(int)M.size())break;}M.resize(r);return p;}
Rows ns(Rows M,int n,int q){auto p=rr(M,n,q);Rows N;for(int j=0;j<n;j++)if(find(p.begin(),p.end(),j)==p.end()){Row x(n);x[j]=1;for(unsigned i=0;i<p.size();i++)x[p[i]]=md(-M[i][j],q);N.push_back(x);}rr(N,n,q);return N;}
int tr(const Field&F,int x){int s=0;for(int i=0;i<6;i++){s=F.add(s,x);x=F.frob[x];}assert(s<F.q);return s;}
int from(const Row&c,int q){int x=0,p=1;for(int a:c){x+=a*p;p*=q;}return x;}
struct Tuple {int a,b,c;};
struct Block {uint16_t a0,a1,b0,b1,c;};
struct Orbit {array<int,3>S;int stabilizer_degree;string kind;};
int evalL(const Field&F,Tuple t,int x){int q=F.q;int y=F.mul(t.a,F.pow(x,q));y=F.add(y,F.mul(t.b,F.pow(x,q*q)));y=F.add(y,F.mul(t.c,F.pow(x,q*q*q)));y=F.add(y,F.mul(F.pow(t.b,q*q*q*q),F.pow(x,q*q*q*q)));y=F.add(y,F.mul(F.pow(t.a,q*q*q*q*q),F.pow(x,q*q*q*q*q)));return y;}
Rows gramL(const Field&F,Tuple t){Rows G(6,Row(6));int x=1;for(int j=0;j<6;j++,x*=F.q){int y=evalL(F,t,x),z=1;for(int i=0;i<6;i++,z*=F.q)G[i][j]=tr(F,F.mul(z,y));}for(int i=0;i<6;i++)for(int j=0;j<6;j++)assert(G[i][j]==G[j][i]);return G;}
int det(Rows M,int q){int d=1,n=M.size();for(int j=0;j<n;j++){int k=j;while(k<n&&!M[k][j])k++;if(k==n)return 0;if(k!=j){swap(M[k],M[j]);d=md(-d,q);}int a=M[j][j];d=d*a%q;int inv=ki(a,q);for(int i=j+1;i<n;i++){int c=M[i][j]*inv%q;for(int l=j+1;l<n;l++)M[i][l]=md(M[i][l]-c*M[j][l],q);}}return d;}
bool issquare(int a,int q){for(int i=1;i<q;i++)if(i*i%q==a)return true;return false;}
int64_t egcd(int64_t a,int64_t b,int64_t&x,int64_t&y){if(!b){x=1;y=0;return a;}int64_t u,v,g=egcd(b,a%b,u,v);x=v;y=u-(a/b)*v;return g;}
int main(int argc,char**argv){if(argc<3){cerr<<"usage: inc6 q output_prefix [orbit_limit]\n";return 2;}int q=stoi(argv[1]);Field F(q);int L=F.L,Q=F.Q;string prefix=argv[2];int limit=argc>3?stoi(argv[3]):99999;
 auto start=chrono::steady_clock::now();vector<int> fb(6);fb[0]=1;for(int i=1;i<6;i++)fb[i]=fb[i-1]*q;
 vector<Orbit> orbits;vector<uint8_t>seen(Q);int nsex=0;
 for(int t=q;t<Q;t++)if(!seen[t]&&F.pow(t,q*q)!=t&&F.pow(t,q*q*q)!=t){int marked=0;for(int a=0;a<q;a++)for(int b=0;b<q;b++)for(int c=0;c<q;c++)for(int d=0;d<q;d++)if(md(a*d-b*c,q)){int den=F.add(c,F.scale(d,t));assert(den);int z=F.mul(F.add(a,F.scale(b,t)),F.iv[den]);if(!seen[z]){seen[z]=1;marked++;}}assert(marked==q*(q*q-1));orbits.push_back({{1,t,F.mul(t,t)},1,"sextic"});nsex++;}
 assert(nsex==q*q*q+q-1);int omega=L,xi=q;
 for(int e0=0;e0<q;e0++)for(int e1=0;e1<q;e1++){int e=e0+L*e1;orbits.push_back({{1,omega,F.add(xi,F.mul(e,F.mul(xi,xi)))},1,"quadratic_line"});}
 orbits.push_back({{1,omega,F.mul(xi,xi)},1,"quadratic_line"});
 orbits.push_back({{1,xi,F.mul(xi,xi)},3,"cubic"});assert(orbits.size()==size_t(q*q*q+q*q+q+1));
 int half=(Q-1)/2;vector<int>aid(Q,-1),arep;for(int a=1;a<Q;a++)if(a<F.neg(a)){aid[a]=arep.size();arep.push_back(a);}assert(arep.size()==size_t(half));for(int a=1;a<Q;a++)aid[a]=aid[min(a,F.neg(a))];
 // Exact normalization: b is one of the two square-class representatives;
 // projective scaling leaves only simultaneous (a,c)->(-a,-c).
 vector<int>amulLog(Q),cmul(Q),bc(Q);int64_t inv,zz;assert(egcd((q*q+1)/2,(Q-1)/2,inv,zz)==1);int modn=(Q-1)/2;inv=(inv%modn+modn)%modn;
 for(int b=1;b<Q;b++){int e=F.lg[b],j=e&1;bc[b]=j;int64_t u=((int64_t)(j-e)/2*inv)%modn;if(u<0)u+=modn;amulLog[b]=(int64_t)(q+1)*u%(Q-1);cmul[b]=F.ex[(int64_t)(q*q*q+1)*u%(Q-1)];assert(cmul[b]<L);assert(F.mul(b,F.pow(F.ex[u],q*q+1))==F.ex[j]);}
 size_t NN=size_t(2)*half*L;vector<uint32_t>cnt(NN);int weight=q*q+q+1;uint64_t visited=0,eligible=0;uint64_t perorbit=0;
 ofstream orbout(prefix+"_orbits.txt");for(auto&o:orbits){orbout<<o.kind<<' '<<o.stabilizer_degree;for(int s:o.S)orbout<<' '<<s;orbout<<'\n';}orbout.close();
 vector<array<int,6>>rankhist;vector<uint64_t>goodbyorbit;
 for(int oi=0;oi<(int)orbits.size()&&oi<limit;oi++){
  auto o=orbits[oi];Rows M(3,Row(6));for(int i=0;i<3;i++)for(int j=0;j<6;j++)M[i][j]=tr(F,F.mul(o.S[i],fb[j]));Rows R=ns(M,6,q);assert(R.size()==3);array<int,3>rf;for(int i=0;i<3;i++)rf[i]=from(R[i],q);
  Rows equations(6,Row(15));int k=0;for(int i=0;i<3;i++)for(int j=i;j<3;j++,k++)for(int m=0;m<15;m++){Tuple t={0,0,0};if(m<6)t.a=fb[m];else if(m<12)t.b=fb[m-6];else t.c=fb[m-12];equations[k][m]=tr(F,F.mul(rf[i],evalL(F,t,rf[j])));}
  Rows ker=ns(equations,15,q);assert(ker.size()==9);vector<Tuple>K;for(auto&r:ker)K.push_back({from(Row(r.begin(),r.begin()+6),q),from(Row(r.begin()+6,r.begin()+12),q),from(Row(r.begin()+12,r.end()),q)});
  uint64_t seenhere=0,good=0;int wt=o.stabilizer_degree==3?1:weight;
  for(int lead=0;lead<9;lead++){
   int n=8-lead,n0=n/2,n1=n-n0;int s0=1,s1=1;for(int k=0;k<n0;k++)s0*=q;for(int k=0;k<n1;k++)s1*=q;
   vector<Block>A(s0),B(s1);
   for(int side=0;side<2;side++){int sz=side?s1:s0,nn=side?n1:n0,first=lead+1+(side?n0:0);auto&V=side?B:A;
    for(int code=0;code<sz;code++){int cc=code;Tuple t=side?Tuple{0,0,0}:K[lead];for(int j=0;j<nn;j++){int c=cc%q;cc/=q;if(c){t.a=F.add(t.a,F.scale(c,K[first+j].a));t.b=F.add(t.b,F.scale(c,K[first+j].b));t.c=F.add(t.c,F.scale(c,K[first+j].c));}}V[code]={(uint16_t)(t.a%L),(uint16_t)(t.a/L),(uint16_t)(t.b%L),(uint16_t)(t.b/L),(uint16_t)t.c};}
   }
   const int*la=F.la.data();const int*lm=F.lm.data();const int*ex=F.ex.data();const int*lg=F.lg.data();
   for(auto&x:A)for(auto&y:B){seenhere++;int a=la[x.a0*L+y.a0]+L*la[x.a1*L+y.a1];if(!a)continue;int b=la[x.b0*L+y.b0]+L*la[x.b1*L+y.b1];if(!b)continue;int c=la[x.c*L+y.c];int an=ex[lg[a]+amulLog[b]],cn=lm[cmul[b]*L+c];if(an>F.neg(an))cn=F.ln[cn];size_t id=(size_t(bc[b])*half+aid[an])*L+cn;cnt[id]+=wt;good++;}
  }
  if(!perorbit)perorbit=seenhere;assert(seenhere==perorbit);visited+=seenhere;eligible+=good;goodbyorbit.push_back(good);
  if(oi%10==0||oi+1==(int)orbits.size())cerr<<"q="<<q<<" orbit="<<oi+1<<"/"<<orbits.size()<<" eligible="<<eligible<<" secs="<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"\n";
 }
 bool complete=limit>=(int)orbits.size();if(!complete){cerr<<"PARTIAL RUN ONLY\n";return 0;}
 map<int,uint64_t>allhist;uint64_t sum=0;for(auto &x:cnt){assert(x%weight==0);x/=weight;allhist[x]++;sum+=x;}
 int maxsplit=-1,maxall=0;vector<size_t>maxids;uint64_t tested=0;map<int,uint64_t>highsing;
 for(size_t id=0;id<NN;id++){int value=cnt[id];maxall=max(maxall,value);if(value<maxsplit)continue;int cn=id%L;size_t qid=id/L;int aa=arep[qid%half],bb=F.ex[qid/half];int dt=det(gramL(F,{aa,bb,cn}),q);tested++;
  if(dt&&issquare(md(-dt,q),q)){if(value>maxsplit){maxsplit=value;maxids.clear();}if(value==maxsplit)maxids.push_back(id);}else highsing[value]++;
 }
 ofstream bin(prefix+"_counts.bin",ios::binary);bin.write((char*)cnt.data(),cnt.size()*sizeof(uint32_t));bin.close();
 ofstream out(prefix+".json");out<<"{\n\"q\":"<<q<<",\"cubic\":[1,0,"<<F.c2<<",1],\"quadratic_nu\":"<<F.nu<<",\"nonsquare\":"<<F.ex[1]<<",\"normal_classes\":"<<NN<<",\"scalar_space_orbits\":"<<orbits.size()<<",\"ordinary_space_orbits\":"<<orbits.size()-1<<",\"projective_kernel_directions_per_orbit\":"<<perorbit<<",\"directions_visited\":"<<visited<<",\"eligible_a_b_nonzero\":"<<eligible<<",\"weighted_count_divisor\":"<<weight<<",\"incidence_mass\":"<<sum<<",\"maximum_all_forms\":"<<maxall<<",\"maximum_nondegenerate_split\":"<<maxsplit<<",\"rank_tests_for_upper_bound\":"<<tested<<",\"maxima\":[";
 bool first=true;for(size_t id:maxids){if(!first)out<<",";first=false;int cn=id%L;size_t qid=id/L;out<<"{\"id\":"<<id<<",\"a\":"<<arep[qid%half]<<",\"b\":"<<F.ex[qid/half]<<",\"c\":"<<cn<<"}";}
 out<<"],\"histogram_all_forms\":{";first=true;for(auto[z,n]:allhist){if(!first)out<<",";first=false;out<<"\""<<z<<"\":"<<n;}out<<"},\"eligible_by_orbit\":[";first=true;for(auto n:goodbyorbit){if(!first)out<<",";first=false;out<<n;}out<<"],\"complete\":true,\"seconds\":"<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"}\n";
 cerr<<"COMPLETE q="<<q<<" maxsplit="<<maxsplit<<" maxall="<<maxall<<" maxima="<<maxids.size()<<" secs="<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"\n";
 return 0;
}
