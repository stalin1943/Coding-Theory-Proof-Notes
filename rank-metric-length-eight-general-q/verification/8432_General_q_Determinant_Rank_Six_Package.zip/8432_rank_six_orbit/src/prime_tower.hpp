// Extracted finite-field arithmetic from the uploaded rank-four package.
#pragma once
#include <algorithm>
#include <array>
#include <cassert>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <string>
#include <vector>
using namespace std;
struct Field {
 int q,L,Q,nu,c2; vector<int>la,lm,ln,ex,lg,iv,frob,sc; vector<array<uint8_t,6>>dig;
 int laddraw(int a,int b){int r=0,p=1;for(int i=0;i<3;i++){r+=((a%q+b%q)%q)*p;a/=q;b/=q;p*=q;}return r;}
 int lmulraw(int a,int b){int aa[3],bb[3],c[5]={};for(int i=0;i<3;i++){aa[i]=a%q;bb[i]=b%q;a/=q;b/=q;}for(int i=0;i<3;i++)for(int j=0;j<3;j++)c[i+j]=(c[i+j]+aa[i]*bb[j])%q;for(int i=4;i>=3;i--){int z=c[i];c[i-3]=(c[i-3]-z+q*q)%q;c[i-1]=(c[i-1]-z*c2+q*q)%q;}return c[0]+q*c[1]+q*q*c[2];}
 int add(int a,int b)const{return la[(a%L)*L+b%L]+L*la[(a/L)*L+b/L];}
 int neg(int a)const{return ln[a%L]+L*ln[a/L];}
 int sub(int a,int b)const{return add(a,neg(b));}
 int rawmul(int a,int b)const{int x=a%L,y=a/L,z=b%L,w=b/L;int yw=lm[y*L+w];return la[lm[x*L+z]*L+lm[nu*L+yw]]+L*la[lm[x*L+w]*L+lm[y*L+z]];}
 int powraw(int a,int n)const{int v=1;for(;n;n>>=1,a=rawmul(a,a))if(n&1)v=rawmul(v,a);return v;}
 int mul(int a,int b)const{return a&&b?ex[lg[a]+lg[b]]:0;}
 int pow(int a,int n)const{if(!a)return n?0:1;return ex[(int)((int64_t)lg[a]*n%(Q-1))];}
 int scale(int c,int a)const{return sc[c*Q+a];}
 explicit Field(int p):q(p),L(p*p*p),Q(L*L),la(L*L),lm(L*L),ln(L),ex(2*(Q-1)),lg(Q),iv(Q),frob(Q),sc(q*Q),dig(Q){
  assert(q==3||q==5||q==7);c2=0;for(int a2=0;a2<q;a2++){bool root=false;for(int x=0;x<q;x++)if((1+a2*x*x+x*x*x)%q==0)root=true;if(!root){c2=a2;break;}}
  assert(c2>0);nu=1;for(int n=2;n<q;n++){bool sq=false;for(int a=0;a<q;a++)if(a*a%q==n)sq=true;if(!sq){nu=n;break;}}
  for(int a=0;a<L;a++){int x=a,r=0,w=1;for(int i=0;i<3;i++){r+=((q-x%q)%q)*w;x/=q;w*=q;}ln[a]=r;for(int b=0;b<L;b++){la[a*L+b]=laddraw(a,b);lm[a*L+b]=lmulraw(a,b);}}
  vector<int>factors;int n=Q-1;for(int p0=2;p0*p0<=n;p0++)if(n%p0==0){factors.push_back(p0);while(n%p0==0)n/=p0;}if(n>1)factors.push_back(n);
  int gen=0;for(int a=2;a<Q;a++){bool ok=true;for(int p0:factors)if(powraw(a,(Q-1)/p0)==1)ok=false;if(ok){gen=a;break;}}assert(gen);
  int z=1;vector<bool>seen(Q);for(int i=0;i<Q-1;i++){assert(z&&!seen[z]);seen[z]=true;ex[i]=ex[i+Q-1]=z;lg[z]=i;z=rawmul(z,gen);}assert(z==1);
  for(int a=0;a<Q;a++){int x=a;for(int j=0;j<6;j++){dig[a][j]=x%q;x/=q;}frob[a]=pow(a,q);if(a){iv[a]=pow(a,Q-2);assert(rawmul(a,iv[a])==1);}for(int c=0;c<q;c++)sc[c*Q+a]=rawmul(c,a);}
  cerr<<"field q="<<q<<" cubic=[1,0,"<<c2<<",1], omega2="<<nu<<", generator="<<gen<<"\n";
 }
 int rank(const vector<int>&v)const{array<array<int,6>,6>b{};int r=0;for(int z:v){array<int,6>x;for(int i=0;i<6;i++)x[i]=dig[z][i];for(int k=0;k<6;k++){if(!x[k])continue;if(b[k][k]){int s=x[k];for(int j=k;j<6;j++)x[j]=(x[j]-s*b[k][j]+q*q)%q;}else{int inv=1;while(inv*x[k]%q!=1)inv++;for(int j=k;j<6;j++)b[k][j]=x[j]*inv%q;r++;break;}}}return r;}
 int sr(int a,int b,int c)const{return rank({mul(a,a),mul(a,b),mul(a,c),mul(b,b),mul(b,c),mul(c,c)});}
};
