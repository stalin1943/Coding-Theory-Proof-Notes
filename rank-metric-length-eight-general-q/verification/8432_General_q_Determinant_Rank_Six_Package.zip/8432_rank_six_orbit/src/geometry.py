from pathlib import Path
import sys,json,itertools,collections
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'vendor'))
from algebra import Algebra
from tower_arithmetic import rref,rank,projective

def mm(A,B,q):return [[sum(x*y for x,y in zip(r,c))%q for c in zip(*B)]for r in A]
def ns(K,A,n):
 R,p=rref(K,A,n);out=[]
 for j in range(n):
  if j not in p:
   v=[0]*n;v[j]=1
   for row,k in zip(R,p):v[k]=K.neg[row[j]]
   out.append(v)
 return out

def inv(K,M):
 n=len(M);R,p=rref(K,[list(r)+[int(i==j)for j in range(n)]for i,r in enumerate(M)],2*n)
 assert p[:n]==list(range(n));return [r[n:]for r in R]
def bil(R,x,y,q):return sum(x[i]*R[i][j]*y[j]for i in range(len(x))for j in range(len(y)))%q

def witt(K,R):
 n=len(R);q=K.q
 if not n:return []
 e=next(list(x)for x in projective(q,n)if bil(R,x,x,q)==0)
 j=next(i for i in range(n)if sum(e[k]*R[k][i]for k in range(n))%q)
 f=[0]*n;f[j]=K.inv[sum(e[k]*R[k][j]for k in range(n))%q]
 s=bil(R,f,f,q)*K.inv[2]%q;f=[(x-s*y)%q for x,y in zip(f,e)]
 C=ns(K,mm([e,f],R,q),n)
 if n==2:return [e,f]
 R1=mm(mm(C,R,q),list(zip(*C)),q)
 return [e,f]+mm(witt(K,R1),C,q)

def op(F,t,x):
 a,b,c=t;q=F.q
 co=[0,a,b,c,F.pow(b,q**4),F.pow(a,q**5)]
 return F.dot(co,[F.pow(x,q**j)for j in range(6)])
def coeff(A,T):
 F=A.F;q=A.q
 p=[A.sub(F.mul(T[i][0],T[j][1]),F.mul(T[i][1],T[j][0]))for i in range(4)for j in range(i+1,4)]
 ix=[5,4,3,2,1,0];sg=[1,-1,1,1,-1,1]
 co=[F.dot(p,[(F.pow(p[ix[i]],q**k)if sg[i]==1 else F.neg(F.pow(p[ix[i]],q**k)))for i in range(6)])for k in range(6)]
 assert co[0]==0
 return co[1:4]
def canonical(A,t):
 F=A.F;q=A.q;Q=F.Q;N=Q-1
 # Keep canonical use actual primitive element saved by C++; find it by the same
 # deterministic field property, not a supplied log table.
 factors=[];n=N;p=2
 while p*p<=n:
  if n%p==0:
   factors.append(p)
   while n%p==0:n//=p
  p+=1
 if n>1:factors.append(n)
 gen=next(g for g in range(2,Q)if all(F.pow(g,N//p)!=1 for p in factors))
 ex=[];logs={};z=1
 for i in range(N):ex.append(z);logs[z]=i;z=F.mul(z,gen)
 a,b,c=t;e=logs[b];j=e%2;u_exp=((j-e)//2*pow((q*q+1)//2,-1,N//2))%(N//2);u=ex[u_exp]
 an=F.mul(a,F.pow(u,q+1));cn=F.mul(c,F.pow(u,q**3+1));bn=ex[j]
 if an>F.neg(an):an=F.neg(an);cn=F.neg(cn)
 reps=[x for x in range(1,Q)if x<F.neg(x)];index={x:i for i,x in enumerate(reps)}
 return ((j*len(reps)+index[an])*q**3+cn,(an,bn,cn))
def reconstruct(A,t):
 F=A.F;q=A.q;K=A.K;fb=[q**j for j in range(6)]
 GM=[[F.trace(F.mul(x,y))for y in fb]for x in fb]
 M=list(map(list,zip(*[list(F.digits(op(F,t,x)))for x in fb])))
 Theta=mm(M,inv(K,GM),q)
 assert Theta==list(map(list,zip(*Theta)))
 P=witt(K,Theta);H=mm(mm(P,Theta,q),list(zip(*P)),q)
 H0=[[0]*6 for _ in range(6)]
 for i in [0,2,4]:H0[i][i+1]=H0[i+1][i]=1
 assert H==H0
 C=[[0]*6 for _ in range(6)]
 for i,j,s in [(0,0,1),(1,5,1),(2,1,1),(3,4,-1),(4,2,1),(5,3,1)]:C[i][j]=s%q
 B=mm(inv(K,P),C,q)
 p=[F.from_digits([B[i][j]for i in range(6)])for j in range(6)]
 assert F.add(A.sub(F.mul(p[0],p[5]),F.mul(p[1],p[4])),F.mul(p[2],p[3]))==0
 pm=[[0]*4 for _ in range(4)];k=0
 for i in range(4):
  for j in range(i+1,4):pm[i][j]=p[k];pm[j][i]=F.neg(p[k]);k+=1
 i,j=next((i,j)for i in range(4)for j in range(i+1,4)if pm[i][j]);iv=F.inv(pm[i][j])
 T=[(F.neg(F.mul(pm[j][k],iv)),pm[i][k])for k in range(4)]
 assert coeff(A,T)==list(t)
 return T,Theta,B

def dual(A,T):
 G=[list(v)for v in zip(*T)];R,p=A.rr(G,4);rows=[];F=A.F
 for j in range(4):
  if j not in p:
   v=[0]*4;v[j]=1
   for row,k in zip(R,p):v[k]=F.neg(row[j])
   rows.append(v)
 return [tuple(v)for v in zip(*rows)]
def count(A,T):
 F=A.F;K=A.K;q=A.q;out=[];hist=collections.Counter()
 for c in projective(q,4):
  P=[F.dot(c,[t[i]for t in T])for i in range(2)];pivot=next(j for j,x in enumerate(c)if x)
  S=[A.sub(F.mul(P[0],T[j][1]),F.mul(P[1],T[j][0]))for j in range(4)if j!=pivot]
  assert rank(K,[list(F.digits(x))for x in S])==3
  sr=rank(K,[list(F.digits(F.mul(x,y)))for i,x in enumerate(S)for y in S[i:]])
  hist[sr]+=1
  if sr<6:out.append(list(c))
 return dict(count=len(out),histogram=dict(hist),zero_points=out)
def main():
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path,required=True);args=ap.parse_args()
 base=args.work;out=[]
 for q in [3,5,7]:
  name=base/f'inc{q}.json'
  if not name.exists():continue
  data=json.loads(name.read_text());A=Algebra(q)
  for rec in data['maxima']:
   T,Theta,B=reconstruct(A,(rec['a'],rec['b'],rec['c']));TS=dual(A,T)
   c=count(A,T);d=count(A,TS)
   assert c['count']+d['count']==data['maximum_nondegenerate_split']
   assert c['histogram']==d['histogram']
   out.append(dict(q=q,id=rec['id'],a=rec['a'],b=rec['b'],c=rec['c'],section=T,dual_section=TS,Theta=Theta,B=B,first=c,second=d))
   print(q,rec['id'],c['count'],d['count'],flush=True)
 (base/'geometry_maxima.json').write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__':main()
