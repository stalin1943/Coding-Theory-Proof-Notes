#include "prime_tower.hpp"
#include "poly6.hpp"
#include <numeric>
int main(int argc,char**argv){if(argc!=5){cerr<<"compare6 q primary_counts independent_counts output\n";return 2;}int q=stoi(argv[1]);Field F(q);PField G(q);int Q=F.Q,C=F.L,half=(Q-1)/2;size_t N=size_t(2)*half*C;vector<uint32_t>a(N),b(N);ifstream ia(argv[2],ios::binary),ib(argv[3],ios::binary);ia.read((char*)a.data(),4*N);ib.read((char*)b.data(),4*N);assert(ia.gcount()==int64_t(4*N)&&ib.gcount()==int64_t(4*N));
 // The displayed alternative polynomial is bound to the primary generator xi+omega.
 int theta=F.add(q,C);vector<int>basis(6);basis[0]=1;for(int i=1;i<6;i++)basis[i]=F.mul(basis[i-1],theta);int val=1;for(int i=5;i>=0;i--)val=F.add(F.mul(val,theta),G.f[i]);assert(val==0);
 vector<int>hom(Q),rev(Q,-1);for(int x=0;x<Q;x++){int z=0;for(int i=0;i<6;i++)if(G.digits[x][i])z=F.add(z,F.scale(G.digits[x][i],basis[i]));hom[x]=z;assert(rev[z]<0);rev[z]=x;}for(int x=0;x<Q;x++){assert(hom[G.powq[x]]==F.frob[hom[x]]);assert(hom[G.mul(x,q)]==F.mul(hom[x],theta));}
 vector<int>pra,altidx(Q,-1);for(int x=1;x<Q;x++)if(x<F.neg(x))pra.push_back(x);int n=0;for(int x=Q-1;x>0;x--)if(x<G.negv[x])altidx[x]=n++;assert(n==half);
 vector<int>ml(Q),cm(Q),cl(Q,-1);for(int ue=0;ue<(Q-1)/2;ue++){int u=G.ex[ue],d=G.power(u,q*q+1);for(int j=0;j<2;j++){int z=G.mul(G.ex[j],G.invv[d]);assert(cl[z]<0);cl[z]=j;ml[z]=G.lg[G.power(u,q+1)];cm[z]=G.cti[G.power(u,q*q*q+1)];}}
 vector<uint8_t>seen(N);uint64_t sum=0;for(int bc=0;bc<2;bc++){int bb=rev[F.ex[bc]];vector<int>cmap(C);for(int c=0;c<C;c++){int y=G.cti[rev[c]];assert(y>=0);cmap[c]=G.cmul[cm[bb]*C+y];}for(int ai=0;ai<half;ai++){int aa=rev[pra[ai]];aa=G.ex[G.lg[aa]+ml[bb]];bool sign=aa>G.negv[aa];if(sign)aa=G.negv[aa];int ti=altidx[aa];assert(ti>=0);for(int c=0;c<C;c++){int cc=cmap[c];if(sign)cc=(q-cc%q)%q+q*((q-(cc/q)%q)%q)+q*q*((q-cc/(q*q))%q);size_t pi=(size_t(bc)*half+ai)*C+c,ii=(size_t(cl[bb])*half+ti)*C+cc;assert(!seen[ii]);seen[ii]=1;if(a[pi]!=b[ii]){cerr<<"MISMATCH "<<pi<<" "<<ii<<" "<<a[pi]<<" "<<b[ii]<<"\n";return 1;}sum+=a[pi];}}}
 ofstream out(argv[4]);out<<"{\"q\":"<<q<<",\"classes_compared\":"<<N<<",\"map_bijective\":true,\"all_counts_equal\":true,\"incidence_mass\":"<<sum<<",\"alternative_generator_in_primary\":"<<theta<<"}\n";cerr<<"ALL MATCH q="<<q<<" classes="<<N<<"\n";
}
