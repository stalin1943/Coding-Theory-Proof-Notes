#pragma once
#include <algorithm>
#include <array>
#include <cassert>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <vector>
using namespace std;
struct PField {
 int q,Q,C,V,W;array<int,7>f;vector<array<uint8_t,6>>digits;vector<int> ex,lg,negv,invv,powq,asc;vector<int>sum2;vector<int>ctr,cti,cmul,cadd;int cubic_generator;
 int rawadd(int a,int b)const{int r=0,p=1;for(int j=0;j<6;j++){r+=(a%q+b%q)%q*p;a/=q;b/=q;p*=q;}return r;}
 int rawscale(int c,int a)const{int r=0,p=1;for(int j=0;j<6;j++){r+=c*(a%q)%q*p;a/=q;p*=q;}return r;}
 int rawmul(int a,int b)const{int v[11]={};for(int i=0;i<6;i++)for(int j=0;j<6;j++)v[i+j]+=digits[a][i]*digits[b][j];for(int i=10;i>=6;i--){int z=((v[i]%q)+q)%q;for(int j=0;j<6;j++)v[i-6+j]-=z*f[j];}int r=0,p=1;for(int j=0;j<6;j++){r+=((v[j]%q)+q)%q*p;p*=q;}return r;}
 int rawpow(int a,int n)const{int r=1;while(n){if(n&1)r=rawmul(r,a);a=rawmul(a,a);n>>=1;}return r;}
 int add(int a,int b)const{return sum2[(a%V)*V+b%V]+V*sum2[((a/V)%V)*V+(b/V)%V]+W*sum2[(a/W)*V+b/W];}
 int mul(int a,int b)const{return a&&b?ex[lg[a]+lg[b]]:0;}
 int scale(int c,int a)const{return asc[c*Q+a];}
 int power(int a,int n)const{if(!a)return n?0:1;return ex[int(int64_t(lg[a])*n%(Q-1))];}
 int trace(int a)const{int r=0;for(int i=0;i<6;i++){r=add(r,a);a=powq[a];}assert(r<q);return r;}
 int normal(int x)const{if(!x)return 0;int j=5;while(!digits[x][j])j--;int c=digits[x][j],iv=1;while(c*iv%q!=1)iv++;return scale(iv,x);}
 int plane(int x)const{return normal(x-x%q);}
 explicit PField(int p):q(p),Q(1),C(p*p*p),V(p*p),W(p*p*p*p){
  for(int i=0;i<6;i++)Q*=q;assert(q==3||q==5||q==7);if(q==3)f={2,1,0,1,1,1,1};if(q==5)f={1,0,0,4,0,2,1};if(q==7)f={3,1,2,4,6,2,1};digits.resize(Q);for(int a=0;a<Q;a++){int x=a;for(int j=0;j<6;j++){digits[a][j]=x%q;x/=q;}}
  sum2.resize(V*V);for(int a=0;a<V;a++)for(int b=0;b<V;b++)sum2[a*V+b]=(a%q+b%q)%q+q*((a/q+b/q)%q);
  asc.resize(q*Q);negv.resize(Q);for(int a=0;a<Q;a++){negv[a]=rawscale(q-1,a);for(int c=0;c<q;c++)asc[c*Q+a]=rawscale(c,a);}
  vector<int>div;int n=Q-1;for(int t=2;t*t<=n;t++)if(n%t==0){div.push_back(t);while(n%t==0)n/=t;}if(n>1)div.push_back(n);
  int gen=0;for(int a=q;a<Q;a++){bool ok=true;for(int d:div)if(rawpow(a,(Q-1)/d)==1)ok=false;if(ok){gen=a;break;}}assert(gen);ex.resize(2*(Q-1));lg.resize(Q);invv.resize(Q);powq.resize(Q);vector<uint8_t>seen(Q);int x=1;for(int i=0;i<Q-1;i++){assert(x&&!seen[x]);seen[x]=1;lg[x]=i;ex[i]=ex[i+Q-1]=x;x=rawmul(x,gen);}assert(x==1);for(int a=0;a<Q;a++){powq[a]=power(a,q);if(a){invv[a]=power(a,Q-2);assert(rawmul(a,invv[a])==1);}}
  cubic_generator=0;for(int a=q;a<Q;a++)if(power(a,C)==a){cubic_generator=a;break;}assert(cubic_generator);
  ctr.resize(C);cti.assign(Q,-1);int z2=mul(cubic_generator,cubic_generator);for(int a=0;a<C;a++){int z=add(add(a%q,scale((a/q)%q,cubic_generator)),scale(a/(q*q),z2));ctr[a]=z;assert(cti[z]<0);cti[z]=a;}
  cadd.resize(C*C);cmul.resize(C*C);for(int a=0;a<C;a++)for(int b=0;b<C;b++){cadd[a*C+b]=(a%q+b%q)%q+q*((a/q%q+b/q%q)%q)+q*q*((a/(q*q)+b/(q*q))%q);cmul[a*C+b]=cti[mul(ctr[a],ctr[b])];assert(cmul[a*C+b]>=0);}
  cerr<<"independent field q="<<q<<" generator="<<gen<<" cubicgen="<<cubic_generator<<"\n";
 }
};
