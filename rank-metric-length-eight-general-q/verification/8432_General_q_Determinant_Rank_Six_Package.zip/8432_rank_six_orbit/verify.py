#!/usr/bin/env python3
"""Recompute the six-rank finite theorem from a new directory.
Python standard library + a C++17 compiler. No prior binary output is an input
for the two incidence computations. Assertions must remain enabled.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

QS=(3,5,7)
PROGRAMS=('inc6','ind6','compare6','sweep6','check_sweep','coverage6')

def digest(path:Path)->str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()

def math_only(obj):
    if isinstance(obj,dict):
        return {k:math_only(v) for k,v in obj.items() if k not in {'seconds','elapsed_seconds'}}
    if isinstance(obj,list):return [math_only(v) for v in obj]
    return obj

def invoke(command:list[str],log:Path,cwd:Path)->None:
    with log.open('w') as f:
        subprocess.run(command,cwd=cwd,stdout=f,stderr=subprocess.STDOUT,check=True)

def tex_structure(path:Path)->dict:
    text=re.sub(r'(?<!\\)%[^\n]*','',path.read_text())
    labels=re.findall(r'\\label\{([^}]+)\}',text)
    assert len(labels)==len(set(labels))
    assert set(re.findall(r'\\(?:eqref|ref)\{([^}]+)\}',text))<=set(labels)
    stack=[]
    for op,name in re.findall(r'\\(begin|end)\{([^}]+)\}',text):
        if op=='begin':stack.append(name)
        else:assert stack and stack.pop()==name,(op,name)
    assert not stack
    balance=0
    for ch in re.sub(r'\\[{}]','',text):
        if ch=='{':balance+=1
        if ch=='}':balance-=1
        assert balance>=0
    assert balance==0
    return {'labels':len(labels),'internal_references_resolved':True,'environments_balanced':True}

def run(root:Path,work:Path,compiler:str|None=None,sanitize:bool=False,compare:bool=True)->dict:
    if not __debug__:raise RuntimeError('Do not use python -O; exact checks require assertions.')
    if sys.byteorder!='little':raise RuntimeError('This delivery uses little-endian 32-bit count arrays.')
    root=root.resolve();work=work.resolve()
    if work==root or root in work.parents:raise ValueError('Use a work directory outside the package.')
    if work.exists() and (not work.is_dir() or any(work.iterdir())):raise ValueError('Work directory must be new or empty.')
    work.mkdir(parents=True,exist_ok=True);(work/'bin').mkdir();logs=work/'logs';logs.mkdir()
    manifest=root/'MANIFEST.json';manifest_files=0
    if compare and manifest.exists():
        for name,expected in json.loads(manifest.read_text()).items():
            assert digest(root/name)==expected,('manifest mismatch',name)
            manifest_files+=1
    compiler=compiler or os.environ.get('CXX') or shutil.which('g++') or shutil.which('clang++')
    if not compiler:raise RuntimeError('A C++17 compiler is required.')
    start=time.perf_counter();flags=['-std=c++17','-O3','-march=native']
    if sanitize:flags+=['-fsanitize=undefined','-fno-sanitize-recover=all','-D_GLIBCXX_ASSERTIONS']
    jobs=[]
    for name in PROGRAMS:
        invoke([compiler,*flags,str(root/'src'/f'{name}.cpp'),'-o',str(work/'bin'/name)],logs/f'{name}_compile.log',root)
    for q in QS:
        for name,prefix in [('inc6',f'inc{q}'),('ind6',f'ind{q}')]:
            invoke([str(work/'bin'/name),str(q),str(work/prefix)],logs/f'{prefix}.log',root)
        invoke([str(work/'bin/compare6'),str(q),str(work/f'inc{q}_counts.bin'),str(work/f'ind{q}_counts.bin'),str(work/f'compare{q}.json')],logs/f'compare{q}.log',root)
        a=json.loads((work/f'inc{q}.json').read_text());b=json.loads((work/f'ind{q}.json').read_text())
        assert a['complete'] and b['histogram_all_forms']==a['histogram_all_forms']
        assert a['maximum_nondegenerate_split']=={3:56,5:136,7:262}[q]
        assert a['normal_classes']==q**9-q**3
        assert a['scalar_space_orbits']==q**3+q*q+q+1
        jobs.extend([f'inc{q}.json',f'ind{q}.json',f'compare{q}.json'])
        print('Complete incidence arrays agree for q =',q,flush=True)
        invoke([str(work/'bin/coverage6'),str(q),str(work/f'coverage{q}.json')],logs/f'coverage{q}.log',root)
        assert json.loads((work/f'coverage{q}.json').read_text())['all_membership_tests_agree']
        jobs.append(f'coverage{q}.json')
    # A stronger independent bridge than needed for the new analytic duality:
    # both generator families are directly enumerated, without dividing by two.
    for q,cut,prefix in [(3,0,'sweep3'),(5,69,'sharp5'),(7,262,'maxima7')]:
        invoke([str(work/'bin/sweep6'),str(q),str(work/f'inc{q}_counts.bin'),str(cut),str(work/prefix)],logs/f'{prefix}.log',root)
        out=f'ind_{prefix}'
        invoke([str(work/'bin/check_sweep'),str(q),str(work/f'inc{q}_counts.bin'),str(work/f'{prefix}_planes.txt'),str(cut),str(work/out)],logs/f'{out}.log',root)
        d=json.loads((work/f'{out}.json').read_text())
        assert d['both_families_match'] and d['complete_selected_coverage']
        assert d['maximum_single_family']=={3:28,5:68,7:131}[q]
        jobs.extend([f'{prefix}.json',f'{out}.json'])
        print('Independent two-family geometry passed for q =',q,flush=True)
    invoke([sys.executable,str(root/'src/geometry.py'),'--work',str(work)],logs/'geometry.log',root)
    invoke([sys.executable,str(root/'src/check_duality.py'),'--output',str(work/'duality_cases.json')],logs/'duality_cases.log',root)
    jobs+=['geometry_maxima.json','duality_cases.json']
    if compare:
        for name in jobs:
            assert math_only(json.loads((work/name).read_text()))==math_only(json.loads((root/'results'/name).read_text())),('mathematical output mismatch',name)
        expected=json.loads((root/'results/ARRAY_HASHES.json').read_text())
        for name,meta in expected.items():
            assert (work/name).stat().st_size==meta['bytes'],name
            assert digest(work/name)==meta['sha256'],('full-array mismatch',name)
    tex=tex_structure(root/'THEOREMS_en.tex');tex['compiled']=False
    pdflatex=shutil.which('pdflatex')
    if pdflatex:
        td=work/'tex';td.mkdir()
        for name in ['fragment_check.tex','THEOREMS_en.tex']:
            shutil.copyfile(root/name,td/name)
        for n in range(2):invoke([pdflatex,'-interaction=nonstopmode','-halt-on-error','fragment_check.tex'],logs/f'latex{n}.log',td)
        tex['compiled']=True
    summary={
       'status':'passed','ordinary_characteristics':[3,5,7],
       'independent_full_count_arrays_equal':True,
       'normalized_operator_classes_compared':sum(q**9-q**3 for q in QS),
       'kernel_directions_per_full_implementation':sum(json.loads((work/f'inc{q}.json').read_text())['directions_visited'] for q in QS),
       'three_spaces_directly_covered':sum(json.loads((work/f'coverage{q}.json').read_text())['all_three_spaces'] for q in QS),
       'max_total_two_family_counts':{'3':56,'5':136,'7':262},
       'max_single_family_counts':{'3':28,'5':68,'7':131},
       'direct_two_family_projective_point_checks':sum(json.loads((work/f'ind_{p}.json').read_text())['independent_both_family_point_checks'] for p in ['sweep3','sharp5','maxima7']),
       'actual_maximizing_sections_reconstructed':len(json.loads((work/'geometry_maxima.json').read_text())),
       'duality_example_section_pairs':json.loads((work/'duality_cases.json').read_text())['section_pairs'],
       'saved_mathematical_outputs_compared':compare,
       'manifest_files_checked':manifest_files,
       'compiler':str(compiler),'undefined_behavior_checks_enabled':sanitize,'tex':tex,
       'scope':'complete a*b!=0 normalized self-adjoint incidence classes for q=3,5,7; exact square-rank duality and two-family checks; no full historical code-classification replay',
       'historical_full_chain_reverified':False,
       'elapsed_seconds':round(time.perf_counter()-start,3)
    }
    (work/'verification.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(summary,ensure_ascii=False,indent=2),flush=True)
    return summary

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path,required=True)
    ap.add_argument('--compiler');ap.add_argument('--sanitize',action='store_true');args=ap.parse_args()
    run(Path(__file__).resolve().parent,args.work,args.compiler,args.sanitize,True)
if __name__=='__main__':main()
