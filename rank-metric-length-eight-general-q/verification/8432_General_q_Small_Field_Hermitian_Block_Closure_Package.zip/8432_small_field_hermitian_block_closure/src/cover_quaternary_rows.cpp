// Independent equation-row version of the GF(4) threshold test.
// GF(4)=F2[t]/(t^2+t+1): addition is XOR, never integer arithmetic modulo four.
#include <array>
#include <vector>
#include <fstream>
#include <iostream>
#include <chrono>
#include <cassert>
#include <algorithm>
#include <cstdint>
#include <cstdlib>
using namespace std;
constexpr int n=67,d=18;using Row=array<uint8_t,d>;array<array<Row,4>,n> blocks;int labels[n];
const int M[4][4]={{0,0,0,0},{0,1,2,3},{0,2,3,1},{0,3,1,2}},inv[4]={0,1,3,2};
uint64_t nodes=0,leaves=0,empty_count=0,rhist[19]={};int best=0,target=11;Row bestvector{};
struct Equations{array<Row,d>row{};uint32_t piv=0;int rank=0;
 void add(Row x){for(int i=0;i<d;i++){if(!x[i])continue;if(piv>>i&1){int c=x[i];for(int j=i;j<d;j++)x[j]^=M[c][row[i][j]];}else{int c=inv[x[i]];for(int j=i;j<d;j++)x[j]=M[c][x[j]];row[i]=x;piv|=1u<<i;rank++;return;}}}
 vector<Row>kernel()const{vector<Row>out;for(int f=0;f<d;f++)if(!(piv>>f&1)){Row x{};x[f]=1;for(int i=d-1;i>=0;i--)if(piv>>i&1){int c=0;for(int j=i+1;j<d;j++)c^=M[row[i][j]][x[j]];x[i]=c;}out.push_back(x);}return out;}
};
int reduce(array<array<int,4>,4>&mat,int k){int rank=0;for(int j=0;j<k;j++){int p=rank;while(p<4&&!mat[p][j])p++;if(p==4)continue;swap(mat[p],mat[rank]);int c=inv[mat[rank][j]];for(int h=j;h<k;h++)mat[rank][h]=M[c][mat[rank][h]];for(int i=rank+1;i<4;i++)if(mat[i][j]){int x=mat[i][j];for(int h=j;h<k;h++)mat[i][h]^=M[x][mat[rank][h]];}rank++;if(rank==k)return rank;}return rank;}
bool terminal(const Equations&A){leaves++;auto basis=A.kernel();int k=basis.size();assert(k>0&&k<=4);vector<array<int,4>>vectors;
 for(int p=0;p<k;p++){int lim=1;for(int j=p+1;j<k;j++)lim*=4;for(int x=0;x<lim;x++){array<int,4>a{};a[p]=1;int u=x;for(int j=p+1;j<k;j++){a[j]=u%4;u/=4;}vectors.push_back(a);}}
 vector<int>hits(vectors.size());int all=0;
 for(int i=0;i<n;i++){array<array<int,4>,4>mat{};for(int r=0;r<4;r++)for(int j=0;j<k;j++){int x=0;for(int z=0;z<d;z++)x^=M[blocks[i][r][z]][basis[j][z]];mat[r][j]=x;}int r=reduce(mat,k);if(r==k)continue;if(!r){all++;continue;}
  for(size_t z=0;z<vectors.size();z++){bool zero=true;for(int j=0;j<r&&zero;j++){int x=0;for(int h=0;h<k;h++)x^=M[mat[j][h]][vectors[z][h]];zero=x==0;}hits[z]+=zero;}}
 for(size_t z=0;z<vectors.size();z++)if(hits[z]+all>best){best=hits[z]+all;for(int j=0;j<d;j++){int x=0;for(int h=0;h<k;h++)x^=M[basis[h][j]][vectors[z][h]];bestvector[j]=x;}}
 return best>=target;
}
bool search(const Equations&A,int begin,int need){nodes++;rhist[A.rank]++;if(A.rank==d){empty_count++;return false;}if(A.rank>=14)return terminal(A);if(need<=0){cerr<<"Unexpected unenumerated terminal kernel\n";abort();}if(n-begin<need)return false;
 for(int i=begin;i<=n-need;i++){Equations B=A;for(auto row:blocks[i])B.add(row);if(search(B,i+1,need-1))return true;}return false;
}
int main(int argc,char**argv){assert(argc>=3);ifstream f(argv[1]);int nn,dd,qq;f>>nn>>dd>>qq;assert(nn==n&&dd==d&&qq==4);for(int i=0;i<n;i++){f>>labels[i];for(auto&r:blocks[i])for(auto&v:r){int x;f>>x;assert(f&&x>=0&&x<4);v=x;}}
 if(argc>3)target=atoi(argv[3]);assert(target==11);auto start=chrono::steady_clock::now();Equations A;bool found=search(A,0,target);ofstream out(argv[2]);out<<"{\"target\":"<<target<<",\"found\":"<<(found?"true":"false")<<",\"nodes\":"<<nodes<<",\"leaves\":"<<leaves<<",\"empty\":"<<empty_count<<",\"max_seen\":"<<best<<",\"example\":[";for(int i=0;i<d;i++){if(i)out<<",";out<<int(bestvector[i]);}out<<"],\"hist\":[";for(int i=0;i<19;i++){if(i)out<<",";out<<rhist[i];}out<<"],\"seconds\":"<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"}\n";return 0;}
