#!/usr/bin/env python3
"""Check the GF(4) block-distance supplement and its precise coding consequence."""
from pathlib import Path
import argparse,json,sys,time
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'vendor'))
from algebra import Algebra
from old_hermitian import core,lifts
from input_geometry import hermitian,direct_local
from tower_arithmetic import rank
from graph_independent_arithmetic import Field,U_from_J

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path,required=True);args=ap.parse_args();wd=args.work;start=time.monotonic()
 d=json.loads((wd/'q4_blocks.json').read_text());a=json.loads((wd/'q4_cover.json').read_text());b=json.loads((wd/'q4_ind_cover.json').read_text());A=Algebra(4);F=A.F;IF=Field(d['field']);K=A.K
 assert not a['found'] and not b['found'] and a['target']==b['target']==11
 assert a['max_seen']==b['max_seen']==10
 def dots(x,y):return K.sum(K.mul[u][v] for u,v in zip(x,y))
 examples=[]
 for label,x in [('forward',a['example']),('reversed',b['example'][::-1])]:
  zeros=[r['point_index'] for r in d['records'] if all(dots(row,x)==0 for row in r['rows'])]
  assert len(zeros)==10;examples.append(dict(path=label,vector=x,zero_points=zeros))
 assert rank(K,[row for r in d['records'] for row in r['rows']])==18
 scalar=[]
 for tau in A.E2:
  U=core(A,[0]*6,[[tau,0],[0,tau]]);h=(1,4,F.mul(A.bar(tau),F.mul(16,F.inv(A.dual[2]))));word=[F.dot(h,u) for u in U]
  assert rank(K,[F.digits(x) for x in word])==3
  IU=U_from_J(IF,[0]*6,[[tau,0],[0,tau]]);ih=[IF.convert(x) for x in h];iw=[IF.dot(ih,u) for u in IU]
  assert iw==[IF.convert(x) for x in word] and IF.rank([IF.flat([x]) for x in iw])==3
  scalar.append(dict(tau=tau,h=h,word=word))
 # This is a graph-class upper bound; no claim that it decides s=0 or s=1.
 out=dict(status='passed',q=4,ordinary_points=68,regular_blocks=67,exceptional_point=d['points'][d['star'][0]],
   effective_dimension=18,minimum_block_distance=57,maximum_regular_zero_blocks=10,ordinary_descent_upper=11,
   target_lower='16*s-17',excluded_Hermitian_global_weight_two_counts='s>=2',
   primary_nodes=a['nodes'],second_order_nodes=b['nodes'],examples=examples,scalar_rank_three_endpoints=scalar,
   scope='GF(4) matrices independently reconstructed; separate equation-row and kernel-basis cover programs with different point and coordinate orders',
   seconds=time.monotonic()-start)
 (wd/'quaternary.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
 print('GF(4) supplement: block distance 57; d<=11 excludes Hermitian targets with s>=2.',flush=True)
if __name__=='__main__':main()
