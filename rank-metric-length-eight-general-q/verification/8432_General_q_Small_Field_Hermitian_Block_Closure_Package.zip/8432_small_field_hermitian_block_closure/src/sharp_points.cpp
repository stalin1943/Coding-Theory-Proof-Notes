#include "../vendor/prime_tower.hpp"
#include <unordered_map>
struct Entry {int count=0,first=0,second=0;};
int main(int argc,char**argv){
 Field f(5);using V=std::array<int,3>;
 assert(argc==3);std::array<V,8> U;std::ifstream in(argv[1]);int nn;in>>nn;assert(nn==8);
 for(auto&u:U)for(int&x:u){in>>x;assert(in&&x>=0&&x<f.Q);}

 std::unordered_map<uint64_t,Entry> pts;pts.reserve(100000);uint64_t count=0;
 for(int pivot=0;pivot<8;pivot++){
  int lim=1;for(int i=pivot+1;i<8;i++)lim*=5;
  for(int a=0;a<lim;a++){V v=U[pivot];int u=a;for(int i=pivot+1;i<8;i++){int c=u%5;u/=5;for(int j=0;j<3;j++)v[j]=f.add(v[j],f.scale(c,U[i][j]));}
   int p=v[0]?0:(v[1]?1:2);assert(v[p]);int scale=v[p],inv=f.iv[scale];for(int &x:v)x=f.mul(x,inv);
   uint64_t key=(uint64_t(v[0])*f.Q+v[1])*f.Q+v[2];auto &e=pts[key];if(e.count==0)e.first=scale;else if(e.count==1)e.second=scale;e.count++;count++;
  }
 }
 assert(count==97656);std::map<int,int>hist;std::vector<std::array<int,6>>heavy;
 for(const auto&[key,e]:pts){int w=0;for(int d=1,s=1;d<=8;d++,s=5*s+1)if(s==e.count){w=d;break;}assert(w);hist[w]++;if(w>1){uint64_t k=key;V v{};for(int j=2;j>=0;j--){v[j]=k%f.Q;k/=f.Q;}int ratio=f.mul(e.second,f.iv[e.first]);int deg=6;if(f.pow(ratio,25)==ratio)deg=2;else if(f.pow(ratio,125)==ratio)deg=3;heavy.push_back({v[0],v[1],v[2],w,ratio,deg});}}
 std::sort(heavy.begin(),heavy.end());std::ofstream out(argv[2]);out<<"{\"projective_vectors\":"<<count<<",\"point_weight_histogram\":{";bool first=true;for(auto[w,n]:hist){if(!first)out<<",";first=false;out<<"\""<<w<<"\":"<<n;}out<<"},\"heavy_points\":[";first=true;for(auto r:heavy){if(!first)out<<",";first=false;out<<"[";for(int i=0;i<6;i++){if(i)out<<",";out<<r[i];}out<<"]";}out<<"]}\n";
 assert(hist.size()==2&&hist[1]==97638&&hist[2]==3);for(auto h:heavy)assert(h[5]!=2);
 std::cerr<<"point hist ";for(auto[w,n]:hist)std::cerr<<w<<":"<<n<<" ";std::cerr<<"\n";
}
