#!/usr/bin/env python3
"""Build the exact quinary descent block code from the inherited cubic formula.
No subset or graph sampling. All PG(3,5) points and canonical graph basis vectors
are constructed anew. The independent checker re-solves the original traces.
"""
from pathlib import Path
import argparse, collections, json, sys, time
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'vendor'))
from input_geometry import Algebra, Poly, polynomial_normals, coordinate_graph_basis, hermitian, det
from tower_arithmetic import projective, rref, rank

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path,required=True);args=ap.parse_args()
 out=args.work;start=time.monotonic();q=5;A=Algebra(q);F=A.F;P=Poly(F)
 assert F.E.poly==[1,0,1,1] and F.nu==2 and F.beta==0
 graph_basis=coordinate_graph_basis(A);polynomials=[];normal0=None
 for _,_,lift in graph_basis:
  _,z0,rows=polynomial_normals(A,lift)
  if normal0 is None:normal0=z0
  else:assert normal0==z0
  polynomials.append(rows)
 points=list(map(tuple,projective(q,4)));assert len(points)==156 and len(set(points))==156
 singular=[det(A,hermitian(A,x))==0 for x in points]
 assert sum(singular)==26
 blocks=[];records=[];full_blocks=[]
 for i,x in enumerate(points):
  mat=[[P.eval(polynomials[j][row],x) for j in range(20)] for row in range(6)]
  full_blocks.append(mat)
  reduced=rref(A.K,[row[:18] for row in mat],18)[0]
  blocks.append(reduced)
  if not singular[i] and P.eval(normal0,x):
   assert len(reduced)==4
   records.append({'point_index':i,'rows':reduced})
 star=[i for i,x in enumerate(points) if not singular[i] and not P.eval(normal0,x)]
 assert star==[155] and points[155]==(0,0,0,1)
 assert len(records)==129
 assert rank(A.K,[row for r in records for row in r['rows']])==18
 with (out/'blocks.txt').open('w') as f:
  f.write('129 18 5\n')
  for r in records:f.write(str(r['point_index'])+' '+' '.join(map(str,sum(r['rows'],[])))+'\n')
 result=dict(q=q,field=dict(q=q,beta=F.beta,nu=F.nu,cubic_polynomial=F.E.poly),points=points,
  singular=singular,star=star,blocks=blocks,canonical_blocks20=full_blocks,records=records,
  ordinary_points=130,regular_blocks=129,dimension=18,alphabet_block_dimension=4,
  combined_rank=18,seconds=time.monotonic()-start)
 (out/'blocks.json').write_text(json.dumps(result,separators=(',',':'))+'\n')
 print('Constructed 129 rank-four point blocks; stacked rank 18.',flush=True)
if __name__=='__main__':main()
