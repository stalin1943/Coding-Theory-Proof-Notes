#!/usr/bin/env python3
"""Check all extremal block directions and the actual sharp graph.
Both arithmetic towers are used; the exact global minimum rank is checked by
156 complete affine systems rather than by random codewords.
"""
from pathlib import Path
import argparse,collections,json,sys,time
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'vendor'))
from input_geometry import Algebra,hermitian,direct_local
from old_hermitian import core,lifts
from tower_arithmetic import rank,projective
import raw_trace_baseline as independent
from graph_independent_arithmetic import Field,U_from_J,proj
independent.q=5
q=5

def pk(a):
 c=pow(next(x for x in a if x),-1,5)
 return tuple(x*c%5 for x in a)

def decode(n):
 out=[]
 for _ in range(18):out.append(n%5);n//=5
 assert n==0 and next(x for x in out if x)==1
 return out

def conic_primary(A,z,ss):
 F=A.F;out=[]
 for i,j in [(0,0),(0,1),(0,2),(1,1),(1,2),(2,2)]:
  v=F.mul(F.pow(ss[i],25),F.pow(ss[j],625))
  if i!=j:v=F.add(v,F.mul(F.pow(ss[j],25),F.pow(ss[i],625)))
  out.append(A.tr2(F.mul(z,v)))
 return out

def conic_desc_ind(F,coeff):
 if not any(coeff):return False
 iv=F.ei[next(x for x in coeff if x)]
 return all(F.em[iv][c]<5 for c in coeff)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path,required=True);args=ap.parse_args();wd=args.work;start=time.monotonic()
 data=json.loads((wd/'blocks.json').read_text());a=json.loads((wd/'cover_rows.json').read_text());b=json.loads((wd/'cover_kernels.json').read_text())
 assert a['high_word_keys']==b['high_word_keys'] and len(a['high_word_keys'])==18
 assert a['max_seen']==b['maximum_encountered']==12
 vectors=[]
 for key in a['high_word_keys']:
  x=decode(key);zeros=[]
  for rec in data['records']:
   if all(sum(u*v for u,v in zip(row,x))%5==0 for row in rec['rows']):zeros.append(rec['point_index'])
  assert len(zeros)==12
  vectors.append(dict(key=key,vector=x,zero_points=zeros,block_weight=117))
 # The complete extremal set splits into three constant-weight two-spaces.
 groups={}
 for rec in vectors:groups.setdefault(tuple(rec['zero_points']),[]).append(rec['vector'])
 assert len(groups)==3
 from tower_arithmetic import Base,rref
 K=Base(5);extremal_planes=[]
 for zeros,vs in sorted(groups.items()):
  basis2=rref(K,vs,18)[0];assert len(vs)==6 and len(basis2)==2
  generated={pk([(a*x+b*y)%5 for x,y in zip(*basis2)]) for a in range(5) for b in range(5) if a or b}
  assert generated==set(map(tuple,vs))
  extremal_planes.append(dict(basis=basis2,zero_points=list(zeros)))
 assert rank(K,[v for r in extremal_planes for v in r['basis']])==6
 assert all(not(set(a['zero_points'])&set(b['zero_points'])) for i,a in enumerate(extremal_planes) for b in extremal_planes[i+1:])

 A=Algebra(5);F=A.F;IF=Field(data['field']);endpoints=[]
 for tau in A.E2:
  U=core(A,[0]*6,[[tau,0],[0,tau]]);h=(1,5,F.mul(A.bar(tau),F.mul(25,F.inv(A.dual[2]))));word=[F.dot(h,u) for u in U]
  assert rank(A.K,[F.digits(x) for x in word])==3
  IU=U_from_J(IF,[0]*6,[[tau,0],[0,tau]]);ih=tuple(IF.convert(x) for x in h)
  assert IU==[tuple(IF.convert(x) for x in u) for u in U]
  iword=[IF.dot(ih,u) for u in IU];assert iword==[IF.convert(x) for x in word]
  assert IF.rank([IF.flat([x]) for x in iword])==3
  endpoints.append(dict(tau=tau,message=h,word=word))
 model=json.loads((ROOT/'inputs/sharp_model.json').read_text());U=core(A,model['J'],model['N']);IU=U_from_J(IF,model['J'],model['N'])
 assert [list(u) for u in U]==model['U_columns']
 assert IU==[tuple(IF.convert(x) for x in u) for u in U]
 assert rank(A.K,[[v for x in u for v in F.digits(x)] for u in U])==8
 raw=[]
 for u in U[4:]:
  for x in u[:2]:raw.extend(F.digits(x))
 descended=[];ordinary_normals=[];raw_equations=0
 for i,p in enumerate(data['points']):
  if data['singular'][i]:continue
  z,ss,_=direct_local(A,hermitian(A,p),U[4:]);assert z!=0
  down=A.descent(conic_primary(A,z,ss))
  aa,dd,b0,b1=p;bb=b0+5*b1;HH=[[aa,bb],[IF.bar(bb),dd]]
  iss,images,kb=independent.original_map(IF,HH);iz=IF.dot(raw,images);assert iz!=0
  icoeff=independent.coef(IF,iz,iss);assert down==conic_desc_ind(IF,icoeff)
  ordinary_normals.append(dict(point_index=i,primary_normal=z,independent_normal=IF.back(iz),descends=down))
  raw_equations+=1
  if down:descended.append(i)
 assert len(descended)==13 and 155 in descended
 allowed=[r['point_index'] for r in data['records'] if all(sum(x*y for x,y in zip(row,model['quotient_vector']))%5==0 for row in r['rows'])]
 assert sorted(descended)==sorted(allowed+[155])
 # Complete minimum-rank verification. Every possible rank-three message has a
 # horizontal direction annihilating a point of the scattered four-space.
 basis=[1,IF.xi,IF.mul(IF.xi,IF.xi),IF.mu,IF.mul(IF.mu,IF.xi),IF.mul(IF.mu,IF.mul(IF.xi,IF.xi))]
 bprimary=[F.pow(5,i) for i in range(3)]+[F.mul(F.mu,F.pow(5,i)) for i in range(3)]
 minimum_records=[]
 for cs in proj(5,4):
  point=tuple(IF.dot(cs,[u[j] for u in IU[:4]]) for j in range(3));h=(IF.neg(point[1]),point[0]);im=[IF.dot(h,u[:2]) for u in IU[:4]]
  assert IF.rank([IF.flat([x]) for x in im])==3
  ann=independent.nk([[independent.atr(IF,IF.mul(x,b)) for b in basis] for x in im],6);assert len(ann)==3
  ls=[IF.dot(c,basis) for c in ann];rows=[];rhs=[]
  for u in IU[4:]:
   val=IF.dot(h,u[:2])
   for l in ls:
    rows.append([independent.atr(IF,IF.mul(l,IF.mul(b,u[2]))) for b in basis])
    rhs.append(-independent.atr(IF,IF.mul(l,val))%5)
  cr=IF.rank(rows);ar=IF.rank([r+[v] for r,v in zip(rows,rhs)])
  assert cr==6 and ar==7
  hp=tuple(IF.back(x) for x in h);annp=[IF.back(x) for x in ls]
  pr=[];ps=[]
  for u in U[4:]:
   val=F.dot(hp,u[:2])
   for l in annp:
    pr.append([F.trace(F.mul(l,F.mul(b,u[2]))) for b in bprimary]);ps.append(-F.trace(F.mul(l,val))%5)
  assert pr==rows and ps==rhs
  assert rank(A.K,pr)==6 and rank(A.K,[r+[v] for r,v in zip(pr,ps)])==7
  minimum_records.append(dict(horizontal_message=hp,coefficient_rank=6,augmented_rank=7))
 assert len(minimum_records)==156
 # One explicit zero-intersection pair, recomputed in both towers.
 h=[1,133,10124];g=[0,0,1];w1=[F.dot(h,u) for u in U];w2=[u[2] for u in U]
 r1=rank(A.K,[F.digits(x) for x in w1]);r2=rank(A.K,[F.digits(x) for x in w2]);r12=rank(A.K,[F.digits(x)+F.digits(y) for x,y in zip(w1,w2)])
 assert [r1,r2,r12]==[4,4,8]
 ih=[IF.convert(x) for x in h];iw1=[IF.dot(ih,u) for u in IU];iw2=[u[2] for u in IU]
 assert IF.rank([IF.flat([x,y]) for x,y in zip(iw1,iw2)])==8
 assert iw1==[IF.convert(x) for x in w1]
 out=dict(status='passed',extremal_directions=vectors,extremal_projective_directions=18,minimum_block_distance=117,
  extremal_two_spaces=extremal_planes,scalar_rank_three_endpoints=endpoints,sharp_model=model,sharp_ordinary_descent_points=descended,sharp_ordinary_normals=ordinary_normals,
  sharp_zero_normal_count=0,sharp_minimum_rank=4,sharp_minimum_rank_complete_tests=minimum_records,
  sharp_zero_intersection_pair=dict(h=h,g=g,hG=w1,gG=w2,rank_triple=[4,4,8]),
  scope='exact block extremal directions, all 25 scalar endpoints, and one actual sharp graph with all 156 possible rank-three horizontal directions',
  seconds=time.monotonic()-start)
 (wd/'graphs.json').write_text(json.dumps(out,ensure_ascii=False,separators=(',',':'))+'\n')
 (wd/'sharp_matrix.txt').write_text('8\n'+'\n'.join(' '.join(map(str,u)) for u in U)+'\n')
 print('18 maximum block directions; 25 rank-three scalar endpoints; sharp graph has 13 true descent points and minimum rank 4.',flush=True)
if __name__=='__main__':main()
