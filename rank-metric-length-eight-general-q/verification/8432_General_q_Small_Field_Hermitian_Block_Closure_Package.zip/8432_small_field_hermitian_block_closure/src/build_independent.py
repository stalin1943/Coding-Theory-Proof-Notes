#!/usr/bin/env python3
"""Independent reconstruction via original trace equations and opposite tower arithmetic.
The raw-map implementation is an attributed unchanged input module.
"""
from pathlib import Path
import sys,json,time,importlib.util,collections
ROOT=Path(__file__).resolve().parents[1]
import argparse
ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path,required=True);args=ap.parse_args();out=args.work
sys.path.insert(0,str(ROOT/'vendor'))
spec=importlib.util.spec_from_file_location('rawtrace',ROOT/'vendor/raw_trace_baseline.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.q=5;q=5
src=json.load(open(out/'blocks.json'));F=m.Field(src['field']);start=time.time()
from graph_independent_arithmetic import U_from_J
basis=[]
for i in range(10):
 for e in [1,q**3]:
  J=[0]*6;N=[[0,0],[0,0]]
  if i<6:J[i]=e
  else:N[(i-6)//2][(i-6)%2]=e
  U=U_from_J(F,J,N);row=[]
  for u in U[4:]:
   for z in u[:2]:
    z=F.back(z);row.extend([(z//q**j)%q for j in range(6)])
  basis.append(row)
# 28 gauge vectors generated independently from actual horizontal sections and shears.
U=U_from_J(F,[0]*6,[[0,0],[0,0]]);zvec=[u[2] for u in U[4:]];gauge=[]
def rawcoord(lifts):
 out=[]
 for u in lifts:
  for z in u[:2]:
   z=F.back(z);out.extend([(z//q**j)%q for j in range(6)])
 return out
for slot in range(4):
 for t in U[:4]:
  lift=[[0,0,z] for z in zvec];lift[slot][0]=t[0];lift[slot][1]=t[1];gauge.append(rawcoord(lift))
for co in range(2):
 for a in [1,F.xi,F.mul(F.xi,F.xi),F.mu,F.mul(F.mu,F.xi),F.mul(F.mu,F.mul(F.xi,F.xi))]:
  lift=[[0,0,z] for z in zvec]
  for r,z in zip(lift,zvec):r[co]=F.mul(a,z)
  gauge.append(rawcoord(lift))
assert len(m.rr(gauge,48)[1])==28
assert len(m.rr(gauge+basis,48)[1])==48
scalar=[[(a+b)%q for a,b in zip(basis[12+j],basis[18+j])] for j in range(2)]
assert len(m.rr(gauge+scalar,48)[1])==30
points=sorted({m.normalize(x) for x in m.proj(5,4)})
assert set(points)==set(map(tuple,src['points'])) and len(points)==156
ind_singular={p for p in points if (p[0]*p[1]-p[2]*p[2]+2*p[3]*p[3])%5==0}
assert len(ind_singular)==26
assert ind_singular=={tuple(p) for p,s in zip(src['points'],src['singular']) if s}
records=[];counts=collections.Counter()
for i,x in enumerate(src['points']):
 if src['singular'][i]:continue
 a,d,b0,b1=x;b=b0+q*b1;H=[[a,b],[F.bar(b),d]]
 ss,raw,kb=m.original_map(F,H)
 cols=[m.coef(F,e,ss) for e in kb]
 nk=m.nk([[cols[j][r]//q for j in range(6)] for r in range(6)],6)
 counts[len(nk)]+=1
 if i in src['star']:
  assert len(nk)==3;continue
 assert len(nk)==1
 z0=F.dot(nk[0],kb);v0=F.dig(z0);assert all(c<q for c in m.coef(F,z0,ss))
 colmat=[]
 for z in raw:
  v=F.dig(z);col=[]
  for j,k in [(0,1),(0,2),(1,2)]:
   w=F.ea[F.em[v[j]][v0[k]]][F.en[F.em[v[k]][v0[j]]]];col.extend([w%q,w//q])
  colmat.append(col)
 mat=list(map(list,zip(*colmat)))
 assert len(m.rr(mat,48)[1])==4
 assert all(sum(a*b for a,b in zip(row,v))%q==0 for row in mat for v in gauge+scalar)
 bm=[[sum(a*b for a,b in zip(row,v))%q for v in basis[:18]] for row in mat]
 assert m.rr(bm,18)[0]==m.rr(src['blocks'][i],18)[0]
 # Coordinate order reversed, point order later reversed for the second search.
 rev=m.rr([row[::-1] for row in bm],18)[0];assert len(rev)==4
 records.append(dict(point_index=i,raw_block=mat,block20=[[sum(a*b for a,b in zip(row,v))%q for v in basis] for row in mat],reverse18=rev))
 if len(records)%30==0:print('raw reconstructed',len(records),'sec',time.time()-start,flush=True)
assert len(records)==129 and counts=={1:129,3:1}
raw_all=[row for r in records for row in r['raw_block']]
assert len(m.rr(raw_all,48)[1])==18
assert len(m.nk(raw_all,48))==30
with open(out/'ind_blocks.txt','w') as f:
 f.write('129 18 5\n')
 for r in records[::-1]:f.write(str(r['point_index'])+' '+' '.join(map(str,sum(r['reverse18'],[])))+'\n')
json.dump(dict(q=5,field=src['field'],gauge=gauge,canonical_raw=basis,scalar=scalar,records=records,kernel_dimensions=dict(counts),seconds=time.time()-start),open(out/'independent_blocks.json','w'),separators=(',',':'))
print('DONE',time.time()-start,flush=True)
