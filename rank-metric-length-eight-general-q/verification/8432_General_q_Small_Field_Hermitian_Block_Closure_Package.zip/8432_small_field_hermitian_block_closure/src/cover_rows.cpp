// Complete threshold cover for the fixed quinary block system.
// Maintains assertions; never interprets a truncated traversal as a proof.
#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <vector>
#include <cstdlib>
#include <stdexcept>
#include <set>
#include <cassert>
using namespace std;
constexpr int D=18,Q=5,N=129; using Row=array<uint8_t,D>;
array<array<Row,4>,N> blocks; int labels[N];
uint64_t nodes=0,leaves=0,dead=0,rankhist[19]={};int target=12,best=0;
std::set<uint64_t> high_words;
chrono::steady_clock::time_point start_time;
struct Space{array<Row,D>row{}; uint32_t piv=0;int r=0;
 bool add(Row a){
  for(int j=0;j<D;j++){if(!a[j])continue;if(piv>>j&1){int z=a[j];for(int k=j;k<D;k++)a[k]=(a[k]+25-z*row[j][k])%5;}
   else {int iv[5]={0,1,3,2,4};int c=iv[a[j]];for(int k=j;k<D;k++)a[k]=a[k]*c%5;
    // Forward echelon suffices. Canonicality is not assumed.
    row[j]=a;piv|=1u<<j;r++;return true;}}
  return false;
 }
 vector<Row> kernel()const{vector<Row> ans;for(int f=0;f<D;f++)if(!(piv>>f&1)){
  Row x{};x[f]=1;for(int j=D-1;j>=0;j--)if(piv>>j&1){int v=0;for(int k=j+1;k<D;k++)v+=row[j][k]*x[k];x[j]=(5-v%5)%5;}ans.push_back(x);}return ans;}
};
int small_rank(vector<array<uint8_t,4>>&a,int k){int r=0;for(int j=0;j<k;j++){int p=r;while(p<4&&!a[p][j])p++;if(p==4)continue;swap(a[p],a[r]);int iv[5]={0,1,3,2,4};int c=iv[a[r][j]];for(int u=j;u<k;u++)a[r][u]=a[r][u]*c%5;for(int i=r+1;i<4;i++)if(a[i][j]){int z=a[i][j];for(int u=j;u<k;u++)a[i][u]=(a[i][u]+25-z*a[r][u])%5;}r++;if(r==k)return r;}return r;}
bool check_small(const Space&s){
 auto ker=s.kernel();int k=ker.size(); if(k==0)return false; if(k>4){cerr<<"bad leaf\n";exit(3);}leaves++;
 vector<array<uint8_t,4>> coeff;for(int piv=0;piv<k;piv++){int lim=1;for(int j=piv+1;j<k;j++)lim*=5;for(int a=0;a<lim;a++){array<uint8_t,4>x{};x[piv]=1;int b=a;for(int j=piv+1;j<k;j++){x[j]=b%5;b/=5;}coeff.push_back(x);}}
 vector<int> cnt(coeff.size());int all=0;
 for(int p=0;p<N;p++){
  vector<array<uint8_t,4>> mat(4);for(int row=0;row<4;row++)for(int c=0;c<k;c++){int v=0;for(int j=0;j<D;j++)v+=blocks[p][row][j]*ker[c][j];mat[row][c]=v%5;}
  int r=small_rank(mat,k);if(r==0){all++;continue;}if(r==k)continue;
  for(size_t c=0;c<coeff.size();c++){bool ok=true;for(int j=0;j<r&&ok;j++){int v=0;for(int t=0;t<k;t++)v+=mat[j][t]*coeff[c][t];ok=v%5==0;}if(ok)cnt[c]++;}
 }
 for(size_t c=0;c<cnt.size();c++)if(cnt[c]+all>=target){
  Row x{};for(int j=0;j<D;j++){int v=0;for(int a=0;a<k;a++)v+=coeff[c][a]*ker[a][j];x[j]=v%5;}
  int first=0;while(!x[first])first++;int inv[5]={0,1,3,2,4};int u=inv[x[first]];uint64_t key=0,mult=1;
  for(auto a:x){key+=mult*((int(a)*u)%5);mult*=5;}high_words.insert(key);
 }

 int mx=*max_element(cnt.begin(),cnt.end())+all;if(mx>best){best=mx;cerr<<"best "<<best<<" nodes "<<nodes<<" leaves "<<leaves<<" seconds "<<chrono::duration<double>(chrono::steady_clock::now()-start_time).count()<<"\n";}
 return false;
}
bool dfs(const Space&s,int start,int selected){
 nodes++;rankhist[s.r]++;
 if(s.r==D){dead++;return false;}
 if(selected>=target && s.r<14)throw std::runtime_error("A larger terminal kernel requires full enumeration; verification aborted.");
 if(s.r>=14)return check_small(s);
 int last=N-(target-selected);
 for(int i=start;i<=last;i++){
  Space ns=s;for(const auto&r:blocks[i])ns.add(r);
  if(dfs(ns,i+1,selected+1))return true;
 }
 return false;
}
int main(int argc,char**argv){if(argc<3)return 2;ifstream f(argv[1]);int n,d,q;f>>n>>d>>q;if(n!=N||d!=D||q!=5)return 3;for(int i=0;i<N;i++){f>>labels[i];for(auto&r:blocks[i])for(auto&x:r){int a;f>>a;if(!f||a<0||a>=5)throw std::runtime_error("Bad block coefficient");x=a;}}if(argc>3)target=atoi(argv[3]);if(target!=12)throw std::runtime_error("This verification fixes the complete high-support threshold at 12.");start_time=chrono::steady_clock::now();Space empty;
 bool found=dfs(empty,0,0);assert(!found);double sec=chrono::duration<double>(chrono::steady_clock::now()-start_time).count();ofstream out(argv[2]);out<<"{\"target_regular_zeros\":"<<target<<",\"early_exit\":"<<(found?"true":"false")<<",\"nodes\":"<<nodes<<",\"leaves\":"<<leaves<<",\"rank18_dead\":"<<dead<<",\"max_seen\":"<<best<<",\"rank_hist\":[";for(int i=0;i<19;i++){if(i)out<<",";out<<rankhist[i];}out<<"],\"high_word_keys\":[";bool first=true;for(auto key:high_words){if(!first)out<<",";first=false;out<<key;}out<<"],\"seconds\":"<<sec<<"}\n";cerr<<"EXACT HIGH WORDS "<<high_words.size()<<"\n";cerr<<"END "<<found<<" "<<nodes<<" "<<sec<<"\n";return 0;}
