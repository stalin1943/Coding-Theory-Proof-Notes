#!/usr/bin/env python3
"""Independent GF(4) original-trace matrices and coverage checks."""
from pathlib import Path
import sys,json,time,collections
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'vendor'));import raw_trace_quaternary as m
from graph_independent_arithmetic import Field,U_from_J,proj
import argparse
ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path,required=True);args=ap.parse_args();p=args.work;src=json.load(open(p/'q4_blocks.json'));F=Field(src['field']);q=4
K=M=m.KM

def dot(a,b):
 s=0
 for x,y in zip(a,b):s^=M[x][y]
 return s

def coords(lift):
 out=[]
 for u in lift:
  for z in u[:2]:
   z=F.back(z);out.extend([(z//q**j)%q for j in range(6)])
 return out
basis=[]
for i in range(10):
 for c in [1,q**3]:
  J=[0]*6;N=[[0,0],[0,0]]
  if i<6:J[i]=c
  else:N[(i-6)//2][(i-6)%2]=c
  basis.append(coords(U_from_J(F,J,N)[4:]))
base=U_from_J(F,[0]*6,[[0,0],[0,0]]);zs=[u[2] for u in base[4:]];gauge=[]
for k in range(4):
 for t in base[:4]:
  v=[[0,0,z] for z in zs];v[k][:2]=list(t[:2]);gauge.append(coords(v))
for j in range(2):
 for c in [1,F.xi,F.mul(F.xi,F.xi),F.mu,F.mul(F.mu,F.xi),F.mul(F.mu,F.mul(F.xi,F.xi))]:
  v=[[0,0,z] for z in zs]
  for u in v:u[j]=F.mul(c,u[2])
  gauge.append(coords(v))
scalar=[[a^b for a,b in zip(basis[12+j],basis[18+j])] for j in range(2)]
assert len(m.rr(gauge,48)[1])==28 and len(m.rr(gauge+basis,48)[1])==48
assert len(m.rr(gauge+scalar,48)[1])==30
def normalize(v):
 c=F.ki[next(x for x in v if x)]
 return tuple(F.km[x][c] for x in v)
pp={normalize(v) for v in proj(4,4)}
assert pp==set(map(tuple,src['points'])) and len(pp)==85
ss=set()
for p0 in pp:
 a,d,b0,b1=p0
 # Avoid relying on an incorrectly simplified characteristic-two determinant.
 b=b0+4*b1
 if F.sub(F.mul(a,d),F.mul(b,F.bar(b)))==0:ss.add(p0)
assert len(ss)==17 and ss=={tuple(p0) for p0,x in zip(src['points'],src['singular']) if x}
records=[];hist=collections.Counter();source={r['point_index']:r['rows'] for r in src['records']}
for i,x in enumerate(src['points']):
 if src['singular'][i]:continue
 a,d,b0,b1=x;b=b0+q*b1;H=[[a,b],[F.bar(b),d]]
 ss,raw,kb=m.original_map(F,H);co=[m.coef(F,z,ss) for z in kb]
 ker=m.nk([[co[j][r]//q for j in range(6)] for r in range(6)],6);hist[len(ker)]+=1
 if i in src['star']:
  assert len(ker)==3;continue
 assert len(ker)==1
 z0=F.dot(ker[0],kb);v0=F.dig(z0);columns=[]
 for z in raw:
  v=F.dig(z);col=[]
  for j,k in [(0,1),(0,2),(1,2)]:
   w=F.ea[F.em[v[j]][v0[k]]][F.en[F.em[v[k]][v0[j]]]];col.extend([w%q,w//q])
  columns.append(col)
 mat=list(map(list,zip(*columns)));assert len(m.rr(mat,48)[1])==4
 assert all(dot(row,v)==0 for row in mat for v in gauge+scalar)
 reduced=[[dot(row,v) for v in basis[:18]] for row in mat]
 assert m.rr(reduced,18)[0]==m.rr(source[i],18)[0]
 records.append(dict(point_index=i,rows=m.rr([row[::-1] for row in reduced],18)[0]))
assert len(records)==67 and hist=={1:67,3:1}
with (p/'q4_ind_blocks.txt').open('w') as f:
 f.write('67 18 4\n')
 for r in records[::-1]:f.write(str(r['point_index'])+' '+' '.join(map(str,sum(r['rows'],[])))+'\n')
json.dump(dict(q=4,records=records,rational_normal_dimensions=dict(hist),gauge=gauge,canonical_raw=basis),open(p/'q4_ind_blocks.json','w'))
print('67 actual original-trace blocks match; gauge and scalar dimensions verified over GF(4).')
