#!/usr/bin/env python3
"""Supplementary GF(4) block system; base-field arithmetic is not integer arithmetic modulo four."""
from pathlib import Path
import sys,json,time,collections
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'vendor'))
from input_geometry import Algebra,Poly,coordinate_graph_basis,polynomial_normals,hermitian,det
from tower_arithmetic import projective,rref,rank
A=Algebra(4);F=A.F;P=Poly(F);pol=[]
for _,_,l in coordinate_graph_basis(A):_,z0,r=polynomial_normals(A,l);pol.append(r)
points=list(projective(4,4));sing=[not det(A,hermitian(A,p)) for p in points];star=[i for i,p in enumerate(points) if not sing[i] and not P.eval(z0,p)]
blocks=[]
for i,p in enumerate(points):
 if sing[i] or i in star:continue
 b=[[P.eval(pol[j][k],p) for j in range(18)] for k in range(6)];r=rref(A.K,b,18)[0];assert len(r)==4;blocks.append(dict(point_index=i,rows=r))
assert len(points)==85 and sum(sing)==17 and len(star)==1 and len(blocks)==67
import argparse
ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path,required=True);args=ap.parse_args();out=args.work
with (out/'q4_blocks.txt').open('w') as f:
 f.write('67 18 4\n')
 for r in blocks:f.write(str(r['point_index'])+' '+' '.join(map(str,sum(r['rows'],[])))+'\n')
json.dump(dict(q=4,field=dict(q=4,cubic_polynomial=F.E.poly,beta=F.beta,nu=F.nu),points=points,singular=sing,star=star,records=blocks),open(out/'q4_blocks.json','w'))
print('q4 built',F.E.poly,F.beta,F.nu,'star',star,'rank',rank(A.K,[row for b in blocks for row in b['rows']]))
