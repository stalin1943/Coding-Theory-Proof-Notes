// GF(4) common-kernel cover, independent of cover_quaternary_rows.cpp.
#include <array>
#include <vector>
#include <fstream>
#include <iostream>
#include <chrono>
#include <cassert>
#include <algorithm>
#include <cstdint>
#include <cstdlib>
using namespace std;
constexpr int n=67,d=18;using Vec=array<int,18>;array<array<Vec,4>,n> Fns;int labels[n],threshold=14;
const int km[4][4]={{0,0,0,0},{0,1,2,3},{0,2,3,1},{0,3,1,2}},inv[4]={0,1,3,2};
uint64_t visited=0,terminal=0,empty_count=0,dhist[19]={};int best=0;Vec bestvector{};
struct Kernel{int k=18;array<Vec,18>b{};Kernel(){for(int i=0;i<18;i++)b[i][i]=1;}};
Kernel intersect(const Kernel&V,int point){int c[4][18]={};for(int r=0;r<4;r++)for(int i=0;i<V.k;i++){int s=0;for(int j=0;j<18;j++)s^=km[Fns[point][r][j]][V.b[i][j]];c[r][i]=s;}
 int piv[4],rank=0;bool is_piv[18]={};
 for(int j=V.k-1;j>=0;j--){int a=rank;while(a<4&&!c[a][j])a++;if(a==4)continue;for(int u=0;u<V.k;u++)swap(c[a][u],c[rank][u]);int s=inv[c[rank][j]];for(int u=0;u<V.k;u++)c[rank][u]=km[c[rank][u]][s];
  for(int r=0;r<4;r++)if(r!=rank&&c[r][j]){int h=c[r][j];for(int u=0;u<V.k;u++)c[r][u]^=km[h][c[rank][u]];}piv[rank++]=j;is_piv[j]=true;if(rank==4)break;}
 Kernel W;W.k=0;for(int f=0;f<V.k;f++)if(!is_piv[f]){Vec z{};for(int j=0;j<18;j++){int val=V.b[f][j];for(int r=0;r<rank;r++)val^=km[c[r][f]][V.b[piv[r]][j]];z[j]=val;}W.b[W.k++]=z;}assert(W.k==V.k-rank);return W;}
bool small(const Kernel&V){terminal++;int k=V.k;assert(k>0&&k<=3);vector<array<int,3>>ps;
 for(int p=k-1;p>=0;p--){int lim=1;for(int i=0;i<p;i++)lim*=4;for(int a=0;a<lim;a++){array<int,3>x{};x[p]=1;int u=a;for(int j=0;j<p;j++){x[j]=u%4;u/=4;}ps.push_back(x);}}
 vector<int>hits(ps.size());for(int p=0;p<n;p++){int rows[4][3]={};for(int r=0;r<4;r++)for(int i=0;i<k;i++){int s=0;for(int j=0;j<18;j++)s^=km[Fns[p][r][j]][V.b[i][j]];rows[r][i]=s;}
  for(size_t i=0;i<ps.size();i++){bool yes=true;for(int r=0;r<4&&yes;r++){int v=0;for(int j=0;j<k;j++)v^=km[ps[i][j]][rows[r][j]];yes=v==0;}hits[i]+=yes;}}
 for(size_t i=0;i<hits.size();i++)if(hits[i]>best){best=hits[i];for(int j=0;j<18;j++){int s=0;for(int h=0;h<k;h++)s^=km[V.b[h][j]][ps[i][h]];bestvector[j]=s;}cerr<<"max "<<best<<" nodes "<<visited<<"\n";}
 return best>=threshold;}
bool search(const Kernel&V,int begin,int need){visited++;dhist[V.k]++;if(!V.k){empty_count++;return false;}if(V.k<=3)return small(V);if(need<=0){std::cerr<<"Unexpected large terminal kernel; proof aborted.\n";std::abort();}if(n-begin<need)return false;for(int p=begin;p<=n-need;p++){Kernel next=intersect(V,p);if(search(next,p+1,need-1))return true;}return false;}
int main(int argc,char**argv){assert(argc>=3);ifstream f(argv[1]);int nn,dd,qq;f>>nn>>dd>>qq;assert(nn==n&&dd==d&&qq==4);for(int i=0;i<n;i++){f>>labels[i];for(auto&r:Fns[i])for(int&x:r){f>>x;assert(x>=0&&x<4);}}assert(f.good());if(argc>3)threshold=stoi(argv[3]);assert(threshold>=5&&threshold<n);
 auto t=chrono::steady_clock::now();Kernel V;bool found=search(V,0,threshold);ofstream out(argv[2]);out<<"{\"target\":"<<threshold<<",\"found\":"<<(found?"true":"false")<<",\"nodes\":"<<visited<<",\"leaves\":"<<terminal<<",\"empty\":"<<empty_count<<",\"max_seen\":"<<best<<",\"example\":[";for(int i=0;i<18;i++){if(i)out<<",";out<<bestvector[i];}out<<"],\"hist\":[";for(int i=0;i<19;i++){if(i)out<<",";out<<dhist[i];}out<<"],\"seconds\":"<<chrono::duration<double>(chrono::steady_clock::now()-t).count()<<"}\n";cerr<<"done "<<found<<"\n";return 0;}
