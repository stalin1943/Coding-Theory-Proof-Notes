#!/usr/bin/env python3
"""Two complete scalar-type message covers and independent complete point weights of one fixed graph.
Not an enumeration of graph parameters.
"""
from pathlib import Path
import sys,json,time,itertools,collections,importlib.util
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'vendor'))
import argparse
ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path,required=True);args=ap.parse_args();out=args.work
spec=importlib.util.spec_from_file_location('raw',ROOT/'vendor/raw_trace_baseline.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.q=5
from graph_independent_arithmetic import Field,proj,U_from_J
model=json.loads((ROOT/'inputs/sharp_model.json').read_text());meta=model['field'];F=Field(meta);q=5
U=U_from_J(F,model['J'],model['N']);assert [[F.back(x) for x in u] for u in U]==model['U_columns']

basis=[1,F.xi,F.mul(F.xi,F.xi),F.mu,F.mul(F.mu,F.xi),F.mul(F.mu,F.mul(F.xi,F.xi))]
def normal(v):
 c=F.inv(next(x for x in v if x));return tuple(F.mul(c,x) for x in v)
def vec(cs,rows):return tuple(F.dot(cs,[r[j] for r in rows]) for j in range(len(rows[0])))
def types():
 seen=set(range(q));reps=[];hist=collections.Counter()
 for t in range(q**6):
  if t in seen:continue
  orbit={F.add(a,F.scale(b,t)) for a in range(q) for b in range(1,q)}
  for c in range(q):
   ti=F.inv(F.sub(t,c));orbit.update(F.add(a,F.scale(b,ti)) for a in range(q) for b in range(1,q))
  assert not (orbit&seen) and len(orbit) in [q*(q-1),q*(q*q-1)];seen|=orbit;reps.append(t);hist[len(orbit)]+=1
 assert len(seen)==q**6 and hist=={20:1,120:130};return reps
start=time.time();reps=types();base=[[m.atr(F,F.mul(u[j],b)) for j in range(3) for b in basis] for u in U];low=set();kh=collections.Counter();generated=0
for lam in reps:
 rows=[[m.atr(F,F.mul(lam,F.mul(u[j],b))) for j in range(3) for b in basis] for u in U]
 ker=m.nk(base+rows,18);kh[len(ker)]+=1;assert 2<=len(ker)<=4
 vv=[tuple(F.dot(row[6*j:6*j+6],basis) for j in range(3)) for row in ker]
 for cs in proj(q,len(ker)):low.add(normal(vec(cs,vv)));generated+=1
hist=collections.Counter();disjoint=[];inc=collections.Counter()
for h in sorted(low):
 word=[F.dot(h,u) for u in U];rank=F.rank([F.flat([x]) for x in word]);hist[rank]+=1;assert rank==4
 tw=word[:4];rt=F.rank([F.flat([x]) for x in tw])
 if rt==4:
  joint=F.rank([F.flat([w,u[2]]) for w,u in zip(word,U)]);assert joint==8
  disjoint.append(dict(h=[F.back(x) for x in h],word=[F.back(x) for x in word]))
 elif rt==3:
  coeff=m.nk(list(map(list,zip(*[F.flat([x]) for x in tw]))),4);assert len(coeff)==1
  a=pow(next(v for v in coeff[0] if v),-1,q);p=tuple(a*v%q for v in coeff[0]);inc[p]+=1
 else:assert rt==0
local=collections.Counter();descending=[]
for p in proj(q,4):
 a=pow(next(x for x in p if x),-1,q);p=tuple(x*a%q for x in p);weight=1+inc[p];critical=(p[0]*p[1]-p[2]**2+2*p[3]**2)%q==0
 local[(critical,weight)]+=1
 if not critical and weight==7:descending.append(p)
assert len(descending)==13
assert hist=={4:856};assert sum(n*count for (_,n),count in local.items())==936+75-len(disjoint)
assert len(disjoint)>=78+75
# Direct independent enumeration of all 97,656 K-projective vectors in U.
point_counts=collections.Counter()
mult=[[tuple(F.scale(c,x) for x in u) for c in range(q)] for u in U]
def visit(j,v):
 if j==8:point_counts[normal(v)]+=1;return
 for t in mult[j]:visit(j+1,tuple(F.add(a,b) for a,b in zip(v,t)))
for pivot in range(8):visit(pivot+1,U[pivot])
assert sum(point_counts.values())==97656
assert collections.Counter(point_counts.values())=={1:97638,6:3}
weights=[[F.back(x) for x in p] for p,n in point_counts.items() if n==6]
primary_point_data=json.loads((out/'sharp_points.json').read_text())
assert sorted(weights)==sorted(r[:3] for r in primary_point_data['heavy_points'])
# A separately generated type cover in the primary field must recover the same messages.
from algebra import Algebra
from tower_arithmetic import rref,projective
A=Algebra(5);PF=A.F;PU=[tuple(u) for u in model['U_columns']]
pbasis=[1,5,25,PF.mu,PF.mul(PF.mu,5),PF.mul(PF.mu,25)]
seen=set(range(5));prep=[]
for lam in range(5**6):
 if lam in seen:continue
 orbit={PF.add(a,PF.scale(b,lam)) for a in range(5) for b in range(1,5)}
 for c in range(5):
  inv=PF.inv(PF.add(lam,PF.neg(c)))
  orbit.update(PF.add(a,PF.scale(b,inv)) for a in range(5) for b in range(1,5))
 assert not orbit&seen and len(orbit) in (20,120)
 seen|=orbit;prep.append(lam)
assert len(prep)==131 and len(seen)==15625
pbase=[[PF.trace(PF.mul(u[j],b)) for j in range(3) for b in pbasis] for u in PU]
p_low=set()
for lam in prep:
 rows=[[PF.trace(PF.mul(lam,PF.mul(u[j],b))) for j in range(3) for b in pbasis] for u in PU]
 rr0,pivs=rref(A.K,pbase+rows,18);kernel=[]
 for f in range(18):
  if f in pivs:continue
  v=[0]*18;v[f]=1
  for row,k in zip(rr0,pivs):v[k]=-row[f]%5
  kernel.append(tuple(PF.dot(v[6*j:6*j+6],pbasis) for j in range(3)))
 for cs in projective(5,len(kernel)):
  h=tuple(PF.dot(cs,[v[j] for v in kernel]) for j in range(3));iv=PF.inv(next(x for x in h if x));p_low.add(tuple(PF.mul(iv,x) for x in h))
assert p_low=={tuple(F.back(x) for x in h) for h in low}
primary_pairs={}
from tower_arithmetic import rank as primary_rank
for h in p_low:
 word=[PF.dot(h,u) for u in PU]
 assert primary_rank(A.K,[PF.digits(x) for x in word])==4
 if primary_rank(A.K,[PF.digits(x) for x in word[:4]])==4:
  assert primary_rank(A.K,[PF.digits(x)+PF.digits(u[2]) for x,u in zip(word,PU)])==8
  primary_pairs[h]=word
assert primary_pairs=={tuple(r['h']):r['word'] for r in disjoint}


result=dict(q=q,field=meta,U=model['U_columns'],J=model['J'],N=model['N'],scalar_types=len(reps),scalar_type_orbit_histogram={'20':1,'120':130},trace_kernel_dimensions={str(k):v for k,v in kh.items()},generated_projective_vectors=generated,low_rank_messages=[[F.back(x) for x in h] for h in sorted(low)],rank_histogram={str(k):v for k,v in hist.items()},ordinary_descending_points=[list(p) for p in sorted(descending)],local_multiplicity_histogram={str(k):v for k,v in local.items()},disjoint_from_fixed_section=len(disjoint),witness_pairs=disjoint,independent_projective_point_vectors=97656,independent_heavy_points=sorted(weights),primary_trace_cover_messages=len(p_low),seconds=time.time()-start)
json.dump(result,open(out/'sharp_complete.json','w'),separators=(',',':'))
print('low',hist,'kernels',kh,'zero pairs',len(disjoint),'local',local,'seconds',time.time()-start);print('firstwitness',disjoint[0])
