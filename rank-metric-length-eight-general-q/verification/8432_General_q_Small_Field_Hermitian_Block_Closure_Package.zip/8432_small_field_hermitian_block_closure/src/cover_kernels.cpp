// Complete threshold cover for the fixed quinary block system.
// Maintains assertions; never interprets a truncated traversal as a proof.
#include <array>
#include <vector>
#include <cstdlib>
#include <stdexcept>
#include <fstream>
#include <iostream>
#include <chrono>
#include <cassert>
#include <algorithm>
#include <set>
using namespace std;
constexpr int n=129,d=18;using Vec=array<int,18>;array<array<Vec,4>,n> Fns;int labels[n],threshold=51;
uint64_t visited=0,terminal=0,empty_count=0,dhist[19]={};int best=0;Vec bestvector{};std::set<uint64_t> high_words;
struct Kernel{int k=18;array<Vec,18> b{};Kernel(){for(int i=0;i<18;i++)b[i][i]=1;}};
Kernel intersect(const Kernel&V,int point){int c[4][18]={};for(int r=0;r<4;r++)for(int i=0;i<V.k;i++){int s=0;for(int j=0;j<18;j++)s+=Fns[point][r][j]*V.b[i][j];c[r][i]=s%5;}
 int piv[4],rank=0;bool is_piv[18]={};int inv[5]={0,1,3,2,4};
 for(int j=V.k-1;j>=0;j--){int a=rank;while(a<4&&!c[a][j])a++;if(a==4)continue;for(int u=0;u<V.k;u++)swap(c[a][u],c[rank][u]);int s=inv[c[rank][j]];for(int u=0;u<V.k;u++)c[rank][u]=c[rank][u]*s%5;
  for(int r=0;r<4;r++)if(r!=rank&&c[r][j]){int h=c[r][j];for(int u=0;u<V.k;u++)c[r][u]=(c[r][u]+25-h*c[rank][u])%5;}piv[rank++]=j;is_piv[j]=true;if(rank==4)break;}
 Kernel W;W.k=0;for(int free=0;free<V.k;free++)if(!is_piv[free]){Vec z{};for(int j=0;j<18;j++){int val=V.b[free][j];for(int r=0;r<rank;r++)val+=(5-c[r][free])*V.b[piv[r]][j];z[j]=val%5;}W.b[W.k++]=z;}
 assert(W.k==V.k-rank);return W;
}
bool small(const Kernel&V){terminal++;int k=V.k;assert(k>0&&k<=3);
 vector<array<int,3>> ps;for(int pivot=k-1;pivot>=0;pivot--){int lim=1;for(int i=0;i<pivot;i++)lim*=5;for(int rep=0;rep<lim;rep++){array<int,3>x{};x[pivot]=1;int u=rep;for(int j=0;j<pivot;j++){x[j]=u%5;u/=5;}ps.push_back(x);}}
 vector<int>hits(ps.size());for(int p=0;p<n;p++){int rows[4][3]={};for(int r=0;r<4;r++)for(int i=0;i<k;i++){int s=0;for(int j=0;j<18;j++)s+=Fns[p][r][j]*V.b[i][j];rows[r][i]=s%5;}
  for(size_t i=0;i<ps.size();i++){bool yes=true;for(int r=0;r<4&&yes;r++){int v=0;for(int j=0;j<k;j++)v+=ps[i][j]*rows[r][j];yes=v%5==0;}hits[i]+=yes;}}
 for(size_t i=0;i<hits.size();i++)if(hits[i]>best){best=hits[i];for(int j=0;j<18;j++){int s=0;for(int h=0;h<k;h++)s+=V.b[h][j]*ps[i][h];bestvector[j]=s%5;}cerr<<"max "<<best<<" nodes "<<visited<<"\n";}
 for(size_t i=0;i<hits.size();i++)if(hits[i]>=threshold){
  Vec v{};for(int j=0;j<18;j++){int s=0;for(int h=0;h<k;h++)s+=V.b[h][j]*ps[i][h];v[17-j]=s%5;}
  int pivot=0;while(!v[pivot])pivot++;int inv[5]={0,1,3,2,4};int c=inv[v[pivot]];uint64_t key=0,mult=1;
  for(int x:v){key+=mult*((x*c)%5);mult*=5;}high_words.insert(key);
 }
 return false;
}
bool search(const Kernel&V,int begin,int need){visited++;dhist[V.k]++;if(!V.k){empty_count++;return false;}if(V.k<=3)return small(V);if(need<=0)throw std::runtime_error("Larger threshold kernel requires enumeration; verification aborted.");if(n-begin<need)return false;
 // At least one zero must occur among the first n-begin-need+1 remaining positions.
 for(int p=begin;p<=n-need;p++){Kernel next=intersect(V,p);if(search(next,p+1,need-1))return true;}return false;
}
int main(int argc,char**argv){assert(argc>=3);ifstream f(argv[1]);int nn,dd,qq;f>>nn>>dd>>qq;assert(nn==n&&dd==d&&qq==5);for(int i=0;i<n;i++){f>>labels[i];for(auto&r:Fns[i])for(int&x:r){f>>x;if(!f||x<0||x>=5)throw std::runtime_error("Bad block coefficient");}}assert(f.good());if(argc>3)threshold=stoi(argv[3]);if(threshold!=12)throw std::runtime_error("The complete high-support threshold is fixed at 12.");
 auto t=chrono::steady_clock::now();Kernel V;bool found=search(V,0,threshold);assert(!found);ofstream out(argv[2]);out<<"{\"target_regular_zeros\":"<<threshold<<",\"early_exit\":"<<(found?"true":"false")<<",\"nodes\":"<<visited<<",\"leaves\":"<<terminal<<",\"empty\":"<<empty_count<<",\"maximum_encountered\":"<<best<<",\"example_reversed\":[";for(int i=0;i<18;i++){if(i)out<<",";out<<bestvector[i];}out<<"],\"dimension_histogram\":[";for(int i=0;i<19;i++){if(i)out<<",";out<<dhist[i];}out<<"],\"high_word_keys\":[";bool first=true;for(auto key:high_words){if(!first)out<<",";first=false;out<<key;}out<<"],\"seconds\":"<<chrono::duration<double>(chrono::steady_clock::now()-t).count()<<"}\n";cerr<<"EXACT HIGH WORDS "<<high_words.size()<<"\n";cerr<<"DONE "<<found<<" nodes "<<visited<<"\n";return 0;}
