#!/usr/bin/env python3
"""Rebuild the small-field Hermitian descent codes and independently replay the
complete high-zero-set covers. Python standard library + C++17 compiler.
This does not re-run the historical classification or formalize its proofs.
"""
from __future__ import annotations
import argparse,hashlib,json,os,re,shutil,subprocess,sys,time
from pathlib import Path

OUTPUTS=('blocks.json','independent_blocks.json','cover_rows.json','cover_kernels.json','graphs.json','sharp_points.json','sharp_complete.json','q4_blocks.json','q4_ind_blocks.json','q4_cover.json','q4_ind_cover.json','quaternary.json')

def math_only(x):
 if isinstance(x,dict):return {k:math_only(v) for k,v in x.items() if k not in {'seconds','elapsed_seconds'}}
 if isinstance(x,list):return [math_only(v) for v in x]
 return x

def check_tex(path):
 assert all(ord(c)>=32 or c in '\n\t\r' for c in path.read_text()), 'Control character in TeX fragment'
 text=re.sub(r'(?<!\\)%[^\n]*','',path.read_text());labels=re.findall(r'\\label\{([^}]+)\}',text);refs=re.findall(r'\\(?:ref|eqref)\{([^}]+)\}',text)
 assert len(set(labels))==len(labels) and set(refs)<=set(labels)
 stack=[]
 for typ,name in re.findall(r'\\(begin|end)\{([^}]+)\}',text):
  if typ=='begin':stack.append(name)
  else:assert stack and stack.pop()==name
 assert not stack
 return dict(labels=len(labels),internal_references=len(refs),scope='structural checks; not a complete IEEE manuscript')

def run(root:Path,out:Path,compare=True):
 if sys.flags.optimize:raise RuntimeError('Python assertions must remain enabled.')
 if out.exists() and any(out.iterdir()):raise RuntimeError('The work directory must be new or empty.')
 out.mkdir(parents=True,exist_ok=True);start=time.monotonic()
 if compare:
  for name,digest in json.loads((root/'MANIFEST.json').read_text()).items():
   assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
 cxx=os.environ.get('CXX') or shutil.which('g++') or shutil.which('clang++')
 if not cxx:raise RuntimeError('A C++17 compiler is required.')
 extra=os.environ.get('CXXFLAGS','').split()
 def execute(cmd,log):
  with (out/log).open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True,cwd=root)
 def py(name):execute([sys.executable,str(root/'src'/name),'--work',str(out)],name+'.log')
 def compile(stem):
  exe=out/stem
  execute([cxx,'-std=c++17','-O3','-UNDEBUG',*extra,str(root/'src'/f'{stem}.cpp'),'-o',str(exe)],stem+'_compile.log')
  return exe
 py('build_blocks.py');py('build_independent.py')
 for name,src,outname in [('cover_rows','blocks.txt','cover_rows.json'),('cover_kernels','ind_blocks.txt','cover_kernels.json')]:
  exe=compile(name);execute([str(exe),str(out/src),str(out/outname),'12'],name+'.log')
 a=json.loads((out/'cover_rows.json').read_text());b=json.loads((out/'cover_kernels.json').read_text())
 assert not a['early_exit'] and not b['early_exit']
 assert a['max_seen']==b['maximum_encountered']==12
 assert a['high_word_keys']==b['high_word_keys'] and len(a['high_word_keys'])==18
 py('check_graphs.py');exe=compile('sharp_points');execute([str(exe),str(out/'sharp_matrix.txt'),str(out/'sharp_points.json')],'sharp_points.log')
 py('check_complete_example.py')
 py('build_quaternary.py');py('build_quaternary_independent.py');qr=compile('cover_quaternary_rows');qe=compile('cover_quaternary')
 execute([str(qr),str(out/'q4_blocks.txt'),str(out/'q4_cover.json'),'11'],'q4_cover.log')
 execute([str(qe),str(out/'q4_ind_blocks.txt'),str(out/'q4_ind_cover.json'),'11'],'q4_ind_cover.log')
 py('check_quaternary.py')
 graph=json.loads((out/'graphs.json').read_text());complete=json.loads((out/'sharp_complete.json').read_text())
 assert graph['minimum_block_distance']==117 and len(graph['sharp_ordinary_descent_points'])==13
 assert complete['disjoint_from_fixed_section']==593 and complete['rank_histogram']=={'4':856}
 q4=json.loads((out/'quaternary.json').read_text());assert q4['status']=='passed' and q4['minimum_block_distance']==57 and q4['ordinary_descent_upper']==11
 if compare:
  for name in OUTPUTS:
   actual=json.loads((out/name).read_text());expected=json.loads((root/'results'/name).read_text())
   assert math_only(actual)==math_only(expected),name
 report=dict(status='passed',q=5,ordinary_points=130,regular_blocks=129,raw_graph_dimension=48,gauge_dimension=28,rank_three_family_dimension=2,
  effective_block_code_dimension=18,output_block_dimension=4,minimum_block_distance=117,maximum_regular_zero_blocks=12,
  extremal_projective_directions=18,all_ordinary_descent_upper=13,intersecting_graph_descent_lower='52+ceil(25*s/2)',
  primary_search_nodes=a['nodes'],primary_terminal_kernels=a['leaves'],independent_search_nodes=b['nodes'],independent_terminal_kernels=b['leaves'],
  independent_empty_kernels=b['empty'],extremal_direction_sets_equal=True,independent_raw_trace_point_blocks=129,
  independently_checked_scalar_rank_three_graphs=25,sharp_graph_actual_descents=13,sharp_graph_minimum_rank=4,sharp_graph_rank_four_messages=856,
  sharp_graph_complete_point_vectors=97656,sharp_graph_weight_two_points=3,sharp_graph_disjoint_codeword_pairs=593,
  independent_minimum_rank_affine_systems=156,tex=check_tex(root/'THEOREMS_en.tex'),quaternary_block_distance=q4['minimum_block_distance'],quaternary_descent_upper=q4['ordinary_descent_upper'],quaternary_Hermitian_excluded_s='s>=2',quaternary_independent_point_blocks=67,quaternary_primary_nodes=q4['primary_nodes'],quaternary_independent_nodes=q4['second_order_nodes'],saved_mathematical_outputs_compared=compare,
  scope='new quinary Hermitian special-section exclusion; additional quaternary Hermitian s>=2 exclusion; no classification of all q=4 or q=5 codes or heavy-fibre sections; no replay of the historical rank-six counts',
  elapsed_seconds=round(time.monotonic()-start,3))
 (out/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False,indent=2),flush=True)
 return report

def main():
 p=argparse.ArgumentParser();p.add_argument('--work',type=Path,required=True);args=p.parse_args()
 run(Path(__file__).resolve().parent,args.work.resolve(),True)
if __name__=='__main__':main()
