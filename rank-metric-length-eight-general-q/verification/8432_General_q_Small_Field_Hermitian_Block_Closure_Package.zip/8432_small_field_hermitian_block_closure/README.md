# Small-Field Hermitian Descent Block Codes

本包接续最新六秩结果，完整处理五元 Hermitian 特殊截面，并部分处理四元 Hermitian 特殊截面；不宣称已完成 q=4 或 q=5 的全部码分类。

## 主结论

129个非例外普通点的下降矩阵定义一个 F5-线性块码：基域维数18，每块4维，最小块重量117。非零图参数至多让12个非例外普通点满足下降条件；加入唯一例外点后总数至多13。目标相交性要求至少 `52+ceil(25s/2)` 个下降点，矛盾。

全部高零块参数由两套完整线性空间覆盖计算得到。它们输出同一组18个极值射影方向。程序不枚举全部 5^20 图，也不依赖限时搜索失败。

四元补充：67个4维输出块给出18维 GF(4) 块码，最小块重量57。非标量图的普通下降点至多11，排除 Hermitian 特殊截面中全局 s≥2 的对象；s=0,1继续保留。

一般接口：若必要下降块码的最小块重量为 delta_q，则固定截面的零交缺陷至少为 `(q−3)delta_q+q²s−theta_3(q)`。本轮只确定 q=4,5 的具体距离，不把数值外推到其他域。

## 文件

- `PROOF_zh.md`：完整中文证明、依赖与剩余边界。
- `THEOREMS_en.tex`：英文定理插入片段，需 amsmath/amssymb/amsthm 和 theorem/lemma/proof 环境。
- `src/build_blocks.py`：由输入三次法向量公式重建完整五元点矩阵。
- `src/build_independent.py`：由原始迹方程重建48坐标行块并比较实际行空间。
- `src/cover_rows.cpp`、`src/cover_kernels.cpp`：不同的完整高零块覆盖；需保留断言。
- `src/check_graphs.py`：检查全部极值方向、全部25个标量族秩三消息及一个达到13的实际图。
- `src/sharp_points.cpp`：明确图的全部基域射影向量检查。
- `src/check_complete_example.py`：独立点权，以及两套完整标量轨道迹交覆盖，恢复全部856条秩四消息和593个零交对。
- `src/build_quaternary.py`、`src/build_quaternary_independent.py`：两种算术完整生成四元点行块。
- `src/cover_quaternary_rows.cpp`、`src/cover_quaternary.cpp`：分别以方程行空间、共同核基作完整 GF(4) 覆盖。
- `src/check_quaternary.py`：检查块距离代表、16个标量秩三图和部分排除阈值。
- `vendor/`：明确复用的输入算术、原始迹重建和三次法向量模块。来源见 PROVENANCE.json。
- `inputs/`：最新研究记录、相关基线、锐界模型的具体坐标。
- `results/`：实际重算输出。计时字段可因机器改变，数学内容必须一致。

## 完整重算

需要 Python 3.10+ 标准库和 C++17 编译器。不需要第三方 Python 包、Sage、求解器或 OpenMP。

```bash
python verify.py --work /absolute/path/to/new_or_empty_directory
```

工作目录必须不存在或为空。不得使用 `python -O`；编译时明确保留断言。可用 CXX 指定编译器，用 CXXFLAGS 添加检查选项，例如：

```bash
CXX=clang++ CXXFLAGS="-fsanitize=undefined -fno-sanitize-recover=undefined -D_GLIBCXX_ASSERTIONS" python verify.py --work ../checked_recompute
```

验证从源码重建所有新矩阵并完整执行两条覆盖路径，不是只读取保存的结果。它不重跑历史六秩计数、二元终局或全部一般域归约。

## 覆盖边界

18个极值方向是图商上的 K-射影方向；递归节点和终端核可重复，不能相加当作互不等价图数量。明确锐界图具有最小秩4和三个普通重方向，但不是相交码。

英文片段只作结构与标签检查；本包不是重新编译的完整 IEEE 投稿稿件。一般数学证明仍应由项目外专家审阅。
