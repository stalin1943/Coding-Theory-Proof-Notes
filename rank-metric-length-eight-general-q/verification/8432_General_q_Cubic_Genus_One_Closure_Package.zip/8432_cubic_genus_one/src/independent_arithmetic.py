"""Polynomial-coefficient arithmetic for the independent check path.
No logarithm tables and no import from the uploaded code. Standard library only.
"""
from functools import lru_cache

class Base:
 def __init__(self,p,poly):
  self.p=p;self.pol=list(poly);self.d=len(poly)-1;self.q=p**self.d;q=self.q
  self.digits=[tuple((x//p**i)%p for i in range(self.d)) for x in range(q)]
  self.add=[[0]*q for _ in range(q)];self.mul=[[0]*q for _ in range(q)]
  for x in range(q):
   for y in range(q):
    a,b=self.digits[x],self.digits[y]
    self.add[x][y]=sum(((aa+bb)%p)*p**i for i,(aa,bb) in enumerate(zip(a,b)))
    c=[0]*(2*self.d-1)
    for i,aa in enumerate(a):
     for j,bb in enumerate(b):c[i+j]=(c[i+j]+aa*bb)%p
    for i in range(len(c)-1,self.d-1,-1):
     t=c[i]
     for j,v in enumerate(self.pol[:-1]):c[i-self.d+j]=(c[i-self.d+j]-t*v)%p
    self.mul[x][y]=sum(c[i]*p**i for i in range(self.d))
  self.neg=[next(y for y in range(q) if self.add[x][y]==0) for x in range(q)]
  self.inv=[0]+[next(y for y in range(1,q) if self.mul[x][y]==1) for x in range(1,q)]
 def sub(self,x,y):return self.add[x][self.neg[y]]

def base(q):
 for p in range(2,q+1):
  if q%p==0:break
 n=q;d=0
 while n%p==0:n//=p;d+=1
 if n!=1:raise ValueError('not a prime power')
 pol={4:[1,1,1],8:[1,1,0,1],9:[1,0,1],16:[1,1,0,0,1],25:[2,0,1]}
 return Base(p,[0,1] if d==1 else pol[q])

class Extension:
 def __init__(self,K,poly):
  self.K=K;self.q=K.q;self.pol=list(poly);self.n=len(poly)-1;self.Q=self.q**self.n
  self.dg=[tuple((x//self.q**i)%self.q for i in range(self.n)) for x in range(self.Q)]
  self.tr=None
 def pack(self,c):return sum(v*self.q**i for i,v in enumerate(c))
 def add(self,x,y):return self.pack([self.K.add[a][b] for a,b in zip(self.dg[x],self.dg[y])])
 def neg(self,x):return self.pack([self.K.neg[a] for a in self.dg[x]])
 def sub(self,x,y):return self.add(x,self.neg(y))
 @lru_cache(maxsize=240000)
 def mul(self,x,y):
  if not x or not y:return 0
  if x==1:return y
  if y==1:return x
  K=self.K;c=[0]*(2*self.n-1)
  for i,a in enumerate(self.dg[x]):
   if a:
    for j,b in enumerate(self.dg[y]):
     if b:c[i+j]=K.add[c[i+j]][K.mul[a][b]]
  for i in range(len(c)-1,self.n-1,-1):
   t=c[i]
   if t:
    for j,v in enumerate(self.pol[:-1]):c[i-self.n+j]=K.sub(c[i-self.n+j],K.mul[t][v])
  return self.pack(c[:self.n])
 def pow(self,x,n):
  z=1
  while n:
   if n&1:z=self.mul(z,x)
   n//=2
   if n:x=self.mul(x,x)
  return z
 def inv(self,x):
  assert x;z=self.pow(x,self.Q-2);assert self.mul(x,z)==1;return z
 def scalar(self,c,x):return self.pack([self.K.mul[c][a] for a in self.dg[x]])
 def trace(self,x):
  if self.tr is None:
   basis=[]
   for j in range(self.n):
    y=self.q**j;t=0
    for _ in range(self.n):t=self.add(t,y);y=self.pow(y,self.q)
    assert t<self.q;basis.append(t)
   self.tr=[]
   for dg in self.dg:
    z=0
    for a,b in zip(dg,basis):z=self.K.add[z][self.K.mul[a][b]]
    self.tr.append(z)
  return self.tr[x]
 def normalize(self,x):
  assert x;c=next(a for a in self.dg[x] if a);return self.scalar(self.K.inv[c],x)
 def dot(self,a,b):
  s=0
  for x,y in zip(a,b):s=self.add(s,self.mul(x,y))
  return s

def row_reduce(K,rows,n):
 a=[list(r) for r in rows];r=0;pivs=[]
 for j in range(n):
  p=next((i for i in range(r,len(a)) if a[i][j]),None)
  if p is None:continue
  a[p],a[r]=a[r],a[p];c=K.inv[a[r][j]];a[r]=[K.mul[c][x] for x in a[r]]
  for i in range(len(a)):
   if i!=r and a[i][j]:
    c=a[i][j];a[i]=[K.sub(x,K.mul[c][y]) for x,y in zip(a[i],a[r])]
  pivs.append(j);r+=1
  if r==len(a):break
 return a[:r],pivs

def rank(K,rows,n=None):
 if not rows:return 0
 return len(row_reduce(K,rows,n or len(rows[0]))[1])

def null(K,rows,n):
 a,pivs=row_reduce(K,rows,n);out=[]
 for j in range(n):
  if j in pivs:continue
  v=[0]*n;v[j]=1
  for r,p in zip(a,pivs):v[p]=K.neg[r[j]]
  out.append(v)
 return out

def irreducible(F):
 K=F.K;p=F.pol
 def trim(a):
  a=list(a)
  while len(a)>1 and a[-1]==0:a.pop()
  return a
 def rem(a,b):
  a=trim(a);b=trim(b)
  while any(a) and len(a)>=len(b):
   c=K.mul[a[-1]][K.inv[b[-1]]];off=len(a)-len(b)
   for j,v in enumerate(b):a[off+j]=K.sub(a[off+j],K.mul[c][v])
   a=trim(a)
  return a
 def gcd(a,b):
  while any(b):a,b=b,rem(a,b)
  return trim(a)
 n=F.n;primes=[d for d in range(2,n+1) if n%d==0 and all(d%k for k in range(2,int(d**.5)+1))]
 alpha=F.q
 for ell in primes:
  x=list(F.dg[F.pow(alpha,F.q**(n//ell))]);x[1]=K.sub(x[1],1)
  assert len(gcd(p,x))==1
 assert F.pow(alpha,F.q**n)==alpha
