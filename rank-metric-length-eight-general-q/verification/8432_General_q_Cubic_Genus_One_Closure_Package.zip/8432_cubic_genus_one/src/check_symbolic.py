#!/usr/bin/env python3
"""Integer polynomial checks of the explicit identities.
This is not formal verification of the descent argument or Hasse--Weil theorem.
"""
from pathlib import Path
import argparse,json,itertools as it,math
NAMES=['a0','a1','a2','t','beta','nu','mu','A0','A1','A2','c','n'];nvars=len(NAMES)

def constant(c):return {(0,)*nvars:c} if c else {}
def var(name):
 e=[0]*nvars;e[NAMES.index(name)]=1;return {tuple(e):1}
def add(*polys):
 out={}
 for p in polys:
  for e,c in p.items():out[e]=out.get(e,0)+c
 return {e:c for e,c in out.items() if c}
def neg(p):return {e:-c for e,c in p.items()}
def mul(a,b):
 out={}
 for ea,ca in a.items():
  for eb,cb in b.items():
   e=tuple(x+y for x,y in zip(ea,eb));out[e]=out.get(e,0)+ca*cb
 return {e:c for e,c in out.items() if c}
def scale(c,p):return {e:c*v for e,v in p.items() if c*v}
def prod(ps):
 out=constant(1)
 for p in ps:out=mul(out,p)
 return out
def reduce_mu(p):
 # Quotient relation mu^2=beta*mu+nu, with integer coefficients.
 out={};todo=list(p.items());im=NAMES.index('mu');ib=NAMES.index('beta');iv=NAMES.index('nu')
 while todo:
  e,c=todo.pop()
  if e[im]<2:out[e]=out.get(e,0)+c;continue
  a=list(e);a[im]-=1;a[ib]+=1;todo.append((tuple(a),c))
  b=list(e);b[im]-=2;b[iv]+=1;todo.append((tuple(b),c))
 return {e:c for e,c in out.items() if c}
def determinant(M):
 terms=[]
 for p in it.permutations(range(len(M))):
  sign=(-1)**sum(p[i]>p[j] for i in range(len(p)) for j in range(i+1,len(p)))
  terms.append(scale(sign,prod([M[i][p[i]] for i in range(len(M))])))
 return add(*terms)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
 a=[var('a'+str(i)) for i in range(3)];A=[var('A'+str(i)) for i in range(3)];t,beta,nu,mu,c=[var(x) for x in ['t','beta','nu','mu','c']]
 L=add(*a);Q=add(*[prod([A[i],a[i],a[(i+1)%3]]) for i in range(3)])
 sq=add(*[mul(x,x) for x in a]);cross=add(*[mul(a[i],a[(i+1)%3]) for i in range(3)])
 G=add(mul(t,t),prod([beta,t,L]),mul(c,Q),scale(-2,mul(nu,cross)),neg(mul(nu,sq)))
 fact=prod([add(t,mul(mu,L)),add(t,mul(add(beta,neg(mu)),L))])
 assert not reduce_mu(add(G,neg(fact),neg(mul(c,Q))))
 for root in [neg(mu),add(mu,neg(beta))]:
  assert not reduce_mu(add(mul(root,root),mul(beta,root),neg(nu)))
 gradient=[[{},A[0],A[2]],[A[0],{},A[1]],[A[2],A[1],{}]]
 det=determinant(gradient);assert det==scale(2,prod(A))
 rad=[A[1],A[2],A[0]]
 gradvals=[add(*[mul(x,y) for x,y in zip(row,rad)]) for row in gradient]
 assert all(all(c%2==0 for c in p.values()) for p in gradvals)
 qrad=add(*[prod([A[i],rad[i],rad[(i+1)%3]]) for i in range(3)])
 assert qrad==scale(3,prod(A))
 # Frobenius rotates the embedding index and interchanges the two quadratic roots.
 def frob(x):return tuple(1-x[(i-1)%3] for i in range(3))
 orbits=[];todo=set(it.product([0,1],repeat=3))
 while todo:
  x=min(todo);orbit=[];y=x
  while y not in orbit:orbit.append(y);y=frob(y)
  assert y==x;todo.difference_update(orbit);orbits.append(orbit)
 assert sorted(map(len,orbits))==[2,6]
 constants=next(o for o in orbits if len(o)==2)
 assert set(constants)=={(0,0,0),(1,1,1)}
 # Hilbert polynomial: multiply the Koszul expression by 6, avoiding division.
 n=var('n');one=constant(1)
 def shift(j):return add(n,constant(j))
 hilbert=add(prod([shift(3),shift(2),shift(1)]),scale(-2,prod([shift(1),n,shift(-1)])),prod([shift(-1),shift(-2),shift(-3)]))
 assert hilbert==scale(24,n)
 # The beta-z terms in the trace quotient cancel under cyclic reindexing.
 left=[(i,(i+1)%3,i) for i in range(3)]
 right=[(i,(i+2)%3,(i+2)%3) for i in range(3)]
 canon=lambda mon:(tuple(sorted(mon[:2])),mon[2])
 assert sorted(map(canon,left))==sorted(map(canon,right))
 report=dict(status='passed',integer_identities=['exceptional factorization','two distinct quadratic root formulas','gradient determinant 2*A0*A1*A2','characteristic-two polar radical and nonzero conic value','Koszul Hilbert polynomial 4n','cyclic trace cancellation'],
  root_label_frobenius_orbits=orbits,only_root_patterns_with_orbit_at_most_two=constants,
  scope='Exact finite symbolic identities over integers and all 8 root-label patterns; this is not a formal proof of geometric normalization, irreducibility descent, or Hasse--Weil.')
 args.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
