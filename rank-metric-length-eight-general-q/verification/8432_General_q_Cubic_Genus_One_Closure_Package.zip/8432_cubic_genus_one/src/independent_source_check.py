#!/usr/bin/env python3
"""Independently verify each original-space certificate and the dual coordinate change."""
from pathlib import Path
import argparse,json,time,collections
from independent_arithmetic import base,Extension,rank,null,irreducible

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--results',type=Path,required=True);args=ap.parse_args();root=Path(__file__).resolve().parents[1];start=time.time()
 old=json.loads((root/'inputs/old_residual_inputs.json').read_text());new=json.loads((args.results/'source_link.json').read_text())
 assert new['count']==len(old['records'])==1228
 byid={r['id']:r for r in old['records']};assert len(byid)==1228;assert {r['id'] for r in new['records']}==set(byid)
 totals=collections.Counter();trace_checks=0;field_checks=[]
 for mid,model in enumerate(new['models']):
  q=model['q'];K=base(q);F=Extension(K,model['polynomial']);irreducible(F);field_checks.append(q)
  mu=model['new_mu'];beta=model['beta'];nu=model['nu'];k=model['k'];s=model['change_s'];d=model['change_d'];l=model['lambda_value'];factor=model['dual_scale'];eta=F.sub(mu,beta)
  sq=F.pow(s,q);dq=F.pow(d,q)
  assert mu>=q and F.pow(mu,q*q)==mu and F.pow(mu,q)==F.sub(beta,mu)
  assert F.mul(mu,mu)==F.add(nu,F.mul(beta,mu))
  assert F.pow(l,q**3)==l and F.pow(l,q)!=l
  assert F.mul(factor,F.sub(F.scalar(K.add[1][1],mu),beta))==k
  def tr3(x):
   assert F.pow(x,q**3)==x
   return F.add(F.add(x,F.pow(x,q)),F.pow(x,q*q))
  assert tr3(k)==0 and tr3(F.mul(k,l))==0 and tr3(F.mul(k,F.mul(l,l)))==1
  def flatten(v):return [c for x in v for c in F.dg[x]]
  def action(w):return [F.mul(s,w[0]),F.mul(sq,w[1]),F.add(w[2],F.add(F.mul(d,w[0]),F.mul(dq,w[1])))]
  for r in new['records']:
   if r['model_id']!=mid:continue
   W=byid[r['id']]['W'];assert rank(K,[flatten(w) for w in W])==10
   equations=[[F.trace(F.mul(x,q**j)) for x in w for j in range(6)] for w in W]
   Ub=[[F.pack(v[6*j:6*j+6]) for j in range(3)] for v in null(K,equations,18)]
   assert len(Ub)==8
   A=r['A'];e=r['e'];assert F.pow(A,q**3)==A and A and F.pow(e,q**3)==e
   ratio=F.mul(F.add(e,K.mul[K.add[1][1]][nu]),F.inv(A));assert (ratio<q)==r['exceptional']
   def u(z,y,c,t):
    zz=F.add(F.mul(mu,F.pow(z,q)),F.scalar(beta,z));zz=F.sub(zz,F.pow(y,q));zz=F.add(zz,F.scalar(t,A));zz=F.sub(zz,F.scalar(c,e))
    return [zz,F.add(y,F.mul(eta,F.pow(z,q*q))),F.add(z,F.scalar(c,eta))]
   explicit=[u(z,0,0,0) for z in model['E_basis']]+[u(0,y,0,0) for y in model['E_basis']]+[u(0,0,1,0),u(0,0,0,1)]
   assert rank(K,[flatten(v) for v in explicit])==8
   for v in explicit:
    v=[F.mul(factor,x) for x in v]
    for w in W:
     assert F.trace(F.dot(v,action(w)))==0;trace_checks+=1
   if r['exceptional']:
    assert ratio==r['ratio'];v=r['vector'];mv=r['scaled_vector'];assert any(v)
    assert [F.mul(mu,x) for x in v]==mv
    assert rank(K,[flatten(v),flatten(mv)])==2
    assert rank(K,[flatten(v) for v in Ub]+[flatten(v),flatten(mv)])==8
    assert F.pow(mu,q**3)!=mu
    totals[q,'quadratic']+=1
   else:
    a=r['a'];t=r['t'];assert a and F.pow(a,q**3)==a and 0<=t<q
    aa=F.mul(a,F.pow(a,q));assert tr3(F.mul(A,aa))==0
    G=K.add[K.add[K.mul[t][t]][K.mul[beta][K.mul[t][tr3(a)]]]][K.sub(tr3(F.mul(e,aa)),K.mul[nu][tr3(F.mul(a,a))])]
    assert G==0
    hnew=[F.pow(a,q),F.pow(a,q*q),F.add(t,F.mul(mu,a))];h=r['message']
    assert action(h)==hnew
    words=[F.dot(h,v) for v in r['U_basis']];assert words==r['codeword']
    assert rank(K,[flatten(v) for v in Ub]+[flatten(v) for v in r['U_basis']])==8
    assert rank(K,[F.dg[x] for x in words])==3
    assert rank(K,[F.dg[F.dot(h,v)] for v in Ub])==3
    totals[q,'rank3']+=1
  F.mul.cache_clear()
  print('independent original-space certificates q',q,'passed',flush=True)
 out=dict(status='passed',fields=field_checks,original_models=1228,trace_orthogonality_checks=trace_checks,
 counts={str(q):{kind:totals[q,kind] for kind in ['rank3','quadratic']} for q in [3,4,5]},
 scope='Independent coefficient arithmetic and left-pivot elimination: all 1228 uploaded W spaces, full dual-coordinate linkage, and every new original-space certificate. This is a finite check, not the general-q proof.',seconds=round(time.time()-start,3))
 assert out['counts']==new['counts']
 (args.results/'independent_source.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
