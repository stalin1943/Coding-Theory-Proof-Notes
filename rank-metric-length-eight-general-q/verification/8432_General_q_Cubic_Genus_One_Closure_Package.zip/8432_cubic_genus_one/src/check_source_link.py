#!/usr/bin/env python3
"""Rebuild the new dual formula in all 1228 uploaded candidate spaces.
Uses the explicitly attributed, unchanged arithmetic from the preceding package.
The old enumeration is input; no old search is repeated.
"""
from pathlib import Path
import sys,json,argparse,itertools as it,time,collections
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'vendor'))
from tower_model import Model,Field,rank,null,solve,dot,scale,fs,vec

def pg(q,n):
 for j in range(n):
  for tail in it.product(range(q),repeat=n-j-1):yield [0]*j+[1]+list(tail)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);args=ap.parse_args();root=Path(__file__).resolve().parents[1]
 data=json.loads((root/'inputs/old_residual_inputs.json').read_text());start=time.time();records=[];models=[];counts=collections.Counter();trace_tests=0
 for mid,src in enumerate(data['models']):
  q=src['q'];old=Model(q,src['mu'],src['lambda_value']);F=old.F;K=old.K
  mu=next(x for x in range(q,F.Q) if F.pow(x,q*q)==x);new=Model(q,mu,old.lam)
  aa,bb=old.split(mu);assert bb
  s=F.pow(F.inv(bb),q);sq=F.pow(s,q);d=F.pow(F.neg(F.mul(aa,F.inv(bb))),q);dq=F.pow(d,q)
  def action(w):return [F.mul(s,w[0]),F.mul(sq,w[1]),fs(F,[w[2],F.mul(d,w[0]),F.mul(dq,w[1])])]
  def inverse(h):
   x=F.mul(h[0],F.inv(s));y=F.mul(h[1],F.inv(sq))
   return [x,y,fs(F,[h[2],F.neg(F.mul(d,x)),F.neg(F.mul(dq,y))])]
  nu,beta=new.split(F.mul(mu,mu));assert nu<q and beta<q
  two=K.add[1][1];den=F.add(F.scale(two,mu),F.neg(beta));k=old.kappa_weight;factor=F.mul(k,F.inv(den));eta=F.add(mu,F.neg(beta))
  l=old.lam;lq=F.pow(l,q);lq2=F.pow(l,q*q);common=F.inv(F.add(lq2,F.neg(lq)))
  f0=F.mul(F.add(l,F.neg(lq)),common);f1=F.mul(F.add(lq2,F.neg(l)),common)
  oldx=[[0,0,1]]+[[t,F.pow(t,q),F.mul(old.mu,F.pow(t,q*q))] for t in old.eb]
  newx=[[0,0,1]]+[[t,F.pow(t,q),F.mul(mu,F.pow(t,q*q))] for t in old.eb]
  assert rank(K,[vec(F,w) for w in newx]+[vec(F,action(w)) for w in oldx])==4
  models.append(dict(q=q,polynomial=F.pol,lambda_value=l,old_mu=old.mu,new_mu=mu,nu=nu,beta=beta,k=k,change_s=s,change_d=d,dual_scale=factor,E_basis=old.eb))
  basisF=[q**j for j in range(6)]
  traces=[[F.trace(F.mul(w,b)) for b in basisF] for w in range(F.Q)]
  trace_row=lambda w:[c for x in w for c in traces[x]]
  points=[old.element(c) for c in pg(q,3)];power={a:F.mul(a,F.pow(a,q)) for a in points}
  conic_cache={}
  for source in data['records']:
   if source['model_id']!=mid:continue
   W=source['W'];Wp=[action(w) for w in W];PP=[];values=[]
   for v in Wp[-2:]:
    a1,p=new.split(v[0]);a2,r=new.split(v[1]);c1,c2=new.split(v[2]);ff=F.add(F.mul(f0,F.pow(a1,q*q)),F.mul(f1,F.pow(a2,q)))
    b=F.add(c2,F.neg(ff));xi=F.mul(F.pow(k,q*q),F.inv(k))
    assert r==F.mul(xi,F.pow(p,q*q))
    assert b==F.neg(F.scale(beta,F.add(p,r)))
    PP.append(p);values.append(old.kappa(c1))
   TM=[[old.tr3(F.mul(p,e)) for e in old.eb] for p in PP]
   alpha=old.element(solve(K,TM,values));ann=old.element(null(K,TM,3)[0])
   A=F.mul(ann,F.inv(k));e=F.mul(alpha,F.inv(k));ratio=F.mul(F.add(e,K.mul[two][nu]),F.inv(A));special=ratio<q
   def u(z,y,c,t):return [fs(F,[F.mul(mu,F.pow(z,q)),F.scale(beta,z),F.neg(F.pow(y,q)),F.scale(t,A),F.neg(F.scale(c,e))]),fs(F,[y,F.mul(eta,F.pow(z,q*q))]),F.add(z,F.scale(c,eta))]
   Us=[u(z,0,0,0) for z in old.eb]+[u(0,y,0,0) for y in old.eb]+[u(0,0,1,0),u(0,0,0,1)]
   assert rank(K,[vec(F,v) for v in Us])==8
   for v in Us:
    vscaled=scale(F,factor,v)
    assert all(F.trace(dot(F,vscaled,w))==0 for w in Wp);trace_tests+=len(Wp)
   Uold=[list(F.pack(v[6*j:6*j+6]) for j in range(3)) for v in null(K,[trace_row(w) for w in W],18)]
   assert len(Uold)==8
   rec=dict(id=source['id'],model_id=mid,q=q,A=A,e=e,exceptional=special)
   if special:
    vv=[nu,nu,eta];assert u(0,nu,1,ratio)==vv
    vmu=scale(F,mu,vv);assert u(nu,K.mul[beta][nu],0,0)==vmu
    v=scale(F,factor,vv)
    # Original U = S^T ((k/(2mu-beta)) U').
    oldv=[F.add(F.mul(s,v[0]),F.mul(d,v[2])),F.add(F.mul(sq,v[1]),F.mul(dq,v[2])),v[2]]
    oldmv=scale(F,mu,oldv)
    assert all(F.trace(dot(F,w,t))==0 for w in W for t in [oldv,oldmv])
    assert rank(K,[vec(F,t) for t in Uold]+[vec(F,oldv),vec(F,oldmv)])==8
    rec.update(ratio=ratio,multiplier=mu,vector=oldv,scaled_vector=oldmv)
    counts[q,'quadratic']+=1
   else:
    if A not in conic_cache:conic_cache[A]=[a for a in points if old.tr3(F.mul(A,power[a]))==0]
    assert len(conic_cache[A])==q+1
    found=None
    for a in conic_cache[A]:
     c0=K.sub(old.tr3(F.mul(e,power[a])),K.mul[nu][old.tr3(F.mul(a,a))]);b0=K.mul[beta][old.tr3(a)]
     for t in range(q):
      if K.add[K.add[K.mul[t][t]][K.mul[b0][t]]][c0]==0:found=(a,t);break
     if found:break
    assert found is not None
    a,t=found;h=[F.pow(a,q),F.pow(a,q*q),F.add(t,F.mul(mu,a))];oldh=inverse(h)
    word=[dot(F,oldh,v) for v in Uold];assert rank(K,[F.digits(x) for x in word])==3
    rec.update(a=a,t=t,message=oldh,codeword=word,U_basis=Uold)
    counts[q,'rank3']+=1
   records.append(rec)
  print('source q',q,'all linked models checked',flush=True)
 result=dict(status='passed',models=models,records=records,count=len(records),trace_orthogonality_tests=trace_tests,
 counts={str(q):{kind:counts[q,kind] for kind in ['rank3','quadratic']} for q in [3,4,5]},
 scope='All 1228 uploaded residual W spaces, with explicitly verified F-linear coordinate change, dual formula, and a new rank-three or quadratic-fibre witness; not all codes.',seconds=round(time.time()-start,3))
 assert len(records)==1228
 assert result['counts']=={'3':{'rank3':104,'quadratic':13},'4':{'rank3':315,'quadratic':21},'5':{'rank3':744,'quadratic':31}}
 args.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['records','models']},indent=2))
if __name__=='__main__':main()
