#!/usr/bin/env python3
"""Finite checks of the new trace-conic dichotomy.
Only the explicitly listed A,e pairs are checked; the all-q proof is analytic.
"""
from pathlib import Path
import argparse,itertools as it,json,time,collections
from independent_arithmetic import base,Extension,rank,irreducible

def first_cubic(K):
 for c in range(1,K.q):
  for b in range(K.q):
   for a in range(K.q):
    if all(K.add[K.mul[K.add[K.mul[K.add[x][a]][x]][b]][x]][c] for x in range(K.q)):
     return [c,b,a,1]
 raise AssertionError('no cubic found')

def quadratic(K):
 for beta in range(K.q):
  for nu in range(1,K.q):
   if all(K.sub(K.sub(K.mul[t][t],K.mul[beta][t]),nu) for t in range(K.q)):
    return beta,nu
 raise AssertionError('no quadratic found')

class Tower:
 def __init__(self,E,beta,nu):self.E=E;self.K=E.K;self.beta=beta;self.nu=nu
 def add(self,x,y):return (self.E.add(x[0],y[0]),self.E.add(x[1],y[1]))
 def mul(self,x,y):
  E=self.E;z=E.mul(x[1],y[1]);return(E.add(E.mul(x[0],y[0]),E.mul(self.nu,z)),E.add(E.add(E.mul(x[0],y[1]),E.mul(x[1],y[0])),E.mul(self.beta,z)))
 def dot(self,x,y):
  z=(0,0)
  for a,b in zip(x,y):z=self.add(z,self.mul(a,b))
  return z
 def flat(self,v):return [t for c in v for x in c for t in self.E.dg[x]]
 def valdigits(self,c):return list(self.E.dg[c[0]])+list(self.E.dg[c[1]])
 def u(self,A,e,z,y,c,d):
  E=self.E;beta=self.beta;q=E.q
  return ((E.sub(E.add(E.sub(E.mul(beta,z),E.pow(y,q)),E.mul(A,d)),E.mul(e,c)),E.pow(z,q)),
    (E.sub(y,E.mul(beta,E.pow(z,q*q))),E.pow(z,q*q)),(E.sub(z,E.mul(beta,c)),c))
 def basis(self,A,e):
  E=self.E;b=[1,E.q,E.q*E.q]
  return [self.u(A,e,z,0,0,0) for z in b]+[self.u(A,e,0,y,0,0) for y in b]+[self.u(A,e,0,0,1,0),self.u(A,e,0,0,0,1)]

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);args=ap.parse_args();start=time.time();models=[];rows=[];tests=0
 for q in [2,3,4,5,7,8,9,11,13,16]:
  K=base(q);E=Extension(K,first_cubic(K));irreducible(E);beta,nu=quadratic(K);F=Tower(E,beta,nu)
  assert not any(E.sub(E.sub(E.mul(x,x),E.mul(beta,x)),nu)==0 for x in range(E.Q))
  pts=[a for a in range(1,E.Q) if E.normalize(a)==a];assert len(pts)==q*q+q+1
  # Complete normalized A classes only for q<=5; a fixed 3-class sample otherwise.
  As=pts if q<=5 else [pts[0],pts[len(pts)//2],pts[-1]]
  aquad={a:E.mul(a,E.pow(a,q)) for a in pts};atr={a:E.trace(a) for a in pts};asq={a:E.trace(E.mul(a,a)) for a in pts}
  fieldrec=dict(q=q,base_polynomial=K.pol,cubic_polynomial=E.pol,beta=beta,nu=nu,
     A_classes=len(As),all_normalized_A_classes=(q<=5));models.append(fieldrec)
  stats=collections.Counter();curvecounts=collections.Counter()
  for A in As:
   conic=[a for a in pts if E.trace(E.mul(A,aquad[a]))==0];assert len(conic)==q+1
   pivot=next(j for j,x in enumerate(E.dg[A]) if x);free=[j for j in range(3) if j!=pivot]
   for vals in it.product(range(q),repeat=2):
    ec=[0]*3
    for j,v in zip(free,vals):ec[j]=v
    e=E.pack(ec);ratio=E.mul(E.add(e,K.mul[K.add[1][1]][nu]),E.inv(A));exceptional=ratio<q
    points=[]
    for a in conic:
     c=K.sub(E.trace(E.mul(e,aquad[a])),K.mul[nu][asq[a]])
     b=K.mul[beta][atr[a]]
     for t in range(q):
      tests+=1
      if K.add[K.add[K.mul[t][t]][K.mul[b][t]]][c]==0:points.append((a,t))
    U=F.basis(A,e);Urows=[F.flat(v) for v in U];assert rank(K,Urows)==8
    record=dict(q=q,A=A,e=e,exceptional=exceptional,curve_point_count=len(points))
    if exceptional:
     assert points==[(a,0) for a in conic if atr[a]==0]
     v=((nu,0),(nu,0),(K.neg[beta],1));mv=tuple(F.mul((0,1),z) for z in v)
     assert v==F.u(A,e,0,nu,1,ratio)
     assert mv==F.u(A,e,nu,K.mul[beta][nu],0,0)
     assert rank(K,Urows+[F.flat(v),F.flat(mv)])==8
     assert rank(K,[F.flat(v),F.flat(mv)])==2
     record['ratio']=ratio;stats['quadratic']+=1
    else:
     assert points
     a,t=points[0];h=((E.pow(a,q),0),(E.pow(a,q*q),0),(t,a))
     assert rank(K,[F.valdigits(F.dot(h,v)) for v in U])==3
     record.update(a=a,t=t);stats['rank3']+=1;curvecounts[len(points)]+=1
    rows.append(record)
  assert stats['quadratic']==len(As)
  fieldrec['counts']=dict(stats);fieldrec['generic_curve_points_histogram']=dict(sorted(curvecounts.items()))
  E.mul.cache_clear();print('new trace-conic checks q',q,dict(stats),flush=True)
 out=dict(status='passed',models=models,cases=rows,case_count=len(rows),equation_evaluations=tests,
   scope='Complete normalized A,e parameter sets for q=2,3,4,5, and exactly three specified A classes with all their e cosets for q=7,8,9,11,13,16. These checks do not prove the uniform theorem.',seconds=round(time.time()-start,3))
 args.output.write_text(json.dumps(out,indent=2)+'\n');print('finite examples',len(rows),'equation evaluations',tests,'seconds',out['seconds'],flush=True)
if __name__=='__main__':main()
