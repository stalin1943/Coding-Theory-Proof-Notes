#!/usr/bin/env python3
"""Recompute the new checks, not the preceding classification programs.
Uses only Python's standard library. Assertions must stay enabled.
"""
from pathlib import Path
import argparse,hashlib,json,os,re,subprocess,sys,time

def math_data(x):
 if isinstance(x,dict):return {k:math_data(v) for k,v in x.items() if k not in ['seconds','elapsed_seconds']}
 if isinstance(x,list):return [math_data(v) for v in x]
 return x

def tex_check(path):
 s=path.read_text();clean=re.sub(r'(?<!\\)%[^\n]*','',s)
 labels=re.findall(r'\\label\{([^}]+)\}',clean);refs=re.findall(r'\\(?:eqref|ref)\{([^}]+)\}',clean)
 assert len(labels)==len(set(labels)) and set(refs)<=set(labels)
 depth=0
 for c in re.sub(r'\\[{}]','',clean):
  if c=='{':depth+=1
  if c=='}':depth-=1
  assert depth>=0
 assert depth==0
 stack=[]
 for op,name in re.findall(r'\\(begin|end)\{([^}]+)\}',clean):
  if op=='begin':stack.append(name)
  else:assert stack and stack.pop()==name
 assert not stack
 return dict(labels=len(labels),references=len(refs),scope='Braces, environments and internal references; no complete manuscript compilation.')

def main():
 p=argparse.ArgumentParser();p.add_argument('--work',type=Path,required=True);args=p.parse_args()
 if sys.flags.optimize:raise RuntimeError('Do not disable assertions.')
 root=Path(__file__).resolve().parent;work=args.work.resolve()
 if root==work or root in work.parents:raise ValueError('Work directory must be outside the extracted package.')
 if work.exists() and (not work.is_dir() or any(work.iterdir())):raise ValueError('Work directory must be new or empty.')
 work.mkdir(parents=True,exist_ok=True);start=time.time()
 manifest=json.loads((root/'MANIFEST.json').read_text())
 for name,digest in manifest.items():
  if hashlib.sha256((root/name).read_bytes()).hexdigest()!=digest:raise RuntimeError('File checksum mismatch: '+name)
 jobs=[('check_source_link.py',['--output',str(work/'source_link.json')],'source_link.json'),
       ('independent_source_check.py',['--results',str(work)],'independent_source.json'),
       ('check_quadrics.py',['--output',str(work/'quadric_checks.json')],'quadric_checks.json'),
       ('check_symbolic.py',['--output',str(work/'symbolic.json')],'symbolic.json')]
 env=dict(os.environ);env['PYTHONDONTWRITEBYTECODE']='1';checked=[]
 for name,cmd,result in jobs:
  t=time.time()
  with (work/(name+'.log')).open('w') as log:
   subprocess.run([sys.executable,'-u',str(root/'src'/name),*cmd],stdout=log,stderr=subprocess.STDOUT,check=True,env=env)
  got=json.loads((work/result).read_text());expected=json.loads((root/'results'/result).read_text())
  assert math_data(got)==math_data(expected),result
  checked.append(dict(script=name,result=result,all_mathematical_fields_match=True,seconds=round(time.time()-t,3)))
  print(name,'passed',flush=True)
 source=json.loads((work/'source_link.json').read_text());examples=json.loads((work/'quadric_checks.json').read_text())
 report=dict(status='passed',manifest_files=len(manifest),jobs=checked,
   source_models=source['count'],source_counts=source['counts'],trace_orthogonality_checks_per_path=source['trace_orthogonality_tests'],
   additional_quadric_parameter_pairs=examples['case_count'],quadric_equation_evaluations=examples['equation_evaluations'],
   tex=tex_check(root/'THEOREMS_en.tex'),seconds=round(time.time()-start,3),
   scope='New dual formula, all 1228 supplied original residual spaces and their explicit obstructions, independent arithmetic, specified trace-conic examples, and exact symbolic identities. Not formal verification of Hasse--Weil/descent and not full general-q code classification.')
 (work/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2),flush=True)
if __name__=='__main__':main()
