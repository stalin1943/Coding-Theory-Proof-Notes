#!/usr/bin/env python3
"""Recompute the new finite checks, then compare complete mathematical data.
The written proof, not this runner, establishes the uniform theorem.
"""
from pathlib import Path
import argparse,subprocess,json,hashlib,re,sys,time

JOBS=[('check_regulus.py','regulus.json'),('check_epsilon_one.py','epsilon_one.json'),('independent_check.py','independent.json'),('check_symbolic.py','symbolic.json'),('check_sextic_closure.py','closure.json'),('independent_closure.py','independent_closure.json')]

def tex_check(path):
 s=re.sub(r'(?<!\\)%[^\n]*','',path.read_text())
 labels=re.findall(r'\\label\{([^}]+)\}',s)
 refs=re.findall(r'\\(?:ref|eqref)\{([^}]+)\}',s)
 assert len(labels)==len(set(labels));assert set(refs)<=set(labels)
 stack=[]
 for op,name in re.findall(r'\\(begin|end)\{([^}]+)\}',s):
  if op=='begin':stack.append(name)
  else:assert stack and stack.pop()==name,(op,name)
 assert not stack
 balance=0
 for c in re.sub(r'\\[{}]','',s):
  if c=='{':balance+=1
  elif c=='}':balance-=1
  assert balance>=0
 assert balance==0
 return {'labels':len(labels),'internal_references':len(refs),'compiled':False,'scope':'braces, environments and internal references only'}

def run(root,work,compare=True):
 if not __debug__:raise RuntimeError('Do not disable assertions.')
 root=root.resolve();work=work.resolve()
 if work==root or root in work.parents:raise ValueError('Use a work directory outside the package.')
 if work.exists() and (not work.is_dir() or any(work.iterdir())):raise ValueError('Work directory must be new or empty.')
 work.mkdir(parents=True,exist_ok=True);start=time.perf_counter();manifest_count=0
 if compare:
  manifest=json.loads((root/'MANIFEST.json').read_text())
  for name,digest in manifest.items():
   if hashlib.sha256((root/name).read_bytes()).hexdigest()!=digest:raise RuntimeError('Manifest mismatch: '+name)
  manifest_count=len(manifest)
 for script,result in JOBS:
  cmd=[sys.executable,str(root/'src'/script)]
  cmd+=['--results',str(work)] if script.startswith('independent') else ['--output',str(work/result)]
  with (work/(script+'.log')).open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
  actual=json.loads((work/result).read_text());assert actual['status']=='passed'
  if compare:assert actual==json.loads((root/'results'/result).read_text()),result
  print(script,'passed',flush=True)
 A=json.loads((work/'regulus.json').read_text());B=json.loads((work/'epsilon_one.json').read_text());C=json.loads((work/'closure.json').read_text());D=json.loads((work/'independent_closure.json').read_text());E=json.loads((work/'independent.json').read_text())
 out={'status':'passed','date':'2026-09-13','all_saved_mathematical_outputs_match':compare,'manifest_files_checked':manifest_count,
 'epsilon_zero_cores':A['core_count'],'epsilon_zero_lifts':A['lift_count'],'epsilon_zero_grid_values':A['grid_evaluations'],'disjoint_support_pairs':A['explicit_witnesses'],
 'epsilon_one_initial_lifts':B['case_count'],'epsilon_one_initial_grid_values':B['grid_evaluations'],'independent_direct_six_by_six_determinants':E['direct_six_by_six_determinants'],
 'final_sextic_generators':C['field_models'],'final_parameter_models':C['final_models'],'curve_equation_checks_per_path':C['curve_equation_checks'],'trace_pairings_final_models_per_path':C['trace_pairings'],
 'rank_three_codewords':C['rank3_witnesses'],'quadratic_subfield_fibers':C['quadratic_fiber_witnesses'],'nonzero_z_weight_three_models':C['nonzero_z_models'],'additional_secant_formula_checks':C['additional_grid_checks'],
 'small_q_nonexceptional_without_affine_points':C['small_q_without_affine'],'independent_final_model_check':D['all_parameter_sets_and_outputs_match'],
 'tex':tex_check(root/'THEOREMS_en.tex'),
 'scope':'New sextic proof supplement only. Finite tests concern listed generators, their complete final q^2 parameter sets and selected grid lifts; uniform general-q conclusions rely on the analytic proof. No old small-field sextic exhaustion or global low-point classification is rerun.',
 'elapsed_seconds':round(time.perf_counter()-start,3)}
 (work/'verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2),flush=True);return out

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path,required=True);args=ap.parse_args();run(Path(__file__).resolve().parent,args.work)
if __name__=='__main__':main()
