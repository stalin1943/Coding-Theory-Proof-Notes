#!/usr/bin/env python3
"""Independent direct degree-six polynomial arithmetic, inverse by Euclid,
right-pivot elimination, and original 6x6 determinant coefficients.
Does not import the main checker or its tower arithmetic.
"""
from pathlib import Path
from functools import lru_cache
import json,itertools as it,argparse

class Base:
 def __init__(self,q):
  defs={4:(2,[1,1,1]),8:(2,[1,1,0,1]),9:(3,[1,0,1])}
  if q in defs:p,f=defs[q]
  else:p,f=q,[0,1]
  assert p>=2 and all(p%d for d in range(2,int(p**.5)+1))
  self.q=q;self.p=p;self.f=f;self.degree=len(f)-1
  self.add=[[0]*q for _ in range(q)];self.mul=[[0]*q for _ in range(q)]
  def digs(x):return [(x//p**i)%p for i in range(self.degree)]
  for a,b in it.product(range(q),repeat=2):
   x,y=digs(a),digs(b)
   self.add[a][b]=sum(((u+v)%p)*p**i for i,(u,v) in enumerate(zip(x,y)))
   c=[0]*(2*self.degree-1)
   for i,u in enumerate(x):
    for j,v in enumerate(y):c[i+j]=(c[i+j]+u*v)%p
   for j in range(len(c)-1,self.degree-1,-1):
    z=c[j]
    for k,d in enumerate(f[:-1]):c[j-self.degree+k]=(c[j-self.degree+k]-z*d)%p
   self.mul[a][b]=sum(c[i]*p**i for i in range(self.degree))
  self.neg=[next(b for b in range(q) if self.add[a][b]==0) for a in range(q)]
  self.inv=[0]+[next(b for b in range(1,q) if self.mul[a][b]==1) for a in range(1,q)]
 def sub(self,a,b):return self.add[a][self.neg[b]]
 def sum(self,seq):
  z=0
  for a in seq:z=self.add[z][a]
  return z

def trim(a):
 a=list(a)
 while len(a)>1 and a[-1]==0:a.pop()
 return a or [0]

def padd(K,a,b,minus=False):
 c=[0]*max(len(a),len(b))
 for i,x in enumerate(a):c[i]=x
 for i,x in enumerate(b):c[i]=K.sub(c[i],x) if minus else K.add[c[i]][x]
 return trim(c)

def pmul(K,a,b):
 c=[0]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  if x:
   for j,y in enumerate(b):
    if y:c[i+j]=K.add[c[i+j]][K.mul[x][y]]
 return trim(c)

def pdiv(K,a,b):
 a=trim(a);b=trim(b);assert any(b);out=[0]*max(1,len(a)-len(b)+1)
 while any(a) and len(a)>=len(b):
  j=len(a)-len(b);c=K.mul[a[-1]][K.inv[b[-1]]];out[j]=c
  for i,x in enumerate(b):a[i+j]=K.sub(a[i+j],K.mul[c][x])
  a=trim(a)
 return trim(out),a

def ppow(K,a,n,m):
 out=[1]
 while n:
  if n&1:out=pdiv(K,pmul(K,out,a),m)[1]
  n//=2
  if n:a=pdiv(K,pmul(K,a,a),m)[1]
 return out

class Field:
 def __init__(self,q,f):
  self.q=q;self.Q=q**6;self.K=K=Base(q);self.f=list(f)
  for d in [2,3]:
   a=padd(K,ppow(K,[0,1],q**d,f),[0,1],True);b=f
   while any(a):b,a=a,pdiv(K,b,a)[1]
   assert len(trim(b))==1
  assert ppow(K,[0,1],q**6,f)==[0,1]
  self.trbasis=[]
  for i in range(6):
   x=q**i;z=0
   for _ in range(6):z=self.add(z,x);x=self.pow(x,q)
   assert z<q;self.trbasis.append(z)
 @lru_cache(maxsize=100000)
 def digits(self,x):return tuple((x//self.q**i)%self.q for i in range(6))
 def pack(self,c):return sum(a*self.q**i for i,a in enumerate(c))
 def add(self,a,b):return self.pack([self.K.add[x][y] for x,y in zip(self.digits(a),self.digits(b))])
 def neg(self,a):return self.pack([self.K.neg[x] for x in self.digits(a)])
 @lru_cache(maxsize=150000)
 def mul(self,a,b):
  c=pdiv(self.K,pmul(self.K,self.digits(a),self.digits(b)),self.f)[1]
  return self.pack(c)
 @lru_cache(maxsize=20000)
 def inv(self,a):
  assert a;r0=self.f;r1=trim(self.digits(a));s0=[0];s1=[1]
  while any(r1):
   q,r2=pdiv(self.K,r0,r1);r0,r1=r1,r2;s0,s1=s1,padd(self.K,s0,pmul(self.K,q,s1),True)
  assert len(r0)==1
  z=pdiv(self.K,[self.K.mul[self.K.inv[r0[0]]][x] for x in s0],self.f)[1]
  out=self.pack(z);assert self.mul(a,out)==1;return out
 def pow(self,a,n):
  out=1
  while n:
   if n&1:out=self.mul(out,a)
   n//=2
   if n:a=self.mul(a,a)
  return out
 def trace(self,a):return self.K.sum(self.K.mul[x][y] for x,y in zip(self.digits(a),self.trbasis))
 def dot(self,a,b):
  z=0
  for x,y in zip(a,b):z=self.add(z,self.mul(x,y))
  return z

def echelon(K,rows,n):
 A=[list(a) for a in rows];r=0;piv=[]
 for j in range(n-1,-1,-1):
  p=next((i for i in range(r,len(A)) if A[i][j]),None)
  if p is None:continue
  A[r],A[p]=A[p],A[r];iv=K.inv[A[r][j]];A[r]=[K.mul[iv][x] for x in A[r]]
  for i in range(len(A)):
   if i!=r and A[i][j]:
    c=A[i][j];A[i]=[K.sub(x,K.mul[c][y]) for x,y in zip(A[i],A[r])]
  piv.append(j);r+=1
  if r==len(A):break
 return A[:r],piv

def rank(K,rows):return len(echelon(K,rows,len(rows[0]))[1]) if rows else 0

def det(K,A):
 A=[list(x) for x in A];r=0;out=1;n=len(A)
 # Reverse both row and column traversal; reversing both preserves determinant.
 A=[list(reversed(row)) for row in reversed(A)]
 for j in range(n):
  p=next((i for i in range(j,n) if A[i][j]),None)
  if p is None:return 0
  if p!=j:A[j],A[p]=A[p],A[j];out=K.neg[out]
  z=A[j][j];out=K.mul[out][z];iz=K.inv[z]
  for i in range(j+1,n):
   c=K.mul[A[i][j]][iz]
   for k in range(j+1,n):A[i][k]=K.sub(A[i][k],K.mul[c][A[j][k]])
 return out

def normalized(K,a):
 v=next(x for x in a if x);iv=K.inv[v];return [K.mul[iv][x] for x in a]

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--results',type=Path,required=True);args=ap.parse_args()
 first=json.loads((args.results/'regulus.json').read_text());second=json.loads((args.results/'epsilon_one.json').read_text());fields={};grids=0;traces=0;detcoeff=0;witnesses=0
 def get(row):
  key=(row['q'],tuple(row['polynomial']))
  if key not in fields:fields[key]=Field(*key)
  return fields[key]
 for row in first['cases']:
  F=get(row);K=F.K;q=F.q;l=q;m=row['mu'];u=row['u'];v=row['v'];l2=F.mul(l,l);l3=F.mul(l2,l)
  assert rank(K,[F.digits(x) for x in [1,l,m,F.mul(l,m)]])==4
  X=[[1,0,0],[0,1,0],[l,0,1],[0,l,m]];W=X+[[F.mul(l,z) for z in x] for x in X]+[[l3,0,u],[0,l3,v]]
  assert rank(K,[sum([list(F.digits(x)) for x in w],[]) for w in W])==10
  # Form the original six-dimensional determinant, with no quotient or wedge helpers.
  plus=[x if j%2==0 else K.neg[x] for j,x in enumerate(F.f)];E=[0]*6;E[5]=1
  for j in range(5,0,-1):E[j-1]=F.add(plus[j],F.neg(F.mul(l,E[j])))
  aa=[F.add(u,F.neg(l2)),l];bb=[F.add(v,F.neg(F.mul(m,l2))),F.mul(m,l)]
  N=[[0]*7 for _ in range(7)]
  for i,j in it.product(range(6),repeat=2):
   for r,s in it.product(range(2),repeat=2):
    val=det(K,[F.digits(x) for x in [1,m,E[i],F.mul(m,E[j]),aa[r],bb[s]]])
    N[i+r][j+s]=K.add[N[i+r][j+s]][val];detcoeff+=1
  assert all(not N[i][j] for i,j in it.product(range(7),repeat=2) if i>=5 or j>=5)
  assert normalized(K,[N[i][j] for i,j in it.product(range(5),repeat=2)])==normalized(K,sum(row['coefficients'],[]))
  bad=0
  for g in row['grid']:
   s,t=g['s'],g['t'];h=[0 if s is None else F.neg(F.inv(F.add(l,s))),0 if t is None else F.neg(F.mul(m,F.inv(F.add(l,t)))),1]
   r=rank(K,[F.digits(F.dot(h,w)) for w in W]);assert r==g['rank'];bad+=r==6;grids+=1
  assert bad==row['bad_grid_pairs']
  if q>=4:assert bad>=(q-3)**2
  if row['has_grid_witness']:
   e=row['witness'];U=e['U_columns'];assert len(U)==8 and rank(K,[sum([list(F.digits(x)) for x in a],[]) for a in U])==8
   for a,w in it.product(U,W):assert F.trace(F.dot(a,w))==0;traces+=1
   words=[[F.dot(h,a) for a in U] for h in [e['x'],e['y']]];assert words==e['words']
   mats=[[[F.digits(x)[j] for x in word] for j in range(6)] for word in words]
   assert [rank(K,mats[0]),rank(K,mats[1]),rank(K,mats[0]+mats[1])]==[4,4,8];witnesses+=1
 for row in second['cases']:
  F=get(row);K=F.K;q=F.q;l=q;c=row['c'];u=row['u'];v=row['v'];l2=F.mul(l,l);l3=F.mul(l2,l);il=F.inv(l)
  A=F.digits(F.mul(l2,c));Z=F.digits(F.add(F.mul(l,v),F.mul(l3,c)));f5=F.f[5]
  lead=[K.sub(K.mul[f5][Z[5]],Z[4]),K.sub(K.add[Z[5]][K.mul[f5][A[5]]],A[4]),A[5],0,0]
  assert lead==row['leading_coefficient'];assert (not any(lead))==row['three_constraints_hold']
  X=[[0,0,1],[l,0,0],[0,1,0],[1,F.neg(l),c]];W=X+[[F.mul(l,z) for z in x] for x in X]+[[l3,0,u],[0,l3,v]]
  for s,t,r,_ in row['grid']:
   h=[F.neg(F.mul(s,il)),0 if t is None else F.mul(F.add(F.mul(s,il),F.neg(c)),F.inv(F.add(t,F.neg(l)))),1]
   assert rank(K,[F.digits(F.dot(h,w)) for w in W])==r;grids+=1
  if q>=4 and any(lead):assert row['rank_six_witness'] is not None
 out=dict(status='passed',direct_field_models=len(fields),epsilon_zero_lifts=first['lift_count'],epsilon_one_lifts=second['case_count'],direct_six_by_six_determinants=detcoeff,grid_ranks_checked=grids,trace_orthogonality_pairs=traces,explicit_disjoint_support_pairs=witnesses,all_saved_data_match=True,scope='independent arithmetic and direct determinant/rank checks for the listed finite examples; not a formal proof of the uniform theorem')
 (args.results/'independent.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2),flush=True)
if __name__=='__main__':main()
