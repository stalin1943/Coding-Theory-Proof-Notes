#!/usr/bin/env python3
"""Characteristic-free identities in sparse Laurent polynomial rings over Z.
No computer-algebra package is imported. Negative z exponents are only used
in the explicitly localized nonzero-z branch of the written proof.
"""
from pathlib import Path
import itertools as it,json,argparse
NAMES='S T a z f0 f1 f2 f3 f4 f5 u0 u3 u4 u5 r v L p h P w'.split();n=len(NAMES);zero=(0,)*n

def con(a):return {} if a==0 else {zero:a}
def var(name,e=1):
 x=[0]*n;x[NAMES.index(name)]=e;return {tuple(x):1}
def add(*ps):
 out={}
 for p in ps:
  for m,c in p.items():out[m]=out.get(m,0)+c
 return {m:c for m,c in out.items() if c}
def neg(p):return {m:-c for m,c in p.items()}
def sub(a,b):return add(a,neg(b))
def mul(*ps):
 out=con(1)
 for p in ps:
  z={}
  for a,c in out.items():
   for b,d in p.items():
    m=tuple(x+y for x,y in zip(a,b));z[m]=z.get(m,0)+c*d
  out={m:c for m,c in z.items() if c}
 return out
def power(p,e):
 assert e>=0;out=con(1)
 for _ in range(e):out=mul(out,p)
 return out
def determinant(M):
 d={};k=len(M)
 for perm in it.permutations(range(k)):
  inversions=sum(perm[i]>perm[j] for i in range(k) for j in range(i+1,k))
  term=mul(*(M[i][perm[i]] for i in range(k)))
  d=add(d,neg(term) if inversions%2 else term)
 return d
def detcols(*cols):return determinant([list(r) for r in zip(*cols)])
def coefficient(p,**fixed):
 inds={NAMES.index(k):v for k,v in fixed.items()};out={}
 for m,c in p.items():
  if all(m[i]==e for i,e in inds.items()):
   x=list(m)
   for i in inds:x[i]=0
   t=tuple(x);out[t]=out.get(t,0)+c
 return {m:c for m,c in out.items() if c}
def subst(p,subs):
 inds={NAMES.index(k):v for k,v in subs.items()};out={}
 for m,c in p.items():
  x=list(m);term=con(c)
  for i,v in inds.items():
   assert x[i]>=0;term=mul(term,power(v,x[i]));x[i]=0
  out=add(out,mul(term,{tuple(x):1}))
 return out

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);args=ap.parse_args();env={s:var(s) for s in NAMES};globals().update(env)
 one=con(1);two=con(2)
 f=add(power(T,6),*[mul(env[f'f{i}'],power(T,i)) for i in range(6)])
 q0=add(power(T,5),*[mul(env[f'f{i}'],power(T,i-1)) for i in range(1,6)])
 qvec=[q0,add(power(T,2),mul(f5,T),f4),add(T,f5),one]
 first=[sub(mul(f1,z),S),add(a,mul(f4,z)),mul(f5,z),z]
 third=[u0,sub(u3,S),u4,u5]
 fourth=[sub(r,mul(f0,z,T)),v,mul(a,add(T,f5)),a]
 residue=[add(neg(mul(a,power(T,3))),mul(f1,z)),mul(f4,z),mul(f5,z),z]
 DtimesT=add(mul(sub(sub(mul(a,power(T,4)),mul(f0,z)),mul(S,T)),detcols(first,qvec,third,fourth)),mul(f,detcols(first,residue,third,fourth)))
 assert all(m[NAMES.index('T')]>=1 for m in DtimesT)
 D=mul(DtimesT,var('T',-1));assert all(m[NAMES.index('S')]<=2 and m[NAMES.index('T')]<=4 for m in D)
 assert coefficient(D,S=2,T=3)==neg(mul(a,u5))
 assert subst(coefficient(D,S=2,T=2),{'a':{}})==neg(mul(f0,power(z,2)))
 D1=subst(D,{'a':one,'u5':{}})
 assert coefficient(D1,S=2,T=2)==sub(u4,mul(f0,power(z,2)))
 D2=subst(D1,{'u4':mul(f0,power(z,2))})
 assert coefficient(D2,S=2,T=1)==mul(z,add(r,mul(f0,f5,z)))
 assert coefficient(D2,S=2,T=0)==mul(f0,z,add(one,mul(f4,z),neg(mul(z,v))))
 D3=subst(D2,{'r':neg(mul(f0,f5,z)),'v':add(f4,var('z',-1))})
 assert coefficient(D3,S=1,T=3)==neg(mul(z,add(u0,mul(power(f0,2),power(z,3)))))
 D4=subst(D3,{'u0':neg(mul(power(f0,2),power(z,3)))})
 assert coefficient(D4,S=1,T=2)==mul(f0,power(z,2),sub(sub(u3,mul(f1,z)),mul(f0,f5,power(z,2))))
 assert not subst(D4,{'u3':add(mul(f1,z),mul(f0,f5,power(z,2)))})
 assert not subst(D,{'z':{},'u4':{},'u5':{}})
 # Rank-three curve and the codeword identity, without dividing by 2 or 3.
 H=add(p,mul(sub(h,f4),r),neg(mul(f5,power(r,2))))
 J=add(f0,mul(f1,r),mul(f2,power(r,2)),mul(add(f3,p),power(r,3)),mul(h,power(r,4)))
 fr=add(power(r,6),*[mul(env[f'f{i}'],power(r,i)) for i in range(6)])
 assert not sub(add(power(r,6),neg(mul(H,power(r,3))),J),fr)
 fL=add(power(L,6),*[mul(env[f'f{i}'],power(L,i)) for i in range(6)])
 N=add(mul(f0,sub(L,r)),neg(mul(add(p,mul(r,h)),power(L,3),sub(L,r))),neg(mul(r,f5,power(L,4),sub(L,r))),mul(sub(P,mul(r,power(L,2))),sub(power(L,3),w),L),mul(w,power(L,3),sub(L,r)))
 Br=add(mul(add(f3,p),r),mul(h,power(r,2)));Ar=add(mul(r,Br),mul(f2,r))
 Rhs=add(neg(mul(r,fL)),mul(power(L,4),sub(add(P,w),H)),mul(L,sub(J,mul(P,w))))
 assert not sub(sub(N,mul(L,sub(L,r),add(Ar,mul(Br,L)))),Rhs)
 out=dict(status='passed',ring='integer sparse Laurent polynomials; localization only at z for the explicitly nonzero-z branch',post_leading_grid_degree_S=2,post_leading_grid_degree_T=4,expanded_grid_terms=len(D),grid_coefficient_relations_verified=6,nonzero_z_substitution_is_identically_zero=True,zero_z_substitution_is_identically_zero=True,sextic_curve_identity=True,rank_three_codeword_identity=True,no_division_by_characteristic=True,scope='specified characteristic-free polynomial identities; geometry and normalization are justified in the written proof')
 args.output.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
