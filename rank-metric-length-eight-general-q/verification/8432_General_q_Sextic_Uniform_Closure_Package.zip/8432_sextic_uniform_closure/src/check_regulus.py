#!/usr/bin/env python3
"""Finite, explicit checks for the new sextic epsilon-zero proof.
The uniform theorem is the accompanying proof, not these examples.
Reuses the supplied tower arithmetic with source attribution.
"""
from pathlib import Path
import sys,itertools as it,json,random,argparse
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'vendor'))
from tower_arithmetic import Tower,rank,rref

PAIRS=list(it.combinations(range(4),2));QPAIRS=list(it.combinations_with_replacement(range(4),2))

def null(K,A,n):
 R,piv=rref(K,A,n);out=[]
 for j in range(n):
  if j in piv:continue
  x=[0]*n;x[j]=1
  for row,p in zip(R,piv):x[p]=K.neg[row[j]]
  out.append(x)
 return out

def solve(K,A,b):
 R,piv=rref(K,[list(r)+[c] for r,c in zip(A,b)],len(A[0])+1)
 assert len(A[0]) not in piv
 x=[0]*len(A[0])
 for r,p in zip(R,piv):x[p]=r[-1]
 return x

def kdot(K,a,b):return K.sum(K.mul[x][y] for x,y in zip(a,b))
def vadd(K,a,b):return [K.add[x][y] for x,y in zip(a,b)]
def vneg(K,a):return [K.neg[x] for x in a]
def vscale(K,c,a):return [K.mul[c][x] for x in a]
def wedge(K,a,b):return [K.sub(K.mul[a[i]][b[j]],K.mul[a[j]][b[i]]) for i,j in PAIRS]
def vol(K,a,b):
 return K.sum([K.mul[a[0]][b[5]],K.neg[K.mul[a[1]][b[4]]],K.mul[a[2]][b[3]],K.mul[a[3]][b[2]],K.neg[K.mul[a[4]][b[1]]],K.mul[a[5]][b[0]]])
def det(K,A):
 A=[list(x) for x in A];d=1
 for j in range(len(A)):
  p=next((i for i in range(j,len(A)) if A[i][j]),None)
  if p is None:return 0
  if p!=j:A[p],A[j]=A[j],A[p];d=K.neg[d]
  z=A[j][j];d=K.mul[d][z];iz=K.inv[z]
  for i in range(j+1,len(A)):
   c=K.mul[A[i][j]][iz]
   for k in range(j+1,len(A)):A[i][k]=K.sub(A[i][k],K.mul[c][A[j][k]])
 return d

def trim(p):
 p=list(p)
 while len(p)>1 and not p[-1]:p.pop()
 return p

def prem(K,a,b):
 a=trim(a);b=trim(b)
 while any(a) and len(a)>=len(b):
  c=K.mul[a[-1]][K.inv[b[-1]]];j=len(a)-len(b)
  for i,v in enumerate(b):a[i+j]=K.sub(a[i+j],K.mul[c][v])
  a=trim(a)
 return a

def pgcd(K,a,b):
 while any(b):a,b=b,prem(K,a,b)
 return trim(a)

def keval(K,p,x):
 z=0
 for c in reversed(p):z=K.add[K.mul[z][x]][c]
 return z

def normpoly(F,l,sign=1):
 p=[1];x=l
 for _ in range(6):
  a=x if sign==1 else F.neg(x);new=[0]*(len(p)+1)
  for i,c in enumerate(p):new[i]=F.add(new[i],F.mul(a,c));new[i+1]=F.add(new[i+1],c)
  p=new;x=F.pow(x,F.q)
 assert x==l and all(c<F.q for c in p)
 return p

def polyquad(K,P):
 rows=[[0]*len(QPAIRS) for _ in range(9)]
 for k,(a,b) in enumerate(QPAIRS):
  for i in range(5):
   for j in range(5):rows[i+j][k]=K.add[rows[i+j][k]][K.mul[P[i][a]][P[j][b]]]
 return rows

def trace_dual(F,W):
 e=[F.from_digits([int(i==j) for i in range(6)]) for j in range(6)]
 A=[[F.trace(F.mul(w[k],z)) for k in range(3) for z in e] for w in W]
 return [[F.from_digits(v[6*k:6*k+6]) for k in range(3)] for v in null(F.K,A,18)]

def setup(F,l,m):
 K=F.K;lp=[1]
 for _ in range(5):lp.append(F.mul(lp[-1],l))
 assert rank(K,[F.digits(x) for x in lp])==6
 R=[list(F.digits(x)) for x in [1,m]];P=null(K,R,6);assert len(P)==4
 proj=lambda x:[kdot(K,r,F.digits(x)) for r in P]
 f=normpoly(F,l,1);E=[0]*6;E[5]=1
 for i in range(5,0,-1):E[i-1]=F.add(f[i],F.neg(F.mul(l,E[i])))
 assert F.mul(l,E[0])==f[0]
 C=[proj(x) for x in E];D=[proj(F.mul(m,x)) for x in E]
 assert C[5]==D[5]==[0]*4
 assert C[4]==vneg(K,proj(l));assert D[4]==vneg(K,proj(F.mul(m,l)))
 common=null(K,polyquad(K,C[:5])+polyquad(K,D[:5]),10);assert len(common)==1
 cb=[1,l,m,F.mul(l,m)];assert rank(K,[F.digits(x) for x in cb])==4
 e=[F.from_digits([int(i==j) for i in range(6)]) for j in range(6)]
 ann=null(K,[[F.trace(F.mul(c,x)) for x in e] for c in cb],6)
 d0,d1=[F.from_digits(x) for x in ann]
 funcs=[[F.trace(F.mul(a,z)) for z in e] for a in [d0,d1,F.mul(l,d0),F.mul(l,d1)]]
 formrank=rank(K,funcs);assert formrank in [3,4]
 pre=[F.from_digits(solve(K,P,[int(i==j) for i in range(4)])) for j in range(4)]
 L=[[F.trace(F.mul(a,z)) for z in pre] for a in [d0,d1,F.mul(l,d0),F.mul(l,d1)]]
 qvec=[]
 for i,j in QPAIRS:
  c=K.sub(K.mul[L[0][i]][L[3][j]],K.mul[L[1][i]][L[2][j]])
  if i!=j:c=K.add[c][K.sub(K.mul[L[0][j]][L[3][i]],K.mul[L[1][j]][L[2][i]])]
  qvec.append(c)
 assert rank(K,[common[0],qvec])==1 and any(qvec)
 ruling=[]
 for multiplier in [1,m]:
  rr=[[F.trace(F.mul(F.mul(multiplier,a),z)) for z in E] for a in [d0,d1]]
  second=[[F.trace(F.mul(F.mul(multiplier,F.mul(l,a)),z)) for z in E] for a in [d0,d1]]
  for a,b in zip(rr,second):
   assert trim(b)==trim([0]+[K.neg[x] for x in a])
  degree=max(len(trim(x))-1 for x in rr)
  gcddeg=len(pgcd(K,*rr))-1
  if formrank==4:assert degree==3 and gcddeg==0
  ruling.append({'row_polynomial_degree':degree,'row_gcd_degree':gcddeg})
 # Conversion from tower coordinates to the lambda power basis.
 invrows=[solve(K,[list(F.digits(x)) for x in lp],[int(i==j) for i in range(6)]) for j in range(6)]
 # Each solved column is the dual coordinate functional.
 enc=lambda x:sum(kdot(K,invrows[j],F.digits(x))*F.q**j for j in range(6))
 assert all(enc(x)==F.q**i for i,x in enumerate(lp))
 return dict(P=P,proj=proj,f=f,E=E,C=C,D=D,common=common[0],quad=qvec,formrank=formrank,ruling=ruling,enc=enc,minpoly=normpoly(F,l,-1))

def case(F,l,m,u,v,M,caseid):
 K=F.K;proj=M['proj'];e=M['E'];l2=F.mul(l,l);l3=F.mul(l2,l)
 a0=proj(F.add(u,F.neg(l2)));a1=proj(l)
 b0=proj(F.add(v,F.neg(F.mul(m,l2))));b1=proj(F.mul(m,l))
 aa=[[0]*6 for _ in range(7)];bb=[[0]*6 for _ in range(7)]
 for i in range(6):
  aa[i]=vadd(K,aa[i],wedge(K,M['C'][i],a0));aa[i+1]=vadd(K,aa[i+1],wedge(K,M['C'][i],a1))
  bb[i]=vadd(K,bb[i],wedge(K,M['D'][i],b0));bb[i+1]=vadd(K,bb[i+1],wedge(K,M['D'][i],b1))
 assert not any(aa[5]+aa[6]+bb[5]+bb[6])
 assert aa[4]==vneg(K,wedge(K,proj(l),proj(u)))
 assert bb[4]==vneg(K,wedge(K,proj(F.mul(m,l)),proj(v)))
 N=[[vol(K,a,b) for b in bb[:5]] for a in aa[:5]];assert any(sum(N,[]))
 X=[[1,0,0],[0,1,0],[l,0,1],[0,l,m]]
 W=X+[[F.mul(l,z) for z in x] for x in X]+[[l3,0,u],[0,l3,v]]
 assert rank(K,[sum([list(F.digits(x)) for x in w],[]) for w in W])==10
 params=list(range(F.q))+[None];small=set(range(min(4,F.q)))|{None};matches=[];witness=None
 for s,t in it.product(params,repeat=2):
  h=[0 if s is None else F.neg(F.inv(F.add(l,s))),0 if t is None else F.neg(F.mul(m,F.inv(F.add(l,t)))),1]
  vals=[F.dot(h,w) for w in W];r=rank(K,[F.digits(z) for z in vals])
  ev=keval(K,[N[i][4] if t is None else keval(K,N[i],t) for i in range(5)],s) if s is not None else (N[4][4] if t is None else keval(K,N[4],t))
  assert (r==6)==bool(ev)
  matches.append({'s':s,'t':t,'rank':r,'polynomial_value':ev})
  if r==6 and witness is None and s in small and t in small:witness=(s,t,h)
 if F.q>=4:
  assert witness is not None
  assert sum(g['rank']==6 for g in matches)>=(F.q-3)**2
 out=dict(id=caseid,q=F.q,polynomial=M['minpoly'],lam=F.q,mu=M['enc'](m),u=M['enc'](u),v=M['enc'](v),coefficients=N,grid=matches,has_grid_witness=witness is not None,bad_grid_pairs=sum(g['rank']==6 for g in matches),minimum_bound=(F.q-3)**2 if F.q>=4 else None)
 if witness:
  s,t,h=witness;x=[1,0,0] if s is None else [F.add(l,s),0,1];y=[0,1,0] if t is None else [0,F.add(l,t),m]
  U=trace_dual(F,W);assert len(U)==8
  words=[[F.dot(z,col) for col in U] for z in [x,y]]
  rows=[[[F.digits(a)[i] for a in word] for i in range(6)] for word in words]
  triple=[rank(K,rows[0]),rank(K,rows[1]),rank(K,rows[0]+rows[1])];assert triple==[4,4,8]
  out['witness']=dict(s=s,t=t,h=[M['enc'](z) for z in h],x=[M['enc'](z) for z in x],y=[M['enc'](z) for z in y],U_columns=[[M['enc'](z) for z in a] for a in U],words=[[M['enc'](z) for z in a] for a in words],rank_triple=triple)
 return out

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
 cases=[];cores=[]
 for q in [3,4,5,7,8,9,11,13]:
  F=Tower(q);rng=random.Random(9132600+q);base=F.add(q,F.mu)
  for li,l in enumerate([base,F.inv(base)]):
   candidates=[F.mul(l,l),F.pow(l,3),F.mu,q]+[rng.randrange(q,F.Q) for _ in range(2)]
   for mi,m in enumerate(candidates):
    if rank(F.K,[F.digits(x) for x in [1,l,m,F.mul(l,m)]])!=4:continue
    M=setup(F,l,m);coreid=f'q{q}-l{li}-m{mi}'
    cores.append(dict(id=coreid,q=q,polynomial=M['minpoly'],lam=q,mu=M['enc'](m),common_quadric_dimension=1,trace_matrix_rank=M['formrank'],ruling_maps=M['ruling']))
    for j,(u,v) in enumerate([(0,0),(rng.randrange(F.Q),rng.randrange(F.Q)),(rng.randrange(F.Q),rng.randrange(F.Q))]):
     cases.append(case(F,l,m,u,v,M,coreid+f'-uv{j}'))
  print('field',q,'finished',flush=True)
 out=dict(status='passed',scope='selected scalar cores and lifts only; no exhaustive scalar or code classification',core_count=len(cores),lift_count=len(cases),grid_evaluations=sum(len(c['grid']) for c in cases),explicit_witnesses=sum(c['has_grid_witness'] for c in cases),core_cases=cores,cases=cases)
 args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(out,indent=2)+'\n')
 print({k:v for k,v in out.items() if k not in ['core_cases','cases']},flush=True)
if __name__=='__main__':main()
