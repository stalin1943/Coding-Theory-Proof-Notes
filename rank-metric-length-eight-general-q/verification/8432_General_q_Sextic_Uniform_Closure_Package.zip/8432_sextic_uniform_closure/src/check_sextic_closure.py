#!/usr/bin/env python3
"""Checks the NEW sextic epsilon-one reduction and its genus-one obstruction.
All (p,s) are checked for each of sixteen listed sextic generators, not for
all scalar types or codes. General assertions belong to PROOF_zh.md.
"""
from pathlib import Path
import sys,itertools as it,json,random,functools,math,argparse
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'vendor'))
from tower_arithmetic import Tower,rank
from check_regulus import normpoly,solve,kdot,null,det,keval

def pmul(F,a,b):
 c=[0]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):c[i+j]=F.add(c[i+j],F.mul(x,y))
 return c

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
 records=[];reductions=[];factorchecks=0;grid_checks=0;quad_checks=0;orth=0;rankproofs=0;fibproofs=0
 for q in [3,4,5,7,8,9,11,13]:
  F=Tower(q);K=F.K;plus=lambda *xs:functools.reduce(F.add,xs,0);rng=random.Random(221309+q)
  for li,l in enumerate([F.add(q,F.mu),F.inv(F.add(q,F.mu))]):
   lp=[F.pow(l,i) for i in range(6)];im=F.inv(l);f=normpoly(F,l,-1)
   invrows=[solve(K,[list(F.digits(x)) for x in lp],[int(i==j) for i in range(6)]) for j in range(6)]
   digits=lambda x:[kdot(K,row,F.digits(x)) for row in invrows]
   enc=lambda x:sum(a*q**i for i,a in enumerate(digits(x)))
   derivative=plus(*[F.scale((i%K.p),F.mul(f[i],lp[i-1])) for i in range(1,7)])
   delta=F.inv(derivative)
   g=[1]
   for i in range(3):g=pmul(F,g,[F.neg(F.pow(l,q**(2*i))),1])
   gb=[F.pow(x,q) for x in g]
   assert pmul(F,g,gb)==f
   C,B,A,_=g;pex=F.neg(F.add(C,F.pow(C,q)));sex=F.mul(A,F.pow(A,q))
   assert pex<q and sex<q;factorchecks+=1
   dc=[F.split(x) for x in [A,B,C]];assert all(x<q and y<q for x,y in dc)
   (a0,a1),(b0,b1),(c0,c1)=dc
   gamma=plus(c1,F.scale(b1,l),F.scale(a1,lp[2]));assert gamma
   vf=[F.neg(plus(lp[2],F.mul(A,l),B)),F.neg(A),1]
   # The nonzero-z branch of the first grid has an explicit weight-three point.
   for z in range(1,min(q,4)):
    z2=K.mul[z][z];z3=K.mul[z2][z]
    cc=F.add(lp[2],F.neg(F.scale(K.mul[f[0]][z],F.mul(im,im))))
    u3=K.add[K.mul[f[1]][z]][K.mul[K.mul[f[0]][f[5]]][z2]]
    uu=plus(F.neg(F.scale(K.mul[K.mul[f[0]][f[0]]][z3],im)),F.scale(u3,lp[2]),F.scale(K.mul[f[0]][z2],lp[3]))
    vv=plus(F.neg(F.scale(K.mul[K.mul[f[0]][f[5]]][z],im)),F.scale(K.add[f[4]][K.inv[z]],lp[2]),F.scale(f[5],lp[3]))
    X=[[0,0,1],[l,0,0],[0,1,0],[1,F.neg(l),cc]]
    W=X+[[F.mul(l,x) for x in row] for row in X]+[[lp[3],0,uu],[0,lp[3],vv]]
    x=[l,K.mul[f[0]][z2],u3]
    flat=lambda v:sum([list(F.digits(x)) for x in v],[])
    assert rank(K,[flat(w) for w in W])==10
    for j in [0,1,2]:assert rank(K,[flat(w) for w in W]+[flat([F.mul(lp[j],y) for y in x])])==10
    reductions.append(dict(kind='nonzero_z_weight3',q=q,polynomial=f,lam=q,z=z,c=enc(cc),u=enc(uu),v=enc(vv),x=[enc(y) for y in x]))
   # Additional secant determinant formulas for arbitrary four parameters.
   for kcase in range(4):
    rho,p,sigma,ss=[rng.randrange(q) for _ in range(4)]
    uu=F.add(F.scale(rho,im),F.scale(p,lp[2]));vv=plus(F.scale(f[5],lp[3]),F.scale(sigma,im),F.scale(ss,lp[2]))
    X=[[0,0,1],[l,0,0],[0,1,0],[1,F.neg(l),lp[2]]]
    S0=X+[[F.mul(l,x) for x in row] for row in X]
    # k=1, t!=0: direct quotient determinant and its leading coefficient.
    aa=K.mul[rho][K.inv[f[0]]];rr=K.mul[sigma][K.inv[f[0]]]
    coeff=[]
    for t in range(1,q):
     h=[plus(F.scale(t,l),F.neg(1),F.neg(lp[2])),plus(lp[3],l,t),F.add(1,lp[2])]
     Av=F.dot(h,[lp[3],0,uu]);Bv=F.dot(h,[0,lp[3],vv])
     proj=lambda x:[K.sub(K.sub(digits(x)[1],digits(x)[3]),K.mul[t][digits(x)[4]]),digits(x)[5]]
     A1=K.sum([1,rho,K.mul[aa][K.sub(f[4],f[2])],K.neg[K.mul[t][t]],K.neg[K.mul[p][t]],K.mul[K.mul[aa][f[5]]][t]])
     B1=K.sum([sigma,K.mul[rr][K.sub(f[4],f[2])],f[3],K.neg[f[5]],K.neg[f[1]],K.mul[t][K.sum([f[4],K.neg[ss],K.neg[K.add[1][1]],K.mul[rr][f[5]]])]])
     assert proj(Av)==[A1,K.neg[K.add[1][aa]]]
     assert proj(Bv)==[B1,K.neg[rr]]
     grid_checks+=1
    # k!=0,1 with sigma=0: the degree-two membership polynomial.
    vv=plus(F.scale(f[5],lp[3]),F.scale(ss,lp[2]));d0=K.sum([1,ss,K.neg[f[4]]])
    for k in range(2,q):
     for t in range(q):
      h=[plus(F.scale(t,l),F.neg(F.scale(k,F.add(1,lp[2])))),plus(lp[3],l,t),F.add(k,lp[2])]
      S=[F.dot(h,x) for x in S0];assert rank(K,[F.digits(x) for x in S])==4
      Bv=F.dot(h,[0,lp[3],vv])
      P=K.sum([K.mul[K.add[k][d0]][K.mul[t][t]],K.mul[K.sum([K.mul[K.mul[k][k]][f[5]],K.neg[K.mul[k][f[3]]],f[1]])][t],K.mul[K.sub(k,1)][K.sum([K.mul[K.mul[k][k]][ss],K.neg[K.mul[k][K.add[f[2]][d0]]],f[0]])]])
      assert (rank(K,[F.digits(x) for x in S+[Bv]])==4)==(P==0)
      grid_checks+=1
   for p,ss in it.product(range(q),repeat=2):
    uu=F.add(F.neg(F.scale(f[0],im)),F.scale(p,lp[2]));vv=F.add(F.scale(f[5],lp[3]),F.scale(ss,lp[2]))
    U=[[1,0,0],[l,0,0],[0,1,0],[0,l,0],[F.neg(lp[2]),0,1],[0,0,l],[0,lp[3],lp[2]],[F.neg(uu),F.neg(vv),lp[3]]]
    X=[[0,0,1],[l,0,0],[0,1,0],[1,F.neg(l),lp[2]]];W=X+[[F.mul(l,x) for x in row] for row in X]+[[lp[3],0,uu],[0,lp[3],vv]]
    assert rank(K,[sum([list(F.digits(x)) for x in row],[]) for row in U])==8
    for v,w in it.product(U,W):assert F.trace(F.mul(delta,F.dot(v,w)))==0;orth+=1
    H=[p,K.sub(ss,f[4]),K.neg[f[5]]];J=[f[0],f[1],f[2],K.add[f[3]][p],ss]
    fback=J+[0,1]
    for j,x in enumerate(H):fback[j+3]=K.sub(fback[j+3],x)
    assert fback==f
    points=[]
    for r,t in it.product(range(q),repeat=2):
     hr=keval(K,H,r);jr=keval(K,J,r);ev=K.sum([K.mul[t][t],K.neg[K.mul[hr][t]],jr]);quad_checks+=1
     if not ev:points.append([r,t]);assert t!=K.mul[K.mul[r][r]][r]
    exception=(p,ss)==(pex,sex)
    record=dict(id=f'q{q}-l{li}-p{p}-s{ss}',q=q,polynomial=f,lam=q,p=p,s=ss,exceptional=exception,affine_points=points)
    if exception:
     vectors=[[F.mul(gamma,x) for x in vf],[F.mul(F.mul(F.mu,gamma),x) for x in vf]]
     flat=lambda x:sum([list(F.digits(y)) for y in x],[])
     for v in vectors:assert rank(K,[flat(x) for x in U]+[flat(v)])==8
     assert vectors[0][2]!=0 and F.pow(F.mu,q*q)==F.mu and F.mu>=q
     record['fiber']=dict(mu=enc(F.mu),g=[enc(x) for x in g],gamma=enc(gamma),point=[enc(x) for x in vf],vectors=[[enc(x) for x in v] for v in vectors])
     fibproofs+=1
    elif points:
     r,t=points[0];z=F.mul(F.add(t,F.neg(F.scale(r,lp[2]))),F.inv(F.add(l,F.neg(r))));h=[1,r,z]
     word=[F.dot(h,x) for x in U];assert rank(K,[F.digits(x) for x in word])==3
     A=F.add(z,F.neg(lp[2]));assert rank(K,[F.digits(x) for x in [1,l,A]])==3
     hr=keval(K,H,r);w=K.sub(hr,t)
     Br=K.sum([K.mul[K.add[f[3]][p]][r],K.mul[ss][K.mul[r][r]]]);Ar=K.add[K.mul[r][Br]][K.mul[f[2]][r]]
     expected=[1,l,r,F.scale(r,l),A,F.add(F.scale(r,A),t),plus(F.scale(K.mul[r][r],A),F.scale(t,l),K.mul[t][r]),plus(F.scale(w,A),Ar,F.scale(Br,l))]
     assert word==expected
     record['rank3']=dict(r=r,t=t,message=[enc(x) for x in h],word=[enc(x) for x in word]);rankproofs+=1
    else:
     assert q<7
     record['scope_note']='No affine point for this selected small-q model; this new Hasse-Weil step only asserts q>=7. Previously proved small-q exclusions are separate inputs.'
    if q>=7 and not exception:assert points
    records.append(record)
  print('sextic closure field',q,'finished',flush=True)
 out=dict(status='passed',scope='all q^2 final parameters for sixteen listed sextic generators, plus selected grid formulas; not all sextic types or codes. Uniform exclusion uses the analytic proof.',field_models=factorchecks,final_models=len(records),curve_equation_checks=quad_checks,trace_pairings=orth,rank3_witnesses=rankproofs,quadratic_fiber_witnesses=fibproofs,small_q_without_affine=sum(not r['exceptional'] and not r['affine_points'] for r in records),additional_grid_checks=grid_checks,nonzero_z_models=len(reductions),reductions=reductions,cases=records)
 args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(out,indent=2)+'\n');print({k:v for k,v in out.items() if k not in ['reductions','cases']})
if __name__=='__main__':main()
