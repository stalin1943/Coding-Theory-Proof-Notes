#!/usr/bin/env python3
"""Independent polynomial-field check of the new two-parameter sextic family.
Imports only the independent arithmetic from this package, not the tower or
any primary proof/check implementation. Reconstructs U,W and every witness.
"""
from pathlib import Path
import json,itertools as it,argparse,functools
from independent_check import Field,rank,echelon

def keval(K,p,x):
 y=0
 for c in reversed(p):y=K.add[K.mul[y][x]][c]
 return y

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--results',type=Path,required=True);args=ap.parse_args();data=json.loads((args.results/'closure.json').read_text());fields={};groups={};pairings=0;lookups=0;rank3=0;fibers=0;chains=0
 def field(row):
  key=(row['q'],tuple(row['polynomial']))
  if key not in fields:fields[key]=Field(*key)
  return fields[key]
 for row in data['cases']:
  F=field(row);K=F.K;q=F.q;l=q;f=F.f;plus=lambda *xs:functools.reduce(F.add,xs,0);lp=[F.pow(l,i) for i in range(6)];im=F.inv(l);p=row['p'];s=row['s'];key=(q,tuple(f));groups.setdefault(key,set()).add((p,s))
  u=F.add(F.neg(F.mul(f[0],im)),F.mul(p,lp[2]));v=F.add(F.mul(f[5],lp[3]),F.mul(s,lp[2]))
  U=[[1,0,0],[l,0,0],[0,1,0],[0,l,0],[F.neg(lp[2]),0,1],[0,0,l],[0,lp[3],lp[2]],[F.neg(u),F.neg(v),lp[3]]]
  X=[[0,0,1],[l,0,0],[0,1,0],[1,F.neg(l),lp[2]]];W=X+[[F.mul(l,x) for x in a] for a in X]+[[lp[3],0,u],[0,lp[3],v]]
  flat=lambda x:sum([list(F.digits(y)) for y in x],[])
  assert rank(K,[flat(x) for x in U])==8 and rank(K,[flat(x) for x in W])==10
  derivative=plus(*[F.mul((i%K.p),F.mul(f[i],lp[i-1])) for i in range(1,7)]);delta=F.inv(derivative)
  for a,b in it.product(U,W):assert F.trace(F.mul(delta,F.dot(a,b)))==0;pairings+=1
  H=[p,K.sub(s,f[4]),K.neg[f[5]]];J=[f[0],f[1],f[2],K.add[f[3]][p],s]
  points=[]
  for r,t in it.product(range(q),repeat=2):
   ev=K.add[K.sub(K.mul[t][t],K.mul[keval(K,H,r)][t])][keval(K,J,r)];lookups+=1
   if ev==0:points.append([r,t])
  assert points==row['affine_points']
  if q>=7 and not row['exceptional']:assert points
  if 'rank3' in row:
   w=row['rank3'];r,t=w['r'],w['t'];z=F.mul(F.add(t,F.neg(F.mul(r,lp[2]))),F.inv(F.add(l,F.neg(r))));message=[1,r,z];assert message==w['message']
   word=[F.dot(message,a) for a in U];assert word==w['word'];assert rank(K,[F.digits(x) for x in word])==3;rank3+=1
  if 'fiber' in row:
   w=row['fiber'];mu=w['mu'];g=w['g'];assert F.pow(mu,q*q)==mu and mu>=q
   assert plus(*[F.mul(c,lp[i]) for i,c in enumerate(g)])==0
   assert all(F.pow(c,q*q)==c for c in g)
   A,B,C=g[2],g[1],g[0];assert p==F.neg(F.add(C,F.pow(C,q))) and s==F.mul(A,F.pow(A,q))
   vf=[F.neg(plus(lp[2],F.mul(A,l),B)),F.neg(A),1];assert vf==w['point']
   a=[F.mul(w['gamma'],x) for x in vf];b=[F.mul(mu,x) for x in a];assert [a,b]==w['vectors'] and a[2]
   for x in [a,b]:assert rank(K,[flat(y) for y in U]+[flat(x)])==8
   assert rank(K,[flat(a),flat(b)])==2;fibers+=1
 for (q,f),seen in groups.items():assert seen==set(it.product(range(q),repeat=2))
 for row in data['reductions']:
  F=field(row);K=F.K;l=row['lam'];l2=F.mul(l,l);l3=F.mul(l,l2);c=row['c'];u=row['u'];v=row['v'];x=row['x']
  X=[[0,0,1],[l,0,0],[0,1,0],[1,F.neg(l),c]];W=X+[[F.mul(l,z) for z in y] for y in X]+[[l3,0,u],[0,l3,v]]
  flat=lambda a:sum([list(F.digits(t)) for t in a],[])
  xs=[[F.mul(t,z) for z in x] for t in [1,l,l2]]
  assert rank(K,[flat(y) for y in xs])==3
  for y in xs:assert rank(K,[flat(z) for z in W]+[flat(y)])==10
  chains+=1
 out=dict(status='passed',independent_field_models=len(fields),all_final_parameter_pairs_for_listed_generators=len(data['cases']),curve_equation_checks=lookups,trace_pairings=pairings,rank_three_codewords=rank3,quadratic_subfield_fibers=fibers,weight_three_chain_models=chains,all_parameter_sets_and_outputs_match=True,scope='independent coefficient arithmetic on the listed sextic generators and their complete q^2 final parameter sets; no all-generator finite exhaustion or formal verification of the geometry')
 (args.results/'independent_closure.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
