#!/usr/bin/env python3
"""Checks new necessary leading-coefficient conditions for sextic epsilon=1.
The check does not claim complete epsilon=1 exclusion.
"""
from pathlib import Path
import sys,itertools as it,json,random,argparse
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'vendor'))
from tower_arithmetic import Tower,rank
from check_regulus import normpoly,solve,kdot,det,vadd,vscale,vneg,keval

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
 records=[]
 for q in [3,4,5,7,8,9,11,13]:
  F=Tower(q);K=F.K;rng=random.Random(170913+q);lbase=F.add(q,F.mu)
  for li,l in enumerate([lbase,F.inv(lbase)]):
   lp=[1]
   for i in range(5):lp.append(F.mul(lp[-1],l))
   co=[solve(K,[list(F.digits(x)) for x in lp],[int(i==j) for i in range(6)]) for j in range(6)]
   digits=lambda x:[kdot(K,row,F.digits(x)) for row in co]
   enc=lambda x:sum(a*q**i for i,a in enumerate(digits(x)))
   pr=lambda x:[digits(x)[i] for i in [0,3,4,5]]
   f=normpoly(F,l,-1);adj=[0]*6;adj[5]=1
   for j in range(5,0,-1):adj[j-1]=F.add(f[j],F.mul(l,adj[j]))
   assert F.neg(F.mul(l,adj[0]))==f[0]
   invl=F.inv(l);inv2=F.mul(invl,invl);l2=lp[2];l3=lp[3]
   cs=[(l2,(1,0)),(inv2,(0,1)),(F.add(l2,inv2),(1,1))]
   for _ in range(3):
    while True:
     c=rng.randrange(F.Q)
     if rank(K,[F.digits(x) for x in [1,l,invl,c]])==4:break
    cs.append((c,None))
   for ci,(c,ab) in enumerate(cs):
    for mode in [0,1]:
     u=rng.randrange(F.Q);v=rng.randrange(F.Q)
     if mode==1 and ab is not None:
      aa,b=ab;r=rng.randrange(q);s=rng.randrange(q)
      v=F.add(F.add(F.scale(K.mul[aa][f[5]],l3),F.scale(r,invl)),F.scale(s,l2))
     C=F.mul(l,c);U=F.mul(l,u);V=F.mul(l,v);A=F.mul(l,C);B=F.mul(l,A)
     first=[pr(C),[-1%K.p,0,0,0]]
     # Use the actual additive inverse of 1 in every characteristic.
     first[1]=[K.neg[1],0,0,0]
     third=[pr(U),[0,K.neg[1],0,0]]
     second=[[pr(F.mul(C,a)) for a in adj],[vneg(K,pr(a)) for a in adj]]
     fourth=[pr(F.add(V,B)),pr(A)]
     coeff=[[0]*7 for _ in range(4)]
     for i,j,k in it.product(range(2),repeat=3):
      for t in range(6):
       for z in range(2):
        val=det(K,[first[i],second[j][t],third[k],fourth[z]])
        coeff[i+j+k][t+z]=K.add[coeff[i+j+k][t+z]][val]
     assert all(not r[5] and not r[6] for r in coeff)
     N=[r[:5] for r in coeff]
     Z=fourth[0];Abar=fourth[1]
     lead=[K.sub(K.mul[f[5]][Z[3]],Z[2]),K.sub(K.add[Z[3]][K.mul[f[5]][Abar[3]]],Abar[2]),Abar[3],0,0]
     assert N[3]==lead
     constraints=all(x==0 for x in lead)
     if mode==1 and ab is not None:assert constraints
     X=[[0,0,1],[l,0,0],[0,1,0],[1,F.neg(l),c]]
     W=X+[[F.mul(l,z) for z in x] for x in X]+[[l3,0,u],[0,l3,v]]
     assert rank(K,[sum([list(F.digits(x)) for x in w],[]) for w in W])==10
     grid=[];witness=None
     for s,t in it.product(range(min(q,4)),list(range(min(q,4)))+[None]):
      h=[F.neg(F.scale(s,invl)),0 if t is None else F.mul(F.add(F.scale(s,invl),F.neg(c)),F.inv(F.add(t,F.neg(l)))),1]
      rnk=rank(K,[F.digits(F.dot(h,w)) for w in W])
      ev=keval(K,[row[4] if t is None else keval(K,row,t) for row in N],s)
      assert bool(ev)==(rnk==6)
      grid.append([s,t,rnk,ev])
      if rnk==6 and witness is None:witness=[s,t,[enc(x) for x in h]]
     if q>=4 and not constraints:assert witness is not None
     records.append(dict(id=f'q{q}-l{li}-c{ci}-m{mode}',q=q,polynomial=f,lam=q,c=enc(c),u=enc(u),v=enc(v),leading_coefficient=lead,three_constraints_hold=constraints,grid=grid,rank_six_witness=witness))
  print('epsilon1 field',q,'finished',flush=True)
 out=dict(status='passed',scope='selected epsilon=1 lifts and exact coefficient identities; no complete epsilon=1 classification',cases=records,case_count=len(records),grid_evaluations=sum(len(r['grid']) for r in records),constraints_pass=sum(r['three_constraints_hold'] for r in records),constraints_fail=sum(not r['three_constraints_hold'] for r in records),rank_six_witnesses=sum(r['rank_six_witness'] is not None for r in records))
 args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(out,indent=2)+'\n');print({k:v for k,v in out.items() if k!='cases'},flush=True)
if __name__=='__main__':main()
