# 一般六次类型孤立子直线的解析排除
## 公共迹二次曲面、割线多项式与一个六次分解控制的亏格一族

**日期：2026-09-13。**

## 0. 本轮的净结果、输入与未决边界

本轮不重复三次子域型的闭合。上传的 Cubic Genus One 与 Cubic Quadric 两套材料均已处理该同一分支。本轮新增的是一般六次类型。

**新主定理。** 对所有素幂 `q≥7`，不存在非退化的 `F=F_(q^6)`-线性 `[8,3]_(q^6/q)` 秩度量相交码，使全部权二点恰好组成一条六次标量类型的孤立普通子直线。

证明进一步分为：

- `epsilon=0`：对所有 `q≥4`，一个明确的 `5×5` 割线网格必然产生秩支撑零交码字对。全部网格至少有 `(q−3)^2` 组这样的消息对。
- `epsilon=1`：对所有 `q≥4`，目标必须进入下文的二参数族 `W_(lambda,p,s)`。对 `q≥7`，非例外参数由亏格至多一的曲线产生秩三码字；唯一的可约例外参数由六次最小多项式在二次子域上的分解，显式产生二次子域型纤维。

接入此前已经完成的 `q=3,4,5` 六次分支有限排除，六次孤立子直线对所有 `q≥3` 关闭。再接入已给出的四类型闭合、普通类型隔离以及三次子域型闭合，得到累计必要条件

$$\boxed{s(U)\in\{0,1,2,3\},\quad\text{全部权二纤维类型互异},\qquad q\ge3.}$$

**这不是整个 `[8,3]_(q^6/q)` 的不存在证明。低点数四个分支均仍未被本轮排除。** 二元终局和旧小域六次全量计算没有重跑。下述一般证明也尚未经过项目外数学审稿或证明助理形式化。

---

## 1. 采用的规范形与精确证明接口

令 `K=F_q`，`F=F_(q^6)`，所有没有特别说明的维数均在 K 上。原始空间与迹对偶为

$$U\le F^3,\quad\dim U=8,\qquad W=U^{\perp_{\rm tr}},\quad\dim W=10.$$

基础支撑—核对应以及迹对偶补权重判据来自 [R1]。目标满足

$$w_U(P),w_W(P)\le2,\qquad 4\le w_W(H)\le6,$$

$$w_W(P+P')>w_W(P)+w_W(P')\qquad(P\ne P').\tag{1.1}$$

六次孤立子直线取

$$B=K+K\lambda,\quad [K(\lambda):K]=6,\quad Q=B^2\times\{0\}.$$

定义

$$X=W\cap\lambda^{-1}W,\quad R=W\cap Fe_3,\quad
\epsilon=\dim(R\cap\lambda^{-1}R)\in\{0,1\}.$$

输入 [B1, B2] 的圆锥投影与允许坐标变换给出下面两个覆盖规范形。这里使用的是所有适当的六次 lambda，不是每个类型只取一个任意代表。

### 1.1 epsilon=0

$$R=K+K\mu,\qquad R\not\sim B,$$

$$X_0=\langle e_1,e_2,\lambda e_1+e_3,\lambda e_2+\mu e_3\rangle_K,$$

$$S_0=X_0+\lambda X_0,$$

$$\boxed{W=S_0+K(\lambda^3,0,u)+K(0,\lambda^3,v),\quad u,v\in F/R.}\tag{1.2}$$

类型互异等价于

$$\dim\langle1,\lambda,\mu,\lambda\mu\rangle=4.\tag{1.3}$$

这是因为一个乘积相关式能将 mu 表成 lambda 的非退化 K-系数分式线性函数，反之亦然。

### 1.2 epsilon=1

$$X_c=\langle e_3,\lambda e_1,e_2,e_1-\lambda e_2+c e_3\rangle_K,$$

$$\boxed{W=X_c+\lambda X_c+K(\lambda^3,0,u)+K(0,\lambda^3,v),\quad u,v\in F/B.}\tag{1.4}$$

其中

$$c\notin L_\lambda:=K+K\lambda+K\lambda^{-1}.$$

更换 c 的 `L_lambda` 陪集代表可由输入中的竖直剪切和提升选基实现。水平共同 K* 缩放又同时缩放 c,u,v，所以其非零陪集可以射影归一化。

### 1.3 为什么 eta 可统一为 lambda 的三次幂

输入初始形式的额外横向方向也可能是 `(lambda−a)^(-1)`。这不能直接丢弃。对该情形令

$$g=\lambda-a,\quad\tau=g^{-1},\quad S=\operatorname{diag}(g,g,1).$$

则

$$X_\tau(SW)=gS X_\lambda(W),\qquad \delta_\tau=\delta g^4,$$

$$\delta_\tau\langle1,\tau,\tau^2,\tau^3\rangle
=\delta g\langle1,\lambda,\lambda^2,\lambda^3\rangle.$$

相应圆锥平面也成为新生成元 tau 的默认平面。随后横向缩放并重新选择 R 的基，就得到 (1.2) 或 (1.4)。tau 仍然六次。原始子直线载体通过逆转置变换保持为 `z=0`。这解释了所用规范形对所有目标的覆盖，而非对某个固定 lambda 的全部旧 eta 作不合法删减。

---

## 2. epsilon=0：两条倒数曲线有唯一的公共迹二次曲面

令

$$V=F/R,\qquad \dim_KV=4,$$

并用 `pi:F→V` 表示商映射。在代数闭包上考虑两条曲线

$$C(s)=[\pi((s+\lambda)^{-1})],\qquad
D(t)=[\pi(\mu(t+\lambda)^{-1})]\subset\mathbb P(V).\tag{2.1}$$

### 引理 2.1：两条曲线均为非退化有理四次曲线

未投影的倒数方向，在六个域嵌入坐标下为

$$[1/(s+\lambda_0):\cdots:1/(s+\lambda_5)].$$

清除分母后，六个五次二元形式构成完整线性系，所以它是五次有理正规曲线。

投影中心 `P(R)` 与第一条曲线相交于单位元方向 O。线与有理正规曲线的概形交长至多二：三个取值/一阶导数条件在五次完全线性系上独立即可说明。若还有第二个不同交点，由中心定义在 K 上及 Frobenius 稳定性，该点必在 K 上；于是 R 是两个 B 倒数方向的张成，其标量类型等于 B，矛盾。若在 O 相切，则中心是 `P(K+Klambda)`，同样矛盾。

所以基点恰为一个简单的 O。第二条曲线的情况通过乘以 mu 的逆元相同。投影线性系的次数为四，像张成整个 P3。若投影的函数域次数（包括不可分部分）为 e，则 `e·deg(image)=4`，而非退化空间曲线的次数至少三。故 e=1，像的次数为四。证毕。

### 引理 2.2：公共二次式空间恰为一维

令

$$D_0=\langle1,\lambda,\mu,\lambda\mu\rangle_K,$$

取 `d_0,d_1` 为 `D_0^(perp_tr)` 的基。定义

$$\Psi(z)=
\begin{pmatrix}
\operatorname{Tr}(d_0z)&\operatorname{Tr}(d_1z)\\
\operatorname{Tr}(\lambda d_0z)&\operatorname{Tr}(\lambda d_1z)
\end{pmatrix}.\tag{2.2}$$

四个线性形式都消去 R，因此 Psi 是 V 到 `Mat_2(K)` 的线性映射。二次式

$$\boxed{Q(z)=\det\Psi(z)}\tag{2.3}$$

包含两条曲线：第一条上第二行等于 `−s` 倍第一行，第二条上第二行等于 `−t` 倍第一行。

为证明唯一性，在分裂坐标中将任意公共二次式拉回六维空间。双极点系数先强制所有平方项系数为零。写其混合项为 `q_ij z_i z_j`，并定义

$$A_{ij}=\frac{q_{ij}}{\lambda_j-\lambda_i}\quad(i\ne j),\qquad A_{ii}=0.$$

A 是交替矩阵，特征二也成立。第一条曲线的简单极点给出 `A1=0`；第二条给出 `Amu=0`。

二次式能下降到 F/R，其极化矩阵 M 必消去 1 与 mu。因为

$$M=A\Lambda-\Lambda A,\qquad\Lambda=\operatorname{diag}(\lambda_i),$$

还得到 `Alambda=0`、`A(lambda mu)=0`。由 (1.3)，这四个向量独立。交替形式的根基包含指定四维空间后，它只来自二维商上的交替形式，空间维数为一。

式 (2.3) 非零：在分裂坐标中，其混合系数为

$$(\lambda_j-\lambda_i)(d_{0i}d_{1j}-d_{1i}d_{0j}),$$

独立的 d0,d1 保证至少一个非零。因此公共二次式空间恰为一维。

特征二下，下降还要求在中心上的二次式值为零；上述计算只用了必要的极化条件来证明上界，而显式 (2.3) 确实下降，所以没有漏掉这一附加条件。

### 引理 2.3：光滑时，两条曲线具有同一方向的双次数 (1,3)

Psi 的秩为三或四。若只有二，`span(d0,d1)` 就被六次元素 lambda 保持，不可能。秩三时，其非零核点是 Q 的奇点。秩四时，Psi 为同构，Q 是光滑的分裂行列式二次曲面。

在后一情形，曲线上的行关系分别为 `(1,−s)` 与 `(1,−t)`。因此两条曲线向同一个直线族参数 P1 的映射次数都是一。Segre 超平面线丛为 O(1,1)，而曲线总次数四，故另一个直线族参数映射的次数为三。

这个论证使用映射次数，不假定三次映射可分；所以特征三不例外。

---

## 3. epsilon=0：公共二次曲面强制相反、又强制相同的直线族

在 X0 中取

$$x_s=(s+\lambda,0,1),\quad y_t=(0,t+\lambda,\mu),\quad s,t\in K,$$

$$x_\infty=e_1,\qquad y_\infty=e_2.$$

每个 x_s,y_t 都 F-独立。有限参数的法向量为

$$h_{s,t}=(-(s+\lambda)^{-1},-\mu(t+\lambda)^{-1},1).\tag{3.1}$$

无穷远对应项为零。因为两点都含 B 型二维纤维，目标必须有 `dim h_(s,t)(W)≤5`。

对有限参数，模去已在 hS0 中的项后，完整秩等于以下六个标量的秩：

$$1,\mu,(s+\lambda)^{-1},\mu(t+\lambda)^{-1},
 u-\lambda^2+s\lambda,
 v-\mu\lambda^2+t\mu\lambda.\tag{3.2}$$

在 V 中令

$$a(s)=\pi(u-\lambda^2+s\lambda),\qquad
b(t)=\pi(v-\mu\lambda^2+t\mu\lambda),$$

$$\ell_s=\langle C(s),[a(s)]\rangle,
\qquad m_t=\langle D(t),[b(t)]\rangle.$$

两族在一般参数处是真正直线：非退化四次曲线不可能与一个直线值映射恒重合。

### 定理 3.1：两族直线不可能处处相交

假设行列式恒零，即每条一般 ell_s 都与每条一般 m_t 相交。

首先，两族都不可能共面，因为各自包含非退化四次曲线。

若 a(s) 非恒定，它沿一条固定直线以次数一移动。若 ell_s 全经过固定点 P，则当 P 不在这条直线上时 C 落在一个平面中；当 P 在其上时 C 落在这条直线上。均矛盾。

若 a(s) 的射影值恒定，它只能是 `[pi(lambda)]`。不共面的这一星形直线族，迫使所有与它每条线相交的 m_t 也经过该点。若 b(t) 非恒定，再次使 D 共面；若 b(t) 恒定，其值为 `[pi(mu lambda)]`，由 (1.3) 与前一个点不同，所有 m_t 将是连接这两个点的同一条线，仍然矛盾。

因此 ell_s 不构成星形，也不共面。一条不可约直线族若所有两条线相交，必为星形或共面：取两条相交线，所有其他线都属于“过其交点”或“在其张成平面内”这两个闭条件之一，不可约性迫使其中一个条件恒成立。故现在可以选出三条两两异面的 ell。

三条异面直线的全部公共横截线构成一个光滑二次曲面的一个直线族。可直接选坐标，使三条线分别为 K2 的两个坐标轴空间与恒等图；其横截线为 `span((x,0),(0,x))`。因此全部 m_t 属于这个直线族，全部 ell_s 属于相反直线族。该光滑二次曲面包含 C,D，只能是引理 2.2 的 Q。

a(s),b(t) 此时都非恒定，其像直线均在 Q 上。ell_s 与 a(s) 的像直线相交，故选取 ell_s 的直线族参数随 s 的次数为一。m_t 同理。引理 2.3 却说明 C,D 在 Q 上次数一的投影属于**同一个**直线族。于是 ell_s 与 m_t 必同族，与前述相反两族矛盾。证毕。

若原迹二次曲面 Q 奇异，前面三异面直线强制的光滑曲面也已直接与公共二次式唯一性矛盾，因此退化 Q 没有被遗漏。

### 定理 3.2：双四次网格与显式支撑零交

令 `n_lambda(S)=N_(F/K)(S+lambda)`，以及

$$E(S)=n_\lambda(S)/(S+\lambda)\in F[S].$$

令 `C_pol=pi E`、`D_pol=pi(mu E)`。它们次数至多四，四次首项分别为 `−pi(lambda)` 与 `−pi(mu lambda)`。三次项分别为 `pi(lambda²)−n_5 pi(lambda)` 及其 mu 倍。

定义两个二向量多项式

$$A(S)=C_{\rm pol}(S)\wedge\pi(u-\lambda^2+S\lambda),$$

$$B(T)=D_{\rm pol}(T)\wedge\pi(v-\mu\lambda^2+T\mu\lambda).$$

五次项相消，故二者次数至多四；四次项分别为

$$-\pi(\lambda)\wedge\pi(u),\qquad
-\pi(\mu\lambda)\wedge\pi(v).$$

其楔积 `N(S,T)=A(S) wedge B(T)` 是双次数至多 (4,4) 的标量多项式，且由定理 3.1 不恒零。有限参数的取值零条件恰等价于 (3.2) 的秩不足六。上述四次项还给出真实的无穷远条件；特别地 `(infty,infty)` 对应法向量 e3，其秩是 `span(1,mu,lambda,mu lambda,u,v)` 的维数。

对于 q≥4，任选四个不同有限基域元素并加上无穷远，每个轴得到五个点。非零双四次形式不可能在整个 5×5 网格消失。因此存在

$$\boxed{\dim_K h_{s,t}(W)=6.}\tag{3.3}$$

于是 `W cap (Fx_s+Fy_t)=Bx_s directsum By_t` 为四维。对 U 的任意列基生成矩阵 G，迹对偶与联合像秩公式给出

$$\boxed{\operatorname{rk}\Gamma(x_sG)=\operatorname{rk}\Gamma(y_tG)=4,
\quad\operatorname{rk}[\Gamma(x_sG);\Gamma(y_tG)]=8.}$$

每个非零双四次形式在完整 `(q+1)×(q+1)` 网格上至少有 `(q−3)^2` 个非零值：至少 q−3 个第一参数使限制非零，每个这样的限制又至少有 q−3 个非零第二参数。所以至少得到这么多不同的指定消息对。

**epsilon=0 对所有 q≥4 已被解析排除。**

---

## 4. epsilon=1：第一个割线网格只允许两种形式

记 lambda 的首一最小多项式为

$$f(T)=T^6+f_5T^5+f_4T^4+f_3T^3+f_2T^2+f_1T+f_0,\qquad f_0\ne0.$$

以下 f 与上一节的 `N(S+lambda)` 不同；它等于 `N(T−lambda)`。

在 (1.4) 中取

$$x_s=(\lambda,0,s),\quad y_t=(1,t-\lambda,c),\quad y_\infty=e_2.$$

有限参数法向量为

$$h_{s,t}=(-s/\lambda,(s/\lambda-c)/(t-\lambda),1).$$

写

$$C=\lambda c,\quad U_1=\lambda u,\quad V_1=\lambda v,$$

在四维商 `F/(lambda B)` 中取基 `(1,lambda³,lambda⁴,lambda⁵)`。所有这些割线的必要条件是

$$\mathcal D(S,T)=\det\bigl(
\overline{C-S},\overline{(C-S)f(T)/(T-\lambda)},
\overline{U_1-S\lambda^3},
\overline{V_1+\lambda^2C+T\lambda C}\bigr)=0.\tag{4.1}$$

其双次数至多 `(3,4)`。第二列的 T5 系数等于第一列，T4 系数模第一列后等于第四列的 T 系数，所以 T6、T5 项都消失。T 的无穷远条件就是最高系数，对应真实 y_infty 割线。因此 q≥4 时，用四个有限 S 参数、四个有限 T 参数及 T=infty，共二十条割线就能强制 `D≡0`。

### 4.1 三次 S 系数先把 c 压到一个射影直线

设

$$Z(T)=\overline{V_1+\lambda^2C+T\lambda C},$$

并按商基记其第4、5次幂坐标为 Z4,Z5。直接展开得

$$[S^3]\mathcal D=(T+f_5)Z_5(T)-Z_4(T).\tag{4.2}$$

所以

$$[\lambda^5](\lambda^2c)=0,$$

$$[\lambda^5](\lambda v+\lambda^3c)=[\lambda^4](\lambda^2c),$$

$$[\lambda^4](\lambda v+\lambda^3c)
=f_5[\lambda^4](\lambda^2c).$$

使用允许的 c 陪集代表改变后，写

$$c=a\lambda^2-f_0z\lambda^{-2},\quad(a,z)\ne(0,0),$$

$$\lambda u\equiv u_0+u_3\lambda^3+u_4\lambda^4+u_5\lambda^5\pmod{\lambda B},$$

$$v=af_5\lambda^3+r\lambda^{-1}+v_3\lambda^2\pmod B.\tag{4.3}$$

### 4.2 非零 z 一定产生三维点纤维

在 (4.3) 下，几个系数为

$$[S^2T^3]\mathcal D=-a u_5,$$

$$[S^2T^2]\mathcal D=-2af_5u_5+a u_4-f_0z^2.$$

若 a=0，则 z≠0，第二式非零。因此 a≠0，可以通过共同 K* 缩放归一化 a=1。

若 z≠0，依次比较下表的系数：

| 已施加前面条件后的系数 | 强制关系 |
|---|---|
| S²T³ | u5=0 |
| S²T² | u4=f0 z² |
| S²T | r=−f0 f5 z |
| S² | v3=f4+z^(-1) |
| ST³ | u0=−f0²z³ |
| ST² | u3=f1 z+f0 f5 z² |

这些是整数 Laurent 多项式恒等式，没有除以二或三。完整的 175 项多项式由标准库稀疏运算重建并验证。

特别地，

$$u=u_3\lambda^2+f_0z^2\lambda c.$$

令

$$x=(\lambda,f_0z^2,u_3)\in X_c.$$

则

$$\lambda^2x=(\lambda^3,0,u)-f_0z^2\bigl(\lambda(e_1-\lambda e_2+ce_3)-\lambda e_1\bigr)\in W.$$

x 与 lambda x 本来就在 W 中；lambda 六次保证这三个向量 K-独立。因此 W 有一个权至少三的点，不可能为目标。

### 4.3 目标只能保留四个基域参数

于是 z=0，c=lambda²，且 u4=u5=0。目标必须满足

$$\boxed{
 u=\rho\lambda^{-1}+p\lambda^2,\qquad
 v=f_5\lambda^3+\sigma\lambda^{-1}+s\lambda^2,
 \quad\rho,p,\sigma,s\in K.
}\tag{4.4}$$

仅第一个网格不能再减少这四个参数；将它们代入后 (4.1) 确实恒零。因此必须使用不同的割线，而不是重复运行同一网格。

---

## 5. 再加九条割线，目标进入一个二参数族

固定

$$x=e_3+(e_1-\lambda e_2+\lambda^2e_3),$$

$$y_{k,t}=\lambda e_1+ke_2+t(e_1-\lambda e_2+\lambda^2e_3).$$

法向量为

$$n_{k,t}=(t\lambda-k(1+\lambda^2),\lambda^3+\lambda+t,k+\lambda^2).\tag{5.1}$$

### 5.1 k=1 的三个非零参数强制 sigma=0

当 k=1、t≠0 时，`nS0` 为四维，其基可以选为

$$1,\lambda^2,\lambda+\lambda^3,\lambda^4+t\lambda.$$

相应二维商坐标是

$$z\longmapsto([\lambda]z-[\lambda^3]z-t[\lambda^4]z,\ [\lambda^5]z).$$

将两个新增向量代入，所得二阶行列式关于 t 的次数至多二，二次项系数为 `sigma/f0`。所以只要在三个不同非零 t 处都满足必要秩条件，就有 sigma=0。q≥4 保证这样的三个参数存在。

### 5.2 两个不同 k 再强制 rho=−f0

设 k≠0,1。核心像仍为四维，位于五维的 `P4=span(1,...,lambda⁴)` 中。第一新增像的 lambda5 系数是

$$-k(1+\rho/f_0),$$

第二新增像的 lambda5 系数为零。

若 rho≠−f0，要使完整像秩至多五，第二新增像必须已经在核心像内。令 `d0=1+s−f4`，该包含关系精确等价于

$$\begin{aligned}
\Pi_k(t)={}&(k+d_0)t^2+(k^2f_5-kf_3+f_1)t\\
&+(k-1)[k^2s-k(f_2+d_0)+f_0]=0.
\end{aligned}\tag{5.2}$$

可以从 `span(d,lambda d,e,lambda e)` 直接消元得到，其中 `d=k+lambda²`、`e=lambda³+lambda+t`。

选两个不同的 `k∈K\{0,1}`，每个 k 选三个不同 t。若六条割线都满足必要条件，两个二次多项式必须恒零，其二次项分别要求 `k+d0=0`，不可能同时成立。所以 rho=−f0。

### 定理 5.1：一般六次 epsilon=1 的二参数覆盖

对所有 q≥4，每个目标可归一化为

$$\boxed{
 c=\lambda^2,\quad
 u=-f_0\lambda^{-1}+p\lambda^2,\quad
 v=f_5\lambda^3+s\lambda^2,
 \qquad p,s\in K.
}\tag{5.3}$$

该结论是必要的覆盖；这里不需要宣称每个二参数对象都满足目标的全部割线条件。固定 lambda 只有 q² 个实际参数记录，且不同坐标等价仍可能产生重复。

---

## 6. 二参数族的迹对偶与秩三消息曲线

令

$$\delta=1/f'(\lambda).$$

由 Lagrange 插值，`Tr(delta P(lambda))` 等于 P 除以 f 的余式中 lambda5 的系数。用这个关系直接核对十个 W 基向量，可得

$$W^{\perp_{\rm tr}}=\delta\widehat U_{p,s},$$

其中八个列基向量组成

$$\boxed{
G_{p,s}=\begin{pmatrix}
1&\lambda&0&0&-\lambda^2&0&0&-u\\
0&0&1&\lambda&0&0&\lambda^3&-v\\
0&0&0&0&1&\lambda&\lambda^2&\lambda^3
\end{pmatrix},
}\tag{6.1}$$

u,v 取 (5.3)。此矩阵的列在 K 上独立；第三坐标的四个幂系数首先确定后四个输入，然后前两坐标确定前四个输入。整体非零标量 delta 不改变任何码字秩或纤维标量类型。

定义基域多项式

$$H(R)=p+(s-f_4)R-f_5R^2,$$

$$J(R)=f_0+f_1R+f_2R^2+(f_3+p)R^3+sR^4.$$

关键恒等式为

$$\boxed{f(R)=R^6-H(R)R^3+J(R).}\tag{6.2}$$

### 定理 6.1：一个仿射有理点直接给出秩三码字

若 `(r,t)∈K²` 满足

$$\boxed{t^2-H(r)t+J(r)=0,}\tag{6.3}$$

则令

$$z=\frac{t-r\lambda^2}{\lambda-r},\qquad h=(1,r,z),$$

便有 `rank_K(hG_(p,s))=3`。

**证明。** 因 f 不可约，f(r)≠0。式 (6.2) 还保证 t≠r³。令

$$A=z-\lambda^2=\frac{t-\lambda^3}{\lambda-r}.$$

A 不属于 B，否则得到一个次数三与次数至多二的多项式在六次 lambda 处相等，矛盾。因此 `span(1,lambda,A)` 为三维。

令

$$w=H(r)-t,\quad B_r=(f_3+p)r+sr^2,\quad A_r=rB_r+f_2r.$$

直接相乘得到完整码字

$$\boxed{
 hG=(1,\lambda,r,r\lambda,A,
 rA+t,\ r^2A+t(\lambda+r),\ wA+A_r+B_r\lambda).
}\tag{6.4}$$

第四个特殊列的等式通过 (6.2)、`t+w=H(r)`、`tw=J(r)` 得到；程序还对清分母后的整数多项式恒等式独立展开检查。码字像恰好为上述三维空间。证毕。

这个曲线不是上一轮三次类型的曲线换一个名字：这里的参数来自六次最小多项式的系数，(6.2) 是新的接口，可约例外将由 f 的二次子域因式分解唯一决定。

---

## 7. 曲线的几何整性与唯一可约例外

把 (6.3) 解释为 `P1` 上线丛 `O(2)` 中的首一二次方程：H 的次数至多二，J 的次数至多四。在无穷远图中使用坐标 `R^(-1)` 与 `t/R²`，得到其有限平坦二重覆盖的射影完成 C。

其推前结构层为

$$\pi_*\mathcal O_C=\mathcal O_{\mathbb P^1}\oplus\mathcal O_{\mathbb P^1}(-2).$$

所以 `chi(O_C)=0`，算术亏格为一。若 C 几何整，其光滑正规化的亏格至多一；正规化到 P1 的次数仍为二，故无穷远以上至多有两个几何点。

### 定理 7.1：几何可约参数恰好一个

在 `K2=F_(q²)` 上，f 分解为两个共轭的首一三次式：

$$f(T)=g(T)\bar g(T),\qquad g(T)=T^3+AT^2+BT+C_0.$$

可选择 g 使 g(lambda)=0。定义

$$\boxed{p_*=-\operatorname{Tr}_{K_2/K}(C_0),\qquad
s_*=N_{K_2/K}(A).}\tag{7.1}$$

那么 C 几何可约，当且仅当 `(p,s)=(p_*,s_*)`。

**证明。** 若关于 t 的二次多项式在 `overline K(R)` 中可约，首一性和多项式环整闭性保证其两个根 u(R),v(R) 均为多项式。次数比较强制其次数至多二。

由 (6.2)，

$$f(R)=(R^3-u(R))(R^3-v(R)).$$

f 可分，所以两因子不同。Frobenius 必交换这一无序因子对；若分别固定，则 f 已在 K 上分解。故两个三次因子定义在 K2 上，并恰为唯一的 g 与其共轭。比较常数和四次系数得到 (7.1)。反向由这个分解直接成立。

若特征二且 H 恒零，泛型二重覆盖可能不可分；但只要其二次多项式不可约，它仍几何整。几何非约化将要求 J 为多项式平方，继而 f 也是平方，与可分性矛盾。证明因此没有漏掉特征二的不可分情形。

### 非例外参数对全部 q≥7 均有仿射点

对于非例外参数，Hasse–Weil 界 [R2] 在光滑正规化上给出

$$\#\widetilde C(K)\ge q+1-2\sqrt q.$$

当 q≥7 时右侧大于二。因此正规化至少有三个 K-点，无穷远之上至多两个，至少一个映到仿射曲线的 K-点。由定理 6.1，得到秩三码字。

**无穷远的删除不可省略。** 本轮样例中确实有 q=3、4 的非例外曲线没有仿射 K-点；本条新论证只断言 q≥7。小域不由这一点数步骤强行覆盖。

---

## 8. 可约例外参数产生明确的二次子域纤维

继续写

$$g(T)=T^3+AT^2+BT+C_0.$$

选 `eta∈K2\K`，令 `eta²=nu+beta eta`，把三次因子的系数分解为

$$A=A_0+\eta A_1,\quad B=B_0+\eta B_1,\quad
C_0=C_{00}+\eta C_{01},$$

所有下标系数均在 K。为简洁，记 `C_{00}=c_0,C_{01}=c_1`。

令

$$\gamma=c_1+B_1\lambda+A_1\lambda^2,$$

$$v_*=(-\lambda^2-A\lambda-B,-A,1).\tag{8.1}$$

因为 g 不在 K[T] 中，A1,B1,c1 不全为零；lambda 六次，所以 gamma≠0。由 g(lambda)=0，

$$\eta\gamma=-(\lambda^3+A_0\lambda^2+B_0\lambda+c_0).\tag{8.2}$$

### 定理 8.1：例外的二维纤维

在 (7.1) 的例外参数下，

$$\boxed{K_2\gamma v_*\subseteq\widehat U_{p_*,s_*}.}\tag{8.3}$$

**证明。** 首先直接展开 gamma v_*：

$$\begin{aligned}
x={}&-c_1\lambda^2+(A_1c_0-A_0c_1)\lambda+(B_1c_0-B_0c_1),\\
y={}&A_1\lambda^3+(A_1B_0-A_0B_1)\lambda+(A_1c_0-A_0c_1),\\
z={}&c_1+B_1\lambda+A_1\lambda^2.
\end{aligned}$$

这由 (6.1) 的 z0=c1,z1=B1,z2=A1,z3=0 及前四个 B 坐标得到，因此属于 Uhat。

再看 eta gamma v_*。由 (8.2)，其第三坐标的四个系数为 `(-c0,-B0,-A0,-1)`。第二坐标模 B 等于

$$(-A_0+f_5)\lambda^3+s_*\lambda^2=-A_0\lambda^3+v.$$

这里使用 `f5=Tr(A)`、`s*=N(A)`。第一坐标模 B 等于

$$-(c_0+\beta c_1)\lambda^2-f_0\lambda^{-1}
=c_0\lambda^2+u,$$

其中 `f0=N(C0)`、`p*=−(2c0+beta c1)`。它们正好是 (6.1) 对应第三坐标时要求的两项。因此 eta gamma v_* 也在 Uhat 中，(8.3) 成立。

该点第三坐标非零，所以它位于原孤立子直线载体 `z=0` 之外；其纤维又包含一个二次子域类型的二维空间。无论实际点权是二还是更高，均违反目标的孤立性或点权上界。证毕。

### 六次分支的最终闭合

对 epsilon=1：

$$\boxed{
\begin{array}{ll}
(p,s)\ne(p_*,s_*),\ q\ge7 &: \text{仿射曲线点给出秩三码字};\\
(p,s)=(p_*,s_*) &: \text{式 (8.3) 给出二次子域纤维}.
\end{array}}$$

结合第 2–3 节，全部六次孤立子直线在 q≥7 由本轮同一套解析证明排除。此前 q=3,4,5 的有限排除作为明示输入接入，故对所有 q≥3 都不再保留六次孤立子直线。

### 一个可以手算核验的七元例子

取

$$f(T)=T^6+2T^5+6T^4+4T^3+2T^2+T+3\in\mathbb F_7[T],$$

令 lambda 为其根，取最终参数 p=s=0。这个六次式的不可约性在独立算术中检查。曲线在 r=0 时为 `t²+3=0`，所以 (r,t)=(0,2) 是仿射点。

令

$$h=(1,0,2\lambda^{-1}),\qquad A=2\lambda^{-1}-\lambda^2.$$

式 (6.4) 成为

$$hG=(1,\lambda,0,0,A,2,2\lambda,5A),$$

像空间恰为 `span_K(1,lambda,A)`，维数三。这只展示如何读取一般定理的一个反例，并非以这个例子代替一般证明。

---

## 9. 本轮实际检查范围

一般证明不是由有限样例归纳得到。计算分别检查三组接口：

### 9.1 epsilon=0 的公共二次曲面与固定网格

在 q=3,4,5,7,8,9,11,13 上，每域两个明确六次 lambda，合计96个指定 (lambda,mu) 核心、288个扩张：

- 共同二次式空间均一维；迹矩阵秩四的73个、秩三的23个；
- 直接检查完整网格23,832个值；
- 每个扩张均保存一对实际 `(4,4,8)` 码字，总计288对；
- q≥4 的实例同时满足固定25网格结论及 `(q−3)^2` 下界。

独立程序不用主塔算术，重新用六次多项式系数乘法、Euclid 求逆及相反主元消元，重建原始6×6行列式的41,472项系数，并比较全部网格和码字。

### 9.2 epsilon=1 的参数归约

192个指定提升检查第一网格的系数、3,648个实际秩值。另46个非零 z 的精确形式逐个产生 `x,lambda x,lambda²x∈W`。九条附加割线归约所用的商坐标和包含多项式，还在3,728个明确参数值上直接核对。

标准库的整数稀疏 Laurent 多项式程序重建了归约后的175项一般行列式，验证六个消元系数、两类恒零代入、恒等式 (6.2) 及清分母后的码字表达式。仅在已分离的 z≠0 分支允许 z 的负指数，没有除以二或三。

### 9.3 最后二参数族及原始码字验证

对上述16个六次生成元分别完整检查 q² 个 (p,s)，合计1,068个最终模型、114,444次曲线方程代入。它们给出：

- 1,048个明确秩三码字；
- 16个明确二次子域型纤维；
- 4个 q=3 或4 的非例外模型没有仿射曲线点，保留为点数步骤的边界对照，不误判为目标码。

每个模型的显式 U 与标准形 W 都直接检查80次迹正交，合计85,440次。独立系数实现重建完整的16组 q² 参数集合，重算全部曲线点、正交关系以及1,064个新反例，结果一致。

**这些是16个指定六次生成元上的完整二参数检查，不是所有基域上所有六次类型的穷举。** 主证明处理一般类型；有限记录用于发现和检查公式。没有重新运行此前百亿级倒数枚举或小域六次分类。

---

## 10. 累计剩余问题与下一处真正缺口

接入已有的四类型闭合、类型隔离、三次子域型闭合及 q=3,4,5 六次结果后，一般 q≥3 的潜在目标只剩

$$\boxed{s=0,1,2,3,\qquad\text{纤维类型互异}.}$$

特别地

$$\dim_KT_{\rm h}\le6,$$

$$M_4(U)=\theta_4(q)+q^2s\le q^4+q^3+4q^2+q+1.$$

已有散布截面入口依然有效：

$$M_{4,\rm sc}(U)\ge(q-s)\theta_3(q)+q^2s+\binom{s}{2}+1>0.$$

因此所有剩余候选都可以从一个**不含权二点的四维截面**开始。该截面存在性不是本轮新证明；本轮的作用是将所有一般子直线分支从剩余表中删除。

低点数候选的截面图、投影以及联合秩条件仍须联立。不能由本轮结论推断这些配置不存在，也不能说三元、四元、五元的完整码分类已经完成。

## 来源与依赖

[B1] 上传 `8432_General_q_Ternary_Subline_Closure_Progress.md`：一般子直线迹交、圆锥选择吸收及三元结果。

[B2] 上传 `8432_General_q_Sextic_Subline_Progress.md`：六次两个 epsilon 标准形与 q=3,4,5 有限排除。仅作为其解析覆盖和小域结果的输入；本轮没有重跑原完整枚举。

[B3] 上传 `8432_General_q_Four_Type_Closure_Progress.md`、`8432_General_q_Cubic_Quadric_Closure_Progress.md`：累计剩余状态。

[B4] 上传 `8432_General_q_Cubic_Tower_Progress.md`：低点数情形的散布四维截面入口。

[R1] M. Borello, O. Polverino, F. Zullo, *On the existence of linear rank-metric intersecting codes*, arXiv:2604.02004, 2026。只用于基础相交码、q-system、迹对偶和最小秩必要条件，不将本轮定理归给该文。

[R2] Y. Aubry and A. Iezzi, *On the maximum number of rational points on singular curves over finite fields*, Moscow Mathematical Journal, 15(4), 615–627, 2015; arXiv:1501.03676。本轮使用光滑正规化上的经典 Hasse–Weil 界，并明确删除至多两个无穷远原像，不把可约曲线直接代入光滑界。

[A1] `vendor/tower_arithmetic.py` 原样来自上传 Cubic Quadric 包。新独立路径 `src/independent_check.py` 及 `src/independent_closure.py` 不导入该模块。全部来源摘要写入 SOURCE_BASELINE.json。
