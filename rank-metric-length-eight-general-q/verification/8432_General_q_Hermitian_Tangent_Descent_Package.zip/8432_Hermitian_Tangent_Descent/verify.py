#!/usr/bin/env python3
"""Recompute this package from its defining inputs, with exact comparisons.
Python 3.10+ and a C++17 compiler are required. No third-party Python modules.
"""
from pathlib import Path
import argparse,json,sys,subprocess,time,hashlib,shutil,os

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def stable(x):
 if isinstance(x,dict):return {k:stable(v) for k,v in x.items() if k not in ('seconds','elapsed_seconds','runtime_seconds')}
 if isinstance(x,list):return [stable(v) for v in x]
 return x

def main():
 if not __debug__:raise SystemExit('Assertions are required; do not use python -O.')
 ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path,required=True)
 ap.add_argument('--compiler',default=None);ap.add_argument('--sanitize',action='store_true')
 args=ap.parse_args();root=Path(__file__).resolve().parent;work=args.work.resolve()
 if work==root or (work.exists() and any(work.iterdir())):raise SystemExit('Work directory must be absent or empty and outside the package.')
 compiler=args.compiler or shutil.which('g++') or shutil.which('clang++')
 if not compiler:raise SystemExit('A C++17 compiler is required for the independent complete point scan.')
 work.mkdir(parents=True,exist_ok=True);start=time.monotonic();entries=[];hashes=0
 manifest=json.loads((root/'MANIFEST.json').read_text())
 for name,h in manifest['sha256'].items():
  p=root/name
  if not p.is_file() or digest(p)!=h:raise RuntimeError('Manifest mismatch: '+name)
  hashes+=1
 def run(name,cmd,outputs):
  t=time.monotonic();log=work/(name+'.log')
  print('Running '+name,flush=True)
  with log.open('w') as stream:subprocess.run(cmd,cwd=root,stdout=stream,stderr=subprocess.STDOUT,check=True)
  checked=[]
  for output in outputs:
   actual=json.loads((work/output).read_text());saved=json.loads((root/'results'/output).read_text())
   if stable(actual)!=stable(saved):raise RuntimeError('Mathematical output mismatch: '+output)
   checked.append(output)
  entries.append(dict(stage=name,status='passed',outputs=checked,seconds=time.monotonic()-t))
 py=sys.executable
 run('01_primary',[py,str(root/'src/primary.py'),'--work',str(work)],['primary.json','primary_data.json'])
 run('02_original_trace',[py,str(root/'src/independent.py'),'--work',str(work)],['independent.json','raw_trace_blocks.json'])
 run('03_minor',[py,str(root/'src/check_minor.py'),'--work',str(work)],['example_minor.json'])
 run('04_square_span',[py,str(root/'src/square_span.py'),'--work',str(work)],['square_span.json'])
 run('05_square_span_independent',[py,str(root/'src/square_span_independent.py'),'--work',str(work)],['square_span_independent.json'])
 run('06_example_messages',[py,str(root/'src/example_graph.py'),'--work',str(work)],['example_graph.json'])
 matrix=json.loads((work/'example_graph.json').read_text())['example']['U']
 expected=list(map(int,(root/'inputs/example_matrix.txt').read_text().split()))
 assert expected==[8]+[x for row in matrix for x in row]
 cpp=work/'example_points';cmd=[compiler,'-std=c++17','-O2','-Wall','-Wextra']
 if args.sanitize:cmd+=['-fsanitize=undefined','-fno-sanitize-recover=undefined','-D_GLIBCXX_ASSERTIONS']
 cmd += [str(root/'src/example_points.cpp'),'-o',str(cpp)]
 t=time.monotonic()
 with (work/'07_compile.log').open('w') as stream:subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT,check=True)
 with (work/'example_points.json').open('w') as out, (work/'07_pointscan.log').open('w') as err:
  subprocess.run([str(cpp),str(root/'inputs/example_matrix.txt')],stdout=out,stderr=err,check=True)
 assert stable(json.loads((work/'example_points.json').read_text()))==stable(json.loads((root/'results/example_points.json').read_text()))
 entries.append(dict(stage='07_complete_point_scan',status='passed',outputs=['example_points.json'],seconds=time.monotonic()-t))
 run('08_example_independent',[py,str(root/'src/example_graph_independent.py'),'--work',str(work)],['example_graph_independent.json'])
 report=dict(status='passed',all_new_stages_recomputed=True,manifest_files_checked=hashes,stages=entries,
   prior_single_fibre_replay='Recorded separately in inputs/single_fibre_actual_replay.json; not repeated by this entry point.',
   historical_proof_chain_reaudited=False,external_mathematical_review=False,
   compiler=compiler,undefined_behavior_sanitizer=args.sanitize,python=sys.version,elapsed_seconds=time.monotonic()-start,
   scope='Complete q=7 Hermitian tangent auxiliary ranks; complete q=3,4 scalar three-space classifications; 13 specified section bindings; one explicit seven-ary graph. No complete q=7 non-Hermitian classification.')
 (work/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(report,ensure_ascii=False,indent=2),flush=True)
if __name__=='__main__':main()
