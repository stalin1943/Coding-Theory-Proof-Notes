// Independent direct point-weight check of one supplied q=7, dimension-eight U.
// Field: GF(7)[x]/(x^3+x^2+1), followed by w^2=3.
// Multiplication/log tables are generated from polynomial arithmetic, not imported.
#include <array>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <unordered_map>
#include <vector>
#include <algorithm>
using V=std::array<int,3>;
constexpr int q=7,L=343,F=117649,order=F-1;
std::vector<int> addL(L*L),mulL(L*L),ex(2*order),lg(F,-1),iv(F);
int madd(int a,int b){return addL[(a%L)*L+b%L]+L*addL[(a/L)*L+b/L];}
int cmul(int a,int b){
 int x=a%L,y=a/L,z=b%L,w=b/L;
 int yw=mulL[y*L+w];int three=mulL[3*L+yw];
 int r=addL[mulL[x*L+z]*L+three];
 int s=addL[mulL[x*L+w]*L+mulL[y*L+z]];return r+L*s;
}
int power(int x,int n){int z=1;while(n){if(n&1)z=cmul(z,x);x=cmul(x,x);n>>=1;}return z;}
int mul(int a,int b){return !a||!b?0:ex[lg[a]+lg[b]];}
int smallpow(int a,int n){if(!a)return n?0:1;return ex[(std::int64_t(lg[a])*n)%order];}
void initialize(){
 for(int a=0;a<L;++a)for(int b=0;b<L;++b){
  int aa[3]={a%7,a/7%7,a/49},bb[3]={b%7,b/7%7,b/49};int s=0,bas=1,c[5]={0};
  for(int i=0;i<3;++i){s+=((aa[i]+bb[i])%7)*bas;bas*=7;for(int j=0;j<3;++j)c[i+j]=(c[i+j]+aa[i]*bb[j])%7;}
  for(int k=4;k>=3;--k){int t=c[k];c[k-3]=(c[k-3]+7-t)%7;c[k-1]=(c[k-1]+7-t)%7;}
  addL[a*L+b]=s;mulL[a*L+b]=c[0]+7*c[1]+49*c[2];
 }
 int gen=0;for(int a=2;a<F;++a){bool ok=true;for(int p:{2,3,19,43})if(power(a,order/p)==1){ok=false;break;}if(ok){gen=a;break;}}
 assert(gen);int t=1;
 for(int i=0;i<order;++i){assert(lg[t]<0);ex[i]=t;lg[t]=i;t=cmul(t,gen);}assert(t==1);
 for(int i=0;i<order;++i)ex[i+order]=ex[i];for(int x=1;x<F;++x)iv[x]=ex[(order-lg[x])%order];
}
struct Entry{std::uint16_t count;int first,second;};
std::unordered_map<std::uint64_t,Entry> pts;
std::array<std::array<V,7>,8> multiples;
std::uint64_t visits=0;
void record(const V& v){
 int pivot=v[0]?0:(v[1]?1:2);assert(v[pivot]);int s=v[pivot],inv=iv[s];
 V u={mul(v[0],inv),mul(v[1],inv),mul(v[2],inv)};
 std::uint64_t key=(std::uint64_t(u[0])*F+u[1])*F+u[2];
 auto it=pts.find(key);if(it==pts.end())pts.emplace(key,Entry{1,s,0});
 else {if(it->second.count==1)it->second.second=s;++it->second.count;}
 ++visits;
}
void visit(int i,const V& v){
 if(i==8){record(v);return;}
 for(int c=0;c<7;++c){const auto& w=multiples[i][c];visit(i+1,{madd(v[0],w[0]),madd(v[1],w[1]),madd(v[2],w[2])});}
}
int main(int argc,char** argv){
 if(argc!=2){std::cerr<<"usage: example_points matrix.txt\n";return 2;}
 initialize();std::ifstream in(argv[1]);int n;in>>n;assert(n==8);std::array<V,8> U;
 for(auto & v:U){in>>v[0]>>v[1]>>v[2];assert(in);for(int x:v)assert(x>=0&&x<F);}
 for(int i=0;i<8;++i)for(int c=0;c<7;++c)for(int j=0;j<3;++j)multiples[i][c][j]=mul(c,U[i][j]);
 pts.reserve(1000000);
 for(int first=0;first<8;++first)visit(first+1,U[first]);
 assert(visits==(5764801-1)/6);std::uint64_t light=0,heavy=0;std::vector<std::array<std::uint64_t,5>> hs;
 for(const auto& p:pts){auto key=p.first;const auto& z=p.second;assert(z.count==1||z.count==8);if(z.count==1){++light;continue;}
  ++heavy;int ratio=mul(z.second,iv[z.first]);assert(ratio>=7);int degree=6;
  if(smallpow(ratio,49)==ratio)degree=2;else if(smallpow(ratio,343)==ratio)degree=3;
  assert(degree!=2);
  int zz=key%F;key/=F;int yy=key%F;key/=F;int xx=key;
  hs.push_back({std::uint64_t(xx),std::uint64_t(yy),std::uint64_t(zz),std::uint64_t(z.count),std::uint64_t(degree)});
 }
 std::sort(hs.begin(),hs.end());assert(heavy==2&&light==960784&&pts.size()==960786);
 std::cout<<"{\"status\":\"passed\",\"projective_vectors\":"<<visits<<",\"light_points\":"<<light<<",\"weight_two_points\":"<<heavy<<",\"points\":"<<pts.size()<<",\"heavy\":[";
 for(unsigned i=0;i<hs.size();++i){if(i)std::cout<<",";std::cout<<"[";for(int j=0;j<5;++j){if(j)std::cout<<",";std::cout<<hs[i][j];}std::cout<<"]";}std::cout<<"]}\n";
}
