#!/usr/bin/env python3
"""Rebuild all low-rank messages of the example using the other field tower.
Does not import example_graph.py or its kernel/normalisation routines.
"""
from pathlib import Path
import sys,json,itertools,collections,argparse,time,hashlib
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'vendor'))
from algebra import Algebra
from tower_arithmetic import rref,projective,rank

def kernel(K,rows,n):
 R,p=rref(K,rows,n);ans=[]
 for j in range(n):
  if j in p:continue
  v=[0]*n;v[j]=1
  for row,k in zip(R,p):v[k]=K.neg[row[j]]
  ans.append(v)
 return ans

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path,required=True);args=ap.parse_args();start=time.monotonic()
 A=Algebra(7);F=A.F;K=A.K;q=7
 original=json.loads((args.work/'example_graph.json').read_text());ex=original['example'];U=ex['U'];T=U[:4]
 assert A.kspan_rank(U)==8
 # Reconstruct orbit representatives by a different traversal of the affine/inversion generators.
 covered=set(range(q));reps=[]
 for t in range(q**6-1,-1,-1):
  if t in covered:continue
  orbit=set()
  for c in range(q):
   inverse=F.inv(F.add(t,c))
   for b in range(1,q):
    for a in range(q):orbit.add(F.add(a,F.scale(b,inverse)))
  orbit.update(F.add(a,F.scale(b,t)) for b in range(1,q) for a in range(q))
  assert len(orbit) in (42,336) and not (orbit&covered)
  covered.update(orbit);reps.append(t)
 assert len(covered)==q**6 and len(reps)==351
 kb=[q**i for i in range(6)]
 rows0=[[F.trace(F.mul(u[j],b)) for j in range(3) for b in kb] for u in U]
 messages=set();histo=collections.Counter();vectors=0
 for lam in reps:
  rows1=[[F.trace(F.mul(F.mul(lam,u[j]),b)) for j in range(3) for b in kb] for u in U]
  ker=kernel(K,rows0+rows1,18);histo[len(ker)]+=1
  hs=[tuple(F.from_digits(v[6*j:6*j+6]) for j in range(3)) for v in ker]
  for cs in projective(q,len(hs)):
   h=tuple(F.dot(cs,[v[j] for v in hs]) for j in range(3));messages.add(A.enorm(h));vectors+=1
 target=set(map(tuple,ex['low_rank_messages']))
 assert messages==target and len(messages)==2899
 disjoint=0;hist=collections.Counter();gword=[u[2] for u in U]
 for h in messages:
  word=[F.dot(h,u) for u in U];r=rank(K,[F.digits(z) for z in word]);hist[r]+=1;assert r==4
  rt=rank(K,[F.digits(F.dot(h,t)) for t in T])
  if rt==4:
   joint=rank(K,[list(F.digits(a))+list(F.digits(b)) for a,b in zip(word,gword)])
   assert joint==8;disjoint+=1
 assert disjoint==2340
 # Inspect both stated heavy points directly and compare to the full C++ projective scan.
 full=json.loads((args.work/'example_points.json').read_text())
 assert full['projective_vectors']==960800 and len(full['heavy'])==2
 heavy=sorted(tuple(p) for p in ex['heavy_points'])
 cppheavy=sorted(tuple(row[:3]) for row in full['heavy'])
 assert heavy==cppheavy
 for p in heavy:
  j=next(i for i,x in enumerate(p) if x)
  image=[[F.add(u[i],F.neg(F.mul(u[j],p[i]))) for i in range(3) if i!=j] for u in U]
  assert 8-A.kspan_rank(image)==2
 result=dict(status='passed',complete_scalar_type_orbits=351,trace_intersection_projective_vectors=vectors,
  kernel_dimension_histogram={str(k):v for k,v in sorted(histo.items())},complete_low_rank_messages=len(messages),
  minimum_rank=4,all_disjoint_message_pairs_checked=disjoint,direct_point_scan_projective_vectors=full['projective_vectors'],
  heavy_points_compared=2,arithmetic='cubic-then-quadratic coefficient tower; left-pivot kernels; descending orbit traversal',
  scope='one fixed seven-ary graph, not classification of graph parameters',seconds=time.monotonic()-start)
 (args.work/'example_graph_independent.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result),flush=True)
if __name__=='__main__':main()
