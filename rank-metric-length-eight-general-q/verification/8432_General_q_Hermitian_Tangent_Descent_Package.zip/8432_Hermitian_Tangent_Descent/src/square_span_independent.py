#!/usr/bin/env python3
"""Independent opposite-tower full scalar classification and raw conic bindings."""
from pathlib import Path
import sys,itertools,json,collections,time,hashlib,argparse
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'vendor'))
from graph_independent_arithmetic import Field,proj


def eliminate(F,rows,n,ext=False,left=False):
 add,mul,neg,inv=(F.ea,F.em,F.en,F.ei) if ext else (F.ka,F.km,F.kn,F.ki)
 a=[list(r) for r in rows];i=0
 for j in (range(n) if left else range(n-1,-1,-1)):
  k=next((k for k in range(i,len(a)) if a[k][j]),None)
  if k is None:continue
  a[i],a[k]=a[k],a[i];iv=inv[a[i][j]];a[i]=[mul[iv][x] for x in a[i]]
  for k in range(len(a)):
   if k!=i and a[k][j]:
    c=a[k][j];a[k]=[add[x][neg[mul[c][y]]] for x,y in zip(a[k],a[i])]
  i+=1
  if i==len(a):break
 return a[:i]

def rspaces(q):
 for piv in itertools.combinations(range(6),3):
  cells=[(i,j) for i,p in enumerate(piv) for j in range(p) if j not in piv]
  for vals in itertools.product(range(q),repeat=len(cells)):
   m=[[int(j==p) for j in range(6)] for p in piv]
   for (i,j),v in zip(cells,vals):m[i][j]=v
   yield m

def from_source(F,v):return F.pack([v[i]+F.q*v[i+3] for i in range(3)])

def tr(F,x):
 z=F.add(F.add(x,F.pow(x,F.q**2)),F.pow(x,F.q**4));assert z<F.e;return z

def coeff(F,z,S):
 out=[]
 for i,j in [(0,0),(0,1),(0,2),(1,1),(1,2),(2,2)]:
  y=F.mul(F.pow(S[i],F.q**2),F.pow(S[j],F.q**4))
  if i!=j:y=F.add(y,F.mul(F.pow(S[j],F.q**2),F.pow(S[i],F.q**4)))
  out.append(tr(F,F.mul(z,y)))
 return out

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path,required=True);a=ap.parse_args();start=time.monotonic()
 expected=json.loads((a.work/'square_span.json').read_text());out=[];fields={}
 for r in expected['complete_scalar_classifications']:
  F=Field(r['field']);q=F.q;fields[q]=F;hist=collections.Counter();keys=[];n=0
  for M in rspaces(q):
   S=[from_source(F,v) for v in M];er=len(eliminate(F,[F.dig(x) for x in S],3,ext=True))
   sq=[F.mul(S[i],S[j]) for i in range(3) for j in range(i,3)]
   sr=F.rank([F.flat([x]) for x in sq]);hist[(er,sr)]+=1;n+=1
   if er==3 and sr<6:
    can=eliminate(F,M,6,left=True);keys.append(bytes(x for row in can for x in row))
  digest=hashlib.sha256(b''.join(sorted(keys))).hexdigest()
  assert digest==r['zero_space_sha256']
  assert n==r['total_three_spaces'] and {str(k):v for k,v in sorted(hist.items())}==r['rank_histogram']
  out.append(dict(q=q,complete_spaces=n,zero_space_count=len(keys),zero_space_sha256=digest))
  print('independent square classification',q,n,flush=True)
 # Separate supplied fields for the selected actual sections.
 models={3:(0,2,[1,0,2,1]),5:(0,2,[1,0,1,1]),7:(0,3,[1,0,1,1])}
 source=json.loads((Path(__file__).resolve().parents[1]/'inputs/section_samples.json').read_text())
 counts=0;bindings=[]
 for r,e in zip(source,expected['selected_scattered_sections']):
  q=r['q']
  if q not in fields:
   beta,nu,cp=models[q];fields[q]=Field(dict(q=q,beta=beta,nu=nu,cubic_polynomial=cp))
  F=fields[q];T=[[F.convert(x) for x in v] for v in r['section']];hist=collections.Counter()
  for cs in proj(q,4):
   p=[F.dot(cs,[v[j] for v in T]) for j in range(2)];chart=next(i for i,x in enumerate(cs) if x)
   S=[F.sub(F.mul(p[0],T[i][1]),F.mul(p[1],T[i][0])) for i in range(4) if i!=chart]
   assert F.rank([F.flat([x]) for x in S])==3
   er=len(eliminate(F,[F.dig(x) for x in S],3,ext=True))
   sq=[F.mul(S[i],S[j]) for i in range(3) for j in range(i,3)]
   sr=F.rank([F.flat([x]) for x in sq]);hist[(er,sr)]+=1
   cols=[coeff(F,z,S) for z in F.eb]
   cols+= [[F.bar(x) for x in c] for c in cols]
   cr=len(eliminate(F,cols,6,ext=True));assert (cr<6)==(sr<6)
   counts+=1
  assert {str(k):v for k,v in sorted(hist.items())}==e['rank_histogram']
  bindings.append([q,r['label'],sum(hist.values())])
 result=dict(status='passed',complete_scalar_classifications=out,original_trace_section_bindings=counts,
  selected_sections=bindings,arithmetic='quadratic then cubic; independently enumerated right-pivot subspaces',
  scope='full auxiliary scalar-space checks at q=3,4 and listed actual sections; not complete code classification',seconds=time.monotonic()-start)
 (a.work/'square_span_independent.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False),flush=True)
if __name__=='__main__':main()
