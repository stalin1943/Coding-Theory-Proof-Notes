#!/usr/bin/env python3
"""Complete low-rank message set for explicitly specified q=7 graph(s).
All normalized 2-dimensional scalar types are covered by disjoint PGL(2,7) orbits.
Not an enumeration of graph parameters or all codes.
"""
from pathlib import Path
import sys,json,itertools,collections,argparse,time
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'vendor'))
from graph_independent_arithmetic import Field,U_from_J,proj
from independent import atr,rr,nk

def vec(F,cs,rows):return tuple(F.dot(cs,[r[j] for r in rows]) for j in range(len(rows[0])))
def kbasis(F):return [1,F.xi,F.mul(F.xi,F.xi),F.mu,F.mul(F.mu,F.xi),F.mul(F.mu,F.mul(F.xi,F.xi))]
def normalized(F,v):
 a=next(x for x in v if x);a=F.inv(a);return tuple(F.mul(a,x) for x in v)

def scalar_types(F):
 seen=set(range(7));reps=[];sizes=collections.Counter()
 for t in range(F.q**6):
  if t in seen:continue
  orbit={F.add(a,F.scale(b,t)) for a in range(7) for b in range(1,7)}
  for c in range(7):
   ti=F.inv(F.sub(t,c));orbit.update(F.add(a,F.scale(b,ti)) for a in range(7) for b in range(1,7))
  assert len(orbit) in (42,336) and not orbit&seen
  seen|=orbit;reps.append(t);sizes[len(orbit)]+=1
 assert len(seen)==7**6 and len(reps)==351 and sizes=={42:1,336:350}
 return reps

def analyze(F,U,reps):
 start=time.monotonic();basis=kbasis(F);T=U[:4]
 base=[[atr(F,F.mul(u[j],b)) for j in range(3) for b in basis] for u in U]
 low=set();heavy=set();kerhist=collections.Counter();vectors=0;quad_dim=None
 for count,lam in enumerate(reps):
  rows=[[atr(F,F.mul(F.mul(lam,u[j]),b)) for j in range(3) for b in basis] for u in U]
  ker=nk(base+rows,18);kerhist[len(ker)]+=1
  assert len(ker)<=5
  vv=[tuple(F.dot(r[6*j:6*j+6],basis) for j in range(3)) for r in ker]
  for cs in proj(7,len(vv)):
   h=normalized(F,vec(F,cs,vv));low.add(h);vectors+=1
  if len(ker)>2:
   joined=U+[tuple(F.neg(F.mul(lam,x)) for x in u) for u in U]
   mat=list(map(list,zip(*[F.flat(u) for u in joined])))
   ku=nk(mat,16);assert len(ku)==len(ker)-2
   uv=[vec(F,r[:8],U) for r in ku]
   for cs in proj(7,len(uv)):heavy.add(normalized(F,vec(F,cs,uv)))
  if F.pow(lam,49)==lam:quad_dim=len(ker)-2
  if (count+1)%100==0:print('explicit graph scalar types',count+1,flush=True)
 assert quad_dim==0
 wh=collections.Counter()
 for p in heavy:
  j=next(i for i,x in enumerate(p) if x)
  quot=[tuple(F.sub(u[i],F.mul(u[j],p[i])) for i in range(3) if i!=j) for u in U]
  w=8-len(rr([F.flat(x) for x in quot],12)[1]);wh[w]+=1
  assert w==2
 s=len(heavy);mh=collections.Counter();compatible=0;disjoint=0;witnesses=[];point_inc=collections.Counter()
 points=[tuple(x) for x in proj(7,4)]
 for h in sorted(low):
  word=[F.dot(h,u) for u in U];r=len(rr([F.flat([x]) for x in word],6)[1]);mh[r]+=1
  if r!=4:continue
  tword=[F.dot(h,u) for u in T];rt=len(rr([F.flat([x]) for x in tword],6)[1])
  if rt==4:
   disjoint+=1
   if len(witnesses)<8:
    gword=[u[2] for u in U]
    joint=len(rr([F.flat([a,b]) for a,b in zip(word,gword)],12)[1]);assert joint==8
    witnesses.append(dict(h=[F.back(x) for x in h],word=[F.back(x) for x in word],joint_rank=joint))
  elif rt==3:
   coeffs=nk(list(map(list,zip(*[F.flat([x]) for x in tword]))),4);assert len(coeffs)==1
   v=coeffs[0];a=pow(next(x for x in v if x),-1,7);pt=tuple(x*a%7 for x in v);point_inc[pt]+=1;compatible+=1
  else:assert rt==0
 print('actual graph low rank histogram',mh,'heavy points',s,'disjoint',disjoint,flush=True)
 assert set(mh)=={4},'This explicit graph fails the minimum-rank test; do not use count identity.'
 assert mh[4]==2801+49*s
 # Ordinary local multiplicities read directly from the complete actual message set.
 def qf(x):return (x[0]*x[1]-x[2]*x[2]+3*x[3]*x[3])%7
 canonpoints=[tuple(x*a%7 for x in p) for p in points for a in [pow(next(v for v in p if v),-1,7)]]
 mult=collections.Counter();descent=0;critical=0
 for pt in canonpoints:
  m=1+point_inc[pt]
  if qf(pt):
   assert m in (1,2,3,4,5,9)
   if m==9:descent+=1
  else:critical+=1;assert m in (1,2,8,9)
  mult[(int(qf(pt)==0),m)]+=1
 assert critical==50
 assert sum(k[1]*v for k,v in mult.items())==3200+49*s-disjoint
 assert descent<=200 and disjoint>=200+49*s
 return dict(q=7,U=[[F.back(x) for x in u] for u in U],
  low_rank_messages=[[F.back(x) for x in h] for h in sorted(low)],
  heavy_points=[[F.back(x) for x in p] for p in sorted(heavy)],
  scalar_type_kernel_histogram={str(k):v for k,v in sorted(kerhist.items())},
  trace_intersection_projective_vectors=vectors,weight_two_points=s,quadratic_core_dimension=quad_dim,
  minimum_rank=4,rank_four_messages=mh[4],disjoint_from_fixed_section=disjoint,
  ordinary_descending_points=descent,local_multiplicity_histogram={str(k):v for k,v in sorted(mult.items())},
  witness_pairs=witnesses,seconds=time.monotonic()-start)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path,required=True);a=ap.parse_args();start=time.monotonic()
 F=Field(dict(q=7,beta=0,nu=3,cubic_polynomial=[1,0,1,1]));reps=scalar_types(F)
 U=U_from_J(F,[1,0,0,0,0,0],[[1,0],[0,1]])
 result=analyze(F,U,reps)
 out=dict(status='passed',scalar_types=351,scalar_type_representatives=[F.back(x) for x in reps],
  example=result,scope='one explicitly specified graph; complete scalar-type and low-rank-message coverage, not all graphs or all codes',seconds=time.monotonic()-start)
 (a.work/'example_graph.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('U','low_rank_messages','heavy_points')},ensure_ascii=False),flush=True)
if __name__=='__main__':main()
