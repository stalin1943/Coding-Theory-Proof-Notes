#!/usr/bin/env python3
"""Exact q=7 point blocks, tangent coverage, and scalar-kernel witnesses.
The polynomial normal and canonical graphs are attributed input modules.
Only Python's standard library is required.
"""
from pathlib import Path
import sys,json,itertools,collections,time,hashlib,argparse
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'vendor'))
from input_geometry import Algebra,Poly,polynomial_normals,coordinate_graph_basis,hermitian,det
from tower_arithmetic import projective,rank
from old_hermitian import core

Q=7

def normal(v):
 v=[x%Q for x in v]
 a=next(x for x in v if x)
 inv=pow(a,-1,Q)
 return tuple((x*inv)%Q for x in v)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path,required=True);args=ap.parse_args();args.work.mkdir(parents=True,exist_ok=True);start=time.monotonic()
 A=Algebra(Q);F=A.F;P=Poly(F);basis=coordinate_graph_basis(A)
 points=[tuple(x) for x in projective(Q,4)];index={x:i for i,x in enumerate(points)}
 singular=[det(A,hermitian(A,x))==0 for x in points]
 assert len(points)==400 and sum(singular)==50
 ps=[];Z0=None
 for j,(_,_,lift) in enumerate(basis):
  _,z0,pol=polynomial_normals(A,lift);ps.append(pol)
  if Z0 is None:Z0=z0
  else:assert z0==Z0
 blocks=[]
 for x in points:
  blocks.append([[P.eval(ps[j][i],x) for j in range(20)] for i in range(6)])
  assert all(0<=a<Q for row in blocks[-1] for a in row)
 exceptional=[i for i,x in enumerate(points) if not singular[i] and P.eval(Z0,x)==0]
 assert len(exceptional)==1 and points[exceptional[0]]==(0,0,0,1)
 star=exceptional[0]
 block_hist=collections.Counter((int(singular[i]),rank(A.K,b)) for i,b in enumerate(blocks))
 assert block_hist=={(0,4):349,(0,0):1,(1,2):50}
 scalar_basis=[]
 for j in range(2):
  a=[0]*20;a[12+j]=a[18+j]=1;scalar_basis.append(a)
 for b in blocks:
  for t in scalar_basis:assert all(sum(x*y for x,y in zip(row,t))%Q==0 for row in b)
 # Point-pair enumeration: no tangent-plane classification is assumed here.
 lines=set()
 for i in range(400):
  if not singular[i]:continue
  for j in range(400):
   if j==i:continue
   ids=tuple(sorted([index[normal([a+t*b for a,b in zip(points[i],points[j])])] for t in range(Q)]+[j]))
   if sum(singular[k] for k in ids)==1:lines.add(ids)
 lines=sorted(lines);assert len(lines)==400
 degree=collections.Counter(k for ids in lines for k in ids if not singular[k])
 assert len(degree)==350 and set(degree.values())=={8}
 ranks=collections.Counter();records=[];good=bad=0
 for ids in lines:
  ordinary=[i for i in ids if not singular[i]];rr=[]
  for subset in itertools.combinations(ordinary,5):
   m=[row for i in subset for row in blocks[i]];r=rank(A.K,m);rr.append(r);ranks[r]+=1
   assert r==(16 if star in ids else 18)
  full_rank=rank(A.K,[row for i in ordinary for row in blocks[i]])
  assert full_rank==(16 if star in ids else 18)
  records.append(dict(points=list(ids),ordinary=ordinary,five_point_ranks=rr,all_ordinary_rank=full_rank))
  if star in ids:bad+=1
  else:good+=1
 assert (good,bad)==(392,8) and ranks=={18:8232,16:168}
 exceptional_lines=[r for r in records if star in r['points']]
 exceptional_pairs=[]
 for i,j in itertools.combinations(range(8),2):
  ids=sorted(set(exceptional_lines[i]['ordinary']+exceptional_lines[j]['ordinary']))
  pair_rank=rank(A.K,[row for k in ids for row in blocks[k]])
  assert pair_rank==18
  exceptional_pairs.append([i,j,pair_rank])
 # Canonical 20 graph coordinates plus 28 gauge directions span all raw 48 coordinates.
 def flatten(lift):return [v for col in lift for u in col[:2] for v in F.digits(u)]
 raw_graph=[flatten(lift) for _,_,lift in basis]
 zvec=[c[2] for c in basis[0][2]];T=core(A,[0]*6,[[0,0],[0,0]])[:4]
 gauge=[]
 for col in range(4):
  for t in T:
   lift=[[0,0,z] for z in zvec];lift[col][0]=t[0];lift[col][1]=t[1];gauge.append(flatten(lift))
 kb=[F.from_digits([int(i==j) for i in range(6)]) for j in range(6)]
 for coord in range(2):
  for a in kb:
   lift=[[0,0,z] for z in zvec]
   for col,z in zip(lift,zvec):col[coord]=F.mul(a,z)
   gauge.append(flatten(lift))
 assert rank(A.K,gauge)==28 and rank(A.K,gauge+raw_graph)==48
 # Complete scalar family: every member has the displayed rank-three codeword.
 endpoints=[]
 for tau in A.E2:
  U=core(A,[0]*6,[[tau,0],[0,tau]])
  h=[1,Q,F.mul(A.bar(tau),F.mul(Q*Q,F.inv(A.dual[2])))]
  word=[F.dot(h,u) for u in U]
  assert rank(A.K,[list(F.digits(y)) for y in word])==3
  assert A.kspan_rank(U)==8
  endpoints.append(dict(tau=tau,U=[list(u) for u in U],h=h,word=word))
 # All degree-three generators in the fixed cubic subfield are covered by PGL(2,K).
 transformations=[];images={}
 for mat in projective(Q,4):
  a,c,b,d=mat
  if (a*d-b*c)%Q==0:continue
  den=F.add(a,F.scale(b,Q));num=F.add(c,F.scale(d,Q));xi1=F.mul(num,F.inv(den))
  assert xi1<Q**3 and xi1>=Q
  assert xi1 not in images
  images[xi1]=mat;transformations.append([list(mat),xi1])
 assert set(images)==set(range(Q,Q**3)) and len(transformations)==336
 output=dict(q=Q,field=dict(q=Q,beta=F.beta,nu=F.nu,cubic_polynomial=F.E.poly),
  points=[list(x) for x in points],singular=singular,exceptional=star,
  blocks=blocks,scalar_kernel=scalar_basis,canonical_raw_columns=raw_graph,
  gauge_raw_columns=gauge,tangents=records,exceptional_tangent_pairs=exceptional_pairs,scalar_endpoints=endpoints,
  cubic_generator_transformations=transformations,
  counts=dict(projective_points=400,ordinary=350,singular=50,ordinary_nonexceptional=349,
   tangents=400,good_tangents=good,exceptional_tangents=bad,
   five_point_rank_histogram={str(k):v for k,v in sorted(ranks.items())},
   ordinary_tangent_degree=8,nonzero_graph_zero_bound=(400*4+3)//8,exceptional_pair_ranks=len(exceptional_pairs),
   scalar_endpoints=len(endpoints),gauge_rank=28,total_raw_rank=48))
 (args.work/'primary_data.json').write_text(json.dumps(output,separators=(',',':'))+'\n')
 result=dict(status='passed',counts=output['counts'],arithmetic='cubic-then-quadratic coefficient tower; polynomial normal from attributed input',
  scope='complete 400-point and 400-tangent incidence for one normalized q=7 Hermitian graph; not all codes or all remaining special sections',seconds=time.monotonic()-start)
 (args.work/'primary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False),flush=True)
if __name__=='__main__':main()
