#!/usr/bin/env python3
"""An auxiliary test of the three-space square-span classification.
Complete q=3,4 Grassmannian checks; selected q=3,5,7 actual scattered sections.
These are not exhaustive code searches.
"""
from pathlib import Path
import sys,itertools,collections,json,argparse,time,hashlib
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'vendor'))
from algebra import Algebra,projective
from tower_arithmetic import rref,rank
from baseline_octic import Polynomial,octic

def spaces(q,n,k):
 for piv in itertools.combinations(range(n),k):
  free=[(i,j) for i,p in enumerate(piv) for j in range(p+1,n) if j not in piv]
  for vals in itertools.product(range(q),repeat=len(free)):
   rows=[[int(j==p) for j in range(n)] for p in piv]
   for (i,j),v in zip(free,vals):rows[i][j]=v
   yield rows

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path,required=True);a=ap.parse_args();start=time.monotonic();a.work.mkdir(parents=True,exist_ok=True)
 classifications=[]
 for qq in [3,4]:
  A=Algebra(qq);F=A.F;K=A.K;hist=collections.Counter();zeros=set();n=0
  def canonical(S):return tuple(tuple(r) for r in rref(K,[F.digits(x) for x in S],6)[0])
  for M in spaces(qq,6,3):
   S=[F.from_digits(r) for r in M];er=len(A.rr([A.ec(s) for s in S])[1]);n+=1
   sq=[F.mul(S[i],S[j]) for i in range(3) for j in range(i,3)]
   sr=rank(K,[F.digits(x) for x in sq]);hist[(er,sr)]+=1
   if er==3:
    assert sr in (3,5,6)
    if sr<6:zeros.add(tuple(tuple(r) for r in M))
  assert n=={3:33880,4:376805}[qq]
  assert hist[(2,5)]==(qq**4+qq**2+1)*sum(qq**i for i in range(4))
  assert all(sr in (3,5,6) for er,sr in hist)
  seen=set();reps=[];degs=[]
  for t in range(F.Q):
   if t in seen or F.pow(t,qq**2)==t:continue
   deg=3 if F.pow(t,qq**3)==t else 6
   orbit={F.add(a,F.scale(b,t)) for a in range(qq) for b in range(1,qq)}
   for c in range(qq):
    inv=F.inv(F.add(t,F.neg(c)))
    orbit.update(F.add(a,F.scale(b,inv)) for a in range(qq) for b in range(1,qq))
   assert len(orbit)==qq*(qq**2-1) and not seen.intersection(orbit)
   seen.update(orbit);reps.append(t);degs.append(deg)
  assert collections.Counter(degs)=={3:1,6:qq**3+qq-1}
  generated=set();bydeg={3:set(),6:set()}
  scales=[F.from_digits(v) for v in projective(qq,6)]
  for t,d in zip(reps,degs):
   plane=[1,t,F.mul(t,t)]
   for alpha in scales:
    sp=canonical([F.mul(alpha,v) for v in plane]);generated.add(sp);bydeg[d].add(sp)
  assert not(bydeg[3]&bydeg[6]) and generated==zeros
  assert len(bydeg[3])==qq**3+1 and len(bydeg[6])==(qq**3+qq-1)*sum(qq**i for i in range(6))
  digest=hashlib.sha256(b''.join(bytes(x for row in sp for x in row) for sp in sorted(zeros))).hexdigest()
  classifications.append(dict(q=qq,field=dict(q=qq,beta=F.beta,nu=F.nu,cubic_polynomial=F.E.poly),
    total_three_spaces=n,rank_histogram={str(k):v for k,v in sorted(hist.items())},ordinary_zero_spaces=len(zeros),
    cubic_progressions=len(bydeg[3]),sextic_progressions=len(bydeg[6]),zero_space_sha256=digest))
  print('complete scalar classification',qq,n,len(zeros),flush=True)
 # Only selected input sections, with their actual octic built anew.
 records=json.loads((Path(__file__).resolve().parents[1]/'inputs/section_samples.json').read_text())
 bindings=[];total=0
 for r in records:
  B=Algebra(r['q']);G=B.F;P=Polynomial(B);T=[tuple(v) for v in r['section']]
  weights=B.point_weights(T);assert weights['histogram']=={1:(r['q']**4-1)//(r['q']-1)}
  O,_=octic(B,P,T);bh=collections.Counter();ordinary=0
  for x in projective(B.q,4):
   p=[G.dot(x,[v[j] for v in T]) for j in range(2)];chart=next(i for i,v in enumerate(x) if v)
   S=[B.sub(G.mul(p[0],T[i][1]),G.mul(p[1],T[i][0])) for i in range(4) if i!=chart]
   assert rank(B.K,[G.digits(s) for s in S])==3
   er=len(B.rr([B.ec(s) for s in S])[1]);sq=[G.mul(S[i],S[j]) for i in range(3) for j in range(i,3)]
   sr=rank(B.K,[G.digits(s) for s in sq]);oz=P.eval(O,x)==0
   assert oz==(sr<6)
   if er==3:assert sr in (3,5,6);ordinary+=1
   bh[(er,sr)]+=1;total+=1
  bindings.append(dict(q=B.q,label=r['label'],point_count=sum(bh.values()),ordinary=ordinary,
    rank_histogram={str(k):v for k,v in sorted(bh.items())},octic_identically_zero=not O))
  print('square-span binding',B.q,r['label'],sum(bh.values()),flush=True)
 result=dict(status='passed',complete_scalar_classifications=classifications,
  selected_scattered_sections=bindings,selected_section_point_bindings=total,
  scope='q=3,4 scalar three-spaces fully checked; listed scattered sections only, no complete q=7 r=0 classification',seconds=time.monotonic()-start)
 (a.work/'square_span.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False),flush=True)
if __name__=='__main__':main()
