#!/usr/bin/env python3
from pathlib import Path
import argparse,json

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path,required=True);a=ap.parse_args()
 p=json.loads((a.work/'primary_data.json').read_text());idx={tuple(x):i for i,x in enumerate(p['points'])}
 pts=[]
 for t in range(5):
  v=[t,0,1,0];iv=pow(next(x for x in v if x),-1,7);pts.append([x*iv%7 for x in v])
 ids=[idx[tuple(x)] for x in pts];cols=[i for i in range(20) if i not in (12,13)]
 rows=[0,1,2,3,6,7,8,9,12,13,14,15,18,19,20,21,26,27]
 full=[r for i in ids for r in p['blocks'][i]];minor=[[full[i][j] for j in cols] for i in rows]
 m=[r[:] for r in minor];det=1
 for j in range(18):
  k=next((i for i in range(j,18) if m[i][j]),None);assert k is not None
  if k!=j:m[k],m[j]=m[j],m[k];det=-det%7
  det=det*m[j][j]%7;iv=pow(m[j][j],-1,7)
  for k in range(j+1,18):
   z=m[k][j]*iv%7;m[k]=[(x-z*y)%7 for x,y in zip(m[k],m[j])]
 assert det==6
 (a.work/'example_minor.json').write_text(json.dumps(dict(point_ids=ids,points=pts,column_ids=cols,row_ids=rows,minor=minor,determinant_mod7=det),indent=2)+'\n')
 print('18 by 18 minor determinant = 6 mod 7',flush=True)
if __name__=='__main__':main()
