#!/usr/bin/env python3
"""Independent original-trace reconstruction, without importing primary normals.
Arithmetic is quadratic-then-cubic; elimination uses rightmost pivots.
Canonical conic lines are found by K-rationality, not by f_H.
"""
from pathlib import Path
import sys,itertools,json,collections,time,argparse
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'vendor'))
from graph_independent_arithmetic import Field,U_from_J,proj

q=7

def rr(rows,n):
 a=[list(r) for r in rows];p=[];i=0
 for j in range(n-1,-1,-1):
  k=next((k for k in range(i,len(a)) if a[k][j]%q),None)
  if k is None:continue
  a[i],a[k]=a[k],a[i];inv=pow(a[i][j],-1,q);a[i]=[(x*inv)%q for x in a[i]]
  for k in range(len(a)):
   if k!=i and a[k][j]:
    c=a[k][j];a[k]=[(x-c*y)%q for x,y in zip(a[k],a[i])]
  p.append(j);i+=1
  if i==len(a):break
 return a[:i],p

def nk(rows,n):
 a,p=rr(rows,n);ans=[]
 for j in range(n):
  if j in p:continue
  v=[0]*n;v[j]=1
  for row,k in zip(a,p):v[k]=-row[j]%q
  ans.append(v)
 return ans

def ei(F,mat):
 n=len(mat);a=[list(row)+[int(i==j) for j in range(n)] for i,row in enumerate(mat)];out=[None]*n;i=0
 for j in range(n-1,-1,-1):
  k=next((k for k in range(i,n) if a[k][j]),None);assert k is not None
  a[i],a[k]=a[k],a[i];iv=F.ei[a[i][j]];a[i]=[F.em[iv][z] for z in a[i]]
  for k in range(n):
   if k!=i and a[k][j]:
    c=a[k][j];a[k]=[F.ea[x][F.en[F.em[c][y]]] for x,y in zip(a[k],a[i])]
  i+=1
 for row in a:
  j=next(j for j in range(n) if row[j]);assert row[j]==1;out[j]=row[n:]
 return out

def tr(F,x):
 v=F.add(F.add(x,F.pow(x,q*q)),F.pow(x,q**4));assert v<F.e;return v

def atr(F,x):
 a=tr(F,x);r=F.ea[a][F.epow(a,q)];assert r<q;return r

def dot_e(F,a,b):
 z=0
 for x,y in zip(a,b):z=F.ea[z][F.em[x][y]]
 return z

def coef(F,z,ss):
 out=[]
 for i,j in [(0,0),(0,1),(0,2),(1,1),(1,2),(2,2)]:
  v=F.mul(F.pow(ss[i],q*q),F.pow(ss[j],q**4))
  if i!=j:v=F.add(v,F.mul(F.pow(ss[j],q*q),F.pow(ss[i],q**4)))
  out.append(tr(F,F.mul(z,v)))
 return out

def normalize(v):
 inv=pow(next(x for x in v if x),-1,q);return tuple(x*inv%q for x in v)

def qform(x):
 a,d,b0,b1=x;return (a*d-b0*b0+3*b1*b1)%q

def polar(x,y):
 a,d,b,c=x;aa,dd,bb,cc=y;return (a*dd+d*aa-2*b*bb+6*c*cc)%q

def original_map(F,H):
 """Return independent ss and 3x4 weights for all raw graph variables."""
 xi,mu=F.xi,F.mu
 T=[(1,0),(0,xi),(xi,1),(F.mul(xi,F.bar(mu)),mu)]
 wh=[F.add(H[0][j],F.mul(xi,H[1][j])) for j in range(2)];ell=[F.neg(wh[1]),wh[0]]
 vals=[F.dot(ell,t) for t in T]
 kb=[1,mu,xi,F.mul(mu,xi),F.mul(xi,xi),F.mul(mu,F.mul(xi,xi))]
 D=[F.dot(v,kb) for v in nk([[atr(F,F.mul(s,b)) for b in kb] for s in vals],6)]
 assert len(D)==3
 # Pick a K-basis of the rank-three image; its E-independence is checked by inverse.
 vv,p=rr([F.flat([s]) for s in vals],6)
 ss=[F.dot(v,kb) for v in vv];assert len(ss)==3
 ei(F,[F.dig(s) for s in ss])
 comp=kb[2:]
 zvec=[F.mul(F.alpha,z) for z in [1,mu,xi,F.mul(mu,xi)]]
 mat=[[atr(F,F.mul(z,b)) for b in comp] for z in zvec]
 ci=ei(F,mat);assert all(x<q for row in ci for x in row)
 di=ei(F,[F.dig(d) for d in D])
 gram=[[tr(F,F.mul(x,y)) for y in F.eb] for x in F.eb];gi=ei(F,gram)
 dual=[F.dot(row,F.eb) for row in gi]
 weights=[]
 for i in range(3):
  ws=[]
  for slot in range(4):
   a=ci[0][slot]+q*ci[1][slot];b=ci[2][slot]+q*ci[3][slot]
   aa=F.dot([F.em[di[j][i]][a] for j in range(3)],dual)
   bb=F.dot([F.em[di[j][i]][b] for j in range(3)],dual)
   ws.append(F.sub(F.mul(aa,dual[2]),F.mul(bb,dual[1])))
  weights.append(ws)
 raw=[]
 for slot in range(4):
  for coord in range(2):
   # Use the same raw-coordinate order as primary: 1,xi,xi^2,mu,mu*xi,mu*xi^2.
   for elem in [1,xi,F.mul(xi,xi),mu,F.mul(mu,xi),F.mul(mu,F.mul(xi,xi))]:
    z=0
    for i in range(3):
     rhs=-atr(F,F.mul(D[i],F.mul(ell[coord],elem)))%q
     z=F.add(z,F.scale(rhs,weights[i][slot]))
    raw.append(z)
 return ss,raw,kb

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path,required=True);args=ap.parse_args();start=time.monotonic()
 data=json.loads((args.work/'primary_data.json').read_text());F=Field(data['field'])
 assert (F.nu,F.beta,F.cp)==(3,0,[1,0,1,1])
 # Independently enumerate all projective points with last pivot, then normalise.
 points=sorted(set(normalize(v) for v in proj(q,4)))
 assert set(points)==set(map(tuple,data['points'])) and len(points)==400
 idx={x:i for i,x in enumerate(map(tuple,data['points']))};sing={idx[x] for x in points if qform(x)==0}
 assert sing=={i for i,v in enumerate(data['singular']) if v} and len(sing)==50
 star=idx[(0,0,0,1)];basis=[]
 for i in range(10):
  for e in [1,q**3]:
   J=[0]*6;N=[[0,0],[0,0]]
   if i<6:J[i]=e
   else:N[(i-6)//2][(i-6)%2]=e
   U=U_from_J(F,J,N);basis.append([list(u) for u in U[4:]])
 # Canonical lift coordinates are regenerated, not trusted from the input JSON.
 flat_basis=[]
 for lift in basis:
  row=[]
  for u in lift:
   for z in u[:2]:
    zz=F.back(z);row.extend([(zz//q**j)%q for j in range(6)])
  flat_basis.append(row)
 assert flat_basis==data['canonical_raw_columns']
 def raw_coordinates(lift):
  out=[]
  for col in lift:
   for z in col[:2]:
    z=F.back(z);out.extend([(z//q**j)%q for j in range(6)])
  return out
 base=U_from_J(F,[0]*6,[[0,0],[0,0]]);zvec=[u[2] for u in base[4:]];gauge=[]
 for slot in range(4):
  for u in base[:4]:
   lift=[[0,0,z] for z in zvec];lift[slot][0]=u[0];lift[slot][1]=u[1];gauge.append(raw_coordinates(lift))
 for coord in range(2):
  for a in [1,F.xi,F.mul(F.xi,F.xi),F.mu,F.mul(F.mu,F.xi),F.mul(F.mu,F.mul(F.xi,F.xi))]:
   lift=[[0,0,z] for z in zvec]
   for col,z in zip(lift,zvec):col[coord]=F.mul(a,z)
   gauge.append(raw_coordinates(lift))
 assert gauge==data['gauge_raw_columns']
 assert len(rr(gauge,48)[1])==28 and len(rr(gauge+flat_basis,48)[1])==48
 scalar_raw=[[(a+b)%q for a,b in zip(flat_basis[12+j],flat_basis[18+j])] for j in range(2)]
 common=gauge+scalar_raw;assert len(rr(common,48)[1])==30
 blocks={};rawblocks={};normal_dims=collections.Counter();comparisons=0
 for k,x in enumerate(points):
  i=idx[x]
  if i in sing:continue
  a,d,b0,b1=x;b=b0+q*b1;H=[[a,b],[F.bar(b),d]]
  ss,raw,kb=original_map(F,H)
  # All conics in this net are computed from relative traces; find its K-rational subspace.
  columns=[coef(F,e,ss) for e in kb]
  kernel=nk([[columns[j][r]//q for j in range(6)] for r in range(6)],6)
  normal_dims[len(kernel)]+=1
  if i==star:
   assert len(kernel)==3
   blocks[i]=[[0]*20 for _ in range(6)];rawblocks[i]=[[0]*48 for _ in range(6)]
   continue
  assert len(kernel)==1
  z0=F.dot(kernel[0],kb);v0=F.dig(z0)
  assert all(c<q for c in coef(F,z0,ss)) and z0!=0
  quotient=[]
  for z in raw:
   v=F.dig(z);col=[]
   for j,k1 in [(0,1),(0,2),(1,2)]:
    w=F.ea[F.em[v[j]][v0[k1]]][F.en[F.em[v[k1]][v0[j]]]];col.extend([w%q,w//q])
   quotient.append(col)
  rawmatrix=list(map(list,zip(*quotient)));rawblocks[i]=rawmatrix
  assert len(rr(rawmatrix,48)[1])==4
  assert all(sum(a*b for a,b in zip(row,g))%q==0 for row in rawmatrix for g in common)
  bm=[[sum(a*b for a,b in zip(row,v))%q for v in flat_basis] for row in rawmatrix];blocks[i]=bm
  assert rr(bm,20)[0]==rr(data['blocks'][i],20)[0]
  comparisons+=1
  if comparisons%100==0:print('original trace point blocks',comparisons,flush=True)
 assert comparisons==349 and normal_dims=={1:349,3:1}
 # Independent tangent enumeration uses only the polar equation, not point counting on lines.
 lines=set()
 rawpoints=[tuple(p) for p in data['points']]
 for i in sorted(sing):
  x=rawpoints[i]
  for y in points:
   if y==x or polar(x,y)!=0:continue
   ids={idx[normalize(tuple((a+t*b)%q for a,b in zip(x,y)))] for t in range(q)};ids.add(idx[y])
   assert len(ids)==8 and len(ids&sing)==1
   lines.add(tuple(sorted(ids)))
 assert len(lines)==400 and lines=={tuple(t['points']) for t in data['tangents']}
 line_lookup={tuple(t['points']):t for t in data['tangents']}
 hist=collections.Counter();raw_hist=collections.Counter();inc=collections.Counter();ranks_checked=0
 for count,ids in enumerate(sorted(lines)):
  ordinary=sorted(set(ids)-sing);inc.update(ordinary);got=[]
  for sub in itertools.combinations(ordinary,5):
   m=[row for i in sub for row in blocks[i]];r=len(rr(m,20)[1])
   mr=[row for i in sub for row in rawblocks[i]];rraw=len(rr(mr,48)[1])
   assert r==rraw==(16 if star in ids else 18)
   hist[r]+=1;raw_hist[rraw]+=1;got.append(r);ranks_checked+=1
  assert got==line_lookup[ids]['five_point_ranks']
  full=len(rr([row for i in ordinary for row in rawblocks[i]],48)[1])
  assert full==line_lookup[ids]['all_ordinary_rank']==(16 if star in ids else 18)
  if (count+1)%100==0:print('independent tangent lines',count+1,flush=True)
 assert hist=={18:8232,16:168} and raw_hist==hist and set(inc.values())=={8} and len(inc)==350
 exceptional=sorted(ids for ids in lines if star in ids)
 for i,j in itertools.combinations(range(8),2):
  expected=18
  ordinary=sorted(set(exceptional[i]+exceptional[j])-sing)
  r=len(rr([row for k in ordinary for row in rawblocks[k]],48)[1]);assert r==expected==18
 # All 49 scalar endpoints, in independently rebuilt fields/graphs.
 for r in data['scalar_endpoints']:
  U=U_from_J(F,[0]*6,[[r['tau'],0],[0,r['tau']]])
  assert U==[tuple(F.convert(x) for x in u) for u in r['U']]
  tau=F.convert(r['tau']);h=[1,F.xi,F.mul(F.bar(tau),F.mul(F.mul(F.xi,F.xi),F.inv(F.alpha)))]
  word=[F.dot(h,u) for u in U]
  assert word==[F.convert(x) for x in r['word']]
  assert F.rank([F.flat(u) for u in U])==8 and F.rank([F.flat([z]) for z in word])==3
 # Recheck full degree-three generator orbit and formulas with independent field labels.
 images=set()
 for mat,expected in data['cubic_generator_transformations']:
  a,c,b,d=mat;assert (a*d-b*c)%q
  actual=F.mul(F.add(c,F.scale(d,F.xi)),F.inv(F.add(a,F.scale(b,F.xi))))
  assert actual==F.convert(expected) and F.pow(actual,q**3)==actual and F.pow(actual,q)!=actual
  images.add(actual)
 assert len(images)==336
 (args.work/'raw_trace_blocks.json').write_text(json.dumps(dict(
  raw_coordinate_order='input vectors (1,0),(mu,0),(0,1),(0,mu) of E^2; each output x then y in (1,xi,xi^2,mu,mu*xi,mu*xi^2)',
  points=data['points'],ordinary_blocks={str(i):b for i,b in rawblocks.items()},
  common_kernel_basis=rr(common,48)[0]),separators=(',',':'))+'\n')
 result=dict(status='passed',original_trace_point_blocks=349,raw_graph_dimensions=48,
  graph_basis_directions_per_point=48,original_linear_basis_evaluations=349*48,
  independently_compared_point_rowspaces=349,exceptional_normal_dimension=3,
  complete_tangent_lines=400,five_point_stack_matrices=ranks_checked,
  full_48_column_stack_rank_histogram={str(k):v for k,v in sorted(raw_hist.items())},
  canonical_20_column_stack_rank_histogram={str(k):v for k,v in sorted(hist.items())},
  scalar_rank_three_endpoints=49,cubic_generators=336,exceptional_line_pair_ranks=28,nonzero_graph_zero_bound=200,
  arithmetic='quadratic-then-cubic polynomial coefficients; rightmost-pivot elimination',
  independent_scope='original local trace equations and K-rational conic subspaces; imports no primary graph normal, f_H formula, sextic polynomial, or tangent enumeration',
  seconds=time.monotonic()-start)
 (args.work/'independent.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False),flush=True)
if __name__=='__main__':main()
