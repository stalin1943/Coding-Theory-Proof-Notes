#pragma once
// X_B=(BT)^perp, rank-three projective directions, and the K-linear map
// u -> [r -> Tr(u . (x Phi(y r)-y Phi(x r)))], for r=1,mu.
// Only q=3,4 are enumerated; the two-word point masks support all their PG(3,q) points.
#include "common.hpp"
#include <random>
using V2=array<int,2>;using T4=array<V2,4>;
inline int det2(const Field&f,V2 u,V2 v){return sub(f,f.mul(u[0],v[1]),f.mul(u[1],v[0]));}
inline vector<vector<int>> nullK(const Field&f,vector<vector<int>>a,int n){int r=0;vector<int>ps;for(int j=0;j<n&&r<(int)a.size();j++){int p=r;while(p<(int)a.size()&&!a[p][j])p++;if(p==(int)a.size())continue;swap(a[p],a[r]);int iv=f.ki[a[r][j]];for(int k=j;k<n;k++)a[r][k]=f.km[iv][a[r][k]];for(int i=0;i<(int)a.size();i++)if(i!=r){int c=a[i][j];for(int k=j;k<n;k++)a[i][k]=f.ka[a[i][k]][f.kn[f.km[c][a[r][k]]]];}ps.push_back(j);r++;}vector<vector<int>>out;for(int j=0;j<n;j++)if(find(ps.begin(),ps.end(),j)==ps.end()){vector<int>v(n);v[j]=1;for(int i=0;i<r;i++)v[ps[i]]=f.kn[a[i][j]];out.push_back(v);}return out;}
inline vector<vector<vector<int>>> grass2(const Field&f,int n){vector<vector<vector<int>>>out;for(int a=0;a<n-1;a++)for(int b=a+1;b<n;b++){vector<pair<int,int>>slots;for(int j=a+1;j<n;j++)if(j!=b)slots.push_back({0,j});for(int j=b+1;j<n;j++)slots.push_back({1,j});int lim=1;for(auto p:slots)lim*=f.q;for(int z=0;z<lim;z++){vector<vector<int>>R(2,vector<int>(n));R[0][a]=R[1][b]=1;int x=z;for(auto[i,j]:slots){R[i][j]=x%f.q;x/=f.q;}out.push_back(R);}}return out;}
inline vector<int> flatK(const Field&f,V2 v){vector<int>x(12);for(int j=0;j<6;j++){x[j]=f.digits[v[0]][j];x[6+j]=f.digits[v[1]][j];}return x;}
inline V2 unflatK(const Field&f,const vector<int>&v){V2 a{};int pw=1;for(int j=0;j<6;j++){a[0]+=pw*v[j];a[1]+=pw*v[6+j];pw*=f.q;}return a;}
struct Mask{uint64_t lo=0,hi=0;void add(int i){if(i<64)lo|=1ULL<<i;else hi|=1ULL<<(i-64);}bool contains(Mask b)const{return (lo&b.lo)==b.lo&&(hi&b.hi)==b.hi;}int count()const{return __builtin_popcountll(lo)+__builtin_popcountll(hi);}};
struct Prep{
 const Field&f; vector<int>zb,fb; vector<vector<int>>pg; vector<vector<vector<int>>>lines;vector<Mask>linemask; vector<array<int,2>>Bs;
 Prep(const Field&ff):f(ff){int pw=1;for(int i=0;i<6;i++){fb.push_back(pw);pw*=f.q;}zb={1,f.mu,f.xi,f.mul(f.mu,f.xi)};pg=proj(f.q,4);lines=grass2(f,4);map<int,int>ids;for(int i=0;i<(int)pg.size();i++){int k=0,p=1;for(int c:pg[i]){k+=p*c;p*=f.q;}ids[k]=i;}
 for(auto&R:lines){Mask m;for(auto c:proj(f.q,2)){vector<int>v(4);for(int j=0;j<4;j++)v[j]=f.ka[f.km[c[0]][R[0][j]]][f.km[c[1]][R[1][j]]];int lead=*find_if(v.begin(),v.end(),[](int x){return x;});int iv=f.ki[lead],k=0,p=1;for(int x:v){k+=p*f.km[iv][x];p*=f.q;}m.add(ids.at(k));}linemask.push_back(m);int x=combination(f,zb,R[0]),y=combination(f,zb,R[1]);if(erank(f,{x,y})==2)Bs.push_back({x,y});}
 }
};
struct Geometry{array<int,2>B;T4 X;Mask good;vector<int>allowed;};
inline Geometry geometry(const Prep&p,const T4&T,array<int,2>B){auto&f=p.f;Geometry g;g.B=B;vector<vector<int>>rows;
 for(int b:B)for(auto t:T){vector<int>r(12);for(int j=0;j<6;j++){r[j]=f.trace[f.mul(b,f.mul(t[0],p.fb[j]))];r[6+j]=f.trace[f.mul(b,f.mul(t[1],p.fb[j]))];}rows.push_back(r);}
 auto ns=nullK(f,rows,12);assert(ns.size()==4);for(int j=0;j<4;j++)g.X[j]=unflatK(f,ns[j]);
 for(int i=0;i<(int)p.pg.size();i++){V2 u{};for(int j=0;j<4;j++){u[0]=f.add(u[0],f.scale(p.pg[i][j],g.X[j][0]));u[1]=f.add(u[1],f.scale(p.pg[i][j],g.X[j][1]));}vector<int>vals;for(auto t:T)vals.push_back(f.add(f.mul(u[0],t[0]),f.mul(u[1],t[1])));int r=can(f,vals).size();assert(r==3||r==4);if(r==3)g.good.add(i);}
 for(int j=0;j<(int)p.lines.size();j++)if(g.good.contains(p.linemask[j]))g.allowed.push_back(j);return g;
}
inline bool validT(const Field&f,const Prep&p,const T4&T){vector<array<int,12>>et;for(auto t:T)for(int e:{1,f.mu}){auto v=flatK(f,{f.mul(e,t[0]),f.mul(e,t[1])});array<int,12>a{};copy(v.begin(),v.end(),a.begin());et.push_back(a);}if(f.rank(et)!=8)return false;set<int>pts;for(auto c:p.pg){V2 v{};for(int i=0;i<4;i++){v[0]=f.add(v[0],f.scale(c[i],T[i][0]));v[1]=f.add(v[1],f.scale(c[i],T[i][1]));}if(!v[0]&&!v[1])return false;int k=v[0]?f.mul(v[1],f.iv[v[0]]):f.Q;if(!pts.insert(k).second)return false;}return true;}
inline pair<vector<vector<int>>,vector<int>> rrefK(const Field&f,vector<vector<int>>a,int n){int r=0;vector<int>ps;for(int j=0;j<n&&r<(int)a.size();j++){int p=r;while(p<(int)a.size()&&!a[p][j])p++;if(p==(int)a.size())continue;swap(a[p],a[r]);int iv=f.ki[a[r][j]];for(int k=j;k<n;k++)a[r][k]=f.km[iv][a[r][k]];for(int i=0;i<(int)a.size();i++)if(i!=r){int c=a[i][j];if(c)for(int k=j;k<n;k++)a[i][k]=f.ka[a[i][k]][f.kn[f.km[c][a[r][k]]]];}ps.push_back(j);r++;}a.resize(r);return {a,ps};}
inline vector<int> freeGraph(const Prep&p,const T4&T){auto&f=p.f;vector<vector<int>>gauge;for(int j=0;j<4;j++)for(auto t:T){vector<int>a(48);for(int c=0;c<2;c++)for(int k=0;k<6;k++)a[j*12+c*6+k]=f.digits[t[c]][k];gauge.push_back(a);}for(int c=0;c<2;c++)for(int k=0;k<6;k++){vector<int>a(48);for(int j=0;j<4;j++){int z=f.mul(p.fb[k],p.zb[j]);for(int l=0;l<6;l++)a[j*12+c*6+l]=f.digits[z][l];}gauge.push_back(a);}auto[a,ps]=rrefK(f,gauge,48);assert(a.size()==28);vector<int>free;for(int j=0;j<48;j++)if(find(ps.begin(),ps.end(),j)==ps.end())free.push_back(j);assert(free.size()==20);return free;}
// Rows for e=1,omega, each with four X_B basis inputs, each graph coefficient dimension20.
inline vector<vector<vector<int>>> compatibility(const Prep&p,const Geometry&g,const vector<int>&free){auto&f=p.f;int x=g.B[0],y=g.B[1];vector<vector<vector<int>>>C(2,vector<vector<int>>(4,vector<int>(20)));
 for(int e=0;e<2;e++){int r=e?f.mu:1,xr=f.mul(x,r),yr=f.mul(y,r);for(int j=0;j<20;j++){int slot=free[j]/12,coord=free[j]/6%2,k=free[j]%6;int z=sub(f,f.scale(f.digits[yr][slot],x),f.scale(f.digits[xr][slot],y));for(int i=0;i<4;i++)C[e][i][j]=f.trace[f.mul(f.mul(g.X[i][coord],p.fb[k]),z)];}}
 return C;}
inline vector<vector<int>> lineEquations(const Prep&p,const vector<vector<vector<int>>>&C,int line){auto&f=p.f;vector<vector<int>>eq(4,vector<int>(20));for(int e=0;e<2;e++)for(int a=0;a<2;a++)for(int i=0;i<4;i++){int k=p.lines[line][a][i];if(k)for(int j=0;j<20;j++)eq[2*e+a][j]=f.ka[eq[2*e+a][j]][f.km[k][C[e][i][j]]];}return eq;}
