// Complete graph-kernel covering stage for the primary residual list.
#include "witness.hpp"
static uint64_t witness_count=0;static ostream* witness_file=nullptr;
#include <sstream>
#include <limits>
struct Condition{Geometry g;vector<vector<vector<int>>>C;vector<vector<vector<int>>>eq;};
using Rows=vector<vector<int>>;
inline string rowskey(const Rows&S){string s;for(auto&r:S)for(int x:r)s.push_back(char(x));return s;}
struct Solver{
 const Prep&p;const Field&f;T4 T;vector<int>free;vector<Condition>conds;uint64_t nodes=0,tested=0,exactbad=0;int maxdim=0;vector<vector<int>>survivors;bool unresolved=false;
 Solver(const Prep&pp,T4 tt):p(pp),f(p.f),T(tt){free=freeGraph(p,T);for(auto B:p.Bs){Condition c;c.g=geometry(p,T,B);c.C=compatibility(p,c.g,free);for(int l:c.g.allowed)c.eq.push_back(lineEquations(p,c.C,l));conds.push_back(move(c));}stable_sort(conds.begin(),conds.end(),[](auto&a,auto&b){return a.eq.size()<b.eq.size();});}
 Rows intersect(const Rows&S,const Rows&E){int d=S.size();Rows r;for(auto&e:E){vector<int>v(d);for(int i=0;i<d;i++)for(int j=0;j<20;j++)v[i]=f.ka[v[i]][f.km[S[i][j]][e[j]]];r.push_back(v);}auto ns=nullK(f,r,d);Rows out;for(auto&c:ns){vector<int>a(20);for(int i=0;i<d;i++)if(c[i])for(int j=0;j<20;j++)a[j]=f.ka[a[j]][f.km[c[i]][S[i][j]]];out.push_back(a);}return rrefK(f,out,20).first;}
 bool exact(const vector<int>&x){tested++;for(auto&c:conds){int a[2][4]={};for(int e=0;e<2;e++)for(int i=0;i<4;i++)for(int j=0;j<20;j++)a[e][i]=f.ka[a[e][i]][f.km[c.C[e][i][j]][x[j]]];for(int h=0;h<(int)p.pg.size();h++){Mask bit;bit.add(h);if(c.g.good.contains(bit))continue;int b0=0,b1=0;for(int i=0;i<4;i++){b0=f.ka[b0][f.km[a[0][i]][p.pg[h][i]]];b1=f.ka[b1][f.km[a[1][i]][p.pg[h][i]]];}if(!b0&&!b1){auto w=buildWitness(p,T,free,x,c.g,p.pg[h]);if(witness_count<20&&witness_file)writeWitness(*witness_file,p,T,c.g,w);witness_count++;exactbad++;return false;}}}return true;}
 void enumerate(const Rows&S){int d=S.size();if(d>10){unresolved=true;return;}for(auto&c:proj(f.q,d)){vector<int>x(20);for(int i=0;i<d;i++)if(c[i])for(int j=0;j<20;j++)x[j]=f.ka[x[j]][f.km[c[i]][S[i][j]]];if(exact(x))survivors.push_back(x);}}
 void recurse(const Rows&S,int start){nodes++;maxdim=max(maxdim,int(S.size()));if(S.empty())return;if(S.size()<=3){enumerate(S);return;}if(nodes>2000000){unresolved=true;return;}
  for(int b=start;b<(int)conds.size();b++){
   vector<Rows>children;set<string>seen;bool automatic=false;
   for(auto&E:conds[b].eq){auto child=intersect(S,E);if(child.size()==S.size()){automatic=true;break;}if(child.empty())continue;auto key=rowskey(child);if(seen.insert(key).second)children.push_back(move(child));}
   if(automatic)continue;
   for(auto&child:children){recurse(child,b+1);if(unresolved)return;}return;
  }
  enumerate(S);
 }
 void run(){Rows S(20,vector<int>(20));for(int i=0;i<20;i++)S[i][i]=1;recurse(S,0);sort(survivors.begin(),survivors.end());survivors.erase(unique(survivors.begin(),survivors.end()),survivors.end());}
};
int main(int argc,char**argv){assert(argc==5);Field f=makefield(atoi(argv[1]));Prep p(f);ifstream in(argv[2]);ofstream out(argv[3]);ofstream wf(string(argv[4])+".witnesses.jsonl");witness_file=&wf;string line;uint64_t total=0,nodes=0,tested=0,nonempty=0,unresolved=0;map<int,int>counts;auto start=chrono::steady_clock::now();while(getline(in,line)){auto k=line.find("\"T\":[");assert(k!=string::npos);string t=line.substr(k+5);for(char&c:t)if(c<'0'||c>'9')c=' ';stringstream ss(t);T4 T;for(auto&v:T)ss>>v[0]>>v[1];Solver solver(p,T);solver.run();total++;nodes+=solver.nodes;tested+=solver.tested;unresolved+=solver.unresolved;counts[solver.survivors.size()]++;if(!solver.survivors.empty()||solver.unresolved){nonempty++;out<<"{\"record\":"<<total-1<<",\"T\":[";for(int i=0;i<4;i++){if(i)out<<",";out<<"["<<T[i][0]<<","<<T[i][1]<<"]";}out<<"],\"unresolved\":"<<(solver.unresolved?"true":"false")<<",\"nodes\":"<<solver.nodes<<",\"tested\":"<<solver.tested<<",\"free\":[";for(int i=0;i<20;i++){if(i)out<<",";out<<solver.free[i];}out<<"],\"parameters\":[";bool fst=true;for(auto&x:solver.survivors){if(!fst)out<<",";fst=false;out<<"[";for(int i=0;i<20;i++){if(i)out<<",";out<<x[i];}out<<"]";}out<<"]}\n";out.flush();}
 if(total%20==0)cerr<<"q="<<f.q<<" solved="<<total<<" nonempty="<<nonempty<<" nodes="<<nodes<<" tested="<<tested<<" unresolved="<<unresolved<<" seconds="<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"\n";
 }
 ofstream summary(argv[4]);summary<<"{\"q\":"<<f.q<<",\"records\":"<<total<<",\"nodes\":"<<nodes<<",\"tested\":"<<tested<<",\"direct_witness_checks\":"<<witness_count<<",\"nonempty_records\":"<<nonempty<<",\"unresolved_records\":"<<unresolved<<",\"survivor_histogram\":{";bool first=true;for(auto[n,c]:counts){if(!first)summary<<",";first=false;summary<<"\""<<n<<"\":"<<c;}summary<<"},\"seconds\":"<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"}\n";
 cerr<<"DONE "<<total<<" nonempty "<<nonempty<<" unresolved "<<unresolved<<"\n";
 return 0;
}
