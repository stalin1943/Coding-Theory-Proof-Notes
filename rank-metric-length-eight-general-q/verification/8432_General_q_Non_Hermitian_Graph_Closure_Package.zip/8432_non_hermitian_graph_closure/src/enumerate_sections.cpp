// Complete primary section enumeration. No truncation option.
#include "blocker.hpp"
using Mat=array<int,4>; using M4=array<Mat,4>;
struct GrassChart {array<int,3>p;vector<pair<int,int>>slots;uint32_t offset,count;};
struct SectionUniverse{
 const Field&f; vector<GrassChart>charts;array<int,343>chartIndex{};uint32_t total=0;
 SectionUniverse(const Field&ff):f(ff){chartIndex.fill(-1);for(int a=0;a<5;a++)for(int b=a+1;b<6;b++)for(int c=b+1;c<7;c++){
  GrassChart ch;ch.p={a,b,c};ch.offset=total;ch.count=1;
  for(int i=0;i<3;i++)for(int j=ch.p[i]+1;j<7;j++)if(j!=a&&j!=b&&j!=c){ch.slots.push_back({i,j});ch.count*=f.q;}
  total+=ch.count;chartIndex[a+7*b+49*c]=charts.size();charts.push_back(ch);
 }assert(total==(f.q==3?925771u:24208613u));}
 M4 decode(const GrassChart&ch,uint32_t v)const{
  int x[3][7]={};for(int i=0;i<3;i++)x[i][ch.p[i]]=1;for(auto[i,j]:ch.slots){x[i][j]=v%f.q;v/=f.q;}assert(!v);
  M4 M;M[0]={1,0,0,1};for(int i=0;i<3;i++){int full[8]={};for(int j=0;j<7;j++)full[j+1]=x[i][j];for(int k=0;k<4;k++)M[i+1][k]=full[2*k]+f.q*full[2*k+1];}return M;
 }
 uint32_t encode(M4 M)const{
  int a[4][7]={};for(int i=0;i<4;i++){int full[8];for(int j=0;j<4;j++){full[2*j]=M[i][j]%f.q;full[2*j+1]=M[i][j]/f.q;}full[6]=f.ka[full[6]][f.kn[full[0]]];for(int j=0;j<7;j++)a[i][j]=full[j+1];}
  array<int,3>ps{};int r=0;
  for(int j=0;j<7&&r<4;j++){int p=r;while(p<4&&!a[p][j])p++;if(p==4)continue;for(int k=0;k<7;k++)swap(a[p][k],a[r][k]);int inv=f.ki[a[r][j]];for(int k=j;k<7;k++)a[r][k]=f.km[inv][a[r][k]];
   for(int i=0;i<4;i++)if(i!=r&&a[i][j]){int c=a[i][j];for(int k=j;k<7;k++)a[i][k]=f.ka[a[i][k]][f.kn[f.km[c][a[r][k]]]];}assert(r<3);ps[r++]=j;}
  assert(r==3);int ci=chartIndex[ps[0]+7*ps[1]+49*ps[2]];assert(ci>=0);const auto&ch=charts[ci];uint32_t v=0,pw=1;for(auto[i,j]:ch.slots){v+=pw*a[i][j];pw*=f.q;}assert(v<ch.count);return ch.offset+v;
 }
};
inline Mat mmul(const Field&f,Mat A,Mat B){return {f.eadd(f.emul(A[0],B[0]),f.emul(A[1],B[2])),f.eadd(f.emul(A[0],B[1]),f.emul(A[1],B[3])),f.eadd(f.emul(A[2],B[0]),f.emul(A[3],B[2])),f.eadd(f.emul(A[2],B[1]),f.emul(A[3],B[3]))};}
inline int mdet(const Field&f,Mat M){return f.eadd(f.emul(M[0],M[3]),f.en[f.emul(M[1],M[2])]);}
inline bool erank4(const Field&f,M4 M){int r=0;for(int j=0;j<4;j++){int p=r;while(p<4&&!M[p][j])p++;if(p==4)continue;swap(M[p],M[r]);int inv=f.iv[M[r][j]];for(int k=j;k<4;k++)M[r][k]=f.emul(inv,M[r][k]);for(int i=r+1;i<4;i++)if(M[i][j]){int c=M[i][j];for(int k=j;k<4;k++)M[i][k]=f.eadd(M[i][k],f.en[f.emul(c,M[r][k])]);}r++;}return r==4;}
inline vector<Mat> points(const Prep&p,const M4&M){vector<Mat>v;for(auto&c:p.pg){Mat a{};for(int i=0;i<4;i++)for(int j=0;j<4;j++)a[j]=p.f.eadd(a[j],p.f.emul(c[i],M[i][j]));v.push_back(a);}return v;}
inline bool scattered(const Field&f,const vector<Mat>&points){uint64_t seen=0;for(auto&M:points)if(mdet(f,M)==0){int a,b;if(M[0]||M[1]){a=M[0];b=M[1];}else{a=M[2];b=M[3];}assert(a||b);int dir=a?f.emul(b,f.iv[a]):f.e;uint64_t bit=1ULL<<dir;if(seen&bit)return false;seen|=bit;}return true;}
inline bool descended(const Field&f,const M4&M){vector<int>co;for(int i=0;i<4;i++){co.push_back(mdet(f,M[i]));for(int j=i+1;j<4;j++){Mat a;for(int k=0;k<4;k++)a[k]=f.eadd(M[i][k],M[j][k]);co.push_back(f.eadd(f.eadd(mdet(f,a),f.en[mdet(f,M[i])]),f.en[mdet(f,M[j])]));}}int a=0;for(int x:co)if(x){a=x;break;}assert(a);for(int x:co)if(f.emul(x,f.iv[a])>=f.q)return false;return true;}
inline T4 toT(const Field&f,const M4&M){T4 T;for(int i=0;i<4;i++)T[i]={f.add(M[i][0],f.mul(f.xi,M[i][2])),f.add(M[i][1],f.mul(f.xi,M[i][3]))};return T;}
int main(int argc,char**argv){assert(argc==4);assert(atoi(argv[1])==3||atoi(argv[1])==4);Field f=makefield(atoi(argv[1]));Prep p(f);SectionUniverse all(f);
 M4 HH={Mat{1,0,0,0},Mat{0,0,0,1},Mat{0,1,1,0},Mat{0,f.mu,f.pow(f.mu,f.q),0}};
 set<uint32_t>hermitian_ids;for(auto m:points(p,HH)){int d=mdet(f,m);if(!d)continue;Mat inv={m[3],f.en[m[1]],f.en[m[2]],m[0]};for(int&x:inv)x=f.emul(x,f.iv[d]);M4 N;for(int i=0;i<4;i++)N[i]=mmul(f,HH[i],inv);hermitian_ids.insert(all.encode(N));}
 assert(hermitian_ids.size()==size_t(f.q*f.q*f.q+f.q));
 ofstream out(argv[2]);auto start=chrono::steady_clock::now();vector<uint8_t>seen(all.total,0);
 uint64_t scan=0,rep=0,efail=0,nonSc=0,sc=0,herm=0,blocked=0,surv=0,zero=0;map<int,uint64_t>dims,orbSizes,blockerids;
 for(auto&ch:all.charts)for(uint32_t k=0;k<ch.count;k++){
  uint32_t idx=ch.offset+k;scan++;if(seen[idx])continue;auto M=all.decode(ch,k);if(!erank4(f,M)){efail++;continue;}rep++;auto pts=points(p,M);set<uint32_t>orbit;
  for(auto m:pts){int d=mdet(f,m);if(!d)continue;Mat inv={m[3],f.en[m[1]],f.en[m[2]],m[0]};for(int&x:inv)x=f.emul(x,f.iv[d]);M4 N;for(int i=0;i<4;i++)N[i]=mmul(f,M[i],inv);uint32_t id=all.encode(N);if(seen[id])assert(orbit.count(id));orbit.insert(id);seen[id]=1;}
  assert(orbit.count(idx));orbSizes[orbit.size()]++;if(!scattered(f,pts)){nonSc++;continue;}sc++;T4 T=toT(f,M);assert(validT(f,p,T));assert(descended(f,M)==bool(hermitian_ids.count(idx)));if(hermitian_ids.count(idx)){herm++;continue;}
  int block=-1;vector<Geometry>gg;for(int i=0;i<(int)p.Bs.size();i++){auto g=geometry(p,T,p.Bs[i]);if(g.allowed.empty()){block=i;break;}gg.push_back(move(g));}
  if(block>=0){blocked++;blockerids[block]++;continue;}
  auto free=freeGraph(p,T);vector<vector<int>>eq;int n1=0;for(auto&g:gg)if(g.allowed.size()==1){n1++;auto C=compatibility(p,g,free);auto e=lineEquations(p,C,g.allowed[0]);eq.insert(eq.end(),e.begin(),e.end());eq=rrefK(f,eq,20).first;if(eq.size()==20)break;}
  int d=20-eq.size();dims[d]++;if(!d){zero++;}else{surv++;out<<"{\"index\":"<<idx<<",\"orbit_size\":"<<orbit.size()<<",\"T\":[";for(int j=0;j<4;j++){if(j)out<<",";out<<"["<<T[j][0]<<","<<T[j][1]<<"]";}out<<"],\"dimension\":"<<d<<",\"unique_constraints\":"<<n1<<"}\n";}
  if(sc%1000==0)cerr<<"q="<<f.q<<" scan="<<scan<<" rep="<<rep<<" sc="<<sc<<" herm="<<herm<<" blocked="<<blocked<<" jointzero="<<zero<<" surviving="<<surv<<" seconds="<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"\n";

 }

 uint64_t weighted=0;for(auto[n,c]:orbSizes)weighted+=uint64_t(n)*c;
 if(scan==all.total){assert(weighted+efail==all.total);uint64_t q=f.q,q2=q*q,q4=q2*q2,q6=q4*q2,q8=q4*q4;assert(weighted==(q8-q2)*(q8-q4)*(q8-q6)/((q4-q)*(q4-q2)*(q4-q*q2)));}

 ofstream sum(argv[3]);sum<<"{\"q\":"<<f.q<<",\"universe\":"<<all.total<<",\"scan\":"<<scan<<",\"E_rank_fail\":"<<efail<<",\"E_full_orbits\":"<<rep<<",\"nonscattered_orbits\":"<<nonSc<<",\"scattered_orbits\":"<<sc<<",\"hermitian_orbits\":"<<herm<<",\"universal_blocked\":"<<blocked<<",\"unique_linear_zero\":"<<zero<<",\"surviving_orbits\":"<<surv<<",\"remaining_dimension_histogram\":{";bool first=true;for(auto[d,n]:dims){if(!first)sum<<",";first=false;sum<<"\""<<d<<"\":"<<n;}sum<<"},\"orbit_size_histogram\":{";first=true;for(auto[d,n]:orbSizes){if(!first)sum<<",";first=false;sum<<"\""<<d<<"\":"<<n;}sum<<"},\"seconds\":"<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"}\n";
 cerr<<"DONE q="<<f.q<<" total="<<all.total<<" scan="<<scan<<" rep="<<rep<<" sc="<<sc<<" herm="<<herm<<" blocked="<<blocked<<" zero="<<zero<<" surv="<<surv<<" seconds="<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"\n";
}
