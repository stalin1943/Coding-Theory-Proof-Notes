# 三元、四元非 Hermitian 散布特殊截面的图排除

`PROOF_zh.md` 给出完整中文证明；`THEOREMS_en.tex` 是可并入论文的英文定理片段。`DEPENDENCIES.md` 区分本轮独立证明和全 q 推论依赖的历史输入。

## 新结论

对 q=3、4，任何非 Hermitian 散布四维 T（dim_E ET=4）与二维 E-投影 Z 的八维图，都有两条秩四码字，联合展开秩为八。因此，它不能成为相交码。Hermitian 类则通过同一兼容核计算，仅保留二维标量族；这些图由显式秩三码字排除。

每个二维 K-标量平面 B≤Z（EB=Z）产生一个四维消息空间 X_B 和一个到二维空间的兼容映射。若其核有一个在 T 上秩四的向量，可通过8×6线性系统恢复第三消息坐标，直接构造零交秩支撑对。否则其核必须包含一条恒秩三的二维子空间，给图参数至多四条线性条件。两套完整有限覆盖处理所有这些可能。

## 复算

仅需 Python 3.10+ 标准库和 C++17 编译器，不需要 Sage、NumPy、SAT/优化器或 OpenMP。不得关闭 Python 或 C++ 断言。

```bash
python verify.py --work /absolute/path/to/new_or_empty_directory
```

启用额外运行检查：

```bash
python verify.py --work /absolute/path/to/another_empty_directory \
  --compiler clang++ --sanitize
```

工作目录必须不存在或为空。默认完整执行，不提供将部分扫描当作完整结论的选项。所有代码从源码编译；不分发本机可执行二进制。

## 文件说明

- `src/enumerate_sections.cpp`：第一套完整截面宇宙和右作用去重；直接空好线排除与单线线性条件。
- `src/solve_compatibility.cpp`：第一套剩余图核的完整并集覆盖。
- `src/independent.cpp`：不同域表示、不同规范化坐标和相反主元的第二套完整分类与图条件排除。
- `src/blocker.hpp`：标量平面、四维消息核、恒秩三二维子空间和20参数兼容矩阵。
- `src/witness.hpp`：直接恢复唯一的第三消息坐标，核验码字展开秩。
- `src/check_examples.cpp`：额外的完整公式对照、规范自由度检查与 Hermitian 阳性控制。
- `src/check_hermitian_primary.cpp` 和 `src/check_hermitian_independent.cpp`：分别完整重算 Hermitian 类的兼容图，比较实际剩余集合与二维标量族，并直接核验秩三码字。
- `src/verify_witnesses.cpp`：在第二域中建立显式同构，直接重算第一路径输出的实际码字对。
- `vendor/`：从输入 Heavy Projection Capacity 包明确复用的两个有限域算术实现；归属见 PROVENANCE.json。
- `reference/`：本轮实际输出。复算时不把其代表清单作为第二路径输入；两个完整路径均从 Grassmann 宇宙开始。

两套分支顺序不同，因此节点数和终端参数访问数可以不同。比较的是完整宇宙、轨道分布、全部非 Hermitian 图均被排除，以及实际码字对。叶端访问次数可包含重复的参数方向，不是不同码数量。

本包只重算本轮的新定理，不自动重跑全部历史依赖。英文文件做结构和内部引用检查；本包未声称编译新的完整 IEEE 投稿稿。
