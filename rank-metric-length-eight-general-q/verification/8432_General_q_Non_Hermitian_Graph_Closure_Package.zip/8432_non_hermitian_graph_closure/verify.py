#!/usr/bin/env python3
"""Recompute the complete NEW q=3,4 non-Hermitian graph exclusion.

Python standard library and a C++17 compiler are sufficient. No stored list is
used to generate a search space. Both complete finite paths start from the
Grassmann universe. The Hermitian orbit is also rechecked through the same compatibility criterion.
Historical heavy-section/global reductions remain explicit inputs.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

STEMS = ('enumerate_sections', 'solve_compatibility', 'independent',
         'check_examples', 'verify_witnesses',
         'check_hermitian_primary', 'check_hermitian_independent')


def mathematical(x):
    if isinstance(x, dict):
        return {k: mathematical(v) for k, v in x.items()
                if k not in {'seconds', 'elapsed_seconds'}}
    if isinstance(x, list):
        return [mathematical(y) for y in x]
    return x


def read_json(path: Path):
    return json.loads(path.read_text(encoding='utf-8'))


def compile_cpp(root: Path, work: Path, compiler: str, sanitize: bool) -> None:
    flags = ['-std=c++17', '-O3', '-march=native', '-D_GLIBCXX_ASSERTIONS']
    if sanitize:
        flags += ['-fsanitize=undefined', '-fno-sanitize-recover=all']
    for stem in STEMS:
        cmd = [compiler, *flags, str(root / 'src' / f'{stem}.cpp'),
               '-o', str(work / stem)]
        with (work / f'{stem}.compile.log').open('w') as log:
            subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT, check=True)


def execute(work: Path, stem: str, args: list[str], logname: str) -> None:
    with (work / logname).open('w') as log:
        subprocess.run([str(work / stem), *args], stdout=log,
                       stderr=subprocess.STDOUT, check=True)


def proof_structure(root: Path) -> dict:
    text = (root / 'THEOREMS_en.tex').read_text(encoding='utf-8')
    text = re.sub(r'(?<!\\)%[^\n]*', '', text)
    labels = re.findall(r'\\label\{([^}]+)\}', text)
    refs = re.findall(r'\\(?:eqref|ref)\{([^}]+)\}', text)
    assert len(labels) == len(set(labels))
    assert set(refs) <= set(labels)
    stack: list[str] = []
    for op, name in re.findall(r'\\(begin|end)\{([^}]+)\}', text):
        if op == 'begin':
            stack.append(name)
        else:
            assert stack and stack.pop() == name, (op, name)
    assert not stack
    return {'labels': len(labels), 'references': len(refs),
            'scope': 'structure and internal references; no full-paper compilation'}


def run(root: Path, work: Path, compiler: str | None = None,
        sanitize: bool = False, compare: bool = True) -> dict:
    if sys.flags.optimize:
        raise RuntimeError('Run without python -O; assertions are part of the checks.')
    root, work = root.resolve(), work.resolve()
    if work.exists() and any(work.iterdir()):
        raise ValueError('The work directory must not exist or must be empty.')
    work.mkdir(parents=True, exist_ok=True)
    start = time.perf_counter()
    compiler = compiler or os.environ.get('CXX') or shutil.which('g++')
    if not compiler:
        raise RuntimeError('A C++17 compiler is required.')
    manifest_checked = 0
    if compare and (root / 'MANIFEST.json').exists():
        for name, digest in read_json(root / 'MANIFEST.json').items():
            assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
            manifest_checked += 1
    compile_cpp(root, work, compiler, sanitize)
    outputs: list[str] = []
    summaries = []
    for q in (3, 4):
        residual = f'section_survivors_q{q}.jsonl'
        sections = f'sections_q{q}.json'
        failed = f'compat_survivors_q{q}.jsonl'
        compat = f'compat_q{q}.json'
        independent = f'independent_q{q}.json'
        samples = f'universal_examples_q{q}.jsonl'
        sample_summary = f'universal_examples_q{q}.json'
        direct_input = f'direct_input_q{q}.txt'
        direct_report = f'direct_independent_q{q}.json'
        hermitian_primary = f'hermitian_short_primary_q{q}.json'
        hermitian_independent = f'hermitian_short_independent_q{q}.json'
        execute(work, 'enumerate_sections',
                [str(q), str(work / residual), str(work / sections)],
                f'sections_q{q}.log')
        execute(work, 'solve_compatibility',
                [str(q), str(work / residual), str(work / failed), str(work / compat)],
                f'compat_q{q}.log')
        execute(work, 'independent', [str(q), str(work / independent)],
                f'independent_q{q}.log')
        execute(work, 'check_examples',
                [str(q), str(work / samples), str(work / sample_summary)],
                f'examples_q{q}.log')
        records = []
        for file in (work / samples, work / (compat + '.witnesses.jsonl')):
            records.extend(json.loads(line) for line in file.read_text().splitlines())
        with (work / direct_input).open('w') as out:
            out.write(f'{q} {len(records)}\n')
            for r in records:
                values = sum(r['T'], []) + sum(r['phi'], []) + r['B']
                values += r['message'] + r['hword'] + r['gword']
                assert len(values) == 37
                out.write(' '.join(map(str, values)) + '\n')
        execute(work, 'verify_witnesses',
                [str(work / direct_input), str(work / direct_report)],
                f'direct_q{q}.log')
        execute(work, 'check_hermitian_primary',
                [str(q), str(work / hermitian_primary)], f'hermitian_primary_q{q}.log')
        execute(work, 'check_hermitian_independent',
                [str(q), str(work / hermitian_independent)], f'hermitian_independent_q{q}.log')
        hp, hi = (read_json(work / name) for name in
                  (hermitian_primary, hermitian_independent))
        for hr in (hp, hi):
            assert hr['status'] == 'passed'
            assert hr['surviving_projective_parameters'] == q + 1
            assert hr['survivor_span_dimension'] == 2
            assert hr['equal_to_scalar_Hermitian_family']
            assert hr['rank_three_messages_checked'] == q + 1
            assert hr['zero_class_rank'] == 3
            assert hr['zero_class_bad_kernel_directions'] == {3: 2760, 4: 20060}[q]
            assert hr['terminal_visits'] == (hr['direct_disjoint_pair_visits'] + q + 1)
        a, b, c = (read_json(work / name) for name in (sections, compat, independent))
        examples, direct = (read_json(work / name)
                            for name in (sample_summary, direct_report))
        expected_universe = {3: 925771, 4: 24208613}[q]
        expected_scattered = {3: 19677, 4: 262806}[q]
        assert a['universe'] == a['scan'] == c['universe'] == c['scan'] == expected_universe
        assert a['scattered_orbits'] == c['scattered_orbits'] == expected_scattered
        for key in ('E_rank_fail', 'E_full_orbits', 'nonscattered_orbits',
                    'hermitian_orbits', 'universal_blocked', 'orbit_size_histogram'):
            assert a[key] == c[key], (q, key)
        assert a['hermitian_orbits'] == 1
        assert a['scattered_orbits'] == (a['hermitian_orbits'] + a['universal_blocked']
                                        + a['unique_linear_zero'] + a['surviving_orbits'])
        assert b['records'] == a['surviving_orbits']
        assert c['jointly_excluded'] == a['unique_linear_zero'] + b['records']
        assert b['nonempty_records'] == b['unresolved_records'] == c['surviving'] == c['unresolved'] == 0
        assert b['tested'] == b['direct_witness_checks']
        assert c['projective_parameter_visits'] == c['direct_witness_checks']
        assert (work / failed).stat().st_size == 0
        assert (work / (independent + '.failures.txt')).stat().st_size == 0
        assert examples['explicit_rank_pairs'] == 512
        assert examples['hermitian_control_rank'] == 3
        assert examples['hermitian_control_bad_kernel_directions'] == 0
        assert direct['status'] == 'passed' and direct['witness_pairs'] == 532
        weighted = sum(int(k) * v for k, v in a['orbit_size_histogram'].items())
        expected_full = ((q**8-q**2)*(q**8-q**4)*(q**8-q**6)
                         // ((q**4-q)*(q**4-q**2)*(q**4-q**3)))
        assert weighted == expected_full == expected_universe - a['E_rank_fail']
        summaries.append({'q': q, 'complete_normalized_section_universe': expected_universe,
                          'scattered_right_action_orbits': expected_scattered,
                          'explicit_Hermitian_orbits_reserved': 1,
                          'non_Hermitian_orbits_excluded': expected_scattered-1,
                          'universal_scalar_plane_exclusions': a['universal_blocked'],
                          'joint_kernel_exclusions': c['jointly_excluded'],
                          'primary_search_nodes': b['nodes'],
                          'independent_search_nodes': c['search_nodes'],
                          'primary_direct_leaf_rank_pairs': b['direct_witness_checks'],
                          'independent_direct_leaf_rank_pairs': c['direct_witness_checks'],
                          'additional_universal_examples': 512,
                          'cross_field_example_pairs': 532,
                          'remaining_non_Hermitian_graphs': 0,
                          'Hermitian_compatibility_survivor_dimension': 2,
                          'Hermitian_projective_survivors': q+1,
                          'Hermitian_remaining_target_graphs': 0,
                          'Hermitian_primary_nodes': hp['nodes'],
                          'Hermitian_independent_nodes': hi['nodes'],
                          'Hermitian_primary_rank_four_pairs': hp['direct_disjoint_pair_visits'],
                          'Hermitian_independent_rank_four_pairs': hi['direct_disjoint_pair_visits'],
                          'Hermitian_explicit_rank_three_directions': q+1})
        outputs += [residual, sections, failed, compat, compat+'.witnesses.jsonl',
                    independent, independent+'.failures.txt', samples, sample_summary,
                    direct_input, direct_report, hermitian_primary, hermitian_independent]
        print(json.dumps(summaries[-1], ensure_ascii=False), flush=True)
    compared = 0
    for name in outputs:
        if compare:
            expected = root / 'reference' / name
            actual = work / name
            if name.endswith('.json'):
                assert mathematical(read_json(expected)) == mathematical(read_json(actual)), name
            else:
                assert expected.read_bytes() == actual.read_bytes(), name
            compared += 1
    report = {'status': 'PASS_FOR_COMPLETE_Q3_Q4_SCATTERED_SPECIAL_GRAPH_THEOREM',
              'report_date': '2026-09-19', 'new_results': summaries,
              'all_new_spaces_and_graph_parameters_covered': True,
              'unresolved_new_branches': 0,
              'full_new_runs_from_delivered_source': True,
              'different_field_defining_polynomials': True,
              'different_section_coordinates_and_enumeration_order': True,
              'different_equation_space_and_kernel_space_searches': True,
              'Hermitian_orbit_reproved_by_new_complete_compatibility_check': True,
              'old_large_Hermitian_parameter_scans_replayed': False,
              'historical_heavy_section_and_global_chains_replayed': False,
              'cumulative_q3_q4_nonexistence': 'Follows upon adjoining the explicitly listed input reductions.',
              'cumulative_all_q_nonexistence': 'Follows upon additionally adjoining the uploaded q=2 and q>=5 results; this run does not re-audit that historical chain.',
              'external_mathematical_review_completed': False,
              'proof_assistant_formalization_completed': False,
              'compared_generated_files': compared,
              'manifest_files_checked': manifest_checked,
              'compiler': str(compiler), 'undefined_behavior_checks': sanitize,
              'tex': proof_structure(root),
              'elapsed_seconds': round(time.perf_counter()-start, 3)}
    (work / 'verification.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps(report, ensure_ascii=False, indent=2), flush=True)
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--work', type=Path, required=True)
    parser.add_argument('--compiler', default=None)
    parser.add_argument('--sanitize', action='store_true')
    args = parser.parse_args()
    run(Path(__file__).resolve().parent, args.work, args.compiler, args.sanitize, True)


if __name__ == '__main__':
    main()
